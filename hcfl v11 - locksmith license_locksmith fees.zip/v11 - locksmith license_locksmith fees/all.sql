
use hcfl_prod;
go

IF OBJECT_ID('tempdb.dbo.##completed', 'U') IS NOT NULL
DROP TABLE ##completed
;
create table ##completed (dt datetime, val varchar(1000))
;

--## this lets me have a folder for each record type, include truncates in those folders for work within that record type, and allows me to ignore those truncates and combine any record types together for a single conversion.
IF OBJECT_ID('tempdb.dbo.#includeTruncates', 'U') IS NOT NULL
DROP TABLE #includeTruncates
;
select 1 includeTruncates into #includeTruncates
;

go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0000\0000 0000 0000 edits.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0000\0000 0000 0000 edits.sql')
--apostraphe--officer's comments
;update R2CHCKBOX set R1_CHECKBOX_DESC = 'Officer�s Comments' where R1_CHECKBOX_DESC = 'Officer''s Comments'
;
--fieldname length
;update R2CHCKBOX set R1_CHECKBOX_DESC = 'who appeared for hearing' where R1_CHECKBOX_DESC = 'Text field for name of person who appeared for hearing'
;


go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0000\0000 0020 HistoryStagingTables-MSSQL.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0000\0000 0020 HistoryStagingTables-MSSQL.sql')
/* HistoryStagingTables-MSSQL.sql */
/* ***************************************************************************
*Purpose: This file will create SQL Server tables for data migrations      
* Version     : 3.0  Date: 03/08/2006                                                          
* Modification History
* 01/27/2007 DQ	Added Permit_Status and Permit_AttachedTable
* 04/18/2007 AW	Added columns to permit_history and removed ones regarding the project 
*			valuation 
* 			modified fee table, permit_status (added the fname, mname and lname
* 			modified  permit_people, permit_workflow and permit_insp
* 09/02/2008 BEB	Added Trust_Account_Trans table
* 10/02/2008 AW	Added  4 fields to permit_history priority, total_job_cost closed by 
*			and closed_date
*  			Added tables of permit_costing_ams, permit_calcvaluatn 
* 12/04/2008 TKS	Increase various fields to 4000.
*			(Permit_AppSpecInfo.App_Spec_Value, Permit_TaskSpec_Info.Task_Spec_Value,
*			 and Permit_AttachedTable.Attribute_Value)
*			This code will be copied into Standard History mdbs
*			and into Data Mapper mst files so that all are in-synch.
* 12/05/2008 TKS	Made Permit_Workflow.LName 25 (was 15), to match ORA script.
*************Branched to AA67 Script*****************************************
02/23/2009 DQ Updated Permit_People Added additional columns
03/17/2009 DQ Updated Permit_history Added additional columns
	         Removed code_enforcement
04/20/2009 DQ Added Permit_PeopleLicTable to sync with oracle script
04/27/2009 Added additional fields to permit_parcel subdivision, Primary parcel flag, township, range and seciton
*   04/30/2009  Added the standard tables for Assets
05/04/2009 DQ Added last of items to permit_history
05/18/2009 AW added the permit_asset table  Relates an asset to the cap
05/26/2009 DQ removed not null from insp_number
06/ 12/2009 AW added the permit_part_ams table  - relates the parts to a work order (ams module only)
07/13/2009  - AW added the ams_asset_ca, ams_asset_ca_attr and ams_asset_ca_observ
11/02/2015  EricL updated to AA 733
12/02/2015  EricL Added the field TASK_ORDER_INDEX in table PERMIT_TASK_AMS for JIRA 1150
12/17/2015  EricL Added the field B1_INTERNAL_USER_FLAG,B1_INTERNAL_USER_ID in table permit_people for AA 800(JIRA ) 1460
03/16/2016  EricL Updated the field Short_notes to 255 of table permit_history
*/
/*
******  Branch to 7.0 version 03/02/2010   ******
Permit_History 
  Modified ap_name  increased to 130
  modified const_type_code increased to 4 characters      
  Added  valuation_multiplier, valuation_extra_amt, last_audit_date 
  Add app_status_date  
PERMIT_PEOPLE
 Modified  address1 2 and 3 in permit_people  Increased to 200
 Modified the state field increased to 30 characters
 Modified  lic_type set to 255
 Added fields of social security_number and federal_employer_id_num
    Lic_board and  contra_type_flag
     B1_id 
    
PERMIT_ASSET_AMS
    Added 4 fields woasset_order, woasset_complete, woasset_complete_date, woasset_short_notes

PERMIT_ADDRESS
   Added address1, address2,Situs_nbrhd
   Modified str_num_start , str_num_end, str_suffix and situs_state
           
           Permit_fee
             Modified gf_fee_schedule
             Modified the account code fields increased to 32 
             Added fee_schedule_version
             Added fee_key
             Modified  primary key  permitnum, fee_key     
Permit_feeallocation
   added field of  fee_key
   modified primary key removed gf_cod and fee period  
permit_total
   added index on permitnum and gf_fee_period
Trust_act_people
   Modified lic_state to be 30 characters lic_type increased to 255
   Modified the addr 1 , 2 and 3 to be 200 characters
   modified  the state field to be 30 characters  


permit_peopleLicTable  
  Modified lic_type increased to  be 255
  Removed  not null from column_num 
   removed column_num from PK   
permit_insp
   modified the insp_result_comm and insp_sched_comm fields.  made them a "text" field.
   Modified the insp_number.  made it not nullabel and must be unique 
   added field of insp_seq_nBR  -- value will come from the rinsptyp.insp_seq_nBR field during data mapping 
   Added index  on insp_number.
permit_guidesheet
   Added the fields  of guide_key, score
   Modified the primary key   added guide_key to it  
Permit_workflow  added asgn_date, due_date
  NEW TABLES
permit_exam
permit_education   
permit_cont_edu
permit_condition
Permit_activity
Permit_stru_esta
permit_address_type
permit_guidesheet_asi
permit_guidesheet_asitab

***************************************************************
04/12/2010 - DQ
		-Fixed Primary Key for permit_cont_edu, added permitnum to PK


****************************************************************************/

--permit_history 

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'permit_history')
BEGIN
drop table permit_history
END
go

create table permit_history (
permitNum               varchar(30)     not null,
b1_per_group            varchar(30)     not null,
b1_per_type             varchar(30)     not null,
b1_per_sub_type         varchar(30)     not null,
b1_per_category         varchar(30)     not null,
CONTRACTOR_VALUATION    numeric(15,2)   null,
dateOpened              datetime        not null,
EXPIRATION_DATE         dateTime        null,
EXPIRATION_STATUS       varchar(30)     null,
app_status              varchar(30)     null,
Work_desc               varchar(4000)   null,
app_name                varchar(255)    null,
house_count             numeric(19)     null,       --8/18/2010  Change to 19
building_count          numeric(19)     null,		    --8/18/2010  Change to 19
public_owned            varchar(1)      null,
const_type_code         varchar(4)      null,
app_status_group_code   varchar(30)     null,
Short_notes             varchar(255)     null,  --Eric Updated 03/16/2016
asgn_dept               varchar(100)    null,
asgn_staff              varchar(50)     null,
asgn_date               datetime        null,
Completed_dept          varchar(100),
completed_by            varchar(50),
completed_date          datetime        null,
Scheduled_date          datetime        null,
priority                varchar(30)     null,
total_job_cost          numeric(15,2)   null,
closed_date             datetime, 
closed_by               varchar(50),
IVR_TRACKING_NUM        numeric(19),	--DQ Added 6.7    --8/18/2010 Increase to 19
CREATED_BY	            varchar(100),	--DQ Added 6.7
REPORTED_CHANNEL        varchar(30),	--DQ Added 6.7
CREATED_BY_DEPT         VARCHAR(100),	--DQ Added 6.7
FIRST_ISSUED_DATE        DATETIME,	    --DQ Added 6.7
ANONYMOUS_FLAG	VARCHAR(1),		--DQ ADD 05/04/2009
REFERENCE_TYPE	VARCHAR(30),	--DQ ADD 05/04/2009
APPEARANCE_DAYOFWEEK	VARCHAR(10),	--DQ ADD 05/04/2009
APPEARANCE_DATE	DATETIME,	--DQ ADD 05/04/2009
BOOKING_FLAG	VARCHAR(1),	--DQ ADD 05/04/2009
DEFENDANT_SIGNATURE_FLAG	VARCHAR(1),	--DQ ADD 05/04/2009
ENFORCE_OFFICER_ID	VARCHAR(12),	--DQ ADD 05/04/2009
ENFORCE_OFFICER_NAME	VARCHAR(70),	--DQ ADD 05/04/2009
INFRACTION_FLAG	VARCHAR(1),	--DQ ADD 05/04/2009
INSPECTOR_ID	VARCHAR(12),	--DQ ADD 05/04/2009
MISDEMEANOR_FLAG	VARCHAR(1),	--DQ ADD 05/04/2009
OFFENCE_WITNESSED_FLAG	VARCHAR(1),	--DQ ADD 05/04/2009
INSPECTOR_NAME	VARCHAR(70),	--DQ ADD 05/04/2009
ENFORCE_DEPT	VARCHAR(100),	--DQ ADD 05/04/2009
INSPECTOR_DEPT	VARCHAR(100) ,--DQ ADD 05/04/2009
VALUATION_MULTIPLIER NUMERIC(10,4) default 1.0000,   -- Added 3/3/2010 maps to bpermit_detail
VALUATION_EXTRA_AMT NUMERIC(15,4),  -- Added 3/3/2010 maps to bpermit_detail
LAST_AUDIT_DATE DATETIME,
APP_STATUS_DATE DATETIME,
DELEGATE_USER_ID		 VARCHAR(100),		  --Add by zeal on 05/16/2011
BALANCE				Numeric(15,2) default 0,
TOTAL_FEE			Numeric(15,2) default 0,
TOTAL_PAY			Numeric(15,2) default 0,
LAST_UPDATE_BY 		VARCHAR(70),
LAST_UPDATE_DATE	DATETIME
 )
go
alter table permit_history add constraint permit_history_pk
     primary key (permitnum)

Create index permit_history02 on permit_history(b1_per_group,b1_per_type, b1_per_sub_type, b1_per_category)
GO

GO

-- permit_projects 
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'permit_projects')
BEGIN
drop table permit_projects
END
go

create table permit_projects (
ParentActivityNum       varchar(30)     not null,
ChildActivityNum        varchar(30)     not null,
Relationship            varchar(30),
Status                  varchar(10)    
)
go
alter table permit_projects add constraint permit_projects_pk 
     Primary Key (parentActivityNum,ChildActivityNum)
go

go

--permit_people 
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'permit_people')
BEGIN
drop table permit_people
END
go 

-- table creation for permit_people
create table permit_people (
permitNum               varchar(30)     not null,
contact_type            varchar(255),   --8/18/2010  Increase to 255
contact_relationship    varchar(255),		--Change length to 255 from 30 by zeal on 05/16/2011
IsPrimary               varchar(1),
lic_num                 varchar(30),
lic_type                varchar(255),
name                    varchar(220),   
fname                   varchar(70),
mname                   varchar(70),
lname                   varchar(70),
bus_name                varchar(255),
addr1                   varchar(200),
addr2                   varchar(200),
addr3                   varchar(200),
city                    varchar(30),   --8/18/2010  Reduce to 30
state                   varchar(30),
zip                     varchar(10),
ph1                     varchar(40),
ph2                     varchar(40),
fax                     varchar(40),	--DQ Added 6.7
email                   varchar(80),		--Change length to 70 by zeal on 05/16/2011
comments                varchar(240),
TITLE	                VARCHAR(255),	--DQ ADD 2/23/2009 --Change length to 255 by zeal on 05/16/2011
PH3	                    VARCHAR(40),	--DQ ADD 2/23/2009 
COUNTRY_CODE	        VARCHAR(2),	    --DQ ADD 2/23/2009 
NOTIFY	                VARCHAR(1),	    --DQ ADD 2/23/2009 
NAME_SUFFIX	            VARCHAR(10),	--DQ ADD 2/23/2009 
BUS_LIC	                VARCHAR(15),	--DQ ADD 2/23/2009 
LIC_ORIGINAL_ISSUE_DATE	DATETIME,	    --DQ ADD 2/23/2009 
EXPIRATION_DATE	        DATETIME,	    --DQ ADD 2/23/2009 
RENEWAL_DATE	        DATETIME,	    --DQ ADD 2/23/2009 
MAIL_ADDR1	            VARCHAR(100),	--DQ ADD 2/23/2009 
MAIL_ADDR2	            VARCHAR(40),	--DQ ADD 2/23/2009 
MAIL_ADDR3	            VARCHAR(40),	--DQ ADD 2/23/2009 
MAIL_CITY	            VARCHAR(32),	--DQ ADD 2/23/2009 
MAIL_STATE	            VARCHAR(30),	    --DQ ADD 2/23/2009 
MAIL_ZIP	            VARCHAR(10),	--DQ ADD 2/23/2009 
MAIL_COUNTRY	        VARCHAR(30),	--DQ ADD 2/23/2009 
OWNER_TYPE	            VARCHAR(30),	--DQ ADD 2/23/2009 
GENDER		            VARCHAR(1),	    --DQ ADD 2/23/2009 
SALUTATION	            VARCHAR(255),	--DQ ADD 2/23/2009  -- Change length to 255 by zeal on 05/17/2011
PO_BOX	                VARCHAR(30),	--DQ ADD 2/23/2009 
BUS_NAME2	            VARCHAR(255),	--DQ ADD 2/23/2009 
BIRTH_DATE	            DATETIME,	    --DQ ADD 2/23/2009 
PH1_COUNTRY_CODE	    VARCHAR(3),	    --DQ ADD 2/23/2009 
PH2_COUNTRY_CODE	    VARCHAR(3),	    --DQ ADD 2/23/2009 
FAX_COUNTRY_CODE	    VARCHAR(3),	    --DQ ADD 2/23/2009 
PH3_COUNTRY_CODE	    VARCHAR(3),	    --DQ ADD 2/23/2009 
TRADE_NAME	            VARCHAR(255),	--DQ ADD 2/23/2009 
CONTACT_TYPE_FLAG VARCHAR(20),
SOCIAL_SECURITY_NUMBER VARCHAR(11),
FEDERAL_EMPLOYER_ID_NUM VARCHAR(16),
CONTRA_TYPE_FLAG VARCHAR(20),
LIC_BOARD VARCHAR(255),
b1_id varchar(15),
CONT_LIC_BUS_NAME		     VARCHAR(255),	 --Add by zeal on 05/16/2011
B1_ACCESS_LEVEL					 VARCHAR(20),		 --Add by zeal on 05/16/2011
B1_BIRTH_CITY            VARCHAR(30),    --Add by richie on 09/14/2012
B1_BIRTH_STATE           VARCHAR(30),    --Add by richie on 09/14/2012
B1_BIRTH_REGION          VARCHAR(30),    --Add by richie on 09/14/2012
B1_RACE                  VARCHAR(280),   --Add by richie on 09/14/2012
B1_DECEASED_DATE         DATETIME,       --Add by richie on 09/14/2012
B1_PASSPORT_NBR          VARCHAR(100),   --Add by richie on 09/14/2012
B1_DRIVER_LICENSE_NBR    VARCHAR(100),   --Add by richie on 09/14/2012
B1_DRIVER_LICENSE_STATE  VARCHAR(30),    --Add by richie on 09/14/2012
B1_STATE_ID_NBR          VARCHAR(100),   --Add by richie on 09/14/2012
B1_CONTACT_NBR           numeric(22) ,    --Add by richie on 09/14/2012
G1_CONTACT_NBR           numeric(22),     --Add by richie on 09/14/2012
B1_INTERNAL_USER_FLAG	 VARCHAR(1), 	--Add by Eric on 12/17/2015 For AA 800
B1_INTERNAL_USER_ID 	 VARCHAR(70),   --Add by Eric on 12/17/2015 For AA 800
LIC_STATE 				 VARCHAR(30)	--Add by Alaa on 06/16/2019
)
go
create index permit_people01 on permit_people(permitNum,contact_type,name,lic_type,lic_num)
GO
GRANT Select, Update, Insert ON permit_people  TO Public
GO

-- Permit_PeopleAttrib 
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'Permit_PeopleAttrib')
BEGIN
drop table Permit_PeopleAttrib
END
go
create table Permit_PeopleAttrib (
permitnum               varchar(30)    not null,
attrib_Key              varchar(10)    not null,
attrib_temp_name        varchar(30)    not null,
attrib_type             varchar(255)    not null,   --08/18/2010 Increase to 255
attrib_name             varchar(30)    not null,
name                    varchar(80)    not null,
attrib_value            varchar(200) not null
)
go
alter table permit_peopleattrib add constraint permit_peopleattrib_pk 
     primary key (permitnum,attrib_key,attrib_temp_name, attrib_type,attrib_name,name)

GRANT Select, Update, Insert ON permit_peopleAttrib  TO Public
go

-- permit_parcel (multiple parcels on a permit)
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'permit_parcel')
BEGIN
drop table permit_parcel
END
go

create table permit_parcel (
Permitnum              varchar(30)      not null,
ParcelNum              varchar(24)      not NULL,
Book                   varchar(8)       null,
Page                   varchar(8)       null,
Parcel                 varchar(9)       null,
Lot                    varchar(40)      null,
Block                  varchar(15)      null,
Tract                  varchar(80)      null,
Legal_desc             varchar(2000)    null,
Parcel_area            numeric(15,2)    null,
Plan_area              varchar(8)       null,
Census_tract           varchar(10)      null,
Council_district       varchar(10)      null,
Supervisor_district    varchar(10)      null,
Inspection_district    varchar(255)      null,
Land_value             numeric(15,2)    null,
Improved_value         numeric(15,2)    null,
Exempt_value           numeric(15,2)    null,
Map_reference          varchar(30),
Map_number             varchar(10),
Subdivision            varchar(240),    -- AW added 4/27
Primary_flag           varchar(1),      -- AW added 4/27
Township               varchar(10),     -- AW added 4/27
Range                  varchar(10),     -- AW added 4/27
Section                numeric(10),       -- AW added 4/27  -- 8/18/2010 Increase to 19
EXT_PARCEL_UID		   varchar(100)
)
go
alter table permit_parcel add constraint permit_parcel_pk
   primary key  (permitnum,parcelnum)
go

go
 
--table permit_address
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'permit_address')
BEGIN
drop table permit_address
END
go
create table permit_address (
permitNum               varchar(30)    not null, 
IsPrimary               varchar(1)     null,
str_num_start           int     null,			--Change to int by zeal on 05/16/2011 
str_num_end             int     null,			--Change to int by zeal on 05/16/2011 
str_frac_start          varchar(20)     null,
str_frac_end            varchar(20)     null,
str_dir                 varchar(20)     null,
str_name                varchar(40)    null,
str_suffix              varchar(30)     null,
str_suffix_dir         	varchar(20)		null,
str_prefix	         	varchar(20)		null,
str_unit_start          varchar(10)    null,
str_unit_end            varchar(10)    null,
str_unit_type           varchar(20)     null,
situs_city              varchar(40)    null,
situs_state             varchar(30)     null,
situs_zip               varchar(10)    null,
situs_county            varchar(30),
situs_country           varchar(30),
situs_country_code      varchar(2),
x_coord                 numeric(20,8),
y_coord                 numeric(20,8),
addr_desc               varchar(255),
Full_Address            varchar(600)   null,
ADDRESS1 VARCHAR(200),
ADDRESS2 VARCHAR(200),
SITUS_NBRHD VARCHAR(30),
L1_ADDRESS_NBR 			  int,     --Add by zeal on 05/16/2011
EXT_ADDRESS_UID			  varchar(100),
STREET_NAME_START		varchar(200), -- Added by OMATKARI 8/19/18
STREET_NAME_END			varchar(200), -- Added by OMATKARI 8/19/18
CROSS_STREET_NAME_START	varchar(200), -- Added by OMATKARI 8/19/18
CROSS_STREET_NAME_END	varchar(200), -- Added by OMATKARI 8/19/18
HSE_NBR_ALPHA_START	varchar(20),	-- Added By ALTARAZI 04/09/19
HSE_NBR_ALPHA_END		varchar(20),	-- Added By ALTARAZI 04/09/19
LEVEL_PREFIX		varchar(20),	-- Added By ALTARAZI 04/09/19
LEVEL_NBR_START	varchar(20),	-- Added By ALTARAZI 04/09/19
LEVEL_NBR_END 	varchar(20)		-- Added By ALTARAZI 04/09/19
)
go
 create unique index permit_address01 on permit_address(permitnum,full_address)
go
grant select, update, insert on permit_address to public
go

--table permit_attrib
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'permit_attrib')
BEGIN
drop table permit_attrib
END
go

create table permit_attrib (
permitNum               varchar(30)    not null,
attrib_type             varchar(30)    not null,
attrib_temp_name        varchar(30)    not null,
attrib_name             varchar(30)    not null,
attrib_value            varchar(200),
Attrib_Key              varchar(600) not null 
)
go
alter table permit_attrib add constraint permit_attrib_pk 
    primary key  (permitNum,attrib_type,attrib_temp_name,attrib_name,attrib_key)
go
GRANT Select, Update, Insert ON permit_attrib  TO Public
go

--table permit_comment
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'permit_comment')
BEGIN
drop table permit_comment
END
go

create table permit_comment (
permitnum               varchar(30)     not null,
comments                varchar(MAX)            not null,
AddedBy                 varchar(70),
AddedDate               datetime
)
GO
create index permit_comment01 on permit_comment(permitNum)
GO
GRANT Select, Update, Insert ON permit_comment  TO Public
GO

--table permit_appspecinfo 
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'permit_appspecinfo')
BEGIN
drop table permit_appspecinfo
END
go

create table permit_appSpecInfo (
permitnum               varchar(30)    not null,
app_spec_code           varchar(12)    not null,
app_spec_type           varchar(30)    not null,
app_spec_name           varchar(100)   not null,
app_spec_value          varchar(4000) not null
)
GO
alter table permit_appspecinfo add constraint permit_appspecinfo_pk
    primary key (permitNum,app_spec_type, app_spec_name)
create index permit_appSpecInfo02 on permit_appSpecInfo(permitNum,app_spec_code,app_spec_type, app_spec_name)
GO
create index permit_appspecinfo_idx on permit_appspecinfo(app_spec_code, app_spec_type, app_spec_name)
GO
create index permit_appspecinfo_permitnum on permit_appspecinfo(permitnum)
GO
GRANT Select, Update, Insert ON permit_appspecInfo  TO Public
GO

--table permit_workflow
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'permit_workflow')
BEGIN
drop table permit_workflow
END
go

create table permit_workflow (
permitnum               varchar(30)     not null,
task_desc               varchar(100)     not null,   --8/18/2010   Increase to 100
task_status             varchar(200)     not null,
taskUpdated             datetime        not null,
comments                varchar(4000),
Process_Code            varchar(70)     not null,
Asgn_date               datetime,
Due_date                datetime,
FNAME					varchar(70),
MNAME					varchar(70),
LNAME					varchar(70),
sd_hours_spent              numeric(5,2), 
sd_billable                 varchar(1),
sd_overtime                 varchar(1),
estimated_hours             numeric(5,2),
asgn_email_display_for_aca  varchar(1),
restrict_comment_for_aca    varchar(1),
restrict_role               varchar(10),
USER_ID			            varchar(50),
ID                          NUMERIC  DEFAULT 0,
TASK_UNIQUE_ID              VARCHAR(255)
)
GO
-- BEB removed primary key constraint from table 
-- alter table permit_workflow  add constraint permit_workflow_pk 
--      primary key (permitNum,process_code,Task_desc,task_status,taskupdated)

create index permit_workflow_permitnum on permit_workflow(permitnum)
create index permit_workflow_idx on permit_workflow(task_desc, process_code)
GO
GRANT Select, Update, Insert ON permit_workflow   TO Public
GO

-- permit_taskspecinfo
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'permit_taskspecinfo')
BEGIN
drop table permit_taskspecinfo
END
GO

create table permit_TaskSpecInfo (
permitnum               varchar(30)     not null,
task_spec_code          varchar(12)     not null,
Task_spec_type          varchar(30)     not null,
task_spec_name          varchar(100)    not null,
task_spec_value         varchar(4000)   not null,
process_code            varchar(70)     not null,
task_desc               varchar(100)     not null
)
GO
alter table permit_taskspecinfo add constraint permit_taskspecinfo_pk
      primary key (permitNum,task_spec_type, Task_spec_name,process_code,task_desc)

GO
GRANT Select, Update, Insert ON permit_taskspecInfo  TO Public
GO

-- permit_insp
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'permit_insp')
BEGIN
drop table permit_insp
END
GO

create table permit_insp (
permitnum               varchar(30)     not null,
Insp_code 			   	varchar(12),
insp_type               varchar(255)     not null,
inspDate                datetime,
inspStatus              varchar(70)     not null,
inspSchedDate           datetime,
inspReqDate             datetime,
Insp_result_group       varchar(70),
insp_number             numeric null, 
insp_required           varchar(1),
Phone_num               varchar(40),
latitude                numeric(13,10),
longitude               numeric(13,10),
insp_result_comm        varchar(MAX) ,
insp_sched_comm         varchar(MAX),
insp_seq_nbr            int null,
sd_overtime             varchar(1),      --Add by zeal on 05/16/2011
display_in_aca          varchar(1),      --Add by zeal on 05/16/2011
contact_nbr             varchar(100),     --Add by Richie on 03/07/2012
insp_result_type	   varchar(30),
user_id			varchar(50),
ORDER_BY 	NUMERIC   DEFAULT 1,
G6_ACT_T1 varchar(10),
G6_ACT_T2 varchar(10),
G6_ACT_END_T1 varchar(10),
G6_ACT_END_T2 varchar(10),
G6_ACT_TT numeric,
ESTIMATED_START_TIME varchar(10),
ESTIMATED_END_TIME varchar(10),
G6_DESI_DD datetime,
G6_DESI_TIME varchar(10),
G6_DESI_TIME2 varchar(10),
CONTACT_PHONE_NUM varchar(40),
CONTACT_PHONE_NUM_IDD varchar(3),
CONTACT_FNAME varchar(70),
CONTACT_MNAME varchar(70),
CONTACT_LNAME  varchar(70),
G6_REQ_PHONE_NUM_IDD  varchar(3),
G6_REQ_PHONE_NUM   varchar(40),
MAJOR_VIOLATION_COUNT numeric,
UNIT_NBR varchar(20),
GRADE varchar(30),
TOTAL_SCORE numeric,
VEHICLE_NUM varchar(30),
G6_MILE_T1 numeric,
G6_MILE_T2 numeric,
G6_MILE_TT numeric,
INSP_CANCELLED varchar(1) DEFAULT  'N',
INSP_PENDING varchar(1) DEFAULT 'N',
CLIENT_UNIQUE_ID VARCHAR(255)
 )

GO
create unique index permit_insp_inspnbr on  permit_insp(insp_number)
create index permit_insp_code_type on  permit_insp(insp_code, insp_type)
create index permit_insp_permitnum on  permit_insp(permitnum)
create index permit_insp_order_by on  permit_insp(order_by)
GO
GRANT Select, Update, Insert ON permit_insp   TO Public
GO

/*
  table permit_inspdistricts
*/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'permit_inspDistricts')
BEGIN
drop table permit_inspDistricts 
END
GO
Create table permit_inspDistricts (
PermitNum               varchar(30)     not null,
dist_type               varchar(1)      not null,
Dist_key                varchar(600)    not null,
Insp_district           varchar(30)     not null
)

alter table  permit_inspDistricts add constraint permit_inspDistricts_pk
     Primary key (permitnum, dist_type, dist_key,insp_district)
go

-- permit_fee
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'permit_fee')
BEGIN
drop table permit_fee
END
GO

create table permit_fee ( 
permitNum varchar(30) not null,
fee_key varchar(255) NOT NULL,
gf_cod                  varchar(15)     not null,
gf_fee_period           varchar(15)     not null,
Fee_item_amount         numeric(15,2)   not null,
gf_display              numeric         not null,
Account_Code1           varchar(200),
Account_Code2           varchar(200),
Account_Code3           varchar(200),
gf_fee_schedule         varchar(255),
rec_date                datetime		not null,
rec_ful_nam             varchar(70)     not null,
gf_des                  varchar(100)    not null,
gf_unit                 numeric(18,4),   --Modify by Richie on 03/07/2012
invoice                 varchar(1),
Fee_notes               varchar(4000),
FEE_SCHEDULE_VERSION    VARCHAR(255),
INVOICE_CUSTOMIZED_NBR  varchar(30),
gf_fee_allocation_type  varchar(30),
gf_l1_allocation        numeric(18,4),
gf_l2_allocation        numeric(18,4),
gf_l3_allocation        numeric(18,4),
VOID_FLAG				varchar(1)  default 'N',
GF_FEE_APPLY_DATE		datetime not null
)
GO
alter table permit_fee add constraint  permit_fee_pk 
     primary key  (permitnum,fee_key)


GO
GRANT Select, Update, Insert ON permit_fee TO Public
GO

/*-- permit_feeallocation */
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'permit_feeAllocation')
BEGIN
drop table permit_feeAllocation
END
go

Create table permit_FeeAllocation (
PERMITNUM VARCHAR(30) NOT NULL,
FEE_KEY VARCHAR(255) NOT NULL,
PAY_KEY VARCHAR(255) NOT NULL,
FEE_ALLOCATION NUMERIC(15,2) NOT NULL
)

alter table permit_feeAllocation add constraint permit_feeallocation_pk 
 primary key (PERMITNUM, FEE_KEY, PAY_KEY)
GRANT Select, Update, Insert ON permit_feeallocation TO Public
GO

--permit_total - Customer will not populate-to be used by conversion
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'permit_total')
BEGIN
drop table permit_total
END
GO

create table permit_total (
serv_prov_code          VARCHAR(15) NOT NULL,
b1_per_id1              VARCHAR(5)  NOT NULL,
b1_per_id2              VARCHAR(5)  NOT NULL,
b1_per_id3              VARCHAR(5)  NOT NULL,
invoice_nbr             numeric,
Invoice_due             numeric(15,2),
Amount_Paid             numeric(15,2),
Invoice_date            datetime,      
permitnum               VARCHAR(30),
invoice_customized_nbr  varchar(30) NOT NULL
CONSTRAINT PERMIT_TOTAL_PK
PRIMARY KEY ( serv_prov_code, b1_per_id1, b1_per_id2, b1_per_id3,invoice_customized_nbr )
)
GO
create index permit_total01 on permit_total(invoice_nbr)
create index permit_total02 on permit_total(serv_prov_code, b1_per_id1, b1_per_id2, b1_per_id3)
create index permit_total03 on permit_total(PERMITNUM)
create index permit_total_idx on permit_total(PERMITNUM, invoice_customized_nbr)
go

GRANT Select, Update, Insert ON permit_total  TO Public
GO

--trust_accounts 
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'trust_accounts')
BEGIN
drop table trust_accounts
END
go 

create table trust_accounts (
account_id              varchar(15)    not null,
account_balance         numeric(15,2),
ledger_accountnum       varchar(50),
acct_desc               varchar(30),
acct_status             varchar(10),
acct_overdraft          varchar(1),
acct_overdraftlimit     numeric(15,2),
threshold_amt					  numeric(15,2)		--Add by zeal on 05/16/2011
)
go
alter table trust_accounts add constraint trust_accounts_pk 
     primary key (account_id)  

GO
GRANT Select, Update, Insert ON trust_accounts  TO Public
GO

-- TRUST_ACCT_PEOPLE_LINKS
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'TRUST_ACCT_PEOPLE_LINKS')
BEGIN
drop table TRUST_ACCT_PEOPLE_LINKS
END
go 

create table TRUST_ACCT_PEOPLE_LINKS  (
account_id              varchar(15)    not null,
contact_nbr numeric(22) ,
lic_nbr varchar(30),
lic_type varchar(255),
lic_state varchar(30)
)
GO
create unique index trust_acct_people_links_uix on TRUST_ACCT_PEOPLE_LINKS(account_id, contact_nbr, lic_nbr, lic_type, lic_state)
GO

-- Trust_Account_Trans
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'trust_account_trans')
BEGIN
drop table trust_account_trans
END
go

Create table trust_account_trans (
Account_id              varchar(15)     not null,
Trans_type              varchar(70)     not null,
Trans_amount            numeric (15,2)  not null,
Trans_date              datetime        not null,
Trans_by                varchar(70),
Target_acct_id          varchar(15),
PermitNum               varchar(30)		not null,
PAY_KEY					varchar(255)    not null
)
go

alter table trust_account_trans add constraint trust_account_trans_pk
    primary key (account_id, permitnum, trans_type, trans_date, pay_key, trans_amount)
go

grant Select, Update, Insert ON trust_account_trans to public
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'permit_guidesheet')
BEGIN
drop table permit_guidesheet
END
go
create table PERMIT_GUIDESHEET (
PermitNum               varchar(30)     not null,
insp_number             numeric         not null,
guide_key               varchar(100)     not null,
Item_status             varchar(30) not null,
Comments                varchar(2000),
Score                   numeric(30),
GUIDE_TYPE              varchar(200) not null,
GUIDE_ITEM_TEXT         varchar(255) not null,
TEAM_NAME			  VARCHAR(50),
FLOOR				  VARCHAR(50),
FLOOR_UNIT		  	  VARCHAR(50),
HISTORICAL_GUIDE_TEXT VARCHAR(2000),
HISTORICAL_GUIDE_ITEM_STATUS_GROUP VARCHAR(30),
GUIDE_ITEM_STATUS_GROUP VARCHAR(30) not null 
)
go

alter table permit_guidesheet add constraint permit_guidesheet_pk  
     primary key (permitnum,insp_number, guide_key, guide_type, guide_item_text)
create index PERMIT_GUIDESHEET01 on PERMIT_GUIDESHEET (GUIDE_TYPE, GUIDE_ITEM_TEXT)
create index PERMIT_GUIDESHEET02 on PERMIT_GUIDESHEET (GUIDE_ITEM_STATUS_GROUP, Item_status)
create nonclustered index PERMIT_GUIDESHEET03 ON PERMIT_GUIDESHEET (insp_number,guide_key,GUIDE_TYPE,GUIDE_ITEM_TEXT) INCLUDE (HISTORICAL_GUIDE_TEXT)
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'PERMIT_STATUS')
BEGIN
DROP TABLE PERMIT_STATUS
END
GO
CREATE TABLE PERMIT_STATUS (
PERMITNUM               VARCHAR(30)     NOT NULL, 
STATUS                  VARCHAR(30)     NOT NULL, 
STATUS_DATE             DATETIME        NOT NULL, 
STATUS_COMMENT          VARCHAR(4000),
USER_ID			VARCHAR(50),
ORDER_BY		NUMERIC	DEFAULT 1
)
GO
CREATE INDEX PERMIT_STATUS_X01 ON PERMIT_STATUS (PERMITNUM)
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'PERMIT_ATTACHEDTABLE')
BEGIN
DROP TABLE PERMIT_ATTACHEDTABLE
END
GO
CREATE TABLE PERMIT_ATTACHEDTABLE ( 
PERMITNUM               VARCHAR(30)     NOT NULL, 
GROUP_NAME              VARCHAR(12)     NOT NULL,
TABLE_NAME              VARCHAR(30)     NOT NULL,
COLUMN_NAME             VARCHAR(100)    NOT NULL,
ROW_NUM                 NUMERIC         NOT NULL, 
ATTRIBUTE_VALUE         VARCHAR(4000)    NOT NULL
)
GO
ALTER TABLE PERMIT_ATTACHEDTABLE ADD CONSTRAINT PERMIT_ATTACHEDTABLE_PK 
    PRIMARY KEY (PERMITNUM,GROUP_NAME,TABLE_NAME,COLUMN_NAME,ROW_NUM)
GO
CREATE INDEX PERMIT_ATTACHEDTABLE_X01 ON PERMIT_ATTACHEDTABLE(PERMITNUM,GROUP_NAME,TABLE_NAME,COLUMN_NAME)
GO
-- table permit_calcvaluatn 
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'permit_calcValuatn')
BEGIN
drop table permit_calcValuatn
END
go

create table  permit_calcValuatn  (
permitNum               varchar(30)     not null,
Occ_type                varchar(60)     not null,   -- occupancy type
const_type              varchar(70)     not null,   -- construction type
Unit_Value              numeric(15,2)   not null,
AREA                    NUMERIC(19),              --  NUMBER OF  SQ ft in most cases    8/18/2010  Increase to 19
TotalValue              numeric(15,2)   not null,
Unit_type varchar(60),
Valuatn_version varchar(70)
)
go

create clustered index permit_CalcValuatn01 on permit_calcValuatn(permitnum,Occ_type,const_type)
go

--  ams specific related tables
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'PERMIT_COSTING_AMS')
BEGIN
DROP TABLE PERMIT_COSTING_AMS
END
GO

CREATE TABLE PERMIT_COSTING_AMS (
PERMITNUM               VARCHAR(30)     NOT NULL,
COST_NAME 		          VARCHAR(100)    NOT NULL, -- Leg db cost item key
COST_DATE               DATETIME        NOT NULL,
COST_TYPE               VARCHAR(70)     NOT NULL,      -- Change length to 70 by zeal on 05/16/2011
COST_ITEM               VARCHAR(100)    NOT NULL ,
COST_FIX                NUMERIC(17,4)   DEFAULT 0,
COST_FACTOR             NUMERIC(17,4)   DEFAULT 0,   --Standard Choice of 'COST_FACTOR'
COST_UNIT_COST          NUMERIC(17,4)   NOT NULL, 
COST_UNIT_TYPE          VARCHAR(10),    --Standard Choice of 'COST_UNIT_TYPE'
COST_QUANTITY           NUMERIC(17,4)   DEFAULT 0, 
cost_item_total         numeric(17,4)   null,
COST_COMMENTS           VARCHAR(2000)   NULL,
TASK_CODE 				VARCHAR(30)		NULL,
TASK_ORDER_INDEX 		NUMERIC(4) 		null,
Updated_by 						  varchar(70),		--Add by zeal on 05/17/2011
Updated_date 						DATETIME,				--Add by zeal on 05/17/2011
COST_STATUS							VARCHAR(15),	 --Add by zeal on 05/17/2011
START_TIME							VARCHAR(5),		 --Add by zeal on 05/17/2011
END_TIME								VARCHAR(5),		 --Add by zeal on 05/17/2011
RELATED_ASGN_NBR				bigint		 --Add by zeal on 05/17/2011
)
GO

CREATE CLUSTERED INDEX PERMIT_COSTING_AMS01 ON PERMIT_COSTING_AMS(PERMITNUM, COST_NAME, COST_TYPE, COST_ITEM)
/* ***** Translation Tables List ***** 

Cost Factor Translation Table / RBIZDOMAIN_VALUE / TT_COSTFACTOR 			-> 	COST_FACTOR
Cost Unit Type Translation Table / RBIZDOMAIN_VALUE / TT_COSTUNITTYPE 		-> COST_UNIT_TYPE
Cost Type Translation Table / RWO_COSTING / TT_COSTTYPE 	-> COST_TYPE/COST_ITEM 

*/
GO
/*   table for relating an asset to a work order  (cap)  */
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'permit_asset_ams')
BEGIN
Drop table permit_asset_ams
END
GO

Create table permit_asset_ams (
permitnum varchar(30) not null,
asset_id varchar(65)  NOT NULL,
asset_group varchar(30) not null,
asset_type varchar(30) not null,
WOASSET_ORDER NUMERIC(10) ,   --08/18/2010  Increase to 10
WOASSET_COMPLETE VARCHAR(1),
WOASSET_COMPLETE_DATE DATETIME,
WOASSET_SHORT_NOTES VARCHAR(2000) 
)

Create unique clustered  index permit_asset_ams01 on permit_asset_ams(permitnum, asset_id, asset_group, asset_type)
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'PERMIT_TASK_AMS')
BEGIN
DROP TABLE PERMIT_TASK_AMS
END
GO

CREATE TABLE PERMIT_TASK_AMS(
PERMITNUM			VARCHAR(30) NOT NULL,
TASK_CODE 			VARCHAR(30) NOT NULL, -- Refers to RWO_TASK.R1_TASK_CODE
TASK_DESCRIPTION  	VARCHAR(2000),
OPERATION_PROCEDURE	VARCHAR(2000),
ESTIMATE_EFFORT 	NUMERIC(15,2),
DURATION_UNIT 		VARCHAR(10), --Standard Choice of 'WO_TASK_DURATION_UNIT'
ACTUAL_EFFORT 		NUMERIC(15,2),
COMPLETE_DATE 		DATETIME,
COMPLETE_BY 		VARCHAR(70),
COMMENTS  			VARCHAR(2000),
TASK_ORDER 			NUMERIC(8) NOT NULL,
TASK_ORDER_INDEX  NUMERIC(4) NOT NULL --Eric ADD 12/05/2015
)
GO
/* ***** Translation Tables List ***** 

Duration Unit Translation Table / RBIZDOMAIN_VALUE / TT_DURATIONUNIT 	-> 	DURATION_UNIT
Task Code Translation Table / RWO_TASK / TT_AMSTASKCODE 	-> 	TASK_CODE

*/
CREATE UNIQUE INDEX PERMIT_TASK_AMS01 ON PERMIT_TASK_AMS(PERMITNUM, TASK_CODE, TASK_ORDER_INDEX)
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'permit_part_ams')
BEGIN
Drop table permit_part_ams
END
go

Create table permit_part_ams (
permitnum varchar(30) not null,
transaction_type varchar(30) not null, -- Valid values are ISSUE and VOID
transaction_date datetime not null ,
quantity numeric(17,4) not null,
Part_number varchar(50)  not null,
location_name varchar(100) not null, 
Part_bin varchar(30) , 
taxable varchar(1) ,
part_brand varchar(100),
part_description varchar(2000),
Part_type  varchar(50),
unit_of_measurement varchar(30),
unit_of_cost numeric(17,4),
comments varchar(2000) ,
last_updated_date  datetime,
last_updated_by varchar(70)
)

/* ***** Translation Tables List ***** 

Permit Transaction Type Translation Table / "ISSUE" and "VOID" / TT_PERMITTRANSACTIONTYPE 	-> 	transaction_type

*/
Create index permit_part_ams01 on permit_part_ams(permitnum)
Create index permit_part_ams02 on permit_part_ams(part_number)
Create index permit_part_ams03 on permit_part_ams(location_name)
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'PERMIT_COST_DISTRIBUTION')
BEGIN
DROP TABLE PERMIT_COST_DISTRIBUTION
END
GO

CREATE TABLE PERMIT_COST_DISTRIBUTION (
PERMITNUM 	VARCHAR(30) NOT NULL,
ASSET_ID 	VARCHAR(65) NOT NULL,
ASSET_HIST_TYPE   VARCHAR(100)    NOT NULL,   -- Historical Asset type
PART_NUMBER VARCHAR(50),
COST_NAME 		VARCHAR(100)
)
GO

CREATE INDEX PERMIT_COST_DISTRIBUTION01 ON PERMIT_COST_DISTRIBUTION(PERMITNUM, ASSET_ID, ASSET_HIST_TYPE)
GO


IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'permit_peoplelictable')
BEGIN
drop table  permit_peoplelictable
END
go

Create table  permit_peopleLicTable  (
Permitnum               varchar(30)     not null,
Lic_num                 varchar(30)     not null,
Lic_type                varchar(255)     not null,
table_name              varchar(30)     not null,
Column_name             varchar(100)    not null,
row_num                 numeric(5)      not null,
Column_num              numeric(2)      ,
table_value             varchar(4000)    not null,
INFO_ID     numeric

)
go
ALTER TABLE permit_peopleLicTable ADD CONSTRAINT permit_peopleLicTable_PK 
    PRIMARY KEY (permitnum, lic_num, lic_type, table_name, column_name, row_num)
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'PERMIT_EXAM')
BEGIN
Drop table PERMIT_EXAM
END
go
CREATE TABLE PERMIT_EXAM (
PERMITNUM VARCHAR(30) NOT NULL,
PROVIDER_NAME VARCHAR(255) NOT NULL,
EXAM_NAME VARCHAR(80) not null,
IS_REQUIRED VARCHAR(1),
EXAM_DATE DATETIME not null,
GRADING_STYLE VARCHAR(80),
FINAL_SCORE NUMERIC(15,2),
PASSING_SCORE NUMERIC(15,2),
EXAM_COMMENTS VARCHAR(2000),
ADDR1 VARCHAR(200),
ADDR2 VARCHAR(200),
ADDR3 VARCHAR(200),
CITY VARCHAR(30),
STATE VARCHAR(30),
ZIP VARCHAR(10),
PH1_COUNTRY_CODE VARCHAR(3),
PH1 VARCHAR(40),
PH2_COUNTRY_CODE VARCHAR(3),
PH2 VARCHAR(40),
FAX_COUNTRY_CODE VARCHAR(3),
FAX VARCHAR(40),
EMAIL VARCHAR(70),
B1_COUNTRY VARCHAR(30)
)
go
ALTER TABLE PERMIT_EXAM ADD CONSTRAINT PERMIT_EXAM_PK 
    PRIMARY KEY (PERMITNUM, PROVIDER_NAME, EXAM_NAME, EXAM_DATE)
GO

CREATE INDEX PERMIT_EXAM_PERNUM ON PERMIT_EXAM(PERMITNUM)
CREATE INDEX PERMIT_EXAM_PROVIDERNAME ON PERMIT_EXAM (PROVIDER_NAME)

GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'PERMIT_EDUCATION')
BEGIN
DROP TABLE PERMIT_EDUCATION
END
go
CREATE TABLE  PERMIT_EDUCATION (
PERMITNUM VARCHAR(30) NOT NULL,
PROVIDER_NAME VARCHAR(255) NOT NULL,
EDUCATION_NAME VARCHAR(80),
EDU_DEGREE VARCHAR(30),
YEAR_ATTENDED VARCHAR(60),
YEAR_GRADUATED VARCHAR(60),
EDU_COMMENTS VARCHAR(2000),   --8/18/2010   Increase to 2000
IS_REQUIRED VARCHAR(1),
ADDR1 VARCHAR(200),
ADDR2 VARCHAR(200),
ADDR3 VARCHAR(200),
CITY VARCHAR(30),
STATE VARCHAR(30),
ZIP VARCHAR(10),
PH1_COUNTRY_CODE VARCHAR(3),
PH1 VARCHAR(40),
PH2_COUNTRY_CODE VARCHAR(3),
PH2 VARCHAR(40),
FAX_COUNTRY_CODE VARCHAR(3),
FAX VARCHAR(40),
EMAIL VARCHAR(70),
B1_COUNTRY VARCHAR(30)
)
GO

CREATE INDEX PERMIT_EDU_PERNUM ON PERMIT_EDUCATION(PERMITNUM)
CREATE INDEX PERMIT_EDUCATION_PROVIDERNAME ON PERMIT_EDUCATION (PROVIDER_NAME)
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'PERMIT_CONT_EDU')
BEGIN
DROP TABLE PERMIT_CONT_EDU
END
GO


CREATE TABLE PERMIT_CONT_EDU (
PERMITNUM VARCHAR(30) NOT NULL,
PROVIDER_NAME VARCHAR(255) NOT NULL,
CONT_EDU_NAME VARCHAR(80) not null,
IS_REQUIRED VARCHAR(1),
EDU_CLASS VARCHAR(80) not null,
DATE_OF_CLASS DATETIME not null,
HOURS_COMPLETED NUMERIC(15,2),
GRADING_STYLE VARCHAR(80),
FINAL_SCORE NUMERIC(15,2),
PASSING_SCORE NUMERIC(15,2),
EDU_COMMENTS VARCHAR(2000),
ADDR1 VARCHAR(200),
ADDR2 VARCHAR(200),
ADDR3 VARCHAR(200),
CITY VARCHAR(30),
STATE VARCHAR(30),
ZIP VARCHAR(10),
PH1_COUNTRY_CODE VARCHAR(3),
PH1 VARCHAR(40),
PH2_COUNTRY_CODE VARCHAR(3),
PH2 VARCHAR(40),
FAX_COUNTRY_CODE VARCHAR(3),
FAX VARCHAR(40),
EMAIL VARCHAR(70),
B1_COUNTRY VARCHAR(30)
)
go
ALTER TABLE PERMIT_CONT_EDU ADD CONSTRAINT PERMIT_CONT_EDU_PK 
    PRIMARY KEY (PERMITNUM,PROVIDER_NAME, CONT_EDU_NAME, EDU_CLASS, DATE_OF_CLASS)
    
GO

CREATE INDEX PERMIT_CONT_EDU_PERMITNUM ON PERMIT_CONT_EDU(PERMITNUM)
CREATE INDEX PERMIT_CONT_EDU_PROVIDERNAME ON PERMIT_CONT_EDU (PROVIDER_NAME)

GO 

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'PERMIT_CONDITIONS')
BEGIN
DROP TABLE PERMIT_CONDITIONS
END
GO

CREATE TABLE PERMIT_CONDITIONS (
PERMITNUM VARCHAR(30) NOT NULL,
CON_COMMENTS VARCHAR(4000) NOT NULL,
CON_DES VARCHAR(255),
CON_IMPACT_CODE VARCHAR(8),
EFFECTIVE_DATE DATETIME,
EXPIR_DATE DATETIME,
ISS_DD DATETIME,
STAT_DD DATETIME,
CON_STATUS VARCHAR(30) NOT NULL,
CON_TYPE VARCHAR(255) NOT NULL,
DISPLAY_ORDER NUMERIC(5),
CON_INHERITABLE VARCHAR(1),
CON_GROUP       VARCHAR(255),
ISS_USER_ID	VARCHAR(50),
STAT_USER_ID	VARCHAR(50),
INC_CON_NAME VARCHAR(1),
INC_SHORT_DESC VARCHAR(1),
DIS_CON_NOTICE VARCHAR(1),
CON_STATUS_TYP VARCHAR(20),
LONG_COMMENTS VARCHAR(4000) -- Added By AALTARAZI 04/09/19
)
GO

CREATE INDEX PERMIT_CONDITIONS_PERMITNUM ON PERMIT_CONDITIONS(PERMITNUM)
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'PERMIT_ACTIVITY')
BEGIN
DROP TABLE PERMIT_ACTIVITY
END
GO

CREATE TABLE PERMIT_ACTIVITY (
PERMITNUM VARCHAR(30) NOT NULL,
ACT_NAME VARCHAR(30) not null,
ACT_DES VARCHAR(4000),
ACT_TYPE VARCHAR(255) NOT NULL,  -- VALID VALUES ARE IN STANDARD CHOICE 'ACTIVITY_TYPES' MUST VALIDATE AGAINST
ACT_DATE DATETIME NOT NULL,
ACT_DEPT VARCHAR(100),
ACT_STAF VARCHAR(50),
REC_DATE DATETIME,
REC_FUL_NAM VARCHAR(70),
INTERNAL_USE_ONLY VARCHAR(1) NOT NULL,
ACT_DUE_DATE DATETIME,
ACT_STATUS   VARCHAR(30) default 'Completed',
ACT_PRIORITY VARCHAR(30),
act_unique_id numeric  not null
)
CREATE INDEX PERMIT_ACTIVITY_PERMITNUM ON PERMIT_ACTIVITY(PERMITNUM)
GO
ALTER TABLE PERMIT_ACTIVITY ADD CONSTRAINT permitAct_PK PRIMARY KEY (PERMITNUM,act_unique_id)
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'PERMIT_ACTIVITY_ASI')
BEGIN
DROP TABLE PERMIT_ACTIVITY_ASI
END
GO
create table PERMIT_ACTIVITY_ASI
(
PERMITNUM VARCHAR(30) NOT NULL,
act_unique_id numeric not null,
asi_group_code varchar(12) not null ,
asi_sub_group  varchar(30) not null,
asi_field_label varchar(100) not null,
asi_field_value varchar(200) not null,
)
go
ALTER TABLE PERMIT_ACTIVITY_ASI ADD CONSTRAINT permitActAsi_PK PRIMARY KEY (PERMITNUM,act_unique_id, asi_sub_group , asi_field_label)
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'PERMIT_STRU_ESTA')
BEGIN
DROP TABLE PERMIT_STRU_ESTA
END
GO

CREATE  TABLE PERMIT_STRU_ESTA (
PERMITNUM VARCHAR(30) NOT NULL,
L1_NUMBER  VARCHAR(30) NOT NULL,
L1_GROUP VARCHAR(30) NOT NULL,
L1_TYPE  VARCHAR(30) NOT NULL
)
GO


CREATE UNIQUE INDEX PERMIT_STRU_ESTA_UIX ON PERMIT_STRU_ESTA(PERMITNUM, L1_NUMBER, L1_GROUP, L1_TYPE) 

go
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'PERMIT_ADDRESS_TYPE')
BEGIN
DROP TABLE PERMIT_ADDRESS_TYPE
END
GO

CREATE TABLE PERMIT_ADDRESS_TYPE (
PERMITNUM VARCHAR(30) NOT NULL,
FULL_ADDRESS VARCHAR(600),
ADDRESS_TYPE VARCHAR(30) NOT NULL
)
GO
CREATE UNIQUE INDEX PERMIT_ADDRESS_TYPE_UIX ON PERMIT_ADDRESS_TYPE(PERMITNUM, FULL_ADDRESS, ADDRESS_TYPE)
GO


IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'PERMIT_GUIDESHEET_ASI')
BEGIN
DROP TABLE PERMIT_GUIDESHEET_ASI
END
go


CREATE TABLE PERMIT_GUIDESHEET_ASI (
PERMITNUM			VARCHAR(30) NOT NULL,
INSP_NUMBER			NUMERIC NOT NULL,
GUIDE_KEY			VARCHAR(100) NOT NULL,
ASI_GROUP_CODE		VARCHAR(12) NOT NULL,
ASI_SUB_GROUP_CODE	VARCHAR(30) NOT NULL,
ASI_NAME			VARCHAR(100) NOT NULL,
ASI_VALUE			VARCHAR(4000) NOT NULL,
GUIDE_TYPE			VARCHAR(200) not null,
GUIDE_ITEM_TEXT		VARCHAR(255) not null
)
GO

CREATE UNIQUE INDEX PERMIT_GUIDESHEET_ASI_UIX ON PERMIT_GUIDESHEET_ASI(PERMITNUM, GUIDE_TYPE,GUIDE_ITEM_TEXT, INSP_NUMBER, GUIDE_KEY, ASI_SUB_GROUP_CODE,ASI_NAME)
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'PERMIT_GUIDESHEET_ASITAB')
BEGIN
DROP TABLE PERMIT_GUIDESHEET_ASITAB
END
GO

CREATE TABLE PERMIT_GUIDESHEET_ASITAB  (
PERMITNUM				VARCHAR(30) NOT NULL,
INSP_NUMBER				NUMERIC NOT NULL,
GUIDE_KEY				VARCHAR(100) NOT NULL,
ASITAB_GROUP_CODE		VARCHAR(12) NOT NULL,
ASITAB_SUB_GROUP_NAME	VARCHAR(30) NOT NULL,
ASITAB_NAME				VARCHAR(100) NOT NULL,
ASITAB_ROW_INDEX		NUMERIC NOT NULL,
ASITAB_VALUE			VARCHAR(4000) NOT NULL,
GUIDE_TYPE              VARCHAR(200) not null,
GUIDE_ITEM_TEXT         VARCHAR(255) not null
)
GO
CREATE UNIQUE INDEX PERMIT_GUIDESHEET_ASITAB_UIX ON PERMIT_GUIDESHEET_ASITAB(PERMITNUM, INSP_NUMBER, GUIDE_KEY,ASITAB_SUB_GROUP_NAME, ASITAB_NAME, ASITAB_ROW_INDEX,GUIDE_TYPE,GUIDE_ITEM_TEXT ) 
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'PERMIT_AUDIT_SETS')
BEGIN
DROP TABLE PERMIT_AUDIT_SETS
END
GO

CREATE TABLE PERMIT_AUDIT_SETS (
PERMITNUM       VARCHAR(30) NOT NULL,
SET_ID          VARCHAR(100) NOT NULL
)
GO

ALTER TABLE PERMIT_AUDIT_SETS ADD CONSTRAINT PERMIT_AUDIT_SETS_PK PRIMARY KEY (PERMITNUM, SET_ID)
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'PERMIT_TRUST')
BEGIN
DROP TABLE PERMIT_TRUST
END
GO

CREATE TABLE PERMIT_TRUST (
PERMITNUM            VARCHAR(30) NOT NULL,
TRUST_ACCOUNT_ID     VARCHAR(15) NOT NULL
)
GO

ALTER TABLE PERMIT_TRUST ADD CONSTRAINT PERMIT_TRUST_PK PRIMARY KEY (PERMITNUM, TRUST_ACCOUNT_ID)
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'permit_time_accounting')
BEGIN
Drop Table permit_time_accounting
END
GO

Create table permit_time_accounting (
    permitnum        varchar(30) not null,
    time_group_name  varchar(70) not null,
    time_type_name   varchar(70) not null,
    billable_flag    varchar(1)  not null,
    log_date         DATETIME    not null,
    time_start       DATETIME,
    time_end         DATETIME,
    time_elapsed     DATETIME not null,
    total_minutes    NUMERIC  not null,
    materials_desc   varchar(64),
    materials_cost   NUMERIC(17,4),
    Mileage_start    NUMERIC(17,4),
    Mileage_end      NUMERIC(17,4),
    Milage_total     NUMERIC(17,4),
    vehicle_id       varchar(250),
    entry_rate       NUMERIC(17,4) not null,
    entry_pct        NUMERIC(12,4) not null,
    entry_cost       NUMERIC(17,4) not null,
    created_date     DATETIME not null,
    created_by       varchar(70) not null,
    notation         varchar(250),
    group_seq_nbr    NUMERIC not null,
    entity_id        varchar(50),
    entity_type      varchar(20) constraint chk_entity_type check (entity_type in ('INSPECTION','WORKFLOW', 'N/A','RECORD')), 
    user_name        varchar(50) not null,
    Unique_Id        varchar(100),
	TIME_LOG_STATUS  VARCHAR(1) NOT NULL constraint chk_time_log_status check (TIME_LOG_STATUS in ('U','L')),
	RECORD_TYPE		 VARCHAR(3) not null constraint chk_record_type check (RECORD_TYPE in ('CAP','N/A'))
    )
GO

CREATE INDEX PERMIT_TIME_ACCOUNTING_IX ON PERMIT_TIME_ACCOUNTING(PERMITNUM, TIME_GROUP_NAME, TIME_TYPE_NAME)
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'permit_workflowAdHoc')
BEGIN
Drop Table permit_workflowAdHoc
END
GO

Create table permit_workflowAdHoc (
  permitnum              varchar(30)    not null,
  task_desc              varchar(100)   not null,
  task_status            varchar(200)    not null,
  taskUpdated            DATETIME       not null,
  Fname                  varchar(70),
  Mname                  varchar(70),
  Lname                  varchar(70),
  comments               varchar(4000),
  Process_Code           varchar(70),
  check_level1           varchar(1)     not null,
  check_level2           varchar(1)     not null, 
  G6_ASGN_DD             DATETIME,
  B1_DUE_DD              DATETIME,
  SD_DUE_DAY             NUMERIC(22),
  SD_NOTE                varchar(2000),
  sd_stp_num             NUMERIC,
  ASGN_AGENCY_CODE       varchar(8),
  ASGN_BUREAU_CODE       varchar(8),
  ASGN_DIVISION_CODE     varchar(8),
  ASGN_GROUP_CODE        varchar(8),
  ASGN_SECTION_CODE      varchar(8),
  ASGN_OFFICE_CODE       varchar(8),
  ASGN_FNAME             varchar(70),
  ASGN_MNAME             varchar(70),
  ASGN_LNAME             varchar(70)
)
GO

CREATE INDEX PERMIT_WORKFLOWADHOC_IX ON PERMIT_WORKFLOWADHOC(PERMITNUM, TASK_DESC, TASKUPDATED, SD_STP_NUM)
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'permit_TaskSpecInfoAdHoc')
BEGIN
Drop Table permit_TaskSpecInfoAdHoc
END
GO

create table permit_TaskSpecInfoAdHoc (
permitnum              varchar(30)    not null,
task_spec_code         varchar(12)    not null,
Task_spec_type         varchar(30)    not null,
task_spec_name         varchar(100)   not null,
task_spec_value        varchar(240)   not null,
process_code           varchar(70)    not null,
task_desc              varchar(70)    not null,
sd_stp_num             NUMERIC
)
GO

CREATE UNIQUE INDEX  PERMIT_TASKSPECINFOADHOC01 ON PERMIT_TASKSPECINFOADHOC(TASK_SPEC_TYPE, TASK_SPEC_NAME, PROCESS_CODE, TASK_DESC, SD_STP_NUM)
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'pos_transaction')
BEGIN
drop table pos_transaction
END
go

create table pos_transaction 
( 
	tran_key       int         not null, -- Loaded it to f4pos_transaction.batch_transaction_nbr
	module_name    varchar(15) not null,
	pos_trans_type varchar(30) not null
)
go

alter table pos_transaction add constraint pos_transaction_pk primary key (tran_key)
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'pos_trans_fee')
BEGIN
drop table pos_trans_fee
END
go

create table pos_trans_fee ( 
	tran_key                int            not null, 
	fee_key                 varchar(255)   not null,
	gf_cod                  varchar(15)    not null,
	gf_des                  varchar(100)   not null,
	gf_unit                 numeric(18,4),
	gf_fee                  numeric(15,2),
	gf_fee_apply_date       datetime,
	gf_sub_group            varchar(40),
	gf_fee_schedule         varchar(255),
	gf_fee_schedule_version varchar(255),
	fee_notes               varchar(4000)
)

alter table pos_trans_fee add constraint pos_trans_fee_pk primary key (tran_key, fee_key)
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'pos_trans_pay')
BEGIN
drop table pos_trans_pay
END
go

create table pos_trans_pay (
	tran_key                int            not null,
	pay_key                 varchar(255)   not null,
	payment_status          varchar(30)    not null,
	payment_amount          numeric(15,2)  not null,
	payment_date            datetime       not null,
	cashier_id              varchar(70)    not null,
	payment_method          varchar(30),
	payment_ref_nbr         varchar(70),
	payee                   varchar(600),
	payee_address           varchar(240),
	payee_phone             varchar(240),
	cc_auth_code            varchar(30),
	payment_comment         varchar(2000),
	HIST_RECEIPT_NBR        VARCHAR(75)    NOT NULL,
	register_nbr            varchar(8),
	VOID_DATE               DATETIME,
	VOID_BY                 VARCHAR(70) 
)
go

alter table pos_trans_pay add constraint pos_trans_pay_pk primary key (tran_key, pay_key)
go

/*--refer_people*/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'REFER_PEOPLE')
BEGIN
DROP TABLE REFER_PEOPLE
END
GO

CREATE TABLE REFER_PEOPLE  
(CONTACT_NBR            numeric(22)  NOT NULL,
CONTACT_TYPE            VARCHAR(255) NOT NULL,
TITLE                   VARCHAR(255),
FNAME                   VARCHAR(70),
MNAME                   VARCHAR(70),
LNAME                   VARCHAR(70),
NAME_SUFFIX	            VARCHAR(10),
FULL_NAME               VARCHAR(220),	
BUS_NAME                VARCHAR(255),
ADDR1                   VARCHAR(200),
ADDR2                   VARCHAR(200),
ADDR3                   VARCHAR(200),
CITY                    VARCHAR(30),
STATE                   VARCHAR(30),
ZIP                     VARCHAR(10),
COUNTRY                 VARCHAR(30),
PH1                     VARCHAR(40),
PH2                     VARCHAR(40),
FAX                     VARCHAR(40),
EMAIL                   VARCHAR(80),
G1_ID                   VARCHAR(15),
G1_FLAG                 VARCHAR(1),
COMMENTS                VARCHAR(240),
RELATION                VARCHAR(255),
G1_PREFERRED_CHANNEL    numeric(2),
COUNTRY_CODE	          VARCHAR(2),
GA_IVR_PIN              numeric(10),
PH3	                    VARCHAR(40),	
SALUTATION              VARCHAR(255),
GENDER                  VARCHAR(1),	
POST_OFFICE_BOX         VARCHAR(30),	
BIRTH_DATE              datetime,	
PH1_COUNTRY_CODE        VARCHAR(3),	
PH2_COUNTRY_CODE        VARCHAR(3),	
PH3_COUNTRY_CODE        VARCHAR(3),	
FAX_COUNTRY_CODE	      VARCHAR(3),
SOCIAL_SECURITY_number  VARCHAR(11),
FEDERAL_EMPLOYER_ID_NUM VARCHAR(16),
TRADE_NAME	            VARCHAR(255),	
CONTACT_TYPE_FLAG       VARCHAR(20),
BUSINESS_NAME2          VARCHAR(255),
BIRTH_CITY              VARCHAR(30),
BIRTH_STATE             VARCHAR(30),
BIRTH_REGION            VARCHAR(30),
G1_RACE                 VARCHAR(280),
DECEASED_DATE           datetime,
PASSPORT_NBR            VARCHAR(100),
DRIVER_LICENSE_NBR      VARCHAR(100),
DRIVER_LICENSE_STATE	  VARCHAR(30),
STATE_ID_NBR            VARCHAR(100)
)
GO

create unique index refer_people_pk on refer_people(contact_nbr,contact_type)
GO 

CREATE INDEX REFER_PEOPLE02 ON REFER_PEOPLE(CONTACT_NBR,CONTACT_TYPE,FULL_NAME)
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'REFER_PEOPLECONDIT')
BEGIN
DROP TABLE REFER_PEOPLECONDIT
END
GO

CREATE TABLE REFER_PEOPLECONDIT
(
  ENTITY_TYPE               VARCHAR(50) NOT NULL,
  ENTITY_ID                 VARCHAR(30) NOT NULL,
  L1_CON_NBR                NUMERIC(22) NOT NULL,
  CON_COMMENT               VARCHAR(4000),
  CON_DES                   VARCHAR(255),
  CON_EFF_DD1               datetime,
  CON_EXPIR_DD              datetime,
  CON_IMPACT_CODE           VARCHAR(8),
  CON_REF_NUM1              VARCHAR(20),
  CON_REF_NUM2              VARCHAR(20),
  CON_STATUS                VARCHAR(30),
  CON_TYP                   VARCHAR(255),
  CON_LONG_COMMENT          VARCHAR(4000),
  CON_DIS_CON_NOTICE        VARCHAR(1),
  CON_INC_CON_NAME          VARCHAR(1),
  CON_INC_SHORT_DESC        VARCHAR(1),
  CON_INHERITABLE           VARCHAR(1),
  CON_STATUS_TYP            VARCHAR(20),
  CON_GROUP                 VARCHAR(255),
  CON_DIS_NOTICE_ACA        VARCHAR(1),
  CON_DIS_NOTICE_ACA_FEE    VARCHAR(1),
  R3_CON_RESOLUTION_ACTION  VARCHAR(4000),     --maps to rcoa_detail
  R3_CON_PUBLIC_DIS_MESSAGE VARCHAR(2000),     --maps to rcoa_detail
  PRIORITY                  NUMERIC(5),        --maps to rcoa_detail
  ADDITIONAL_INFORMATION    varchar(MAX)               --maps to rcoa_detail
)
GO

CREATE INDEX REFER_PEOPLECONDIT_IX ON REFER_PEOPLECONDIT (ENTITY_TYPE, ENTITY_ID,L1_CON_NBR)
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'REFER_PEOPLEADDR')
BEGIN
DROP TABLE REFER_PEOPLEADDR
END
GO

CREATE TABLE REFER_PEOPLEADDR
( 
  ENTITY_TYPE        VARCHAR(15) NOT NULL,
  ENTITY_ID          numeric(22) NOT NULL,
  ADDRESS_TYPE       VARCHAR(255),
  EFF_DATE           datetime,
  EXPR_DATE          datetime,
  RECIPIENT          VARCHAR(220),
  FULL_ADDRESS       VARCHAR(1024),
  ADDRESS1           VARCHAR(200),
  ADDRESS2           VARCHAR(200),
  ADDRESS3           VARCHAR(200),
  HSE_NBR_START      numeric(9),
  HSE_NBR_END        numeric(9),
  STR_DIR            VARCHAR(20),
  STR_PREFIX         VARCHAR(20),
  STR_NAME           VARCHAR(40),
  STR_SUFFIX         VARCHAR(30),
  UNIT_TYPE          VARCHAR(20),
  UNIT_START         VARCHAR(10),
  UNIT_END           VARCHAR(10),
  STR_SUFFIX_DIR     VARCHAR(20),
  COUNTRY_CODE       VARCHAR(2),
  CITY               VARCHAR(32),
  STATE              VARCHAR(30),
  ZIP                VARCHAR(10),
  PHONE              VARCHAR(40),
  PHONE_COUNTRY_CODE VARCHAR(3),
  FAX                VARCHAR(40),
  FAX_COUNTRY_CODE   VARCHAR(3),
HSE_NBR_ALPHA_START     VARCHAR(20),
HSE_NBR_ALPHA_END       VARCHAR(20),
LEVEL_PREFIX            VARCHAR(20),
LEVEL_NBR_START         VARCHAR(20),
LEVEL_NBR_END           VARCHAR(20),
VALIDATE_ADDR_FLAG      VARCHAR(1),
PRIMARY_ADDR_FLAG		VARCHAR(1)
)
GO

CREATE INDEX REFER_PEOPLEADDR_IX ON REFER_PEOPLEADDR (ENTITY_TYPE, ENTITY_ID)
GO


/**** Standard tables for Assets  *****/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AMS_MASTER')
BEGIN
DROP TABLE AMS_MASTER
END
GO

CREATE TABLE AMS_MASTER (
ASSET_ID                VARCHAR(65) NOT NULL,
ASSET_HIST_TYPE         VARCHAR(100)    NOT NULL,   -- Historical Asset type
ASSET_GROUP             VARCHAR(30) NOT NULL, -- Refers to RASSET_TYPE.R1_ASSET_GROUP
ASSET_TYPE              VARCHAR(30) NOT NULL, -- Refers to RASSET_TYPE.R1_ASSET_TYPE
CLASS_TYPE							VARCHAR(30) NOT NULL, -- Refers to RASSET_TYPE.R1_CLASS_TYPE
ASSET_DESC              VARCHAR(255),
ASSET_STATUS            VARCHAR(30) DEFAULT  'Active', -- Standard Choice of 'ASSET_STATUS'
ASSET_STATUS_DATE       DATETIME,
ASSET_COMMENTS          VARCHAR(2000),
START_VALUE             NUMERIC(17,4), -- INITIAL VALUE OF ASSET
DATE_OF_SERVICE         DATETIME,
USEFUL_LIFE             NUMERIC(15,2),
SALVAGE_VALUE           NUMERIC(17,4),
CURRENT_VALUE           NUMERIC(17,4),
DEPRECIATION_START_DATE DATETIME,
DEPRECIATION_END_DATE   DATETIME,
DEPRECIATION_AMOUNT     NUMERIC(17,4),
DEPRECIATION_VALUE      NUMERIC(17,4),
ASSET_START_ID          VARCHAR(30),
ASSET_END_ID            VARCHAR(30),
DEPENDENCIES_FLAG       VARCHAR(1),
ASSET_SIZE              NUMERIC(15,2),
ASSET_SIZE_UNIT         VARCHAR(30),  -- Standard Choice of 'ASSET_SIZE_UNIT'    %%%%%%%%%%%%%%%
RES_ID					NUMERIC,
G1_ASSET_NAME			VARCHAR(50)
) 
GO


/* ***** Translation Tables List ***** 

ASSET Status Translation Table
ASSET Type Translation Table
Asset Size Unit Translation Table

*/
--ALTER TABLE AMS_MASTER ADD CONSTRAINT AMS_MASTER_PK PRIMARY KEY (ASSET_ID, ASSET_HIST_TYPE, ASSET_GROUP, ASSET_TYPE)
ALTER TABLE AMS_MASTER ADD CONSTRAINT AMS_MASTER_PK PRIMARY KEY (ASSET_ID,  ASSET_GROUP, ASSET_TYPE)
CREATE UNIQUE INDEX AMS_MASTER_TABLE_UIX ON AMS_MASTER(ASSET_ID, ASSET_HIST_TYPE)

GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AMS_ATTRIBUTE')
BEGIN
DROP TABLE AMS_ATTRIBUTE
END
GO

CREATE TABLE AMS_ATTRIBUTE(
ASSET_ID                VARCHAR(65)     NOT NULL,
ASSET_HIST_TYPE         VARCHAR(100)    NOT NULL,   -- Historical Asset type
ASSET_ATTRIB_TEMP_NAME  VARCHAR(30)     NOT NULL,
ASSET_ATTRIB_NAME       VARCHAR(30)     NOT NULL,
ASSET_ATTRIB_VALUE      VARCHAR(2000),
IS_HIDDEN				VARCHAR(1)
)
GO

/* ***** Translation Tables List ***** 
Asset Attribute Translation Table
*/

ALTER TABLE AMS_ATTRIBUTE ADD CONSTRAINT AMS_ATTRIBUTE_PK PRIMARY KEY (ASSET_ID, ASSET_HIST_TYPE, ASSET_ATTRIB_NAME)
CREATE UNIQUE INDEX AMS_ATTRIBUTE_TABLE_UIX ON AMS_ATTRIBUTE(asset_id, asset_hist_type)

GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AMS_ATTRIBUTE_TABLE')
BEGIN
DROP TABLE AMS_ATTRIBUTE_TABLE
END
GO

CREATE TABLE AMS_ATTRIBUTE_TABLE(
ASSET_ID                VARCHAR(65)   NOT NULL,
ASSET_HIST_TYPE         VARCHAR(100)  NOT NULL,   -- Historical Asset type
ASSET_ATTRIB_TAB_NAME 	VARCHAR(30)   NOT NULL,
ASSET_ATTRIB_NAME       VARCHAR(30)   NOT NULL,
ATTRIB_ROW_INDEX		    NUMERIC(5)    NOT NULL, 
ASSET_ATTRIB_VALUE      VARCHAR(2000)
)
GO

/* ***** Translation Tables List ***** 

Asset Attribute Table Translation Table

*/
CREATE UNIQUE INDEX AMS_ATTRIBUTE_TABLE_UIX ON AMS_ATTRIBUTE_TABLE(ASSET_ID, ASSET_HIST_TYPE ,ASSET_ATTRIB_TAB_NAME, ASSET_ATTRIB_NAME, ATTRIB_ROW_INDEX)
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AMS_ASSET_LOCATION')
BEGIN
DROP TABLE AMS_ASSET_LOCATION
END
GO

CREATE TABLE AMS_ASSET_LOCATION (
ASSET_ID 		 VARCHAR(65) NOT NULL, 
ASSET_HIST_TYPE         VARCHAR(100)    NOT NULL,   -- Historical Asset type
ISPRIMARY 	 VARCHAR(1),
STR_NUM_START 	NUMERIC(22),
STR_NUM_END 	NUMERIC(22),
STR_FRAC_START 	VARCHAR(4),
STR_FRAC_END 	VARCHAR(3),
STR_DIR 		VARCHAR(2),
STR_NAME 		VARCHAR(40) NOT NULL,
STR_SUFFIX 		VARCHAR(30),
STR_PREFIX 		VARCHAR(6),
STR_SUFFIX_DIR 	VARCHAR(5),
STR_UNIT_START 	VARCHAR(10),
STR_UNIT_END 	VARCHAR(10),
STR_UNIT_TYPE 	VARCHAR(6),
SITUS_CITY 		VARCHAR(32),
SITUS_STATE 	VARCHAR(30),
SITUS_ZIP 		VARCHAR(10),
ADDRESS1 		VARCHAR(200),
ADDRESS2 		VARCHAR(200),
EXT_UID   		VARCHAR(100)
)
GO

CREATE INDEX AMS_ASSET_LOCATION_01 ON AMS_ASSET_LOCATION (ASSET_ID,ASSET_HIST_TYPE)
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AMS_ASSET_PART')
BEGIN
DROP TABLE AMS_ASSET_PART
END
GO

CREATE TABLE AMS_ASSET_PART (
ASSET_ID     VARCHAR(65)    NOT NULL,
ASSET_HIST_TYPE         VARCHAR(100)    NOT NULL,   -- Historical Asset type
PART_NUMBER  VARCHAR(50)    NOT NULL,
QUANTITY     NUMERIC(15,2),
COMMENTS     VARCHAR(4000)
)
GO

CREATE UNIQUE INDEX AMS_ASSET_PART01 ON AMS_ASSET_PART(ASSET_ID,ASSET_HIST_TYPE, PART_NUMBER)
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AMS_ASSET_CONDITION')
BEGIN
DROP TABLE AMS_ASSET_CONDITION
END
GO

CREATE TABLE AMS_ASSET_CONDITION(
ASSET_ID  			VARCHAR(65) NOT NULL,
ASSET_HIST_TYPE         VARCHAR(100)    NOT NULL,   -- Historical Asset type
CON_COMMENTS 		VARCHAR(4000),   --IIRA 1151. Updated By Eric Liu to support 733, 11/27/2015 extend to 4000
CON_DES 			VARCHAR(255),
CON_IMPACT_CODE 	VARCHAR(8),
EFFECTIVE_DATE 		DATETIME,
EXPIR_DATE 			DATETIME,
ISS_AGENCY_CODE 	VARCHAR(8),
ISS_BUREAU_CODE 	VARCHAR(8),
ISS_DIVISION_CODE 	VARCHAR(8),
ISS_SECTION_CODE 	VARCHAR(8),
ISS_GROUP_CODE 		VARCHAR(8),
ISS_OFFICE_CODE 	VARCHAR(8),
ISS_DD 				DATETIME,
ISS_FNAME 			VARCHAR(70),  --IIRA 1151. Updated By Eric Liu to support 733, 11/27/2015 extend to 70
ISS_MNAME 			VARCHAR(70),  --IIRA 1151. Updated By Eric Liu to support 733, 11/27/2015 extend to 70
ISS_LNAME 			VARCHAR(70),  --IIRA 1151. Updated By Eric Liu to support 733, 11/27/2015 extend to 70
STAT_AGENCY_CODE 	VARCHAR(8),
STAT_BUREAU_CODE 	VARCHAR(8),
STAT_DIVISION_CODE 	VARCHAR(8),
STAT_SECTION_CODE 	VARCHAR(8),
STAT_GROUP_CODE 	VARCHAR(8),
STAT_OFFICE_CODE 	VARCHAR(8),
STAT_DD 			DATETIME,
STAT_FNAME 			VARCHAR(70),  --IIRA 1151. Updated By Eric Liu to support 733, 11/27/2015 extend to 70
STAT_MNAME 			VARCHAR(70),  --IIRA 1151. Updated By Eric Liu to support 733, 11/27/2015 extend to 70
STAT_LNAME 			VARCHAR(70),  --IIRA 1151. Updated By Eric Liu to support 733, 11/27/2015 extend to 70
CON_STATUS 			VARCHAR(30) NOT NULL,
CON_TYPE 			VARCHAR(255) NOT NULL,
CON_INHERITABLE 	VARCHAR(1)
)
GO
/* ***** Translation Tables List ***** 

Asset Condition Type Translation Table / RBIZDOMAIN_VALUE / TT_ASSETCONDTYPE 	-> 	CON_TYPE -- Standard Choice of 'CONDITION TYPE'
Asset Condition Status Translation Table / RBIZDOMAIN_VALUE / TT_ASSETCONDSTATUS 	-> 	CON_STATUS  -- Standard Choice of 'CONDITION STATUS'
Asset Condition Severity Translation Table / Options: Required/Notice/Lock/Hold / TT_ASSETCONDSEVERITY 	-> 	CON_IMPACT_CODE

*/
CREATE INDEX AMS_ASSET_CONDITION01 ON AMS_ASSET_CONDITION(ASSET_ID,ASSET_HIST_TYPE)
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AMS_XASSET_CONTACT')
BEGIN
DROP TABLE AMS_XASSET_CONTACT
END
GO

CREATE TABLE AMS_XASSET_CONTACT (
ASSET_ID                VARCHAR(65)  NOT NULL,
ASSET_HIST_TYPE         VARCHAR(100)    NOT NULL,   -- Historical Asset type
CONTACT_TYPE            VARCHAR(255) NOT NULL, -- Standard Choice of 'CONTACT TYPE'
PRIMARY_CONTACT_FLG     VARCHAR(1), -- Valid Entries are "Y", "N"
TITLE                   VARCHAR(10),
FNAME                   VARCHAR(15),
MNAME                   VARCHAR(15),
LNAME                   VARCHAR(35),
NAME_SUFFIX             VARCHAR(10),
FULL_NAME               VARCHAR(80),
BUSINESS_NAME           VARCHAR(65),
ADDRESS1                VARCHAR(200),
ADDRESS2                VARCHAR(200),
ADDRESS3                VARCHAR(200),
CITY                    VARCHAR(30),
STATE                   VARCHAR(30), 
ZIP                     VARCHAR(10),
COUNTRY                 VARCHAR(30),
PHONE1                  VARCHAR(40),
PHONE2                  VARCHAR(40),
FAX                     VARCHAR(40),
EMAIL                   VARCHAR(80)
)
GO
/* ***** Translation Tables List ***** 

Asset Contact Type Translation Table / RBIZDOMAIN_VALUE / TT_ASSETCONTACTTYPE 	-> 	CONTACT_TYPE -- Standard Choice of 'CONTACT TYPE'

*/
CREATE INDEX AMS_XASSET_CONTACT_01 ON AMS_XASSET_CONTACT(ASSET_ID, ASSET_HIST_TYPE , CONTACT_TYPE)
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AMS_ASSET_ASSET')
BEGIN
DROP TABLE AMS_ASSET_ASSET
END
GO

CREATE TABLE AMS_ASSET_ASSET(
PARENT_ASSET_ID         VARCHAR(65)     NOT NULL,
PARENT_ASSET_HIST_TYPE  VARCHAR(100)    NOT NULL,   -- Historical Asset type
CHILD_ASSET_ID          VARCHAR(65)     NOT NULL,
CHILD_ASSET_HIST_TYPE   VARCHAR(100)    NOT NULL   -- Historical Asset type
)
GO

ALTER TABLE AMS_ASSET_ASSET ADD CONSTRAINT AMS_ASSET_ASSET_PK  PRIMARY KEY (PARENT_ASSET_ID, PARENT_ASSET_HIST_TYPE, CHILD_ASSET_ID, CHILD_ASSET_HIST_TYPE )
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AMS_ASSET_USAGE')
BEGIN
DROP TABLE AMS_ASSET_USAGE
END
GO

CREATE TABLE AMS_ASSET_USAGE(
ASSET_ID 		VARCHAR(65) NOT NULL,
ASSET_HIST_TYPE         VARCHAR(100)    NOT NULL,   -- Historical Asset type
PERMITNUM 		VARCHAR(30) NOT NULL,
READ_ORDER 		NUMERIC, -- Use to calculate reading difference
USAGE_READING 	NUMERIC(17,4) NOT NULL,
UNIT_TYPE 		VARCHAR(30) NOT NULL,      --Refers to RASSET_UNIT_TYPE.R1_UNIT_TYPE_NAME
READING_DATE 	DATETIME,
AGENCY_CODE 	VARCHAR(8),
BUREAU_CODE 	VARCHAR(8),
DIVISION_CODE 	VARCHAR(8),
GROUP_CODE 		VARCHAR(8),
SECTION_CODE 	VARCHAR(8),
OFFICE_CODE 	VARCHAR(8),
READER_FNAME 	VARCHAR(70),-- JIRA 1151 Updated By Eric Liu to support 733, 11/27/2015 extend to 70
READER_MNAME 	VARCHAR(70),--JIRA 1151 Updated By Eric Liu to support 733, 11/27/2015 extend to 70
READER_LNAME 	VARCHAR(70),--JIRA 1151 Updated By Eric Liu to support 733, 11/27/2015 extend to 70
COMMENTS 		VARCHAR(2000)
)
GO
/* ***** Translation Tables List ***** 
Asset Usage Unit Type Translation Table / RASSET_UNIT_TYPE / TT_USAGEUNITTYPE 			-> 	UNIT_TYPE
*/
CREATE INDEX AMS_ASSET_USAGE01 ON AMS_ASSET_USAGE(ASSET_ID, ASSET_HIST_TYPE, PERMITNUM) 
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AMS_ASSET_RATING')
BEGIN
DROP TABLE AMS_ASSET_RATING
END
GO

CREATE TABLE AMS_ASSET_RATING (
CA_ID				VARCHAR(50),  -- When Null for Asset, else for Asset CA 
ASSET_ID			VARCHAR(65) NOT NULL,
ASSET_HIST_TYPE         VARCHAR(100)    NOT NULL,   -- Historical Asset type
RATING_TYPE			VARCHAR(60) NOT NULL, -- Refers to RRATING_TYPE.RATING_TYPE
RATING_VALUE		NUMERIC(7,2) NOT NULL,
RATING_CALC_TYPE	VARCHAR(30) NOT NULL, -- Valid entries are 'Manual','Calc'
INSP_FNAME			VARCHAR(70),  -- JIRA 1151.Updated By Eric Liu to support 733, 11/27/2015 extend to 70
INSP_MNAME			VARCHAR(70),--JIRA 1151.Updated By Eric Liu to support 733, 11/27/2015 extend to 70
INSP_LNAME			VARCHAR(70),--JIRA 1151.Updated By Eric Liu to support 733, 11/27/2015 extend to 70
AGENCY_CODE			VARCHAR(8),
BUREAU_CODE			VARCHAR(8),
DIVISION_CODE		VARCHAR(8),
SECTION_CODE		VARCHAR(8),
GROUP_CODE			VARCHAR(8),
OFFICE_CODE			VARCHAR(8),
RATING_DATE			DATETIME
)
GO
/* ***** Translation Tables List ***** 
Asset Rating Type Translation Table / RRATING_TYPE / TT_RATINGTYPE 			-> 	RATING_TYPE
*/
CREATE INDEX AMS_ASSET_RATING01 ON AMS_ASSET_RATING(CA_ID, ASSET_ID,ASSET_HIST_TYPE , RATING_TYPE)
GO


/* ***** STANDARD TABLES FOR PARTS ***** */
     -- Master table for parts  AA table is rpart_inventory
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AMS_PART_INVENTORY')
BEGIN
DROP TABLE AMS_PART_INVENTORY
END
GO

CREATE TABLE AMS_PART_INVENTORY ( 
PART_NUMBER             VARCHAR(50)     NOT NULL,
PART_TYPE               VARCHAR(50), -- Standard Choice of 'PART_TYPE'
PART_BRAND              VARCHAR(30), 
PART_DESCRIPTION        VARCHAR(2000),
PART_STATUS             VARCHAR(15)     DEFAULT 'Active', -- Standard Choice of 'PART_STATUS'
COMMENTS                VARCHAR(2000),
CALCULATE_TYPE          VARCHAR(30)     DEFAULT 'Simple', -- Standard Choice of 'PART_CALCULATE_TYPE'
MAX_QTY                 NUMERIC(17,4)   DEFAULT 0, 
MIN_QTY                 NUMERIC(17,4)   DEFAULT 0, 
REORDER_DUE             VARCHAR(1)      DEFAULT 'N',
REORDER_QTY             NUMERIC(17,4)   DEFAULT 0, 
TAXABLE                 VARCHAR(1)      DEFAULT 'N', -- Valid entries are 'Y' OR 'N'
TOTAL_SUPPLY            NUMERIC(17,4)   DEFAULT 0, 
UNIT_OF_COST            NUMERIC(17,4),
UNIT_OF_MEASUREMENT     VARCHAR(30)     DEFAULT 'Each',-- Standard Choice of 'PART_UNIT_OF_MEASURE'
ACCOUNT_NAME			VARCHAR(280),   --IIRA 1151. added By Eric Liu to support 733, 11/27/2015 
ACCOUNT_NUMBER			VARCHAR(1024)   --IIRA 1151. added By Eric Liu to support 733, 11/27/2015 
)

GO
/* ***** Translation Tables List ***** 

Part Type Translation Table / RBIZDOMAIN_VALUE / TT_PARTTYPE 		 
	-> 	PART_TYPE
Part Status Translation Table / RBIZDOMAIN_VALUE / TT_PARTSTATUS 		-> PART_STATUS
Part Calc Type Translation Table / RBIZDOMAIN_VALUE / TT_PARTCALCTYPE 		->	CALCULATE_TYPE
Part Unit of Measurement Translation Table / RBIZDOMAIN_VALUE / TT_PARTUOFM 		->	UNIT_OF_MEASUREMENT

*/
CREATE UNIQUE INDEX AMS_PART_INVENTORY01 ON AMS_PART_INVENTORY(PART_NUMBER)
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AMS_PART_TRANSACTION')
BEGIN
DROP TABLE AMS_PART_TRANSACTION
END
GO

CREATE TABLE AMS_PART_TRANSACTION(
TRANSACTION_TYPE	VARCHAR(30) NOT NULL, -- Valid entries are: "ISSUE","RECEIVE","TRANSFER","ADJUST","RESERVE" 
TRANSACTION_DATE	DATETIME NOT NULL ,
QUANTITY 			NUMERIC(17,4) NOT NULL,
PART_NUMBER 		VARCHAR(50) NOT NULL, -- Refers to RPART_INVENTORY.PART_NUMBER
LOCATION_NAME 		VARCHAR(100) NOT NULL, -- For transfer tansaction, refers to RPART_LOCATION.LOCATION_NAME
TO_LOCATION_NAME	VARCHAR(100), -- Refers to RPART_LOCATION.LOCATION_NAME, required for "TRANSFER"
UNIT_COST 			NUMERIC(17,4),
PART_BIN 			VARCHAR(30), 
COMMENTS 			VARCHAR(2000),
HARD_RESERV_FLAG	VARCHAR(1), -- Valid entries are "Y", "N"
last_updated_date  datetime,
last_updated_by varchar(70)
)
GO
/* ***** Translation Tables List ***** 

Ams Transaction Type Translation Table / "ISSUE","RECEIVE","TRANSFER","ADJUST","RESERVE"  / TT_AMSTRANSACTIONTYPE 			-> 	TRANSACTION_TYPE

*/
CREATE INDEX AMS_PART_TRANSACTION01 ON AMS_PART_TRANSACTION(PART_NUMBER)
CREATE INDEX AMS_PART_TRANSACTION02 ON AMS_PART_TRANSACTION(LOCATION_NAME)
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AMS_XPART_CONTACT')
BEGIN
DROP TABLE AMS_XPART_CONTACT
END
GO

CREATE TABLE AMS_XPART_CONTACT(
PART_NUMBER       VARCHAR(20) NOT NULL, -- Refers to RPART_INVENTORY.PART_NUMBER
BUSINESS_NAME     VARCHAR(80) NOT NULL, -- Refers to RPART_CONTACT.BUSINESS_NAME 
CONTACT_FLAG      VARCHAR(30) NOT NULL, -- Refers to RPART_CONTACT.CONTACT_FLAG
ORIGINAL_PART_ID  VARCHAR(30),
PRIMARY_FLAG      VARCHAR(1) NOT NULL,
COMMENTS          VARCHAR(2000)
)
GO
/* ***** Translation Tables List ***** 

Part Contact Flag Translation Table / Null / TT_PARTCONTACTFLAG(Options: "Vendor", "Manufacturer") 	-> 	CONTACT_FLAG

*/
CREATE UNIQUE INDEX AMS_XPART_CONTACT01 ON AMS_XPART_CONTACT(PART_NUMBER,BUSINESS_NAME,CONTACT_FLAG)
GO

 
/* ***** Standard Tables for Gasset_ca  ***** */
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AMS_ASSET_CA')
BEGIN
DROP TABLE AMS_ASSET_CA
END
GO

CREATE TABLE AMS_ASSET_CA (
CA_ID					VARCHAR(50) NOT NULL, 
ASSET_ID				VARCHAR(65) NOT NULL,
ASSET_HIST_TYPE         VARCHAR(100)    NOT NULL,   -- Historical Asset type
CONDITION_ASSESSMENT	VARCHAR(30) NOT NULL, -- refers to RASSET_CA.R1_CONDITION_ASSESSMENT
INSP_SCHED_DATE			DATETIME,
INSP_SCHED_TIME			VARCHAR(10),
INSP_DATE				DATETIME,
INSP_TIME				VARCHAR(10),
INSP_FNAME				VARCHAR(15),
INSP_MNAME				VARCHAR(15),
INSP_LNAME				VARCHAR(25),
AGENCY_CODE				VARCHAR(8),
BUREAU_CODE				VARCHAR(8),
DIVISION_CODE			VARCHAR(8),
SECTION_CODE			VARCHAR(8),
GROUP_CODE				VARCHAR(8),
OFFICE_CODE				VARCHAR(8),
TIME_SPENT				NUMERIC(7,2),
CA_STATUS				VARCHAR(30),  -- Standard Choice of 'ASSET_CONDITION_ASSESSMENT_STATUS'
COMMENTS				VARCHAR(2000)
)
GO
/* ***** Translation Tables List ***** 

Asset Ca Condition Assessment Translation Table / RASSET_CA / TT_CONDITIONASSESSMENT 	-> 	CONDITION_ASSESSMENT
Asset Ca Status Translation Table / RBIZDOMAIN_VALUE / TT_CASTATUS 	-> 	CA_STATUS

*/
CREATE UNIQUE INDEX AMS_ASSET_CA01 ON AMS_ASSET_CA(CA_ID)
CREATE INDEX AMS_ASSET_CA02 ON AMS_ASSET_CA(ASSET_ID, ASSET_HIST_TYPE)
GO

/* ***** Gasset_ca_attr ***** */
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AMS_ASSET_CA_ATTR')
BEGIN
DROP TABLE AMS_ASSET_CA_ATTR
END
GO

CREATE TABLE AMS_ASSET_CA_ATTR(
CA_ID 					VARCHAR(50) NOT NULL,
CONDITION_ASSESSMENT	VARCHAR(30) NOT NULL,
ATTRIBUTE_NAME 	VARCHAR(30) NOT NULL,   -- Refer to rasset_ca_attr.R1_ATTRIBUTE_NAME
ATTRIBUTE_VALUE VARCHAR(2000)
)
GO
/* ***** Translation Tables List ***** 

Asset CA Attribute Translation Table / RASSET_CA_ATTR / TT_ASSETCAATTRIB	-> 	ATTRIBUTE_NAME

*/
CREATE UNIQUE INDEX AMS_ASSET_CA_ATTR01 ON AMS_ASSET_CA_ATTR(CA_ID, CONDITION_ASSESSMENT, ATTRIBUTE_NAME)
GO



/* ***** Gasset_ca_observ ***** */
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AMS_ASSET_CA_OBSERV')
BEGIN
DROP TABLE AMS_ASSET_CA_OBSERV
END
GO

CREATE TABLE AMS_ASSET_CA_OBSERV (
CA_ID 			VARCHAR(50) NOT NULL,
CONDITION_ASSESSMENT	VARCHAR(30) NOT NULL,
ROW_INDEX 		NUMERIC(8)  NOT NULL, 
ATTRIBUTE_NAME 	VARCHAR(30) NOT NULL,  -- Refer to RASSET_CA_OBSERV_ATTR.R1_ATTRIBUTE_NAME
ATTRIBUTE_VALUE VARCHAR(2000)
)
GO
/* ***** Translation Tables List ***** 

Asset CA Observ Table Translation Table

*/
CREATE UNIQUE INDEX AMS_ASSET_CA_OBSERV01 ON AMS_ASSET_CA_OBSERV (CA_ID, CONDITION_ASSESSMENT, ROW_INDEX, ATTRIBUTE_NAME)
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AMS_XASSET_CA_WO')
BEGIN
DROP TABLE AMS_XASSET_CA_WO
END
GO

CREATE TABLE AMS_XASSET_CA_WO (
CA_ID 		VARCHAR(50) NOT NULL,
PERMITNUM 	VARCHAR(30) NOT NULL
)
GO

CREATE UNIQUE INDEX AMS_XASSET_CA_WO01 ON AMS_XASSET_CA_WO (CA_ID, PERMITNUM)
GO


IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'REFER_PEOPLE_LINKS')
BEGIN
DROP TABLE REFER_PEOPLE_LINKS
END
GO

CREATE TABLE REFER_PEOPLE_LINKS (
	CONTACT_NBR NUMERIC(22) NOT NULL,
	ENT_TYPE VARCHAR(50),
	ENT_ID1 VARCHAR(100),
	ENT_ID2 VARCHAR(255) ,
	ENT_ID3 VARCHAR(255),
	PRIMARY_FLAG varchar(10),
	comments varchar(2000),
	START_DATE DATETIME,
	END_DATE DATETIME
)
GO

Create unique index refer_people_links_uix on refer_people_links (contact_nbr, ent_type, ent_id1, ent_id2, ent_id3);
GO

IF EXISTS (SELECT name  FROM sysobjects WHERE type = 'U' AND name = 'LIC_PROF' )
BEGIN
     DROP  Table  Lic_prof
END

CREATE TABLE Lic_prof (
serv_prov_code          varchar(15)  not null,
lic_nbr                 varchar(30)  not null,
lic_status              varchar(1)   not null,
lic_state               varchar(2)   not null,
lic_type                varchar(255) not null,
bus_name                varchar(255) not null,
lic_orig_iss_dd         datetime,
last_renewal_dd         datetime,
lic_expir_dd            datetime,
cae_fname               varchar(70), 
cae_mname               varchar(70),
cae_lname               varchar(70),
address1                varchar(200),
address2                varchar(200),
city                    varchar(32),
state                   varchar(2),
zip			                varchar(10),
phone1			            varchar(40),
phone2			            varchar(40),
fax			                varchar(40),
email			              varchar(70),
lic_comment		          varchar(2000),
ins_co_name		          varchar(65),
ins_amount		          numeric(12,2),
ins_policy_no		        varchar(30),
ins_exp_dt		          datetime,
bus_lic			            varchar(15),
bus_lic_exp_dt		      datetime,
last_update_dd		      datetime,			-- not used at this time
lic_seq_nbr		          numeric,
rec_date		            datetime ,
rec_ful_nam		          varchar(70),
rec_flag		            varchar(1),
lic_board 	            varchar(255),
address3                varchar(200),
wc_exempt               varchar(1),
wc_policy_no            varchar(30),
wc_eff_dt               datetime,
wc_exp_dt               datetime,
wc_canc_dt              datetime,
suffix_name             varchar(10),
country                 varchar(30),
county_code             varchar(2),   
wc_ins_co_code          varchar(3),   
contr_lic_no            numeric,
cont_lic_bus_name       varchar(255),
ga_ivr_pin              numeric,
l1_salutation	          varchar(255),		
l1_gender	              varchar(1),		
l1_post_office_box      varchar(30),		
bus_name2               varchar(255),		
l1_birth_date           datetime,
phone1_country_code     varchar(3),
phone2_country_code     varchar(3),
fax_country_code        varchar(3),	
lic_type_flag                 varchar(20),
lic_social_security_nbr       varchar(11),	
lic_federal_employer_id_nbr   varchar(16),	
phone3                        varchar(40),	
phone3_country_code           varchar(3),	
aca_permission                varchar(1),		
l1_title                      varchar(255),		
past_days                     numeric
 );
go

  Create unique clustered index lic_prof01 on lic_prof (Serv_prov_code,Lic_nbr,lic_type)
go
-- licensed professional attributes staging table

      IF EXISTS (SELECT name  FROM sysobjects WHERE type = 'U' AND name = 'LIC_PROF_ATTR' )
	  BEGIN
            DROP  Table  Lic_prof_attr
	  END
go

Create table lic_prof_attr(
serv_prov_code          varchar(15) not null,
lic_nbr                 varchar(30) not null,
lic_type                varchar(255) not null,
attrib_temp_name        varchar(30) not null,
attrib_name             varchar(30) not null,
attrib_value            varchar(200) not null
 );
go

 create unique clustered index lic_prof_attr01 on lic_prof_attr(serv_prov_code, lic_nbr, lic_type, attrib_name)
go

-- TABLE LICENSED PROFESSIONAL ATTACHED TABLES
-- (all fields required for input to be processed)

      IF EXISTS (SELECT name  FROM sysobjects WHERE type = 'U' AND name = 'LIC_PROF_ATTACH' )
	  BEGIN
            DROP  Table  Lic_prof_attach
	  END
go

Create table lic_prof_attach(
serv_prov_code		    varchar(15) not null,	--serv_prov_code to be processed
lic_nbr			        varchar(30) not null,	--license number
lic_type		        varchar(255) not null,
group_name		        varchar(12) not null,	--validated against r2chckbox.r1_checkbox_code
table_name		        varchar(30) not null,	--validated against r2chckbox.r1_checkbox_type
column_name		        varchar(100) not null,	--validated against r2chckbox.r1_checkbox_desc
row_num			        numeric not null,	--row number which provided field belongs to in the mapped attached table
attach_value		    varchar(240) not null	--input data value, must match expected data type or error will occur in app
 );
go

 create unique clustered index lic_prof_attach01 on lic_prof_attach(serv_prov_code, lic_nbr, lic_type, table_name, row_num, column_name)
go

-- TEMPLATE_ASI
IF EXISTS (SELECT name  FROM sysobjects WHERE type = 'U' AND name = 'TEMPLATE_ASI' )
BEGIN
DROP  Table  TEMPLATE_ASI
END
go

create table TEMPLATE_ASI  
( 
    ENTITY_TYPE numeric NOT NULL ,
    ENTITY_ID numeric NOT NULL, 
    GROUP_CODE VARCHAR(12) NOT NULL ,
    ASI_SUB_GROUP_CODE  VARCHAR(30) NOT NULL,
    FIELD_NAME VARCHAR(100) NOT NULL,
    FIELD_VALUE VARCHAR(4000) NOT NULL 
);

CREATE unique clustered INDEX TEMP_ASI_UIX ON TEMPLATE_ASI(ENTITY_TYPE, ENTITY_ID,GROUP_CODE, ASI_SUB_GROUP_CODE, FIELD_NAME)

-- TEMPLATE_ASIT
IF EXISTS (SELECT name  FROM sysobjects WHERE type = 'U' AND name = 'TEMPLATE_ASIT' )
BEGIN
DROP  Table TEMPLATE_ASIT
END
go

create table TEMPLATE_ASIT  
( 
    ENTITY_TYPE numeric NOT NULL ,
    ENTITY_ID numeric NOT NULL, 
    GROUP_CODE VARCHAR(12) NOT NULL ,
    ASI_SUB_GROUP_CODE  VARCHAR(30) NOT NULL,
    FIELD_NAME VARCHAR(100) NOT NULL,
    FIELD_VALUE VARCHAR(4000) NOT NULL,
    ROW_INDEX numeric not null 
);

CREATE UNIQUE clustered INDEX TEMP_ASIT_UIX ON TEMPLATE_ASIT(ENTITY_TYPE, ENTITY_ID,GROUP_CODE, ASI_SUB_GROUP_CODE, FIELD_NAME,ROW_INDEX) ;

-- PERMIT_PAYMENTS
IF EXISTS (SELECT name  FROM sysobjects WHERE type = 'U' AND name = 'PERMIT_PAYMENTS' )
BEGIN
	DROP  Table  PERMIT_PAYMENTS
END
go

CREATE TABLE PERMIT_PAYMENTS (
PERMITNUM VARCHAR(30) NOT NULL,
PAY_KEY  VARCHAR(255) NOT NULL ,
PAYMENT_METHOD                                     VARCHAR(30) not null ,
PAYMENT_REF_NBR                                    VARCHAR(70 ),
CC_TYPE                                            VARCHAR(30 ),
PAYEE                                              VARCHAR(600 ),
PAYMENT_DATE                                       DATE  not null ,
PAYMENT_AMOUNT                                     NUMERIC(15,2) not null ,
TRANSACTION_CODE                                   VARCHAR(50 ),
TRANSACTION_NBR                                    VARCHAR(30 ),
PAYMENT_COMMENT                                    VARCHAR(2000 ),
CASHIER_ID                                         VARCHAR(70) default 'AA CONV'   ,
REGISTER_NBR                                       VARCHAR(8),
REC_DATE                                           DATE NOT NULL,
REC_FUL_NAM                                        VARCHAR(70 ) NOT NULL,
ACCT_ID                                            VARCHAR(15 ),
PAYEE_ADDRESS                                      VARCHAR(700 ),
PAYEE_PHONE                                        VARCHAR(240 ),
CC_AUTH_CODE                                       VARCHAR(30 ),
PAYEE_PHONE_IDD                                    VARCHAR(3 ),
PAYMENT_RECEIVED_CHANNEL                           VARCHAR(30 ),
CHECK_NUMBER                                       VARCHAR(30 ),
CHECK_TYPE                                         VARCHAR(100 ),
DRIVER_LICENSE                                     VARCHAR(100 ),
CHECK_HOLDER_NAME                                  VARCHAR(255 ),
CHECK_HOLDER_EMAIL                                 VARCHAR(80 ),
PHONE_NUMBER                                       VARCHAR(40 ),
COUNTRY                                            VARCHAR(30 ),
STATE                                              VARCHAR(30 ),
CITY                                               VARCHAR(30 ),
STREET                                             VARCHAR(240 ),
ZIP                                                VARCHAR(10 ),
REASON                                             VARCHAR(300 ),
PAYEE_TYPE                                         VARCHAR(255),
HIST_RECEIPT_NBR                                   VARCHAR(30), 
VOID_BY                                            VARCHAR(70),
VOID_DATE                                          DATE,
payment_pay_key                                    VARCHAR(255)
) ;
go

ALTER TABLE PERMIT_PAYMENTS ADD CONSTRAINT PERMIT_PAYMENTS_PK PRIMARY KEY  (PERMITNUM, PAY_KEY) ;
go

CREATE INDEX PERMIT_PAYMENTS_idx01 ON PERMIT_PAYMENTS(HIST_RECEIPT_NBR)
GO

-- PERMIT_RECEIPTS
IF EXISTS (SELECT name  FROM sysobjects WHERE type = 'U' AND name = 'PERMIT_RECEIPTS' )
BEGIN
	DROP  Table  PERMIT_RECEIPTS
END
go

CREATE TABLE  PERMIT_RECEIPTS (
HIST_RECEIPT_NBR  VARCHAR(30) not null ,
RECEIPT_DATE                              DATE NOT NULL ,
CASHIER_ID                                VARCHAR(70 ) NOT NULL ,
REGISTER_NBR                              VARCHAR(8 ),
RECEIPT_AMOUNT                            NUMERIC(15,2) not null ,
RECEIPT_COMMENT                           VARCHAR(800 ),
RECEIPT_STATUS                            VARCHAR(30 ),
TRANSACTION_CODE                          VARCHAR(50 ),
TRANSACTION_NBR                           VARCHAR(30 ),
REC_DATE                                   DATE NOT NULL ,
REC_FUL_NAM                                VARCHAR(70 ) NOT NULL,
TTERMINAL_ID                               VARCHAR(10 ),
WORKSTATION_ID                             VARCHAR(70 )
) ;
 create unique index PERMIT_RECEIPTS_idx1 on PERMIT_RECEIPTS(HIST_RECEIPT_NBR);
go

IF EXISTS (SELECT name  FROM sysobjects WHERE type = 'U' AND name = 'STDMAP_STATISTICS' )
BEGIN
	DROP  Table  STDMAP_STATISTICS
END
go
CREATE TABLE STDMAP_STATISTICS(
MAP_TABLE_NAME VARCHAR(200),
MAP_NUM_OF_ROWS integer,
HIST_TABLE_NAME VARCHAR(200),
HIST_NUM_OF_ROWS integer,
MAP_REC_DATE datetime,
HIST_REC_DATE datetime
);
go

go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0000\0000 0040 mssql_01_create_tables.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0000\0000 0040 mssql_01_create_tables.sql')
/*
SCRIPT: 01_CREATE_TABLES.SQL
AUTHOR: DANE QUATACKER, ACCELA INC.
DATE: 11/22/2011
DESCRIPTION: CREATES BASE TABLES FOR STANDARD MAP CONVERSION IN AN SQL SERVER DATABASE

UPDATES
11/13/2012 - DQ - ADDED 7.2. FP2 UPDATES

*/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_ACTIVITY')
BEGIN
DROP TABLE AATABLE_PERMIT_ACTIVITY
END
go
CREATE TABLE AATABLE_PERMIT_ACTIVITY
(
  PERMITNUM          VARCHAR(30)          NOT NULL,
  ACT_NAME           VARCHAR(30)          NOT NULL,
  ACT_DES            VARCHAR(4000),
  ACT_TYPE           VARCHAR(255)         NOT NULL,
  ACT_DATE           DATETIME                       NOT NULL,
  ACT_DEPT           VARCHAR(100),
  ACT_STAF           VARCHAR(50),
  REC_DATE           DATETIME,
  REC_FUL_NAM        VARCHAR(70),
  INTERNAL_USE_ONLY  VARCHAR(1)           NOT NULL,
  ACT_DUE_DATE DATETIME,
  ACT_PRIORITY VARCHAR(30),
  ACT_STATUS VARCHAR(30) default 'Completed',
  act_unique_id numeric  not null
)
go
ALTER TABLE AATABLE_PERMIT_ACTIVITY ADD CONSTRAINT AATABLE_permitAct_PK PRIMARY KEY (PERMITNUM,act_unique_id)
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_ACTIVITY_ASI')
BEGIN
DROP TABLE AATABLE_PERMIT_ACTIVITY_ASI
END
go
create table AATABLE_PERMIT_ACTIVITY_ASI
(
PERMITNUM VARCHAR(30) NOT NULL,
act_unique_id numeric not null,
asi_group_code varchar(12) not null ,
asi_sub_group  varchar(30) not null,
asi_field_label varchar(100) not null,
asi_field_value varchar(200) not null,
)
go
ALTER TABLE AATABLE_PERMIT_ACTIVITY_ASI ADD CONSTRAINT aatblPermitActAsi_PK PRIMARY KEY (PERMITNUM, act_unique_id, asi_sub_group , asi_field_label)
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_ADDRESS')
BEGIN
DROP TABLE AATABLE_PERMIT_ADDRESS
END
go
CREATE TABLE AATABLE_PERMIT_ADDRESS
(
  PERMITNUM           VARCHAR(30)         NOT NULL,
  ISPRIMARY           VARCHAR(1),
  STR_NUM_START       NUMERIC(9),
  STR_NUM_END         NUMERIC(9),
  STR_FRAC_START      VARCHAR(20),
  STR_FRAC_END        VARCHAR(20),
  STR_DIR             VARCHAR(20),
  STR_NAME            VARCHAR(40),
  STR_SUFFIX          VARCHAR(30),
  STR_SUFFIX_DIR      VARCHAR(20),
  STR_PREFIX 		  VARCHAR(20),
  STR_UNIT_START      VARCHAR(10),
  STR_UNIT_END        VARCHAR(10),
  STR_UNIT_TYPE       VARCHAR(20),
  SITUS_CITY          VARCHAR(40),
  SITUS_STATE         VARCHAR(30),
  SITUS_ZIP           VARCHAR(10),
  SITUS_COUNTY        VARCHAR(30),
  SITUS_COUNTRY       VARCHAR(30),
  SITUS_COUNTRY_CODE  VARCHAR(2),
  X_COORD             NUMERIC(20,8),
  Y_COORD             NUMERIC(20,8),
  ADDR_DESC           VARCHAR(255),
  FULL_ADDRESS        VARCHAR(600)		NOT NULL,
  ADDRESS1            VARCHAR(200),
  ADDRESS2            VARCHAR(200),
  SITUS_NBRHD         VARCHAR(30),
  EXT_ADDRESS_UID	  VARCHAR(100),
  STREET_NAME_START		varchar(200), -- Added by OMATKARI 8/19/18
  STREET_NAME_END			varchar(200), -- Added by OMATKARI 8/19/18
  CROSS_STREET_NAME_START	varchar(200), -- Added by OMATKARI 8/19/18
  CROSS_STREET_NAME_END	varchar(200), -- Added by OMATKARI 8/19/18
  HSE_NBR_ALPHA_START	VARCHAR(20),	-- Added By ALTARAZI 04/09/19
  HSE_NBR_ALPHA_END		VARCHAR(20),	-- Added By ALTARAZI 04/09/19
  LEVEL_PREFIX		VARCHAR(20),	-- Added By ALTARAZI 04/09/19
  LEVEL_NBR_START	VARCHAR(20),	-- Added By ALTARAZI 04/09/19
  LEVEL_NBR_END 	VARCHAR(20)		-- Added By ALTARAZI 04/09/19
)
go

CREATE UNIQUE INDEX AATABLE_PERMIT_ADDRESS_INDEX01 ON AATABLE_PERMIT_ADDRESS(PERMITNUM,FULL_ADDRESS)

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_ADDRESS_TYPE')
BEGIN
DROP TABLE AATABLE_PERMIT_ADDRESS_TYPE
END
go
CREATE TABLE AATABLE_PERMIT_ADDRESS_TYPE
(
  PERMITNUM     VARCHAR(30)             NOT NULL,
  FULL_ADDRESS  VARCHAR(600)			NOT NULL,
  ADDRESS_TYPE  VARCHAR(30)             NOT NULL
)
go

CREATE UNIQUE INDEX AATABLE_PERMIT_ADDRESS_TYPE_INDEX01 ON AATABLE_PERMIT_ADDRESS_TYPE(PERMITNUM,FULL_ADDRESS,ADDRESS_TYPE)

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_ATTRIB')
BEGIN
DROP TABLE AATABLE_PERMIT_ATTRIB
END
go
CREATE TABLE AATABLE_PERMIT_ATTRIB
(
  PERMITNUM         VARCHAR(30)           NOT NULL,
  ATTRIB_TYPE       VARCHAR(30)           NOT NULL,
  ATTRIB_TEMP_NAME  VARCHAR(30)           NOT NULL,
  ATTRIB_NAME       VARCHAR(30)           NOT NULL,
  ATTRIB_VALUE      VARCHAR(200)          NOT NULL,
  ATTRIB_KEY        VARCHAR(600)          NOT NULL
)
go

CREATE UNIQUE INDEX AATABLE_PERMIT_ATTRIB_INDEX01 ON AATABLE_PERMIT_ATTRIB(PERMITNUM,ATTRIB_TYPE,ATTRIB_TEMP_NAME,ATTRIB_NAME,ATTRIB_KEY)

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_CALCVALUATN')
BEGIN
DROP TABLE AATABLE_PERMIT_CALCVALUATN
END
go
CREATE TABLE AATABLE_PERMIT_CALCVALUATN
(
  PERMITNUM        VARCHAR(30)            NOT NULL,
  OCC_TYPE         VARCHAR(60)            NOT NULL,
  CONST_TYPE       VARCHAR(70)            NOT NULL,
  UNIT_VALUE       NUMERIC(15,2)                 NOT NULL,
  AREA             NUMERIC(19),
  TOTALVALUE       NUMERIC(15,2)                 NOT NULL,
  UNIT_TYPE        VARCHAR(60),
  VALUATN_VERSION  VARCHAR(70)
)
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_COMMENT')
BEGIN
DROP TABLE AATABLE_PERMIT_COMMENT
END
go
CREATE TABLE AATABLE_PERMIT_COMMENT
(
  PERMITNUM  VARCHAR(30)                  NOT NULL,
  COMMENTS   VARCHAR(MAX)                               NOT NULL,
  ADDEDBY    VARCHAR(70),
  ADDEDDATE  DATETIME
)
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_CONDITIONS')
BEGIN
DROP TABLE  AATABLE_PERMIT_CONDITIONS
END
go
CREATE TABLE AATABLE_PERMIT_CONDITIONS
(
  PERMITNUM           VARCHAR(30)         NOT NULL,
  CON_COMMENTS        VARCHAR(4000)       NOT NULL,
  CON_DES             VARCHAR(255),
  CON_IMPACT_CODE     VARCHAR(8),
  EFFECTIVE_DATE      DATETIME,
  EXPIR_DATE          DATETIME,
  ISS_DD              DATETIME,
  STAT_DD             DATETIME,
  CON_STATUS          VARCHAR(30)         NOT NULL,
  CON_TYPE            VARCHAR(255)        NOT NULL,
  DISPLAY_ORDER       NUMERIC(5),
  CON_INHERITABLE     VARCHAR(1),
  CON_GROUP VARCHAR(255),
  ISS_USER_ID VARCHAR(50),
  STAT_USER_ID VARCHAR(50),
  INC_CON_NAME	VARCHAR(1),
  INC_SHORT_DESC VARCHAR(1),
  DIS_CON_NOTICE VARCHAR(1),
  CON_STATUS_TYP VARCHAR(20),
  LONG_COMMENTS VARCHAR(4000) -- Added By AALTARAZI 04/09/19
)
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_CONT_EDU')
BEGIN
DROP TABLE  AATABLE_PERMIT_CONT_EDU
END
go
CREATE TABLE AATABLE_PERMIT_CONT_EDU
(
  PERMITNUM         VARCHAR(30)           NOT NULL,
  PROVIDER_NAME     VARCHAR(255)           NOT NULL,
  CONT_EDU_NAME     VARCHAR(80),
  IS_REQUIRED       VARCHAR(1),
  EDU_CLASS         VARCHAR(80),
  DATE_OF_CLASS     DATETIME,
  HOURS_COMPLETED   NUMERIC(15,2),
  GRADING_STYLE     VARCHAR(80),
  FINAL_SCORE       NUMERIC(15,2),
  PASSING_SCORE     NUMERIC(15,2),
  EDU_COMMENTS      VARCHAR(2000),
  ADDR1             VARCHAR(200),
  ADDR2             VARCHAR(200),
  ADDR3             VARCHAR(200),
  CITY              VARCHAR(30),
  STATE             VARCHAR(30),
  ZIP               VARCHAR(10),
  PH1_COUNTRY_CODE  VARCHAR(3),
  PH1               VARCHAR(40),
  PH2_COUNTRY_CODE  VARCHAR(3),
  PH2               VARCHAR(40),
  FAX_COUNTRY_CODE  VARCHAR(3),
  FAX               VARCHAR(40),
  EMAIL             VARCHAR(70),
  B1_COUNTRY VARCHAR(30)
)
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_EDUCATION')
BEGIN
DROP TABLE  AATABLE_PERMIT_EDUCATION
END
go
CREATE TABLE AATABLE_PERMIT_EDUCATION
(
  PERMITNUM         VARCHAR(30)           NOT NULL,
  PROVIDER_NAME     VARCHAR(255)           NOT NULL,
  EDUCATION_NAME    VARCHAR(80),
  EDU_DEGREE        VARCHAR(30),
  YEAR_ATTENDED     VARCHAR(60),
  YEAR_GRADUATED    VARCHAR(60),
  EDU_COMMENTS      VARCHAR(2000),
  IS_REQUIRED       VARCHAR(1),
  ADDR1             VARCHAR(200),
  ADDR2             VARCHAR(200),
  ADDR3             VARCHAR(200),
  CITY              VARCHAR(30),
  STATE             VARCHAR(30),
  ZIP               VARCHAR(10),
  PH1_COUNTRY_CODE  VARCHAR(3),
  PH1               VARCHAR(40),
  PH2_COUNTRY_CODE  VARCHAR(3),
  PH2               VARCHAR(40),
  FAX_COUNTRY_CODE  VARCHAR(3),
  FAX               VARCHAR(40),
  EMAIL             VARCHAR(70),
  B1_COUNTRY VARCHAR(30)
)
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_EXAM')
BEGIN
DROP TABLE AATABLE_PERMIT_EXAM
END
go
CREATE TABLE AATABLE_PERMIT_EXAM
(
  PERMITNUM         VARCHAR(30)           NOT NULL,
  PROVIDER_NAME     VARCHAR(255)           NOT NULL,
  EXAM_NAME         VARCHAR(80),
  IS_REQUIRED       VARCHAR(1),
  EXAM_DATE         DATETIME,
  GRADING_STYLE     VARCHAR(80),
  FINAL_SCORE       NUMERIC(15,2),
  PASSING_SCORE     NUMERIC(15,2),
  EXAM_COMMENTS     VARCHAR(2000),
  ADDR1             VARCHAR(200),
  ADDR2             VARCHAR(200),
  ADDR3             VARCHAR(200),
  CITY              VARCHAR(30),
  STATE             VARCHAR(30),
  ZIP               VARCHAR(10),
  PH1_COUNTRY_CODE  VARCHAR(3),
  PH1               VARCHAR(40),
  PH2_COUNTRY_CODE  VARCHAR(3),
  PH2               VARCHAR(40),
  FAX_COUNTRY_CODE  VARCHAR(3),
  FAX               VARCHAR(40),
  EMAIL             VARCHAR(70),
  B1_COUNTRY VARCHAR(30)
)
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_FEE')
BEGIN
DROP TABLE AATABLE_PERMIT_FEE
END
go
CREATE TABLE AATABLE_PERMIT_FEE
(
  PERMITNUM               VARCHAR(30)     NOT NULL,
  FEE_KEY                 VARCHAR(255)    NOT NULL,
  GF_FEE_PERIOD           VARCHAR(15)     NOT NULL,
  FEE_ITEM_AMOUNT         NUMERIC(15,2)          NOT NULL,
  GF_DISPLAY              NUMERIC                NOT NULL,
  ACCOUNT_CODE1           VARCHAR(200),
  ACCOUNT_CODE2           VARCHAR(200),
  ACCOUNT_CODE3           VARCHAR(200),
  GF_FEE_SCHEDULE         VARCHAR(255),
  REC_DATE                DATETIME                NOT NULL,
  REC_FUL_NAM             VARCHAR(70)     NOT NULL,
  GF_UNIT                 NUMERIC(15,2),
  INVOICE                 VARCHAR(1),
  FEE_NOTES               VARCHAR(4000),
  FEE_SCHEDULE_VERSION    VARCHAR(255),
  INVOICE_CUSTOMIZED_NBR  VARCHAR(30),
  TT_FEE_CODE             VARCHAR(255)  NOT NULL,
  TT_FEE_DESC		  VARCHAR(255) NOT NULL,
  GF_FEE_TYPE_ALLOCATION VARCHAR(30),
  GF_L1_ALLOCATION NUMERIC(18,4),
  GF_L2_ALLOCATION NUMERIC(18,4),
  GF_L3_ALLOCATION NUMERIC(18,4),
  VOID_FLAG			VARCHAR(1) default 'N',
  GF_FEE_APPLY_DATE		datetime not null
)
go

CREATE UNIQUE INDEX AATABLE_PERMIT_FEE_INDEX01 ON AATABLE_PERMIT_FEE(PERMITNUM,FEE_KEY)

CREATE INDEX AATABLE_PERMIT_FEE_TT_INDEX02 ON AATABLE_PERMIT_FEE(TT_FEE_CODE,TT_FEE_DESC)

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_FEEALLOCATION')
BEGIN
DROP TABLE AATABLE_PERMIT_FEEALLOCATION
END
go
CREATE TABLE AATABLE_PERMIT_FEEALLOCATION
(
PERMITNUM VARCHAR(30) NOT NULL,
FEE_KEY VARCHAR(255) NOT NULL,
PAY_KEY VARCHAR(255) NOT NULL,
FEE_ALLOCATION NUMERIC(15,2) NOT NULL
)
go

CREATE UNIQUE INDEX AATBL_PERMIT_FEEALLOCATION_UIX ON AATABLE_PERMIT_FEEALLOCATION(PERMITNUM, FEE_KEY, PAY_KEY) ;

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_GUIDESHEET')
BEGIN
DROP TABLE AATABLE_PERMIT_GUIDESHEET
END
go
CREATE TABLE AATABLE_PERMIT_GUIDESHEET
(
  PERMITNUM           VARCHAR(30)         NOT NULL,
  INSP_NUMBER         NUMERIC                    NOT NULL,
  GUIDE_KEY           VARCHAR(100)         NOT NULL,
  TT_ITEM_STATUS      VARCHAR(255) NOT NULL,
  COMMENTS            VARCHAR(2000),
  SCORE               NUMERIC(30),
  TT_GUIDE_TYPE		  VARCHAR(255) NOT NULL,
  TT_GUIDE_ITEM		  VARCHAR(255) NOT NULL,
  TEAM_NAME			  VARCHAR(50),
  FLOOR				  VARCHAR(50),
  FLOOR_UNIT		  VARCHAR(50),
  HISTORICAL_GUIDE_TEXT VARCHAR(2000),
  HISTORICAL_GUIDE_ITEM_STATUS_GROUP VARCHAR(30)
  
)
go
CREATE UNIQUE INDEX AATABLE_PERMIT_GUIDESHEET_UIX ON AATABLE_PERMIT_GUIDESHEET(PERMITNUM, INSP_NUMBER, TT_GUIDE_TYPE, TT_GUIDE_ITEM, GUIDE_KEY);

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_HISTORY')
BEGIN
DROP TABLE AATABLE_PERMIT_HISTORY
END
go
CREATE TABLE AATABLE_PERMIT_HISTORY
(
  PERMITNUM                 VARCHAR(30)   NOT NULL,
  CONTRACTOR_VALUATION      NUMERIC(15,2),
  DATEOPENED                DATETIME NOT NULL,
  EXPIRATION_DATE           DATETIME,
  EXPIRATION_STATUS         VARCHAR(30),
  WORK_DESC                 VARCHAR(4000),
  APP_NAME                  VARCHAR(255),
  HOUSE_COUNT               NUMERIC(19),
  BUILDING_COUNT            NUMERIC(19),
  PUBLIC_OWNED              VARCHAR(1),
  CONST_TYPE_CODE           VARCHAR(4),
  SHORT_NOTES               VARCHAR(255),
  ASGN_DEPT                 VARCHAR(100),
  ASGN_STAFF                VARCHAR(50),
  ASGN_DATE                 DATETIME,
  COMPLETED_DEPT            VARCHAR(100),
  COMPLETED_BY              VARCHAR(50),
  COMPLETED_DATE            DATETIME,
  SCHEDULED_DATE            DATETIME,
  PRIORITY                  VARCHAR(30),
  TOTAL_JOB_COST            NUMERIC(15,2),
  CLOSED_DATE               DATETIME,
  CLOSED_BY                 VARCHAR(50),
  IVR_TRACKING_NUM          NUMERIC(19),
  CREATED_BY                VARCHAR(100),
  REPORTED_CHANNEL          VARCHAR(30),
  CREATED_BY_DEPT           VARCHAR(100),
  FIRST_ISSUED_DATE         DATETIME,
  ANONYMOUS_FLAG            VARCHAR(1),
  REFERENCE_TYPE            VARCHAR(30),
  APPEARANCE_DAYOFWEEK      VARCHAR(10),
  APPEARANCE_DATE           DATETIME,
  BOOKING_FLAG              VARCHAR(1),
  DEFENDANT_SIGNATURE_FLAG  VARCHAR(1),
  ENFORCE_OFFICER_ID        VARCHAR(12),
  ENFORCE_OFFICER_NAME      VARCHAR(70),
  INFRACTION_FLAG           VARCHAR(1),
  INSPECTOR_ID              VARCHAR(12),
  MISDEMEANOR_FLAG          VARCHAR(1),
  OFFENCE_WITNESSED_FLAG    VARCHAR(1),
  INSPECTOR_NAME            VARCHAR(70),
  ENFORCE_DEPT              VARCHAR(100),
  INSPECTOR_DEPT            VARCHAR(100),
  VALUATION_MULTIPLIER      NUMERIC(10,4) default 1.0000,
  VALUATION_EXTRA_AMT       NUMERIC(15,4),
  LAST_AUDIT_DATE           DATETIME,
  APP_STATUS_DATE           DATETIME,
  DELEGATE_USER_ID          VARCHAR(100),
  TT_RECORD_STATUS          VARCHAR(255)   NOT NULL,
  TT_RECORD                 VARCHAR(255)   NOT NULL,
  BALANCE					NUMERIC(15,2)	DEFAULT 0,
  TOTAL_FEE					NUMERIC(15,2)	DEFAULT 0,
  TOTAL_PAY					NUMERIC(15,2)	DEFAULT 0,
  LAST_UPDATE_BY 			VARCHAR(70),
  LAST_UPDATE_DATE			DATETIME
)
go

CREATE UNIQUE INDEX AATABLE_PERMIT_HISTORY_INDEX01 ON AATABLE_PERMIT_HISTORY(PERMITNUM)

CREATE INDEX AATABLE_PERMIT_HISTORY_INDEX02 ON AATABLE_PERMIT_HISTORY(TT_RECORD,TT_RECORD_STATUS)

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_INSP')
BEGIN
DROP TABLE AATABLE_PERMIT_INSP
END
go
CREATE TABLE AATABLE_PERMIT_INSP
(
  PERMITNUM             VARCHAR(30)       NOT NULL,
  INSPDATE              DATETIME,
  INSPSCHEDDATE         DATETIME,
  INSPREQDATE           DATETIME,
  INSP_NUMBER           NUMERIC                  NOT NULL,
  INSP_REQUIRED         VARCHAR(1),
  PHONE_NUM             VARCHAR(40),
  LATITUDE              NUMERIC(13,10),
  LONGITUDE             NUMERIC(13,10),
  INSP_RESULT_COMM      VARCHAR(MAX),
  INSP_SCHED_COMM       VARCHAR(MAX),
  SD_OVERTIME           VARCHAR(1),
  DISPLAY_IN_ACA        VARCHAR(1),
  TT_INSPECTION         VARCHAR(255)                  NOT NULL,
  TT_INSPECTION_STATUS  VARCHAR(255)                  NOT NULL,
  CONTACT_NBR VARCHAR(100),
  INSP_SEQ_NBR NUMERIC,
  USER_ID VARCHAR(50),
  ORDER_BY 	NUMERIC   DEFAULT 1,
  G6_ACT_T1 VARCHAR(10),
  G6_ACT_T2 VARCHAR(10),
  G6_ACT_END_T1 VARCHAR(10),
  G6_ACT_END_T2 VARCHAR(10),
  G6_ACT_TT NUMERIC,
  ESTIMATED_START_TIME VARCHAR(10),
  ESTIMATED_END_TIME VARCHAR(10),
  G6_DESI_DD DATETIME,
  G6_DESI_TIME VARCHAR(10),
  G6_DESI_TIME2 VARCHAR(10),
  CONTACT_PHONE_NUM VARCHAR(40),
  CONTACT_PHONE_NUM_IDD VARCHAR(3),
  CONTACT_FNAME VARCHAR(70),
  CONTACT_MNAME VARCHAR(70),
  CONTACT_LNAME  VARCHAR(70),
  G6_REQ_PHONE_NUM_IDD  VARCHAR(3),
  G6_REQ_PHONE_NUM   VARCHAR(40),
  MAJOR_VIOLATION_COUNT NUMERIC,
  UNIT_NBR VARCHAR(20),
  GRADE VARCHAR(30),
  TOTAL_SCORE NUMERIC,
  VEHICLE_NUM VARCHAR(30),
  G6_MILE_T1 NUMERIC,
  G6_MILE_T2 NUMERIC,
  G6_MILE_TT NUMERIC,
  INSP_CANCELLED VARCHAR(1) DEFAULT  'N',
  INSP_PENDING VARCHAR(1) DEFAULT  'N',
  CLIENT_UNIQUE_ID VARCHAR(255)
)
go

CREATE UNIQUE INDEX AATABLE_PERMIT_INSP_INDEX01 ON AATABLE_PERMIT_INSP(INSP_NUMBER)

CREATE INDEX AATABLE_PERMIT_INSP_INDEX02 ON AATABLE_PERMIT_INSP(TT_INSPECTION,TT_INSPECTION_STATUS)

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_INSPDISTRICTS')
BEGIN
DROP TABLE AATABLE_PERMIT_INSPDISTRICTS
END
go
CREATE TABLE AATABLE_PERMIT_INSPDISTRICTS
(
  PERMITNUM      VARCHAR(30)              NOT NULL,
  DIST_TYPE      VARCHAR(1)               NOT NULL,
  DIST_KEY       VARCHAR(600)             NOT NULL,
  INSP_DISTRICT  VARCHAR(30)              NOT NULL
)
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_PARCEL')
BEGIN
DROP TABLE AATABLE_PERMIT_PARCEL
END
go
CREATE TABLE AATABLE_PERMIT_PARCEL
(
  PERMITNUM            VARCHAR(30)        NOT NULL,
  PARCELNUM            VARCHAR(24)        NOT NULL,
  BOOK                 VARCHAR(8),
  PAGE                 VARCHAR(8),
  PARCEL               VARCHAR(9),
  LOT                  VARCHAR(40),
  BLOCK                VARCHAR(15),
  TRACT                VARCHAR(80),
  LEGAL_DESC           VARCHAR(2000),
  PARCEL_AREA          NUMERIC(15,2),
  PLAN_AREA            VARCHAR(8),
  CENSUS_TRACT         VARCHAR(10),
  COUNCIL_DISTRICT     VARCHAR(10),
  SUPERVISOR_DISTRICT  VARCHAR(10),
  INSPECTION_DISTRICT  VARCHAR(255),
  LAND_VALUE           NUMERIC(15,2),
  IMPROVED_VALUE       NUMERIC(15,2),
  EXEMPT_VALUE         NUMERIC(15,2),
  MAP_REFERENCE        VARCHAR(30),
  MAP_NUMBER           VARCHAR(10),
  SUBDIVISION          VARCHAR(240),
  PRIMARY_FLAG         VARCHAR(1),
  TOWNSHIP             VARCHAR(10),
  RANGE                VARCHAR(10),
  SECTION              NUMERIC(10),
  EXT_PARCEL_UID	   VARCHAR(100)
)
go

CREATE UNIQUE INDEX AATABLE_PERMIT_PARCEL_INDEX01 ON AATABLE_PERMIT_PARCEL(PERMITNUM,PARCELNUM)

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_PEOPLE')
BEGIN
DROP TABLE AATABLE_PERMIT_PEOPLE
END
go
CREATE TABLE AATABLE_PERMIT_PEOPLE
(
  PERMITNUM                VARCHAR(30)    NOT NULL,
  TT_CONTACT_TYPE          VARCHAR(255),
  CONTACT_RELATIONSHIP     VARCHAR(255),
  ISPRIMARY                VARCHAR(1),
  LIC_NUM                  VARCHAR(30),
  LIC_TYPE                 VARCHAR(255),
  NAME                     VARCHAR(220),
  FNAME                    VARCHAR(70),
  MNAME                    VARCHAR(70),
  LNAME                    VARCHAR(70),
  BUS_NAME                 VARCHAR(255),
  ADDR1                    VARCHAR(200),
  ADDR2                    VARCHAR(200),
  ADDR3                    VARCHAR(200),
  CITY                     VARCHAR(30),
  STATE                    VARCHAR(30),
  ZIP                      VARCHAR(10),
  PH1                      VARCHAR(40),
  PH2                      VARCHAR(40),
  FAX                      VARCHAR(40),
  EMAIL                    VARCHAR(80),
  COMMENTS                 VARCHAR(240),
  TITLE                    VARCHAR(255),
  PH3                      VARCHAR(40),
  COUNTRY_CODE             VARCHAR(2),
  NOTIFY                   VARCHAR(1),
  NAME_SUFFIX              VARCHAR(10),
  BUS_LIC                  VARCHAR(15),
  LIC_ORIGINAL_ISSUE_DATE  DATETIME,
  EXPIRATION_DATE          DATETIME,
  RENEWAL_DATE             DATETIME,
  MAIL_ADDR1               VARCHAR(100),
  MAIL_ADDR2               VARCHAR(40),
  MAIL_ADDR3               VARCHAR(40),
  MAIL_CITY                VARCHAR(32),
  MAIL_STATE               VARCHAR(30),
  MAIL_ZIP                 VARCHAR(10),
  MAIL_COUNTRY             VARCHAR(30),
  OWNER_TYPE               VARCHAR(30),
  GENDER                   VARCHAR(1),
  SALUTATION               VARCHAR(255),
  PO_BOX                   VARCHAR(30),
  BUS_NAME2                VARCHAR(255),
  BIRTH_DATE               DATETIME,
  PH1_COUNTRY_CODE         VARCHAR(3),
  PH2_COUNTRY_CODE         VARCHAR(3),
  FAX_COUNTRY_CODE         VARCHAR(3),
  PH3_COUNTRY_CODE         VARCHAR(3),
  TRADE_NAME               VARCHAR(255),
  CONTACT_TYPE_FLAG        VARCHAR(20),
  SOCIAL_SECURITY_NUMBER   VARCHAR(11),
  FEDERAL_EMPLOYER_ID_NUM  VARCHAR(16) constraint aatbl_pppl_chk_fein check (FEDERAL_EMPLOYER_ID_NUM LIKE '[0-9][0-9]-[0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
  CONTRA_TYPE_FLAG         VARCHAR(20),
  LIC_BOARD                VARCHAR(255),
  B1_ID                    VARCHAR(15),
  CONT_LIC_BUS_NAME        VARCHAR(255),
  B1_ACCESS_LEVEL          VARCHAR(20),
BIRTH_CITY VARCHAR(30),
BIRTH_STATE VARCHAR(30),
BIRTH_REGION VARCHAR(30),
B1_CONTACT_NBR NUMERIC,
DECEASED_DATE DATETIME,
DRIVER_LIC_NBR VARCHAR(100),
DRIVER_LIC_STATE VARCHAR(30),
PASSPORT_NBR VARCHAR(100),
STATE_ID_NBR VARCHAR(100),
RACE VARCHAR(280),
G1_CONTACT_NBR NUMERIC,
LIC_STATE    VARCHAR(30)
)
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_PEOPLEATTRIB')
BEGIN
DROP TABLE AATABLE_PERMIT_PEOPLEATTRIB
END
go
CREATE TABLE AATABLE_PERMIT_PEOPLEATTRIB
(
  PERMITNUM         VARCHAR(30)           NOT NULL,
  ATTRIB_KEY        VARCHAR(10)           NOT NULL,
  ATTRIB_TEMP_NAME  VARCHAR(30)           NOT NULL,
  ATTRIB_TYPE       VARCHAR(255)          NOT NULL,
  ATTRIB_NAME       VARCHAR(30)           NOT NULL,
  NAME              VARCHAR(80)           NOT NULL,
  ATTRIB_VALUE      VARCHAR(200)          NOT NULL
)
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_PEOPLELICTABLE')
BEGIN
DROP TABLE AATABLE_PERMIT_PEOPLELICTABLE
END
go
CREATE TABLE AATABLE_PERMIT_PEOPLELICTABLE
(
  PERMITNUM    VARCHAR(30)                NOT NULL,
  LIC_NUM      VARCHAR(30)                NOT NULL,
  LIC_TYPE     VARCHAR(255)               NOT NULL,
  TABLE_NAME   VARCHAR(30)                NOT NULL,
  COLUMN_NAME  VARCHAR(100)               NOT NULL,
  ROW_NUM      NUMERIC(5)                        NOT NULL,
  COLUMN_NUM   NUMERIC(2),
  TABLE_VALUE  VARCHAR(4000)               NOT NULL
)
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_PROJECTS')
BEGIN
DROP TABLE AATABLE_PERMIT_PROJECTS
END
go
CREATE TABLE AATABLE_PERMIT_PROJECTS
(
  PARENTACTIVITYNUM  VARCHAR(30)          NOT NULL,
  CHILDACTIVITYNUM   VARCHAR(30)          NOT NULL,
  RELATIONSHIP VARCHAR(30),
  STATUS VARCHAR(30)
)
go

CREATE UNIQUE INDEX AATABLE_PERMIT_PROJECTS_INDEX01 ON AATABLE_PERMIT_PROJECTS(PARENTACTIVITYNUM,CHILDACTIVITYNUM)

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_STATUS')
BEGIN
DROP TABLE AATABLE_PERMIT_STATUS
END
go
CREATE TABLE AATABLE_PERMIT_STATUS
(
  PERMITNUM       VARCHAR(30)             NOT NULL,
  STATUS          VARCHAR(30)             NOT NULL,
  STATUS_DATE     DATETIME                NOT NULL,
  STATUS_COMMENT  VARCHAR(4000),
  USER_ID		  VARCHAR(50),
  ORDER_BY		  NUMERIC				  DEFAULT 1 				
)
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_STRU_ESTA')
BEGIN
DROP TABLE AATABLE_PERMIT_STRU_ESTA
END
go
CREATE TABLE AATABLE_PERMIT_STRU_ESTA
(
  PERMITNUM  VARCHAR(30)                  NOT NULL,
  L1_NUMBER  VARCHAR(30)                  NOT NULL,
  L1_GROUP   VARCHAR(30)                  NOT NULL,
  L1_TYPE    VARCHAR(30)                  NOT NULL
)
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_WORKFLOW')
BEGIN
DROP TABLE AATABLE_PERMIT_WORKFLOW
END
go
CREATE TABLE AATABLE_PERMIT_WORKFLOW
(
  PERMITNUM    VARCHAR(30)                NOT NULL,
  TASKUPDATED  DATETIME                   NOT NULL,
  COMMENTS     VARCHAR(4000),
  ASGN_DATE    DATETIME,
  DUE_DATE     DATETIME,
  TT_WORKFLOW_TASK  VARCHAR(255)                NOT NULL,
  TT_WORKFLOW_STATUS  VARCHAR(255)                NOT NULL,
  USER_ID	   VARCHAR(50),
  ID           NUMERIC					 DEFAULT 0,
  SD_HOURS_SPENT              NUMERIC(5,2),
  SD_BILLABLE                 VARCHAR(1),
  SD_OVERTIME                 VARCHAR(1),
  ESTIMATED_HOURS             NUMERIC(5,2),
  ASGN_EMAIL_DISPLAY_FOR_ACA  VARCHAR(1),
  RESTRICT_COMMENT_FOR_ACA    VARCHAR(1),
  RESTRICT_ROLE               VARCHAR(10),
  TASK_UNIQUE_ID              VARCHAR(255)
)
go

CREATE INDEX AATABLE_PERMIT_WORKFLOW_TT_WORKFLOW_TASK_INDEX ON AATABLE_PERMIT_WORKFLOW(TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS)


IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_TRUST_ACCOUNT_TRANS')
BEGIN
DROP TABLE AATABLE_TRUST_ACCOUNT_TRANS
END
go
CREATE TABLE AATABLE_TRUST_ACCOUNT_TRANS
(
  ACCOUNT_ID        VARCHAR(15)           NOT NULL,
  TRANS_TYPE        VARCHAR(70)           NOT NULL,
  TRANS_AMOUNT      NUMERIC(15,2)                NOT NULL,
  TRANS_DATE        DATETIME                NOT NULL,
  TRANS_BY          VARCHAR(70),
  TARGET_ACCT_ID    VARCHAR(15),
  PERMITNUM         VARCHAR(30),
  PAY_KEY			VARCHAR(255)
)
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_TRUST_ACCOUNTS')
BEGIN
DROP TABLE AATABLE_TRUST_ACCOUNTS
END
go
CREATE TABLE AATABLE_TRUST_ACCOUNTS
(
  ACCOUNT_ID           VARCHAR(15)        NOT NULL,
  ACCOUNT_BALANCE      NUMERIC(15,2),
  LEDGER_ACCOUNTNUM    VARCHAR(50),
  ACCT_DESC            VARCHAR(30),
  ACCT_STATUS          VARCHAR(10),
  ACCT_OVERDRAFT       VARCHAR(1),
  ACCT_OVERDRAFTLIMIT  NUMERIC(15,2),
  THRESHOLD_AMT        NUMERIC(15,2)
)
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_TRUST_ACCT_PEOPLE_LINKS')
BEGIN
DROP TABLE AATABLE_TRUST_ACCT_PEOPLE_LINKS
END
go
create table AATABLE_TRUST_ACCT_PEOPLE_LINKS  (
account_id              varchar(15)    not null,
contact_nbr numeric(22) ,
lic_nbr varchar(30),
lic_type varchar(255),
lic_state varchar(30)
)
GO
create unique index aatbl_trust_acct_people_links_uix on AATABLE_TRUST_ACCT_PEOPLE_LINKS(account_id, contact_nbr, lic_nbr, lic_type, lic_state)
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_AUDIT_SETS')
BEGIN
DROP TABLE AATABLE_PERMIT_AUDIT_SETS
END
GO

CREATE TABLE AATABLE_PERMIT_AUDIT_SETS (
PERMITNUM       VARCHAR(30) NOT NULL,
SET_ID          VARCHAR(100) NOT NULL
) 
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_permit_TaskSpecAdHoc')
BEGIN
DROP TABLE AATABLE_permit_TaskSpecAdHoc
END
GO

CREATE TABLE AATABLE_PERMIT_TASKSPECADHOC (
PERMITNUM              VARCHAR(30)    NOT NULL,
TASK_SPEC_CODE         VARCHAR(12)    NOT NULL,
TASK_SPEC_TYPE         VARCHAR(30)    NOT NULL,
TASK_SPEC_NAME         VARCHAR(100)   NOT NULL,
TASK_SPEC_VALUE        VARCHAR(240)   NOT NULL,
PROCESS_CODE           VARCHAR(70)    NOT NULL,
TASK_DESC              VARCHAR(70)    NOT NULL,
SD_STP_NUM             NUMERIC
)
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_pos_transaction')
BEGIN
DROP TABLE AATABLE_pos_transaction
END
GO

CREATE TABLE AATABLE_pos_transaction 
( 
	tran_key       NUMERIC      NOT NULL, -- Loaded it to f4pos_transaction.batch_transaction_nbr
	module_name    VARCHAR(15) NOT NULL,
	pos_trans_type VARCHAR(30) NOT NULL
)
GO


IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_pos_trans_fee')
BEGIN
DROP TABLE AATABLE_pos_trans_fee
END
GO

CREATE TABLE AATABLE_pos_trans_fee ( 
	tran_key                NUMERIC         NOT NULL, 
	fee_key                 VARCHAR(255)   NOT NULL,
	gf_cod                  VARCHAR(15)    NOT NULL,
	gf_des                  VARCHAR(100)   NOT NULL,
	gf_unit                 NUMERIC(18,4),
	gf_fee                  NUMERIC(15,2),
	gf_fee_apply_date       DATETIME,
	gf_sub_group            VARCHAR(40),
	gf_fee_schedule         VARCHAR(255),
	gf_fee_schedule_version VARCHAR(255),
	fee_notes               VARCHAR(4000)
)
GO


IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_pos_trans_pay')
BEGIN
DROP TABLE AATABLE_pos_trans_pay
END
go

CREATE TABLE AATABLE_pos_trans_pay (
	tran_key                NUMERIC         NOT NULL,
	pay_key                 VARCHAR(255)   NOT NULL,
	payment_status          VARCHAR(30)    NOT NULL,
	payment_amount          NUMERIC(15,2)    NOT NULL,
	payment_date            DATETIME            NOT NULL,
	cashier_id              VARCHAR(70)    NOT NULL,
	payment_method          VARCHAR(30),
	payment_ref_nbr         VARCHAR(70),
	payee                   VARCHAR(600),
	payee_address           VARCHAR(240),
	payee_phone             VARCHAR(240),
	cc_auth_code            VARCHAR(30),
	payment_comment         VARCHAR(2000),
	HIST_RECEIPT_NBR        VARCHAR(75)    NOT NULL,
	register_nbr            VARCHAR(8),
	VOID_DATE               DATETIME,
	VOID_BY                 VARCHAR(70) 
)
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_TRUST')
BEGIN
DROP TABLE AATABLE_PERMIT_TRUST 
END
GO

CREATE TABLE AATABLE_PERMIT_TRUST (
PERMITNUM            VARCHAR(30) NOT NULL,
TRUST_ACCOUNT_ID     VARCHAR(15) NOT NULL
) 
GO

CREATE UNIQUE INDEX AATABLE_PERMIT_TRUST_INDEX01 ON AATABLE_PERMIT_TRUST(PERMITNUM,TRUST_ACCOUNT_ID)

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_permit_time_accounting')
BEGIN
DROP TABLE AATABLE_permit_time_accounting
END
GO

CREATE TABLE AATABLE_permit_time_accounting (
    permitnum         VARCHAR(30) NOT NULL,
    tt_time_group_name   VARCHAR(255) NOT NULL,
    tt_time_type_name    VARCHAR(255) NOT NULL,
    billable_flag     VARCHAR(1) NOT NULL,
    log_DATE          DATETIME NOT NULL,
    time_start        DATETIME,
    time_end          DATETIME,
    time_elapsed      DATETIME NOT NULL,
    total_minutes     NUMERIC NOT NULL,
    materials_desc    VARCHAR(64),
    materials_cost    NUMERIC(17,4),
    Mileage_start     NUMERIC(17,4),
    Mileage_end       NUMERIC(17,4),
    Milage_total      NUMERIC(17,4),
    vehicle_id        VARCHAR(250),
    entry_rate        NUMERIC(17,4) NOT NULL,
    entry_pct         NUMERIC(12,4) NOT NULL,
    entry_cost        NUMERIC(17,4) NOT NULL,
    created_DATE      DATETIME NOT NULL,
    created_by        VARCHAR(70) NOT NULL,
    notation          VARCHAR(250),
    group_seq_nbr     NUMERIC NOT NULL,
    entity_id         VARCHAR(50),
    entity_type       VARCHAR(20) constraint aatbl_chk_entity_type check (entity_type in ('INSPECTION','WORKFLOW', 'N/A','RECORD')), 
    user_name         VARCHAR(50) NOT NULL,
    Unique_Id         VARCHAR(100),
	TIME_LOG_STATUS   VARCHAR(1) NOT NULL constraint aatbl_chk_time_log_status check (TIME_LOG_STATUS in ('U','L')),
	RECORD_TYPE		  VARCHAR(3) not null constraint aatbl_chk_record_type check (RECORD_TYPE in ('CAP','N/A'))
    )
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_WORKFLOWADHOC')
BEGIN
DROP TABLE AATABLE_PERMIT_WORKFLOWADHOC
END
GO

CREATE TABLE AATABLE_permit_workflowAdHoc (
  PERMITNUM              VARCHAR(30)    NOT NULL,
  TASK_DESC              VARCHAR(100)   NOT NULL,
  TASK_STATUS            VARCHAR(200)    NOT NULL,
  TASKUPDATED            DATETIME            NOT NULL,
  FNAME                  VARCHAR(70),
  MNAME                  VARCHAR(70),
  LNAME                  VARCHAR(70),
  COMMENTS               VARCHAR(4000),
  PROCESS_CODE           VARCHAR(70),
  CHECK_LEVEL1           VARCHAR(1)     NOT NULL,
  CHECK_LEVEL2           VARCHAR(1)     NOT NULL, 
  G6_ASGN_DD             DATETIME,
  B1_DUE_DD              DATETIME,
  SD_DUE_DAY             NUMERIC(22),
  SD_NOTE                VARCHAR(2000),
  SD_STP_NUM             NUMERIC,
  ASGN_AGENCY_CODE       VARCHAR(8),
  ASGN_BUREAU_CODE       VARCHAR(8),
  ASGN_DIVISION_CODE     VARCHAR(8),
  ASGN_GROUP_CODE        VARCHAR(8),
  ASGN_SECTION_CODE      VARCHAR(8),
  ASGN_OFFICE_CODE       VARCHAR(8),
  ASGN_FNAME             VARCHAR(70),
  ASGN_MNAME             VARCHAR(70),
  ASGN_LNAME             VARCHAR(70)
)
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_COSTING_AMS')
BEGIN
DROP TABLE AATABLE_PERMIT_COSTING_AMS
END
GO

CREATE TABLE AATABLE_PERMIT_COSTING_AMS (
PERMITNUM               VARCHAR(30)     NOT NULL,
COST_NAME 		          VARCHAR(100)    NOT NULL, -- Leg db cost item key
COST_DATE               DATETIME        NOT NULL,
COST_TYPE               VARCHAR(70)     NOT NULL,      -- Change length to 70 by zeal on 05/16/2011
COST_ITEM               VARCHAR(100)    NOT NULL ,
COST_FIX                NUMERIC(17,4)   DEFAULT 0,
COST_FACTOR             NUMERIC(17,4)   DEFAULT 0,   --Standard Choice of 'COST_FACTOR'
COST_UNIT_COST          NUMERIC(17,4)   NOT NULL, 
COST_UNIT_TYPE          VARCHAR(10),    --Standard Choice of 'COST_UNIT_TYPE'
COST_QUANTITY           NUMERIC(17,4)   DEFAULT 0, 
cost_item_total         numeric(17,4)   null,
COST_COMMENTS           VARCHAR(2000)   NULL,
Updated_by 						  varchar(70),		--Add by zeal on 05/17/2011
Updated_date 						DATETIME,				--Add by zeal on 05/17/2011
COST_STATUS							VARCHAR(15),	 --Add by zeal on 05/17/2011
START_TIME							VARCHAR(5),		 --Add by zeal on 05/17/2011
END_TIME								VARCHAR(5),		 --Add by zeal on 05/17/2011
RELATED_ASGN_NBR				bigint,		 --Add by zeal on 05/17/2011,
TASK_CODE 			VARCHAR(30),
TASK_CODE_INDEX		NUMERIC
)
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_permit_asset_ams')
BEGIN
DROP TABLE AATABLE_permit_asset_ams
END
GO

Create table AATABLE_permit_asset_ams (
permitnum varchar(30) not null,
asset_id varchar(65)  NOT NULL,
asset_group varchar(30) not null,
asset_type varchar(30) not null,
WOASSET_ORDER NUMERIC(10) ,   --08/18/2010  Increase to 10
WOASSET_COMPLETE VARCHAR(1),
WOASSET_COMPLETE_DATE DATETIME,
WOASSET_SHORT_NOTES VARCHAR(2000) 
)

go

CREATE UNIQUE INDEX AATABLE_PERMIT_ASSET_AMS_INDEX01 ON AATABLE_PERMIT_ASSET_AMS(PERMITNUM,ASSET_ID,ASSET_GROUP,ASSET_TYPE)

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_TASK_AMS')
BEGIN
DROP TABLE AATABLE_PERMIT_TASK_AMS
END
GO

CREATE TABLE AATABLE_PERMIT_TASK_AMS(
PERMITNUM			VARCHAR(30) NOT NULL,
TASK_CODE 			VARCHAR(30) NOT NULL, -- Refers to RWO_TASK.R1_TASK_CODE
TASK_CODE_INDEX		NUMERIC  NOT NULL,
TASK_DESCRIPTION  	VARCHAR(2000),
OPERATION_PROCEDURE	VARCHAR(2000),
ESTIMATE_EFFORT 	NUMERIC(15,2),
DURATION_UNIT 		VARCHAR(10), --Standard Choice of 'WO_TASK_DURATION_UNIT'
ACTUAL_EFFORT 		NUMERIC(15,2),
COMPLETE_DATE 		DATETIME,
COMPLETE_BY 		VARCHAR(70),
COMMENTS  			VARCHAR(2000),
TASK_ORDER 			NUMERIC(8)  NOT NULL
)
GO

CREATE UNIQUE INDEX AATABLE_PERMIT_TASK_AMS_INDEX01 ON AATABLE_PERMIT_TASK_AMS(PERMITNUM,TASK_CODE,TASK_CODE_INDEX)

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_COST_DIST')
BEGIN
DROP TABLE AATABLE_PERMIT_COST_DIST
END
GO

CREATE TABLE AATABLE_PERMIT_COST_DIST (
PERMITNUM 	VARCHAR(30) NOT NULL,
ASSET_ID 	VARCHAR(65) NOT NULL,
ASSET_HIST_TYPE   VARCHAR(100)    NOT NULL,   -- Historical Asset type
PART_NUMBER VARCHAR(50),
COST_NAME 		VARCHAR(100)
)
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_PERMIT_PART_AMS')
BEGIN
DROP TABLE AATABLE_PERMIT_PART_AMS
END
go


CREATE TABLE AATABLE_PERMIT_PART_AMS (
PERMITNUM varchar(30) NOT NULL,
TRANSACTION_TYPE varchar(30) NOT NULL, -- VALID VALUES ARE  ISSUE AND VOID
TRANSACTION_DATE DATETIME  NOT NULL ,
QUANTITY NUMERIC(17,4) NOT NULL,
PART_NUMBER varchar(50)  NOT NULL,
LOCATION_NAME varchar(100) NOT NULL, 
PART_BIN varchar(30) , 
TAXABLE varchar(1) ,
PART_BRAND varchar(100),
PART_DESCRIPTION varchar(2000),
PART_TYPE  varchar(50),
UNIT_OF_MEASUREMENT varchar(30),
UNIT_OF_COST NUMERIC(17,4),
COMMENTS varchar(2000) ,
LAST_UPDATED_DATE  DATETIME,
LAST_UPDATED_BY varchar(70)
)

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_REFER_PEOPLE')
BEGIN
DROP TABLE AATABLE_REFER_PEOPLE
END
GO

CREATE TABLE AATABLE_REFER_PEOPLE  
(CONTACT_NBR            numeric(22)  NOT NULL,
TT_CONTACT_TYPE         VARCHAR(255) NOT NULL,
TITLE                   VARCHAR(255),
FNAME                   VARCHAR(70),
MNAME                   VARCHAR(70),
LNAME                   VARCHAR(70),
NAME_SUFFIX	            VARCHAR(10),
FULL_NAME               VARCHAR(220),	
BUS_NAME                VARCHAR(255),
ADDR1                   VARCHAR(200),
ADDR2                   VARCHAR(200),
ADDR3                   VARCHAR(200),
CITY                    VARCHAR(30),
STATE                   VARCHAR(30),
ZIP                     VARCHAR(10),
COUNTRY                 VARCHAR(30),
PH1                     VARCHAR(40),
PH2                     VARCHAR(40),
FAX                     VARCHAR(40),
EMAIL                   VARCHAR(80),
G1_ID                   VARCHAR(15),
G1_FLAG                 VARCHAR(1),
COMMENTS                VARCHAR(240),
RELATION                VARCHAR(255),
G1_PREFERRED_CHANNEL    numeric(2),
COUNTRY_CODE	          VARCHAR(2),
GA_IVR_PIN              numeric(10),
PH3	                    VARCHAR(40),	
SALUTATION              VARCHAR(255),
GENDER                  VARCHAR(1),	
POST_OFFICE_BOX         VARCHAR(30),	
BIRTH_DATE              datetime,	
PH1_COUNTRY_CODE        VARCHAR(3),	
PH2_COUNTRY_CODE        VARCHAR(3),	
PH3_COUNTRY_CODE        VARCHAR(3),	
FAX_COUNTRY_CODE	      VARCHAR(3),
SOCIAL_SECURITY_number  VARCHAR(11),
FEDERAL_EMPLOYER_ID_NUM VARCHAR(16),
TRADE_NAME	            VARCHAR(255),	
CONTACT_TYPE_FLAG       VARCHAR(20),
BUSINESS_NAME2          VARCHAR(255),
BIRTH_CITY              VARCHAR(30),
BIRTH_STATE             VARCHAR(30),
BIRTH_REGION            VARCHAR(30),
G1_RACE                 VARCHAR(280),
DECEASED_DATE           datetime,
PASSPORT_NBR            VARCHAR(100),
DRIVER_LICENSE_NBR      VARCHAR(100),
DRIVER_LICENSE_STATE	  VARCHAR(30),
STATE_ID_NBR            VARCHAR(100)
)
GO

CREATE UNIQUE INDEX AATABLE_REFER_PEOPLE_CONTACT_NBR_INDEX ON AATABLE_REFER_PEOPLE(CONTACT_NBR)

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_REFER_PEOPLECONDIT')
BEGIN
DROP TABLE AATABLE_REFER_PEOPLECONDIT
END
GO

CREATE TABLE AATABLE_REFER_PEOPLECONDIT
(
  ENTITY_TYPE               VARCHAR(50) NOT NULL,
  ENTITY_ID                 VARCHAR(30) NOT NULL,
  L1_CON_NBR                NUMERIC(22) NOT NULL,
  CON_COMMENT               VARCHAR(4000),
  CON_DES                   VARCHAR(255),
  CON_EFF_DD1               datetime,
  CON_EXPIR_DD              datetime,
  CON_IMPACT_CODE           VARCHAR(8),
  CON_REF_NUM1              VARCHAR(20),
  CON_REF_NUM2              VARCHAR(20),
  CON_STATUS                VARCHAR(30),
  CON_TYP                   VARCHAR(255),
  CON_LONG_COMMENT          VARCHAR(4000),
  CON_DIS_CON_NOTICE        VARCHAR(1),
  CON_INC_CON_NAME          VARCHAR(1),
  CON_INC_SHORT_DESC        VARCHAR(1),
  CON_INHERITABLE           VARCHAR(1),
  CON_STATUS_TYP            VARCHAR(20),
  CON_GROUP                 VARCHAR(255),
  CON_DIS_NOTICE_ACA        VARCHAR(1),
  CON_DIS_NOTICE_ACA_FEE    VARCHAR(1),
  R3_CON_RESOLUTION_ACTION  VARCHAR(4000),     --maps to rcoa_detail
  R3_CON_PUBLIC_DIS_MESSAGE VARCHAR(2000),     --maps to rcoa_detail
  PRIORITY                  NUMERIC(5),        --maps to rcoa_detail
  ADDITIONAL_INFORMATION    VARCHAR(MAX)               --maps to rcoa_detail
)
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_REFER_PEOPLEADDR')
BEGIN
DROP TABLE AATABLE_REFER_PEOPLEADDR
END
GO

CREATE TABLE AATABLE_REFER_PEOPLEADDR
( 
  ENTITY_TYPE        VARCHAR(15) NOT NULL,
  ENTITY_ID          numeric(22) NOT NULL,
  ADDRESS_TYPE       VARCHAR(255),
  EFF_DATE           datetime,
  EXPR_DATE          datetime,
  RECIPIENT          VARCHAR(220),
  FULL_ADDRESS       VARCHAR(1024),
  ADDRESS1           VARCHAR(200),
  ADDRESS2           VARCHAR(200),
  ADDRESS3           VARCHAR(200),
  HSE_NBR_START      numeric(9),
  HSE_NBR_END        numeric(9),
  STR_DIR            VARCHAR(20),
  STR_PREFIX         VARCHAR(20),
  STR_NAME           VARCHAR(40),
  STR_SUFFIX         VARCHAR(30),
  UNIT_TYPE          VARCHAR(20),
  UNIT_START         VARCHAR(10),
  UNIT_END           VARCHAR(10),
  STR_SUFFIX_DIR     VARCHAR(20),
  COUNTRY_CODE       VARCHAR(2),
  CITY               VARCHAR(32),
  STATE              VARCHAR(30),
  ZIP                VARCHAR(10),
  PHONE              VARCHAR(40),
  PHONE_COUNTRY_CODE VARCHAR(3),
  FAX                VARCHAR(40),
  FAX_COUNTRY_CODE   VARCHAR(3),
  HSE_NBR_ALPHA_START VARCHAR(20),
  HSE_NBR_ALPHA_END   VARCHAR(20),
  LEVEL_PREFIX        VARCHAR(20),
  LEVEL_NBR_START     VARCHAR(20),
  LEVEL_NBR_END       VARCHAR(20),
  VALIDATE_ADDR_FLAG  VARCHAR(1),
  PRIMARY_ADDR_FLAG   VARCHAR(1)
)
GO

-- Standard Map tables for Assets 
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_AMS_MASTER')
BEGIN
DROP TABLE AATABLE_AMS_MASTER
END
GO

CREATE TABLE AATABLE_AMS_MASTER (
ASSET_ID                VARCHAR(65) NOT NULL,
ASSET_HIST_TYPE         VARCHAR(100)    NOT NULL,   -- Historical Asset type
ASSET_GROUP             VARCHAR(30) NOT NULL, -- Refers to RASSET_TYPE.R1_ASSET_GROUP
ASSET_TYPE              VARCHAR(30) NOT NULL, -- Refers to RASSET_TYPE.R1_ASSET_TYPE
CLASS_TYPE							VARCHAR(30) NOT NULL, -- Refers to RASSET_TYPE.R1_CLASS_TYPE
ASSET_DESC              VARCHAR(255),
ASSET_STATUS            VARCHAR(30) DEFAULT  'Active', -- Standard Choice of 'ASSET_STATUS'
ASSET_STATUS_DATE       DATETIME,
ASSET_COMMENTS          VARCHAR(2000),
START_VALUE             NUMERIC(17,4), -- INITIAL VALUE OF ASSET
DATE_OF_SERVICE         DATETIME,
USEFUL_LIFE             NUMERIC(15,2),
SALVAGE_VALUE           NUMERIC(17,4),
CURRENT_VALUE           NUMERIC(17,4),
DEPRECIATION_START_DATE DATETIME,
DEPRECIATION_END_DATE   DATETIME,
DEPRECIATION_AMOUNT     NUMERIC(17,4),
DEPRECIATION_VALUE      NUMERIC(17,4),
ASSET_START_ID          VARCHAR(30),
ASSET_END_ID            VARCHAR(30),
DEPENDENCIES_FLAG       VARCHAR(1),
ASSET_SIZE              NUMERIC(15,2),
ASSET_SIZE_UNIT         VARCHAR(30),  -- Standard Choice of 'ASSET_SIZE_UNIT'    %%%%%%%%%%%%%%%
RES_ID					NUMERIC,
G1_ASSET_NAME			VARCHAR(50)
) 
GO


/* ***** Translation Tables List ***** 

ASSET Status Translation Table
ASSET Type Translation Table
Asset Size Unit Translation Table

*/
--ALTER TABLE AMS_MASTER ADD CONSTRAINT AMS_MASTER_PK PRIMARY KEY (ASSET_ID, ASSET_HIST_TYPE, ASSET_GROUP, ASSET_TYPE)
ALTER TABLE AATABLE_AMS_MASTER ADD CONSTRAINT AATABLE_AMS_MASTER_PK PRIMARY KEY (ASSET_ID,  ASSET_GROUP, ASSET_TYPE)
CREATE UNIQUE INDEX AATABLE_AMS_MASTER_UIX ON AATABLE_AMS_MASTER(ASSET_ID, ASSET_HIST_TYPE)

GO


IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_AMS_ATTRIBUTE')
BEGIN
DROP TABLE AATABLE_AMS_ATTRIBUTE
END
GO

CREATE TABLE AATABLE_AMS_ATTRIBUTE(
ASSET_ID                VARCHAR(65)     NOT NULL,
ASSET_HIST_TYPE         VARCHAR(100)    NOT NULL,   -- Historical Asset type
ASSET_ATTRIB_TEMP_NAME  VARCHAR(30)     NOT NULL,
ASSET_ATTRIB_NAME       VARCHAR(30)     NOT NULL,
ASSET_ATTRIB_VALUE      VARCHAR(2000),
IS_HIDDEN				VARCHAR(1)
)
GO

/* ***** Translation Tables List ***** 
Asset Attribute Translation Table
*/

ALTER TABLE AATABLE_AMS_ATTRIBUTE ADD CONSTRAINT AATABLE_AMS_ATTRIBUTE_PK PRIMARY KEY (ASSET_ID, ASSET_HIST_TYPE, ASSET_ATTRIB_NAME)
CREATE UNIQUE INDEX AATABLE_AMS_ATTRIBUTE_UIX ON AATABLE_AMS_ATTRIBUTE(asset_id, asset_hist_type)

GO


IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_AMS_ATTRIBUTE_TABLE')
BEGIN
DROP TABLE AATABLE_AMS_ATTRIBUTE_TABLE
END
GO

CREATE TABLE AATABLE_AMS_ATTRIBUTE_TABLE(
ASSET_ID                VARCHAR(65)   NOT NULL,
ASSET_HIST_TYPE         VARCHAR(100)  NOT NULL,   -- Historical Asset type
ASSET_ATTRIB_TAB_NAME 	VARCHAR(30)   NOT NULL,
ASSET_ATTRIB_NAME       VARCHAR(30)   NOT NULL,
ATTRIB_ROW_INDEX		    NUMERIC(5)    NOT NULL, 
ASSET_ATTRIB_VALUE      VARCHAR(2000)
)
GO

/* ***** Translation Tables List ***** 

Asset Attribute Table Translation Table

*/
CREATE UNIQUE INDEX AATABLE_AMS_ATTRIBUTE_TABLE_UIX ON AATABLE_AMS_ATTRIBUTE_TABLE(ASSET_ID, ASSET_HIST_TYPE ,ASSET_ATTRIB_TAB_NAME, ASSET_ATTRIB_NAME, ATTRIB_ROW_INDEX)
GO


IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_AMS_ASSET_ASSET')
BEGIN
DROP TABLE AATABLE_AMS_ASSET_ASSET
END
GO

CREATE TABLE AATABLE_AMS_ASSET_ASSET(
PARENT_ASSET_ID         VARCHAR(65)     NOT NULL,
PARENT_ASSET_HIST_TYPE  VARCHAR(100)    NOT NULL,   -- Historical Asset type
CHILD_ASSET_ID          VARCHAR(65)     NOT NULL,
CHILD_ASSET_HIST_TYPE   VARCHAR(100)    NOT NULL   -- Historical Asset type
)
GO

ALTER TABLE AATABLE_AMS_ASSET_ASSET ADD CONSTRAINT AATABLE_AMS_ASSET_ASSET_PK  PRIMARY KEY (PARENT_ASSET_ID, PARENT_ASSET_HIST_TYPE, CHILD_ASSET_ID, CHILD_ASSET_HIST_TYPE )
GO



IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = N'AATABLE_REFER_PEOPLE_LINKS')
BEGIN
DROP TABLE AATABLE_REFER_PEOPLE_LINKS
END
GO

CREATE TABLE AATABLE_REFER_PEOPLE_LINKS(
CONTACT_NBR NUMERIC(22) NOT NULL,
ENT_TYPE VARCHAR(50),
ENT_ID1 VARCHAR(100),
ENT_ID2 VARCHAR(255) ,
ENT_ID3 VARCHAR(255),
PRIMARY_FLAG varchar(10),
comments varchar(2000),
START_DATE DATETIME,
END_DATE DATETIME
)
GO
IF EXISTS (SELECT name  FROM sysobjects WHERE type = 'U' AND name = 'AATABLE_LIC_PROF' )
BEGIN
     DROP  Table  AATABLE_LIC_PROF
END

CREATE TABLE AATABLE_LIC_PROF (
serv_prov_code          varchar(15)  not null,
lic_nbr                 varchar(30)  not null,
lic_status              varchar(1)   not null,
lic_state               varchar(2)   not null,
tt_lic_type                varchar(255) not null,
bus_name                varchar(255) not null,
lic_orig_iss_dd         datetime,
last_renewal_dd         datetime,
lic_expir_dd            datetime,
cae_fname               varchar(70), 
cae_mname               varchar(70),
cae_lname               varchar(70),
address1                varchar(200),
address2                varchar(200),
city                    varchar(32),
state                   varchar(2),
zip			                varchar(10),
phone1			            varchar(40),
phone2			            varchar(40),
fax			                varchar(40),
email			              varchar(70),
lic_comment		          varchar(2000),
ins_co_name		          varchar(65),
ins_amount		          numeric(12,2),
ins_policy_no		        varchar(30),
ins_exp_dt		          datetime,
bus_lic			            varchar(15),
bus_lic_exp_dt		      datetime,
last_update_dd		      datetime,			-- not used at this time
lic_seq_nbr		          numeric,
rec_date		            datetime ,
rec_ful_nam		          varchar(70),
rec_flag		            varchar(1),
lic_board 	            varchar(255),
address3                varchar(200),
wc_exempt               varchar(1),
wc_policy_no            varchar(30),
wc_eff_dt               datetime,
wc_exp_dt               datetime,
wc_canc_dt              datetime,
suffix_name             varchar(10),
country                 varchar(30),
county_code             varchar(2),   
wc_ins_co_code          varchar(3),   
contr_lic_no            numeric,
cont_lic_bus_name       varchar(255),
ga_ivr_pin              numeric,
l1_salutation	          varchar(255),		
l1_gender	              varchar(1),		
l1_post_office_box      varchar(30),		
bus_name2               varchar(255),		
l1_birth_date           datetime,
phone1_country_code     varchar(3),
phone2_country_code     varchar(3),
fax_country_code        varchar(3),	
lic_type_flag                 varchar(20),
lic_social_security_nbr       varchar(11),	
lic_federal_employer_id_nbr   varchar(16),	
phone3                        varchar(40),	
phone3_country_code           varchar(3),	
aca_permission                varchar(1),		
l1_title                      varchar(255),		
past_days                     numeric
 );
go

  Create unique clustered index AATABLE_LIC_PROF01 on AATABLE_LIC_PROF (Serv_prov_code,Lic_nbr,tt_lic_type)
go

-- licensed professional attributes staging table

      IF EXISTS (SELECT name  FROM sysobjects WHERE type = 'U' AND name = 'AATABLE_LIC_PROF_ATTR' )
	  BEGIN
            DROP  Table  AATABLE_LIC_PROF_ATTR
	  END
go

Create table AATABLE_LIC_PROF_ATTR(
serv_prov_code          varchar(15) not null,
lic_nbr                 varchar(30) not null,
lic_type                varchar(255) not null,
attrib_temp_name        varchar(30) not null,
attrib_name             varchar(30) not null,
attrib_value            varchar(200) not null
 );
go

 create unique clustered index AATABLE_LIC_PROF_ATTR01 on AATABLE_LIC_PROF_ATTR(serv_prov_code, lic_nbr, lic_type, attrib_name)
go

-- TABLE LICENSED PROFESSIONAL ATTACHED TABLES
-- (all fields required for input to be processed)

      IF EXISTS (SELECT name  FROM sysobjects WHERE type = 'U' AND name = 'AATABLE_LIC_PROF_ATTACH' )
	  BEGIN
            DROP  Table  AATABLE_LIC_PROF_ATTACH
	  END
go

Create table AATABLE_LIC_PROF_ATTACH(
serv_prov_code		    varchar(15) not null,	--serv_prov_code to be processed
lic_nbr			        varchar(30) not null,	--license number
lic_type		        varchar(255) not null,
group_name		        varchar(12) not null,	--validated against r2chckbox.r1_checkbox_code
table_name		        varchar(30) not null,	--validated against r2chckbox.r1_checkbox_type
column_name		        varchar(100) not null,	--validated against r2chckbox.r1_checkbox_desc
row_num			        numeric not null,	--row number which provided field belongs to in the mapped attached table
attach_value		    varchar(240) not null	--input data value, must match expected data type or error will occur in app
 );
go

 create unique clustered index AATABLE_LIC_PROF_ATTACH01 on AATABLE_LIC_PROF_ATTACH(serv_prov_code, lic_nbr, lic_type, table_name, row_num, column_name)
go

-- AATABLE_TEMPLATE_ASI
IF EXISTS (SELECT name  FROM sysobjects WHERE type = 'U' AND name = 'AATABLE_TEMPLATE_ASI' )
BEGIN
	DROP  Table  AATABLE_TEMPLATE_ASI
END
go

Create table AATABLE_TEMPLATE_ASI(
ENTITY_TYPE 		    numeric not null,
ENTITY_ID 			    numeric not null,
GROUP_CODE 		        varchar(12) not null,
ASI_SUB_GROUP_CODE  	varchar(30) not null,
FIELD_NAME 		        varchar(100) not null,
FIELD_VALUE 		    varchar(4000) not null
 );
go

create unique clustered index AATABLE_TEMP_ASI_UIX on AATABLE_TEMPLATE_ASI(ENTITY_TYPE, ENTITY_ID,GROUP_CODE, ASI_SUB_GROUP_CODE, FIELD_NAME)
go

-- AATABLE_TEMPLATE_ASIT
IF EXISTS (SELECT name  FROM sysobjects WHERE type = 'U' AND name = 'AATABLE_TEMPLATE_ASIT' )
BEGIN
	DROP  Table  AATABLE_TEMPLATE_ASIT
END
go

Create table AATABLE_TEMPLATE_ASIT(
ENTITY_TYPE  		    numeric not null,
ENTITY_ID  			    numeric not null,
GROUP_CODE  		        varchar(12) not null,
ASI_SUB_GROUP_CODE    	varchar(30) not null,
FIELD_NAME  		        varchar(100) not null,
FIELD_VALUE  		    varchar(4000) not null,
ROW_INDEX 				numeric  not null 
 );
go

create unique clustered index AATABLE_TEMP_ASIT_UIX  on AATABLE_TEMPLATE_ASIT(ENTITY_TYPE, ENTITY_ID,GROUP_CODE, ASI_SUB_GROUP_CODE, FIELD_NAME,ROW_INDEX)
go

-- AATABLE_PERMIT_PAYMENTS
IF EXISTS (SELECT name  FROM sysobjects WHERE type = 'U' AND name = 'AATABLE_PERMIT_PAYMENTS' )
BEGIN
	DROP  Table  AATABLE_PERMIT_PAYMENTS
END
go

CREATE TABLE AATABLE_PERMIT_PAYMENTS (
PERMITNUM VARCHAR(30) NOT NULL,
PAY_KEY  VARCHAR(255) NOT NULL ,
PAYMENT_METHOD                                     VARCHAR(30) not null ,
PAYMENT_REF_NBR                                    VARCHAR(70 ),
CC_TYPE                                            VARCHAR(30 ),
PAYEE                                              VARCHAR(600 ),
PAYMENT_DATE                                       DATE  not null ,
PAYMENT_AMOUNT                                     NUMERIC(15,2) not null ,
TRANSACTION_CODE                                   VARCHAR(50 ),
TRANSACTION_NBR                                    VARCHAR(30 ),
PAYMENT_COMMENT                                    VARCHAR(2000 ),
CASHIER_ID                                         VARCHAR(70) default 'AA CONV'   ,
REGISTER_NBR                                       VARCHAR(8),
REC_DATE                                           DATE NOT NULL,
REC_FUL_NAM                                        VARCHAR(70 ) NOT NULL,
ACCT_ID                                            VARCHAR(15 ),
PAYEE_ADDRESS                                      VARCHAR(700 ),
PAYEE_PHONE                                        VARCHAR(240 ),
CC_AUTH_CODE                                       VARCHAR(30 ),
PAYEE_PHONE_IDD                                    VARCHAR(3 ),
PAYMENT_RECEIVED_CHANNEL                           VARCHAR(30 ),
CHECK_NUMBER                                       VARCHAR(30 ),
CHECK_TYPE                                         VARCHAR(100 ),
DRIVER_LICENSE                                     VARCHAR(100 ),
CHECK_HOLDER_NAME                                  VARCHAR(255 ),
CHECK_HOLDER_EMAIL                                 VARCHAR(80 ),
PHONE_NUMBER                                       VARCHAR(40 ),
COUNTRY                                            VARCHAR(30 ),
STATE                                              VARCHAR(30 ),
CITY                                               VARCHAR(30 ),
STREET                                             VARCHAR(240 ),
ZIP                                                VARCHAR(10 ),
REASON                                             VARCHAR(300 ),
PAYEE_TYPE                                         VARCHAR(255),
HIST_RECEIPT_NBR                                   VARCHAR(30), 
VOID_BY                                            VARCHAR(70),
VOID_DATE                                          DATE,
payment_pay_key                                    VARCHAR(255)
) ;
go

ALTER TABLE AATABLE_PERMIT_PAYMENTS ADD CONSTRAINT AATBL_PERMIT_PAYMENTS_PK PRIMARY KEY  (PERMITNUM, PAY_KEY) ;
go

-- AATABLE_PERMIT_RECEIPTS
IF EXISTS (SELECT name  FROM sysobjects WHERE type = 'U' AND name = 'AATABLE_PERMIT_RECEIPTS' )
BEGIN
	DROP  Table  AATABLE_PERMIT_RECEIPTS
END
go

CREATE TABLE  AATABLE_PERMIT_RECEIPTS (
HIST_RECEIPT_NBR  VARCHAR(30) not null ,
RECEIPT_DATE                              DATE NOT NULL ,
CASHIER_ID                                VARCHAR(70 ) NOT NULL ,
REGISTER_NBR                              VARCHAR(8 ),
RECEIPT_AMOUNT                            NUMERIC(15,2) not null ,
RECEIPT_COMMENT                           VARCHAR(800 ),
RECEIPT_STATUS                            VARCHAR(30 ),
TRANSACTION_CODE                          VARCHAR(50 ),
TRANSACTION_NBR                           VARCHAR(30 ),
REC_DATE                                   DATE NOT NULL ,
REC_FUL_NAM                                VARCHAR(70 ) NOT NULL,
TTERMINAL_ID                               VARCHAR(10 ),
WORKSTATION_ID                             VARCHAR(70 )
) ;

CREATE UNIQUE INDEX AATBL_PRMT_RCTS_idx1 ON AATABLE_PERMIT_RECEIPTS(HIST_RECEIPT_NBR);
go

go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0000\0000 0060 mssql_02_create_views.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0000\0000 0060 mssql_02_create_views.sql')
/*
SCRIPT: 02_CREATE_VIEWS.SQL
AUTHOR: DANE QUATACKER, ACCELA INC.
DATE: 11/22/2011
DESCRIPTION: CREATES BASE VIEWS FOR STANDARD MAP CONVERSION IN AN SQL SERVER DATABASE

UPDATES:
11/13/2012 - DQ - ADDED 7.2 FP2 UPDATES

*/
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_ACTIVITY')
BEGIN
DROP VIEW AASTD_PERMIT_ACTIVITY
END
go
CREATE VIEW AASTD_PERMIT_ACTIVITY AS
SELECT
  PERMITNUM,
  ACT_NAME,
  ACT_DES,
  ACT_TYPE,
  ACT_DATE,
  ACT_DEPT,
  ACT_STAF,
  REC_DATE,
  REC_FUL_NAM,
  INTERNAL_USE_ONLY,
  ACT_DUE_DATE,
  ACT_PRIORITY,
  ACT_STATUS,
  act_unique_id
FROM AATABLE_PERMIT_ACTIVITY
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_ACTIVITY_ASI')
BEGIN
DROP VIEW AASTD_PERMIT_ACTIVITY_ASI
END
go
CREATE VIEW AASTD_PERMIT_ACTIVITY_ASI AS
SELECT 
PERMITNUM,
act_unique_id,
asi_group_code, 
asi_sub_group ,
asi_field_label,
asi_field_value
FROM AATABLE_PERMIT_ACTIVITY_ASI
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_ADDRESS')
BEGIN
DROP VIEW AASTD_PERMIT_ADDRESS
END
go
CREATE VIEW AASTD_PERMIT_ADDRESS AS
SELECT
  PERMITNUM,
  ISPRIMARY,
  STR_NUM_START,
  STR_NUM_END,
  STR_FRAC_START,
  STR_FRAC_END,
  STR_DIR,
  STR_NAME,
  STR_SUFFIX,
  STR_SUFFIX_DIR,
  STR_PREFIX,
  STR_UNIT_START,
  STR_UNIT_END,
  STR_UNIT_TYPE,
  SITUS_CITY,
  SITUS_STATE,
  SITUS_ZIP,
  SITUS_COUNTY,
  SITUS_COUNTRY,
  SITUS_COUNTRY_CODE,
  X_COORD,
  Y_COORD,
  ADDR_DESC,
  FULL_ADDRESS,
  ADDRESS1,
  ADDRESS2,
  SITUS_NBRHD,
  EXT_ADDRESS_UID,
  STREET_NAME_START, -- Added by OMATKARI 8/19/18
  STREET_NAME_END, -- Added by OMATKARI 8/19/18
  CROSS_STREET_NAME_START, -- Added by OMATKARI 8/19/18
  CROSS_STREET_NAME_END, -- Added by OMATKARI 8/19/18
  HSE_NBR_ALPHA_START,	-- Added By ALTARAZI 04/09/19
  HSE_NBR_ALPHA_END,	-- Added By ALTARAZI 04/09/19
  LEVEL_PREFIX,			-- Added By ALTARAZI 04/09/19
  LEVEL_NBR_START,	-- Added By ALTARAZI 04/09/19
  LEVEL_NBR_END 		-- Added By ALTARAZI 04/09/19
FROM AATABLE_PERMIT_ADDRESS
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_ADDRESS_TYPE')
BEGIN
DROP VIEW AASTD_PERMIT_ADDRESS_TYPE
END
go
CREATE VIEW AASTD_PERMIT_ADDRESS_TYPE AS
SELECT
  PERMITNUM,
  FULL_ADDRESS,
  ADDRESS_TYPE
FROM AATABLE_PERMIT_ADDRESS_TYPE
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_ATTRIB')
BEGIN
DROP VIEW AASTD_PERMIT_ATTRIB
END
go
CREATE VIEW AASTD_PERMIT_ATTRIB AS
SELECT
  PERMITNUM,
  ATTRIB_TYPE,
  ATTRIB_TEMP_NAME,
  ATTRIB_NAME,
  ATTRIB_VALUE,
  ATTRIB_KEY
FROM AATABLE_PERMIT_ATTRIB
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_CALCVALUATN')
BEGIN
DROP VIEW AASTD_PERMIT_CALCVALUATN
END
go
CREATE VIEW AASTD_PERMIT_CALCVALUATN AS
SELECT
  PERMITNUM,
  OCC_TYPE,
  CONST_TYPE,
  UNIT_VALUE,
  AREA,
  TOTALVALUE,
  UNIT_TYPE,
  VALUATN_VERSION
FROM AATABLE_PERMIT_CALCVALUATN
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_COMMENT')
BEGIN
DROP VIEW AASTD_PERMIT_COMMENT
END
go
CREATE VIEW AASTD_PERMIT_COMMENT AS
SELECT
  PERMITNUM,
  COMMENTS,
  ADDEDBY,
  ADDEDDATE
FROM AATABLE_PERMIT_COMMENT
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_CONDITIONS')
BEGIN
DROP VIEW AASTD_PERMIT_CONDITIONS
END
go
CREATE VIEW AASTD_PERMIT_CONDITIONS AS
SELECT
  PERMITNUM,
  CON_COMMENTS,
  CON_DES,
  CON_IMPACT_CODE,
  EFFECTIVE_DATE,
  EXPIR_DATE,
  ISS_DD,
  STAT_DD,
  CON_STATUS,
  CON_TYPE,
  DISPLAY_ORDER,
  CON_INHERITABLE,
  CON_GROUP,
  ISS_USER_ID,
  STAT_USER_ID,
  INC_CON_NAME,
  INC_SHORT_DESC,
  DIS_CON_NOTICE,
  CON_STATUS_TYP,
  LONG_COMMENTS
FROM AATABLE_PERMIT_CONDITIONS
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_CONT_EDU')
BEGIN
DROP VIEW AASTD_PERMIT_CONT_EDU
END
go
CREATE VIEW AASTD_PERMIT_CONT_EDU AS
SELECT
  PERMITNUM,
  PROVIDER_NAME,
  CONT_EDU_NAME,
  IS_REQUIRED,
  EDU_CLASS,
  DATE_OF_CLASS,
  HOURS_COMPLETED,
  GRADING_STYLE,
  FINAL_SCORE,
  PASSING_SCORE,
  EDU_COMMENTS,
  ADDR1,
  ADDR2,
  ADDR3,
  CITY,
  STATE,
  ZIP,
  PH1_COUNTRY_CODE,
  PH1,
  PH2_COUNTRY_CODE,
  PH2,
  FAX_COUNTRY_CODE,
  FAX,
  EMAIL,
  B1_COUNTRY
FROM AATABLE_PERMIT_CONT_EDU
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_EDUCATION')
BEGIN
DROP VIEW AASTD_PERMIT_EDUCATION
END
go
CREATE VIEW AASTD_PERMIT_EDUCATION AS
SELECT
  PERMITNUM,
  PROVIDER_NAME,
  EDUCATION_NAME,
  EDU_DEGREE,
  YEAR_ATTENDED,
  YEAR_GRADUATED,
  EDU_COMMENTS,
  IS_REQUIRED,
  ADDR1,
  ADDR2,
  ADDR3,
  CITY,
  STATE,
  ZIP,
  PH1_COUNTRY_CODE,
  PH1,
  PH2_COUNTRY_CODE,
  PH2,
  FAX_COUNTRY_CODE,
  FAX,
  EMAIL,
  B1_COUNTRY
FROM AATABLE_PERMIT_EDUCATION
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_EXAM')
BEGIN
DROP VIEW AASTD_PERMIT_EXAM
END
go
CREATE VIEW AASTD_PERMIT_EXAM AS
SELECT
  PERMITNUM,
  PROVIDER_NAME,
  EXAM_NAME,
  IS_REQUIRED,
  EXAM_DATE,
  GRADING_STYLE,
  FINAL_SCORE,
  PASSING_SCORE,
  EXAM_COMMENTS,
  ADDR1,
  ADDR2,
  ADDR3,
  CITY,
  STATE,
  ZIP,
  PH1_COUNTRY_CODE,
  PH1,
  PH2_COUNTRY_CODE,
  PH2,
  FAX_COUNTRY_CODE,
  FAX,
  EMAIL,
  B1_COUNTRY
FROM AATABLE_PERMIT_EXAM
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_FEE')
BEGIN
DROP VIEW AASTD_PERMIT_FEE
END
go
CREATE VIEW AASTD_PERMIT_FEE AS
SELECT
  PERMITNUM,
  FEE_KEY,
  GF_FEE_PERIOD,
  FEE_ITEM_AMOUNT,
  GF_DISPLAY,
  ACCOUNT_CODE1,
  ACCOUNT_CODE2,
  ACCOUNT_CODE3,
  GF_FEE_SCHEDULE,
  REC_DATE,
  REC_FUL_NAM,
  GF_UNIT,
  INVOICE,
  FEE_NOTES,
  FEE_SCHEDULE_VERSION,
  INVOICE_CUSTOMIZED_NBR,
  TT_FEE_CODE,
  TT_FEE_DESC,
  GF_FEE_TYPE_ALLOCATION,
  GF_L1_ALLOCATION,
  GF_L2_ALLOCATION,
  GF_L3_ALLOCATION,
  VOID_FLAG,
  GF_FEE_APPLY_DATE
FROM AATABLE_PERMIT_FEE
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_FEEALLOCATION')
BEGIN
DROP VIEW AASTD_PERMIT_FEEALLOCATION
END
go
CREATE VIEW AASTD_PERMIT_FEEALLOCATION AS
SELECT
PERMITNUM,
FEE_KEY,
PAY_KEY,
FEE_ALLOCATION
FROM AATABLE_PERMIT_FEEALLOCATION
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_GUIDESHEET')
BEGIN
DROP VIEW AASTD_PERMIT_GUIDESHEET
END
go
CREATE VIEW AASTD_PERMIT_GUIDESHEET AS
SELECT
  PERMITNUM,
  INSP_NUMBER,
  GUIDE_KEY,
  TT_ITEM_STATUS,
  COMMENTS,
  SCORE,
  TT_GUIDE_TYPE,
  TT_GUIDE_ITEM,
  TEAM_NAME,
  FLOOR,
  FLOOR_UNIT,
  HISTORICAL_GUIDE_TEXT,
  HISTORICAL_GUIDE_ITEM_STATUS_GROUP 
FROM AATABLE_PERMIT_GUIDESHEET
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_HISTORY')
BEGIN
DROP VIEW AASTD_PERMIT_HISTORY
END
go
CREATE VIEW AASTD_PERMIT_HISTORY AS
SELECT
  PERMITNUM,
  CONTRACTOR_VALUATION,
  DATEOPENED,
  EXPIRATION_DATE,
  EXPIRATION_STATUS,
  WORK_DESC,
  APP_NAME,
  HOUSE_COUNT,
  BUILDING_COUNT,
  PUBLIC_OWNED,
  CONST_TYPE_CODE,
  SHORT_NOTES,
  ASGN_DEPT,
  ASGN_STAFF,
  ASGN_DATE,
  COMPLETED_DEPT,
  COMPLETED_BY,
  COMPLETED_DATE,
  SCHEDULED_DATE,
  PRIORITY,
  TOTAL_JOB_COST,
  CLOSED_DATE,
  CLOSED_BY,
  IVR_TRACKING_NUM,
  CREATED_BY,
  REPORTED_CHANNEL,
  CREATED_BY_DEPT,
  FIRST_ISSUED_DATE,
  ANONYMOUS_FLAG,
  REFERENCE_TYPE,
  APPEARANCE_DAYOFWEEK,
  APPEARANCE_DATE,
  BOOKING_FLAG,
  DEFENDANT_SIGNATURE_FLAG,
  ENFORCE_OFFICER_ID,
  ENFORCE_OFFICER_NAME,
  INFRACTION_FLAG,
  INSPECTOR_ID,
  MISDEMEANOR_FLAG,
  OFFENCE_WITNESSED_FLAG,
  INSPECTOR_NAME,
  ENFORCE_DEPT,
  INSPECTOR_DEPT,
  VALUATION_MULTIPLIER,
  VALUATION_EXTRA_AMT,
  LAST_AUDIT_DATE,
  APP_STATUS_DATE,
  DELEGATE_USER_ID,
  TT_RECORD_STATUS,
  TT_RECORD,
  BALANCE,
  TOTAL_FEE,
  TOTAL_PAY,
  LAST_UPDATE_BY,
  LAST_UPDATE_DATE
FROM AATABLE_PERMIT_HISTORY
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_INSP')
BEGIN
DROP VIEW AASTD_PERMIT_INSP
END
go
CREATE VIEW AASTD_PERMIT_INSP AS
SELECT
  PERMITNUM,
  INSPDATE,
  INSPSCHEDDATE,
  INSPREQDATE,
  INSP_NUMBER,
  INSP_REQUIRED,
  PHONE_NUM,
  LATITUDE,
  LONGITUDE,
  INSP_RESULT_COMM,
  INSP_SCHED_COMM,
  SD_OVERTIME,
  DISPLAY_IN_ACA,
  TT_INSPECTION,
  TT_INSPECTION_STATUS,
  CONTACT_NBR,
  INSP_SEQ_NBR,
  USER_ID,
  ORDER_BY,
  G6_ACT_T1,
  G6_ACT_T2,
  G6_ACT_END_T1,
  G6_ACT_END_T2,
  G6_ACT_TT,
  ESTIMATED_START_TIME,
  ESTIMATED_END_TIME,
  G6_DESI_DD,
  G6_DESI_TIME,
  G6_DESI_TIME2,
  CONTACT_PHONE_NUM,
  CONTACT_PHONE_NUM_IDD,
  CONTACT_FNAME,
  CONTACT_MNAME,
  CONTACT_LNAME,
  G6_REQ_PHONE_NUM_IDD,
  G6_REQ_PHONE_NUM,
  MAJOR_VIOLATION_COUNT,
  UNIT_NBR,
  GRADE,
  TOTAL_SCORE,
  VEHICLE_NUM,
  G6_MILE_T1 ,
  G6_MILE_T2 ,
  G6_MILE_TT ,
  INSP_CANCELLED,
  INSP_PENDING,
  CLIENT_UNIQUE_ID 
FROM AATABLE_PERMIT_INSP
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_INSPDISTRICTS')
BEGIN
DROP VIEW AASTD_PERMIT_INSPDISTRICTS
END
go
CREATE VIEW AASTD_PERMIT_INSPDISTRICTS AS
SELECT
  PERMITNUM,
  DIST_TYPE,
  DIST_KEY,
  INSP_DISTRICT
FROM AATABLE_PERMIT_INSPDISTRICTS
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_PARCEL')
BEGIN
DROP VIEW AASTD_PERMIT_PARCEL
END
go
CREATE VIEW AASTD_PERMIT_PARCEL AS
SELECT
  PERMITNUM,
  PARCELNUM,
  BOOK,
  PAGE,
  PARCEL,
  LOT,
  BLOCK,
  TRACT,
  LEGAL_DESC,
  PARCEL_AREA,
  PLAN_AREA,
  CENSUS_TRACT,
  COUNCIL_DISTRICT,
  SUPERVISOR_DISTRICT,
  INSPECTION_DISTRICT,
  LAND_VALUE,
  IMPROVED_VALUE,
  EXEMPT_VALUE,
  MAP_REFERENCE,
  MAP_NUMBER,
  SUBDIVISION,
  PRIMARY_FLAG,
  TOWNSHIP,
  RANGE,
  SECTION,
  EXT_PARCEL_UID
FROM AATABLE_PERMIT_PARCEL
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_PEOPLE')
BEGIN
DROP VIEW AASTD_PERMIT_PEOPLE
END
go
CREATE VIEW AASTD_PERMIT_PEOPLE AS
SELECT
  PERMITNUM,
  TT_CONTACT_TYPE,
  CONTACT_RELATIONSHIP,
  ISPRIMARY,
  LIC_NUM,
  LIC_TYPE,
  NAME,
  FNAME,
  MNAME,
  LNAME,
  BUS_NAME,
  ADDR1,
  ADDR2,
  ADDR3,
  CITY,
  STATE,
  ZIP,
  PH1,
  PH2,
  FAX,
  EMAIL,
  COMMENTS,
  TITLE,
  PH3,
  COUNTRY_CODE,
  NOTIFY,
  NAME_SUFFIX,
  BUS_LIC,
  LIC_ORIGINAL_ISSUE_DATE,
  EXPIRATION_DATE,
  RENEWAL_DATE,
  MAIL_ADDR1,
  MAIL_ADDR2,
  MAIL_ADDR3,
  MAIL_CITY,
  MAIL_STATE,
  MAIL_ZIP,
  MAIL_COUNTRY,
  OWNER_TYPE,
  GENDER,
  SALUTATION,
  PO_BOX,
  BUS_NAME2,
  BIRTH_DATE,
  PH1_COUNTRY_CODE,
  PH2_COUNTRY_CODE,
  FAX_COUNTRY_CODE,
  PH3_COUNTRY_CODE,
  TRADE_NAME,
  CONTACT_TYPE_FLAG,
  SOCIAL_SECURITY_NUMBER,
  FEDERAL_EMPLOYER_ID_NUM,
  CONTRA_TYPE_FLAG,
  LIC_BOARD,
  B1_ID,
  CONT_LIC_BUS_NAME,
  B1_ACCESS_LEVEL,
  BIRTH_CITY,
  BIRTH_STATE,
  BIRTH_REGION,
  B1_CONTACT_NBR,
  DECEASED_DATE,
  DRIVER_LIC_NBR,
  DRIVER_LIC_STATE,
  RACE,
  PASSPORT_NBR,
  STATE_ID_NBR,
  G1_CONTACT_NBR,
  LIC_STATE
FROM AATABLE_PERMIT_PEOPLE
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_PEOPLEATTRIB')
BEGIN
DROP VIEW AASTD_PERMIT_PEOPLEATTRIB
END
go
CREATE VIEW AASTD_PERMIT_PEOPLEATTRIB AS
SELECT
  PERMITNUM,
  ATTRIB_KEY,
  ATTRIB_TEMP_NAME,
  ATTRIB_TYPE,
  ATTRIB_NAME,
  NAME,
  ATTRIB_VALUE
FROM AATABLE_PERMIT_PEOPLEATTRIB
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_PEOPLELICTABLE')
BEGIN
DROP VIEW AASTD_PERMIT_PEOPLELICTABLE
END
go
CREATE VIEW AASTD_PERMIT_PEOPLELICTABLE AS
SELECT
  PERMITNUM,
  LIC_NUM,
  LIC_TYPE,
  TABLE_NAME,
  COLUMN_NAME,
  ROW_NUM,
  COLUMN_NUM,
  TABLE_VALUE
FROM AATABLE_PERMIT_PEOPLELICTABLE
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_PROJECTS')
BEGIN
DROP VIEW AASTD_PERMIT_PROJECTS
END
go
CREATE VIEW AASTD_PERMIT_PROJECTS AS
SELECT
  PARENTACTIVITYNUM,
  CHILDACTIVITYNUM,
  RELATIONSHIP,
  STATUS
FROM AATABLE_PERMIT_PROJECTS
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_STATUS')
BEGIN
DROP VIEW AASTD_PERMIT_STATUS
END
go
CREATE VIEW AASTD_PERMIT_STATUS AS
SELECT
  PERMITNUM,
  STATUS,
  STATUS_DATE,
  STATUS_COMMENT, 
  USER_ID,
  ORDER_BY
FROM AATABLE_PERMIT_STATUS
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_STRU_ESTA')
BEGIN
DROP VIEW AASTD_PERMIT_STRU_ESTA
END
go
CREATE VIEW AASTD_PERMIT_STRU_ESTA AS
SELECT
  PERMITNUM,
  L1_NUMBER,
  L1_GROUP,
  L1_TYPE
FROM AATABLE_PERMIT_STRU_ESTA
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_WORKFLOW')
BEGIN
DROP VIEW AASTD_PERMIT_WORKFLOW
END
go
CREATE VIEW AASTD_PERMIT_WORKFLOW AS
SELECT
  PERMITNUM,
  TASKUPDATED,
  COMMENTS,
  ASGN_DATE,
  DUE_DATE,
  TT_WORKFLOW_TASK,
  TT_WORKFLOW_STATUS,
  USER_ID,
  ID,
  SD_HOURS_SPENT,
  SD_BILLABLE,
  SD_OVERTIME,
  ESTIMATED_HOURS,
  ASGN_EMAIL_DISPLAY_FOR_ACA,
  RESTRICT_COMMENT_FOR_ACA,
  RESTRICT_ROLE,
  TASK_UNIQUE_ID 
FROM AATABLE_PERMIT_WORKFLOW
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_TRUST_ACCOUNT_TRANS')
BEGIN
DROP VIEW AASTD_TRUST_ACCOUNT_TRANS
END
go
CREATE VIEW AASTD_TRUST_ACCOUNT_TRANS AS
SELECT
  ACCOUNT_ID,
  TRANS_TYPE,
  TRANS_AMOUNT,
  TRANS_DATE,
  TRANS_BY,
  TARGET_ACCT_ID,
  PERMITNUM,
  PAY_KEY
FROM AATABLE_TRUST_ACCOUNT_TRANS
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_TRUST_ACCOUNTS')
BEGIN
DROP VIEW AASTD_TRUST_ACCOUNTS
END
go
CREATE VIEW AASTD_TRUST_ACCOUNTS AS
SELECT
  ACCOUNT_ID,
  ACCOUNT_BALANCE,
  LEDGER_ACCOUNTNUM,
  ACCT_DESC,
  ACCT_STATUS,
  ACCT_OVERDRAFT,
  ACCT_OVERDRAFTLIMIT,
  THRESHOLD_AMT
FROM AATABLE_TRUST_ACCOUNTS
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_TRUST_ACCT_PEOPLE_LINKS')
BEGIN
DROP VIEW AASTD_TRUST_ACCT_PEOPLE_LINKS
END
go
CREATE VIEW AASTD_TRUST_ACCT_PEOPLE_LINKS AS
SELECT
ACCOUNT_ID,
CONTACT_NBR,
LIC_NBR,
LIC_TYPE,
LIC_STATE
FROM AATABLE_TRUST_ACCT_PEOPLE_LINKS
go

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_AUDIT_SETS')
BEGIN
DROP VIEW AASTD_PERMIT_AUDIT_SETS
END
GO

CREATE VIEW AASTD_PERMIT_AUDIT_SETS
AS
SELECT
PERMITNUM,
SET_ID
FROM AATABLE_PERMIT_AUDIT_SETS
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_permit_TaskSpecAdHoc')
BEGIN
DROP VIEW AASTD_permit_TaskSpecAdHoc
END
GO

CREATE VIEW AASTD_PERMIT_TASKSPECADHOC
AS
SELECT
PERMITNUM,
TASK_SPEC_CODE,
TASK_SPEC_TYPE,
TASK_SPEC_NAME,
TASK_SPEC_VALUE,
PROCESS_CODE,
TASK_DESC,
SD_STP_NUM
FROM AATABLE_PERMIT_TASKSPECADHOC
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_pos_transaction')
BEGIN
DROP VIEW AASTD_pos_transaction
END
GO 

CREATE VIEW AASTD_pos_transaction 
AS
SELECT
	tran_key, -- Loaded it to f4pos_transaction.batch_transaction_nbr
	module_name,
	pos_trans_type 
FROM AATABLE_pos_transaction
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_pos_trans_fee')
BEGIN
DROP VIEW AASTD_pos_trans_fee
END
GO

CREATE VIEW AASTD_pos_trans_fee 
AS
SELECT
	tran_key, 
	fee_key,
	gf_cod,
	gf_des,
	gf_unit,
	gf_fee,
	gf_fee_apply_date,
	gf_sub_group,
	gf_fee_schedule,
	gf_fee_schedule_version,
	fee_notes
FROM AATABLE_pos_trans_fee
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_pos_trans_pay')
BEGIN
DROP VIEW AASTD_pos_trans_pay
END
GO 

CREATE VIEW AASTD_pos_trans_pay
AS
SELECT
	tran_key,
	pay_key,
	payment_status,
	payment_amount,
	payment_date,
	cashier_id,
	payment_method,
	payment_ref_nbr,
	payee,
	payee_address,
	payee_phone,
	cc_auth_code,
	payment_comment,
	HIST_RECEIPT_NBR,
	register_nbr,
	VOID_DATE,
	VOID_BY
FROM AATABLE_pos_trans_pay
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_TRUST')
BEGIN
DROP VIEW AASTD_PERMIT_TRUST
END
GO

CREATE VIEW AASTD_PERMIT_TRUST
AS
SELECT
PERMITNUM,
TRUST_ACCOUNT_ID
FROM AATABLE_PERMIT_TRUST
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_permit_time_accounting')
BEGIN
DROP VIEW AASTD_permit_time_accounting
END
GO

CREATE VIEW AASTD_permit_time_accounting
AS
SELECT
    permitnum,
    tt_time_group_name,
    tt_time_type_name,
    billable_flag,
    log_date,
    time_start,
    time_end,
    time_elapsed,
    total_minutes,
    materials_desc,
    materials_cost,
    Mileage_start,
    Mileage_end,
    Milage_total,
    vehicle_id,
    entry_rate,
    entry_pct,
    entry_cost,
    created_date,
    created_by,
    notation,
    group_seq_nbr,
    entity_id,
    entity_type, 
    user_name,
    Unique_Id,
	TIME_LOG_STATUS,
	RECORD_TYPE 
FROM AATABLE_permit_time_accounting
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_WORKFLOWADHOC')
BEGIN
DROP VIEW AASTD_PERMIT_WORKFLOWADHOC
END
GO

CREATE VIEW AASTD_permit_workflowAdHoc 
AS
SELECT
  PERMITNUM,
  TASK_DESC,
  TASK_STATUS,
  TASKUPDATED,
  FNAME,
  MNAME,
  LNAME,
  COMMENTS,
  PROCESS_CODE,
  CHECK_LEVEL1,
  CHECK_LEVEL2, 
  G6_ASGN_DD,
  B1_DUE_DD,
  SD_DUE_DAY,
  SD_NOTE,
  SD_STP_NUM,
  ASGN_AGENCY_CODE,
  ASGN_BUREAU_CODE,
  ASGN_DIVISION_CODE,
  ASGN_GROUP_CODE,
  ASGN_SECTION_CODE,
  ASGN_OFFICE_CODE,
  ASGN_FNAME,
  ASGN_MNAME,
  ASGN_LNAME
FROM AATABLE_permit_workflowAdHoc
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_COSTING_AMS')
BEGIN
DROP VIEW AASTD_PERMIT_COSTING_AMS
END
GO 
CREATE  VIEW AASTD_PERMIT_COSTING_AMS 
AS
SELECT
	PERMITNUM,
	COST_NAME,
	COST_DATE,
	COST_TYPE,
	COST_ITEM,
	COST_FIX,
	COST_FACTOR,
	COST_UNIT_COST,
	COST_UNIT_TYPE,
	COST_QUANTITY,
	COST_ITEM_TOTAL,
	COST_COMMENTS,
	UPDATED_BY,
	UPDATED_DATE,
	COST_STATUS,
	START_TIME,
	END_TIME,
	RELATED_ASGN_NBR,
	TASK_CODE,
	TASK_CODE_INDEX
FROM AATABLE_PERMIT_COSTING_AMS
GO


IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_ASSET_AMS')
BEGIN
DROP VIEW AASTD_PERMIT_ASSET_AMS
END
GO

CREATE VIEW  AASTD_PERMIT_ASSET_AMS 
AS
SELECT
PERMITNUM,
ASSET_ID,
ASSET_GROUP,
ASSET_TYPE,
WOASSET_ORDER,
WOASSET_COMPLETE,
WOASSET_COMPLETE_DATE,
WOASSET_SHORT_NOTES
FROM AATABLE_PERMIT_ASSET_AMS
GO


IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_TASK_AMS')
BEGIN
DROP VIEW AASTD_PERMIT_TASK_AMS
END
GO

CREATE VIEW  AASTD_PERMIT_TASK_AMS
AS
SELECT
	PERMITNUM,
	TASK_CODE,
	TASK_CODE_INDEX,
	TASK_DESCRIPTION,
	OPERATION_PROCEDURE,
	ESTIMATE_EFFORT,
	DURATION_UNIT,
	ACTUAL_EFFORT,
	COMPLETE_DATE,
	COMPLETE_BY,
	COMMENTS,
	TASK_ORDER
FROM AATABLE_PERMIT_TASK_AMS
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_COST_DIST')
BEGIN
DROP VIEW AASTD_PERMIT_COST_DIST 
END
GO

CREATE VIEW AASTD_PERMIT_COST_DIST 
AS
SELECT
	PERMITNUM,
	ASSET_ID,
	ASSET_HIST_TYPE,
	PART_NUMBER,
	COST_NAME
FROM AATABLE_PERMIT_COST_DIST
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'aastd_permit_part_ams')
BEGIN
DROP VIEW aastd_permit_part_ams
END
go

create view aastd_permit_part_ams 
as
select
	permitnum,
	transaction_type,
	transaction_date,
	quantity,
	Part_number,
	location_name,
	Part_bin,
	taxable,
	part_brand,
	part_description,
	Part_type,
	unit_of_measurement,
	unit_of_cost,
	comments,
	last_updated_date,
	last_updated_by
from aatable_permit_part_ams
go


IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_REFER_PEOPLE')
BEGIN
DROP VIEW AASTD_REFER_PEOPLE 
END
GO

CREATE VIEW AASTD_REFER_PEOPLE 
AS
SELECT 
CONTACT_NBR,
TT_CONTACT_TYPE,
TITLE,
FNAME,
MNAME,
LNAME,
NAME_SUFFIX,
FULL_NAME,
BUS_NAME,
ADDR1,
ADDR2,
ADDR3,
CITY,
STATE,
ZIP,
COUNTRY,
PH1,
PH2,
FAX,
EMAIL,
G1_ID,
G1_FLAG,
COMMENTS,
RELATION,
G1_PREFERRED_CHANNEL,
COUNTRY_CODE,
GA_IVR_PIN,
PH3,
SALUTATION,
GENDER,
POST_OFFICE_BOX,
BIRTH_DATE,
PH1_COUNTRY_CODE,
PH2_COUNTRY_CODE,
PH3_COUNTRY_CODE,
FAX_COUNTRY_CODE,
SOCIAL_SECURITY_NUMBER,
FEDERAL_EMPLOYER_ID_NUM,
TRADE_NAME,
CONTACT_TYPE_FLAG,
BUSINESS_NAME2,
BIRTH_CITY,
BIRTH_STATE,
BIRTH_REGION,
G1_RACE,
DECEASED_DATE,
PASSPORT_NBR,
DRIVER_LICENSE_NBR,
DRIVER_LICENSE_STATE,
STATE_ID_NBR
FROM AATABLE_REFER_PEOPLE
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_REFER_PEOPLECONDIT')
BEGIN
DROP VIEW AASTD_REFER_PEOPLECONDIT
END
GO


CREATE VIEW AASTD_REFER_PEOPLECONDIT
AS
SELECT 
  ENTITY_TYPE,
  ENTITY_ID,
  L1_CON_NBR,
  CON_COMMENT,
  CON_DES,
  CON_EFF_DD1,
  CON_EXPIR_DD,
  CON_IMPACT_CODE,
  CON_REF_NUM1,
  CON_REF_NUM2,
  CON_STATUS,
  CON_TYP,
  CON_LONG_COMMENT,
  CON_DIS_CON_NOTICE,
  CON_INC_CON_NAME,
  CON_INC_SHORT_DESC,
  CON_INHERITABLE,
  CON_STATUS_TYP,
  CON_GROUP,
  CON_DIS_NOTICE_ACA,
  CON_DIS_NOTICE_ACA_FEE,
  R3_CON_RESOLUTION_ACTION,
  R3_CON_PUBLIC_DIS_MESSAGE,
  PRIORITY,
  ADDITIONAL_INFORMATION
FROM AATABLE_REFER_PEOPLECONDIT
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_REFER_PEOPLEADDR')
BEGIN
DROP VIEW AASTD_REFER_PEOPLEADDR
END
GO

CREATE VIEW AASTD_REFER_PEOPLEADDR
AS
SELECT 
  ENTITY_TYPE,
  ENTITY_ID,
  ADDRESS_TYPE,
  EFF_DATE,
  EXPR_DATE,
  RECIPIENT,
  FULL_ADDRESS,
  ADDRESS1,
  ADDRESS2,
  ADDRESS3,
  HSE_NBR_START,
  HSE_NBR_END,
  STR_DIR,
  STR_PREFIX,
  STR_NAME,
  STR_SUFFIX,
  UNIT_TYPE,
  UNIT_START,
  UNIT_END,
  STR_SUFFIX_DIR,
  COUNTRY_CODE,
  CITY,
  STATE,
  ZIP,
  PHONE,
  PHONE_COUNTRY_CODE,
  FAX,
  FAX_COUNTRY_CODE,
  HSE_NBR_ALPHA_START,
  HSE_NBR_ALPHA_END,
  LEVEL_PREFIX,
  LEVEL_NBR_START,
  LEVEL_NBR_END,
  VALIDATE_ADDR_FLAG,
  PRIMARY_ADDR_FLAG
FROM AATABLE_REFER_PEOPLEADDR

GO

------------------------------------------------------------

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_AMS_MASTER')
BEGIN
DROP VIEW AASTD_AMS_MASTER
END
GO

CREATE VIEW AASTD_AMS_MASTER
AS
SELECT 
 ASSET_ID                 ,
 ASSET_HIST_TYPE          ,
 ASSET_GROUP              ,
 ASSET_TYPE               ,
 CLASS_TYPE				  ,
 ASSET_DESC               ,
 ASSET_STATUS             ,
 ASSET_STATUS_DATE        ,
 ASSET_COMMENTS           ,
 START_VALUE              ,
 DATE_OF_SERVICE          ,
 USEFUL_LIFE              ,
 SALVAGE_VALUE            ,
 CURRENT_VALUE            ,
 DEPRECIATION_START_DATE  ,
 DEPRECIATION_END_DATE    ,
 DEPRECIATION_AMOUNT      ,
 DEPRECIATION_VALUE       ,
 ASSET_START_ID           ,
 ASSET_END_ID             ,
 DEPENDENCIES_FLAG        ,
 ASSET_SIZE               ,
 ASSET_SIZE_UNIT          ,
 RES_ID					  ,
 G1_ASSET_NAME			  
FROM AATABLE_AMS_MASTER
GO



IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_AMS_ATTRIBUTE')
BEGIN
DROP VIEW AASTD_AMS_ATTRIBUTE
END
GO

CREATE VIEW AASTD_AMS_ATTRIBUTE
AS
SELECT 
	ASSET_ID                 ,
	ASSET_HIST_TYPE          ,
	ASSET_ATTRIB_TEMP_NAME   ,
	ASSET_ATTRIB_NAME        ,
	ASSET_ATTRIB_VALUE       ,
	IS_HIDDEN				 
FROM AATABLE_AMS_ATTRIBUTE
GO


IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_AMS_ATTRIBUTE_TABLE')
BEGIN
DROP VIEW AASTD_AMS_ATTRIBUTE_TABLE
END
GO

CREATE VIEW AASTD_AMS_ATTRIBUTE_TABLE
AS
SELECT 
	ASSET_ID        ,
	ASSET_HIST_TYPE ,
	ASSET_ATTRIB_TAB_NAME ,
	ASSET_ATTRIB_NAME,
	ATTRIB_ROW_INDEX,
	ASSET_ATTRIB_VALUE	
FROM AATABLE_AMS_ATTRIBUTE_TABLE
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_AMS_ASSET_ASSET')
BEGIN
DROP VIEW AASTD_AMS_ASSET_ASSET
END
GO

CREATE VIEW AASTD_AMS_ASSET_ASSET
AS
SELECT 
	PARENT_ASSET_ID        ,
	PARENT_ASSET_HIST_TYPE ,
	CHILD_ASSET_ID         ,
	CHILD_ASSET_HIST_TYPE  
FROM AATABLE_AMS_ASSET_ASSET
GO


IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_REFER_PEOPLE_LINKS')
BEGIN
DROP VIEW AASTD_REFER_PEOPLE_LINKS
END
GO

CREATE VIEW AASTD_REFER_PEOPLE_LINKS
AS
SELECT 
	CONTACT_NBR,
	ENT_TYPE,
	ENT_ID1,
	ENT_ID2,  
	ENT_ID3,  
	PRIMARY_FLAG,  
	comments,  
	START_DATE,  
	END_DATE
FROM AATABLE_REFER_PEOPLE_LINKS
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_LIC_PROF')
BEGIN
DROP VIEW AASTD_LIC_PROF
END
go
CREATE VIEW AASTD_LIC_PROF
AS
SELECT 
	serv_prov_code  ,
lic_nbr             ,
lic_status          ,
lic_state           ,
tt_lic_type            ,
bus_name            ,
lic_orig_iss_dd     ,
last_renewal_dd     ,
lic_expir_dd        ,
cae_fname           ,
cae_mname           ,
cae_lname           ,
address1            ,
address2            ,
city                ,
state               ,
zip			        ,
phone1			    ,
phone2			    ,
fax			        ,
email			    ,
lic_comment		    ,
ins_co_name		    ,
ins_amount		    ,
ins_policy_no		,
ins_exp_dt		    ,
bus_lic			    ,
bus_lic_exp_dt		,
last_update_dd		,	
lic_seq_nbr		    ,
rec_date		    ,
rec_ful_nam		    ,
rec_flag		    ,
lic_board 	        ,
address3            ,
wc_exempt           ,
wc_policy_no        ,
wc_eff_dt           ,
wc_exp_dt           ,
wc_canc_dt          ,
suffix_name         ,
country             ,
county_code         ,
wc_ins_co_code      ,
contr_lic_no        ,
cont_lic_bus_name       ,
ga_ivr_pin              ,
l1_salutation	          ,		
l1_gender	              ,		
l1_post_office_box      ,		
bus_name2               ,		
l1_birth_date          ,
phone1_country_code     ,
phone2_country_code    ,
fax_country_code        ,	
lic_type_flag                ,
lic_social_security_nbr       ,	
lic_federal_employer_id_nbr   ,	
phone3                        ,	
phone3_country_code           ,	
aca_permission               ,		
l1_title                      ,		
past_days                     
FROM AATABLE_LIC_PROF
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_LIC_PROF_ATTR')
BEGIN
DROP VIEW AASTD_LIC_PROF_ATTR
END
go

CREATE VIEW AASTD_LIC_PROF_ATTR
AS
SELECT 
serv_prov_code      ,
lic_nbr                 ,
lic_type                ,
attrib_temp_name        ,
attrib_name             ,
attrib_value     
FROM AATABLE_LIC_PROF_ATTR
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_LIC_PROF_ATTACH')
BEGIN
DROP VIEW AASTD_LIC_PROF_ATTACH
END
go

CREATE VIEW AASTD_LIC_PROF_ATTACH
AS
SELECT 
serv_prov_code		    ,
lic_nbr			        ,
lic_type		        ,
group_name		        ,
table_name		        ,
column_name		        ,
row_num			        ,
attach_value
FROM AATABLE_LIC_PROF_ATTACH
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_TEMPLATE_ASI')
BEGIN
DROP VIEW AASTD_TEMPLATE_ASI
END
go

CREATE VIEW AASTD_TEMPLATE_ASI
AS
SELECT 
ENTITY_TYPE 		    ,
ENTITY_ID 			        ,
GROUP_CODE 		        ,
ASI_SUB_GROUP_CODE  		        ,
FIELD_NAME 		        ,
FIELD_VALUE 
FROM AATABLE_TEMPLATE_ASI
GO

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_TEMPLATE_ASIT')
BEGIN
DROP VIEW AASTD_TEMPLATE_ASIT
END
go

CREATE VIEW AASTD_TEMPLATE_ASIT
AS
SELECT 
ENTITY_TYPE 		    ,
ENTITY_ID 			        ,
GROUP_CODE  		        ,
ASI_SUB_GROUP_CODE    		        ,
FIELD_NAME  		        ,
FIELD_VALUE  				,
ROW_INDEX 
FROM AATABLE_TEMPLATE_ASIT
GO

-- AASTD_PERMIT_PAYMENTS
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_PAYMENTS')
BEGIN
DROP VIEW AASTD_PERMIT_PAYMENTS
END
go

CREATE VIEW AASTD_PERMIT_PAYMENTS
AS
SELECT
PERMITNUM,
PAY_KEY,
PAYMENT_METHOD,
PAYMENT_REF_NBR,
CC_TYPE,
PAYEE,
PAYMENT_DATE,
PAYMENT_AMOUNT,
TRANSACTION_CODE,
TRANSACTION_NBR,
PAYMENT_COMMENT,
CASHIER_ID,
REGISTER_NBR,
REC_DATE,
REC_FUL_NAM,
ACCT_ID,
PAYEE_ADDRESS,
PAYEE_PHONE,
CC_AUTH_CODE,
PAYEE_PHONE_IDD,
PAYMENT_RECEIVED_CHANNEL,
CHECK_NUMBER,
CHECK_TYPE,
DRIVER_LICENSE,
CHECK_HOLDER_NAME,
CHECK_HOLDER_EMAIL,
PHONE_NUMBER,
COUNTRY,
STATE,
CITY,
STREET,
ZIP,
REASON,
PAYEE_TYPE,
HIST_RECEIPT_NBR,
VOID_BY,
VOID_DATE,
payment_pay_key 
FROM AATABLE_PERMIT_PAYMENTS
GO

-- AASTD_PERMIT_RECEIPTS
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE TABLE_NAME = N'AASTD_PERMIT_RECEIPTS')
BEGIN
DROP VIEW AASTD_PERMIT_RECEIPTS
END
go

CREATE VIEW AASTD_PERMIT_RECEIPTS
AS
SELECT
HIST_RECEIPT_NBR,
RECEIPT_DATE,
CASHIER_ID,
REGISTER_NBR,
RECEIPT_AMOUNT,
RECEIPT_COMMENT,
RECEIPT_STATUS,
TRANSACTION_CODE,
TRANSACTION_NBR,
REC_DATE,
REC_FUL_NAM,
TTERMINAL_ID,
WORKSTATION_ID
FROM AATABLE_PERMIT_RECEIPTS
GO

go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0000 0000 0000 edits.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0000 0000 0000 edits.sql')
--apostraphe--officer's comments
;update R2CHCKBOX set R1_CHECKBOX_DESC = 'Officer�s Comments' where R1_CHECKBOX_DESC = 'Officer''s Comments'
;
--fieldname length
;update R2CHCKBOX set R1_CHECKBOX_DESC = 'who appeared for hearing' where R1_CHECKBOX_DESC = 'Text field for name of person who appeared for hearing'
;


go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0040 aatable_permit_history.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0040 aatable_permit_history.sql')
/*
I need to square up the comp_type,version to the specific actual accela record types.
rem: refer to permitHistory_setup
do I need to instantiate records for the citizens board hearing idea? Client expects double records. But do I then double the information, and the charges? Is CBS record effectively a dummy record, related to its parent?

regular history
cbs instantiation
*/



--regular history
;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_HISTORY
;
insert into aatable_permit_history
select distinct
    trim(a.number_key) as permitnum
    ,null as CONTRACTOR_VALUATION
    ,coalesce(a.entered_date,'1900-01-01 00:00:00') as DATEOPENED
    ,(case 
        when f.tt_record in ('Locksmith Initial Application','Locksmith License','Locksmith Renewal') 
        then coalesce(permit_info.date_123,'2099-12-31 00:00:00')
        
        else null 
        
        end 
     ) as Expiration_date --,permit_info.date_123 as Expiration_date
    ,(case 
        when f.tt_record in ('Locksmith Initial Application','Locksmith License','Locksmith Renewal')
        then case 
            when DATEDIFF(DAY, getdate(), permit_info.date_123) <= 0 then 'Expired'
            when DATEDIFF(DAY, getdate(), permit_info.date_123) <= 30 then 'About to Expire'
            else 'Active'
            end
        
        else null 
        
        end        
     ) as app_status
    ,left(replace(replace(     convert(varchar(max),d.description)    ,char(10),''),char(13),''),4000) as work_desc --,left(replace(replace( coalesce(  convert(varchar(max),comp_type.description)    ,convert(varchar(max),a.type_title)    ) + isnull(' - '+convert(varchar(max),d.description),'') ,char(10),''),char(13),''),4000)  as work_desc
    ,coalesce(App_Name.name,'Not Set') as App_Name
    ,a.house_cnt as House_Count
    ,a.bld_cnt as Building_Count
    ,null as Public_Owned
    ,null as Const_Type_Code
    ,null as short_notes --,isnull(a.sub_type,'')+isnull(';'+a.location,'') as short_notes --facname.text_010 as Short_Notes
    ,null as asgn_dept --,a.status_class as Asgn_Dept
    ,null as asgn_staff --,coalesce(asgn_staff.user_name,a.insp_area,'Not Set') as Asgn_Staff
    ,null asgn_date --,a.date_a as Asgn_Date --Populates the first visit date, and store for history
    ,null as Completed_Dept
    ,null as Completed_By
    ,a.date_f as Completed_Date --date_f --The �Closing� date of the record
    ,null as scheduled_date --a.date_k as Scheduled_Date --The �Due� date for the next inspection ----https://redmine.scubeenterprise.com/issues/19564
    ,null as Priority
    ,null as Total_Job_Cost
    ,a.date_f as Closed_Date --date_f --The �Closing� date of the record
    ,null as closed_by --,case when a.date_f is null then null else coalesce(asgn_staff.user_name,a.insp_area,'Not Set') end as Closed_By
    ,null as VR_Tracking_Num
    ,null as created_by --,coalesce(created_by.user_name,a.user_id,'Not Set') as Created_By
    ,null as Reported_Channel
    ,null Created_By_Dept --,'Code Enforcement' as Created_By_Dept
    ,null as first_issued_date --,permit_info.date_122 as First_Issued_Date --an assumption based on HBCODE_DATA.pdf
    ,null as Anonymous_Flag
    ,null as Reference_Type
    ,null as Appearance_Dayofweek
    ,null as Appearance_Date
    ,null as Booking_Flag
    ,null as Defendant_Signature_Flag
    ,null as Enforce_Officer_ID
    ,null as Enforce_Officer_Name
    ,null as Infraction_Flag
    ,null as Inspector_ID
    ,null as Misdemeanor_Flag
    ,null as Offence_Witnessed_Flag
    ,null as Inspector_Name
    ,null as Enforce_Dept
    ,null as Inspector_Dept
    ,null as Valuation_Multiplier
    ,null as Valuation_Extra_Amt
    ,null as Last_Audit_Date
    ,try_convert(datetime,f.entered_date_max) as App_Status_Date
    ,null as Delegate_User_ID
    ,a.data_status as TT_Record_Status
    ,(case when a.SUB_TYPE in ('RTN','SWEEP') then f.tt_record + ' - Proactive' else f.tt_record end) as tt_record
    ,0 as Balance
    ,0 as Total_Fee
    ,0 as Total_Pay
    ,null as Last_Update_By
    ,null as Last_Update_Date
from jms_apd_base_filtered a --hcfl_src.dbo.apd_base a
join jms_pre_aatablePermitHistory_filter f on f.NUMBER_KEY = a.NUMBER_KEY
left join jms_permit_info permit_info on permit_info.number_key = a.number_key 
left join jms_comp_type comp_type on comp_type.version = a.version and comp_type.comp_type = a.comp_type
left join hcfl_src.dbo.apd_desc d on d.number_key = a.number_key
left join jms_numberKey_primaryOrdering app_name on app_name.number_key = a.NUMBER_KEY
--left join jms_facname facname on facname.number_key = a.number_key -- all null
left join jms_userid_username created_by on created_by.user_id = a.user_id
left join jms_userid_username asgn_staff on asgn_staff.user_id = a.insp_area
where
    1=1
;




--cbs instantiation
;with cte_cbs as (
	select 
		* 
	from jms_apd_base_filtered a
	where
		1=1
		and (
            a.date_h is not null
            or a.date_g is not null
        )
)
insert into AATABLE_PERMIT_HISTORY
select distinct
    trim(a.number_key)+'-CBS' as permitnum
    ,null as CONTRACTOR_VALUATION
    ,coalesce(a.date_g,a.entered_date,'1900-01-01 00:00:00') as DATEOPENED --date_g=hearing date
    ,null as Expiration_date --permit_info.date_123 as Expiration_date
    ,null as Expiration_Status
    ,left(replace(replace(     convert(varchar(max),d.description)    ,char(10),''),char(13),''),4000)  as work_desc --,left(replace(replace( coalesce(  convert(varchar(max),comp_type.description)    ,convert(varchar(max),a.type_title)    ) + isnull(' - '+convert(varchar(max),d.description),'') ,char(10),''),char(13),''),4000)  as work_desc
    ,coalesce(App_Name.name,'') as App_Name
    ,a.house_cnt as House_Count
    ,a.bld_cnt as Building_Count
    ,null as Public_Owned
    ,null as Const_Type_Code
    ,null as short_notes --,isnull(a.sub_type,'')+isnull(';'+a.location,'') as short_notes --facname.text_010 as Short_Notes
    ,null as asgn_dept --,a.status_class as Asgn_Dept
    ,coalesce(asgn_staff.user_name,a.insp_area,'Not Set') as Asgn_Staff
    ,a.Date_H as Asgn_Date --date_h=Date of Board order%%
    ,null as Completed_Dept
    ,null as Completed_By
    ,a.date_i as Completed_Date --date_i=Date of affidavit execution**
    ,case when a.date_d > a.date_i then null else a.date_d end as scheduled_date --a.date_D as Scheduled_Date --date_d=Hearing date for the specified record%%
    ,null as Priority
    ,null as Total_Job_Cost
    ,a.date_f as Closed_Date --date_f --The �Closing� date of the record
    ,null as closed_by --,case when a.date_f is null then null else coalesce(asgn_staff.user_name,a.insp_area,'Not Set') end as Closed_By
    ,null as VR_Tracking_Num
    ,null as created_By --,coalesce(created_by.user_name,a.user_id,'Not Set') as Created_By
    ,null as Reported_Channel
    ,null as created_by_dept --,'Code Enforcement' as Created_By_Dept
    ,null as First_Issued_Date --,permit_info.date_122 as First_Issued_Date --an assumption based on HBCODE_DATA.pdf
    ,null as Anonymous_Flag
    ,null as Reference_Type
    ,null as Appearance_Dayofweek
    ,null as Appearance_Date
    ,null as Booking_Flag
    ,null as Defendant_Signature_Flag
    ,null as Enforce_Officer_ID
    ,null as Enforce_Officer_Name
    ,null as Infraction_Flag
    ,null as Inspector_ID
    ,null as Misdemeanor_Flag
    ,null as Offence_Witnessed_Flag
    ,null as Inspector_Name
    ,null as Enforce_Dept
    ,null as Inspector_Dept
    ,null as Valuation_Multiplier
    ,null as Valuation_Extra_Amt
    ,null as Last_Audit_Date
    ,try_convert(datetime,f.entered_date_max) as App_Status_Date
    ,null as Delegate_User_ID
    ,a.data_status as TT_Record_Status
    ,'Citizen Board Support' --f.tt_record
    ,0 as Balance
    ,0 as Total_Fee
    ,0 as Total_Pay
    ,null as Last_Update_By
    ,null as Last_Update_Date
from cte_cbs a --same as jms_apd_base_filtered
join jms_pre_aatablePermitHistory_filter f on f.NUMBER_KEY = a.NUMBER_KEY
left join jms_permit_info permit_info on permit_info.number_key = a.number_key 
left join jms_comp_type comp_type on comp_type.version = a.version and comp_type.comp_type = a.comp_type
left join hcfl_src.dbo.apd_desc d on d.number_key = a.number_key
left join jms_numberKey_primaryOrdering app_name on app_name.number_key = a.NUMBER_KEY
left join jms_facname facname on facname.number_key = a.number_key
left join jms_userid_username created_by on created_by.user_id = a.user_id
left join jms_userid_username asgn_staff on asgn_staff.user_id = a.insp_area
where
    1=1
;

go
;update aatable_permit_history set Asgn_Staff = 'Spriggs, Teddy' where Asgn_Staff = 'Spriggs, Edward ''Teddy'''
;
go
delete from aatable_permit_history where tt_record like '%pain man%'
;
go


--
------DEBUG
----delete from aatable_permit_history where tt_record <> 'Enforcement Complaint'
----delete from aatable_permit_history where tt_record <> 'Citizen Board Support'
----delete from aatable_permit_history where tt_record <> 'Locksmith Initial Application'
----delete from aatable_permit_history where tt_record <> 'Locksmith License'
----delete from aatable_permit_history where tt_record <> 'Locksmith Renewal'
----delete from aatable_permit_history where tt_record <> 'Other:Pain Management Clinic'
--;
--
--delete from aatable_permit_history where permitnum not in (
--    ''
--    --,'CE23007383'
--    --,'CE23007383-CBS'
--    --,'RCA2200041'
--    --,'CE24003563'
--    ,'CE19000216'
--)
--;

--update a set 
--    b1_alt_id = right(a.b1_per_id1,3) + '-' + a.b1_alt_id
--from b1permit a 
--join aatable_permit_history f on f.permitnum = a.b1_alt_id
--;

go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0060 0020 aatable_permit_inspection setup.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0060 0020 aatable_permit_inspection setup.sql')
/*
setup to get any orphaned rows (rows without some kind of site visit preceding them)
    setup parents
    setup is_initial_site_visit
    setup g
    which number_key values have orphaned inspection rows?
    setup orphan parents
NOW REDO ABOVE LOGIC AND USE REMAINING LOGIC
    (determine child rows per inspection, then assert inspection type and inspection result based on those children)
    create parents
    create is_initial_site_visit
    create g
    create h
    create violations
    VERIFY the above
ensure no duplicates
*/


--setup to get any orphaned rows (rows without some kind of site visit preceding them)
/* SET UP:
I found 511 unique_key values in apd_insp that dont have a preceding site visit. 
So I run the logic, identify those without the preceding SV et al, then add them to my apd_insp.
*/


;delete from jms_apd_insp_filteredToPop where unique_key like 'ORPH-%'

--determine child rows per inspection, then assert inspection type and inspection result based on those children
;IF OBJECT_ID('tempdb.dbo.#parents', 'U') IS NOT NULL drop table #parents
;IF OBJECT_ID('tempdb.dbo.#is_initial_site_visit', 'U') IS NOT NULL drop table #is_initial_site_visit
;IF OBJECT_ID('tempdb.dbo.#g', 'U') IS NOT NULL drop table #g
;IF OBJECT_ID('tempdb.dbo.#orphaned', 'U') IS NOT NULL drop table #orphaned
;IF OBJECT_ID('tempdb.dbo.#h', 'U') IS NOT NULL drop table #h
;IF OBJECT_ID('tempdb.dbo.#violations', 'U') IS NOT NULL drop table #violations
;
go


--setup parents           
--;with parents
    --assumes inspections are site visits, and results are implied by the subsequent rows prior to the following site visit.
	select
		number_key
		,unique_key
		,date_ent
		,the_Date
		,action_ent
    into #parents
	from jms_apd_insp_filteredToPop
	where action_ent in ('SV','SSV','QCSV','LSV')
	--and number_key = 'CE18015425'
;
--setup is_initial_site_visit                        
--), is_initial_site_visit as (
    --"initial site visiit" is an accela inspection type
	select
		b.UNIQUE_KEY
        ,b.action_ent
    into #is_initial_site_visit
	from jms_apd_base_filtered a
	outer apply (select top 1 * from jms_apd_insp_filteredToPop where NUMBER_KEY = a.NUMBER_KEY and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent,the_date) b
;
--setup g  
--),g as (
    select
        a.number_key
        ,a.item_id
        ,a.unique_key
        ,a.action_ent
        ,action_ent.DESCRIPTION action_ent_desc
        ,case when is_initial_site_visit.UNIQUE_KEY is not null then 1 else 0 end as is_initial_site_visit
        ,'xxxx' [ ]
        ,coalesce(b.unique_key,is_initial_site_visit.unique_key) parent_unique_key
        ,b.action_ent parent_action_ent
        ,(case 
            when is_initial_site_visit.UNIQUE_KEY is not null then 'Initial Site Visit'
            when a.ACTION_ENT in ('QCSV','LSV') then 'Quality Control Inspection'
            when  a.any_comments like '%re%inspect%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%re%check%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%annual%insp%'    then 'Annual Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%post%hearing%'    then 'Post-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%pre%hearing%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%hear%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%follow%up%'    then 'Follow-up Inspection' --I don't know about pre vs post hearing
            else 'Inspection'
            end		
        ) as inspection_type
        ,(case 
            --when a.ACTION_ENT in ('SV','SSV','QCSV','LSV') then null
            when a.ACTION_ENT = 'NOVR' then 'Notice of Violation Requested'
            when a.ACTION_ENT = 'NOVC' then 'NOV issued'
            when a.ACTION_ENT = 'NOVB' then 'Combo Issued'
            when a.action_ent = 'ECIT' then 'Citation Issued'
            when a.ACTION_ENT = 'COMP' then 'Compliant'
            when a.ACTION_ENT = 'VIOL' then 'Violation'
            when A.ACTION_ENT in ('CA','CNCL') then 'No Violation'
            when a.any_comments like '%dead%animal%'	  then 'Extension'
            when a.any_comments like '%exten%'	  then 'Extension'
            when a.any_comments like '%violation%'  then 'Violation'
            when a.any_comments like '%non%compli%' then 'Not Compliant'
            when a.any_comments like '%send%nov%'   then 'NOV Issued'
            when a.any_comments like '%req%nov%'    then 'Notice of Violation Requested'
            when a.any_comments like '%cont%fin%'    then 'Not Compliant' --continue fines
            else null
            end
        ) as inspection_result
        
        ,'xxxx' [2]
        ,a.date_ent
        ,a.the_date
        ,'xxxx'[3]
        ,a.any_comments
    into #g
    from jms_apd_insp_filteredToPop a
    outer apply (select top 1 * from #parents where number_key = a.number_key and the_date <= a.the_date and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent desc,the_date desc) b
    left join jms_actionEnt_passFail action_ent on action_ent.action_ent = a.action_ent
    left join #is_initial_site_visit is_initial_site_visit on is_initial_site_visit.UNIQUE_KEY = a.UNIQUE_KEY
    where
        1=1
        --and a.action_ent not in ('SV','SSV','QCSV','LSV')
        --and a.number_key = 
        --	--'CE03003081'
        --	--'CE22014264'
        --	'CE22014971'
    --order by --a.date_ent,a.the_Date,case when a.action_ent in ('SV','SSV','QCSV','LSV') then 1 else 2 end, l.THE_TEXT
    --	a.UNIQUE_KEY
;

----which number_key values have orphaned inspection rows?
--select 
--	a.NUMBER_KEY
--	,a.parent_unique_key
--	,count(b.number_key) ct
--    
--into #orphaned
--from #g a
--left join hcfl_src..apd_itms b 
--	on b.RECORD_TYPE = 'CD'
--	and b.NUMBER_KEY = a.NUMBER_KEY
--	and year(b.THE_DATE) = year(a.the_date) and month(b.THE_DATE) = month(a.the_date) and day(b.THE_DATE) = day(a.THE_DATE)
--	and b.ITEM_ID = a.ITEM_ID
--where
--	b.NUMBER_KEY is not null
--    and a.parent_unique_key is null
--group by a.numbeR_key,a.parent_unique_key
--;
select 
	a.NUMBER_KEY
	,a.UNIQUE_KEY
    
into #orphaned
from #g a
where
	a.parent_unique_key is null
;


--setup orphan parents             
--;delete from jms_apd_insp_filteredToPop where unique_key like 'ORPH-%' --moved up top. Otherwise, can on alternating conversions yield nothing, while deleting the relevant records.
;
insert into jms_apd_insp_filteredToPop
SELECT distinct
     f.NUMBER_KEY
    ,'A' DATA_LEVEL
    ,'IN' RECORD_TYPE
    ,'14320' ITEM_ID
    ,'ORPH-' + convert(varchar(max),row_number() over(order by f.number_key) ) unique_key 
    ,null INSPECTOR
    ,null USER_ID
    ,'KE' ENTRY_METHOD
    ,null REMOTE_USER_ID
    ,min(a.date_ent) DATE_ENT
    ,'SV' ACTION_ENT
    ,'N' APPROVAL
    ,min(a.THE_DATE) the_date
    ,null BEG_TIME
    ,null END_TIME
    ,null TOTAL_TIME
    ,0 VIOLATIONS
    ,null MILAGE
    ,convert(varchar(max),a.ANY_COMMENTS) any_comments
    ,'14320' ITEM_NO
    ,null REQUEST_ID
    ,null BEG_MILEAGE
    ,null END_MILEAGE
    ,null VEHICLE_ID
    ,null SUBMIT_TIME
    ,null SUBMIT_DATE
from #orphaned f --on f.number_key = a.number_key
outer apply (select top 1 * from jms_apd_insp_filteredToPop where number_key = f.number_key order by the_date,date_ent) a
WHERE
    1=1
group by f.NUMBER_KEY,convert(varchar(max),a.ANY_COMMENTS)
;

-----------------------
--NOW REDO ABOVE LOGIC AND USE REMAINING LOGIC
-----------------------

--determine child rows per inspection, then assert inspection type and inspection result based on those children
;IF OBJECT_ID('tempdb.dbo.#parents', 'U') IS NOT NULL drop table #parents
;IF OBJECT_ID('tempdb.dbo.#is_initial_site_visit', 'U') IS NOT NULL drop table #is_initial_site_visit
;IF OBJECT_ID('tempdb.dbo.#g', 'U') IS NOT NULL drop table #g
;IF OBJECT_ID('tempdb.dbo.#orphaned', 'U') IS NOT NULL drop table #orphaned
;IF OBJECT_ID('tempdb.dbo.#h', 'U') IS NOT NULL drop table #h
;IF OBJECT_ID('tempdb.dbo.#violations', 'U') IS NOT NULL drop table #violations
;IF OBJECT_ID('tempdb.dbo.#req_opt', 'U') IS NOT NULL drop table #req_opt
;
go

--create parents              
--;with parents
    --assumes inspections are site visits, and results are implied by the subsequent rows prior to the following site visit.
	select
		number_key
		,unique_key
		,date_ent
		,the_Date
		,action_ent
    into #parents
	from jms_apd_insp_filteredToPop
	where action_ent in ('SV','SSV','QCSV','LSV')
	--and number_key = 'CE18015425'
;
--create is_initial_site_visit
--), is_initial_site_visit as (
    --"initial site visiit" is an accela inspection type
	select
		b.UNIQUE_KEY
        ,b.action_ent
    into #is_initial_site_visit
	from jms_apd_base_filtered a
	outer apply (select top 1 * from jms_apd_insp_filteredToPop where NUMBER_KEY = a.NUMBER_KEY and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent,the_date) b
;
--create g  
--),g as (
    select
        a.number_key
        ,a.item_id
        ,a.unique_key
        ,a.action_ent
        ,action_ent.DESCRIPTION action_ent_desc
        ,case when is_initial_site_visit.UNIQUE_KEY is not null then 1 else 0 end as is_initial_site_visit
        ,'xxxx' [ ]
        ,coalesce(b.unique_key,is_initial_site_visit.unique_key) parent_unique_key
        ,b.action_ent parent_action_ent
        ,(case 
            when is_initial_site_visit.UNIQUE_KEY is not null then 'Initial Site Visit'
            when a.ACTION_ENT in ('QCSV','LSV') then 'Quality Control Inspection'
            when  a.any_comments like '%re%inspect%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%re%check%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%annual%insp%'    then 'Annual Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%post%hearing%'    then 'Post-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%pre%hearing%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%hear%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%follow%up%'    then 'Follow-up Inspection' --I don't know about pre vs post hearing
            else 'Inspection'
            end		
        ) as inspection_type
        ,(case 
            --when a.ACTION_ENT in ('SV','SSV','QCSV','LSV') then null
            when a.ACTION_ENT = 'NOVR' then 'Notice of Violation Requested'
            when a.ACTION_ENT = 'NOVC' then 'NOV issued'
            when a.ACTION_ENT = 'NOVB' then 'Combo Issued'
            when a.action_ent = 'ECIT' then 'Citation Issued'
            when a.ACTION_ENT = 'COMP' then 'Compliant'
            when a.ACTION_ENT = 'VIOL' then 'Violation'
            when A.ACTION_ENT in ('CA','CNCL') then 'No Violation'
            when a.any_comments like '%dead%animal%'	  then 'Extension'
            when a.any_comments like '%exten%'	  then 'Extension'
            when a.any_comments like '%violation%'  then 'Violation'
            when a.any_comments like '%non%compli%' then 'Not Compliant'
            when a.any_comments like '%send%nov%'   then 'NOV Issued'
            when a.any_comments like '%req%nov%'    then 'Notice of Violation Requested'
            when a.any_comments like '%cont%fin%'    then 'Not Compliant' --continue fines
            else 'No Violation'
            end
        ) as inspection_result
        
        ,'xxxx' [2]
        ,a.date_ent
        ,a.the_date
        ,'xxxx'[3]
        ,a.any_comments
    into #g
    from jms_apd_insp_filteredToPop a
    outer apply (select top 1 * from #parents where number_key = a.number_key and the_date <= a.the_date and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent desc,the_date desc) b
    left join jms_actionEnt_passFail action_ent on action_ent.action_ent = a.action_ent
    left join #is_initial_site_visit is_initial_site_visit on is_initial_site_visit.UNIQUE_KEY = a.UNIQUE_KEY
    where
        1=1
        --and a.action_ent not in ('SV','SSV','QCSV','LSV')
        --and a.number_key = 
        --	--'CE03003081'
        --	--'CE22014264'
        --	'CE22014971'
    --order by --a.date_ent,a.the_Date,case when a.action_ent in ('SV','SSV','QCSV','LSV') then 1 else 2 end, l.THE_TEXT
    --	a.UNIQUE_KEY
;



















--create h
--), h as (
    select distinct
         a1.NUMBER_KEY
        ,a1.UNIQUE_KEY
        ,a1.action_ent
        ,a1.inspection_type
        ,coalesce(b.inspection_result,a1.inspection_result,'Not Set') inspection_result
        ,trim('^|' from stuff((
            select 
                '^|^' + cast(
                    trim(replace(replace(replace(replace(   isnull(a2.any_comments,'')   ,'"',''''''),'''',''),char(13),''),char(10),'�')) 
                    as varchar(max)
                )
            from #g a2 with(nolock)
            where 
                a2.parent_unique_key = a1.parent_unique_key
            group by a2.any_comments
            order by a2.any_comments
            FOR XML PATH('')
         ), 1, 1, '')) as any_comments
    into #h
    from #g a1
    outer apply (
        select top 1 *
        from #g
        where
            parent_unique_key = a1.UNIQUE_KEY
            and inspection_result is not null
        order by case inspection_result 
            when 'violation'		then 1
            when 'combo issued'		then 2
            when 'NOV issued'		then 3
            when 'not compliant'	then 4
            when 'Notice of Violation Requested' then 5
            when 'Extension' then 6
            when 'Compliant' then 7
            when 'No Violation' then 8
            else 999
            end                                                                                                                                                        
    ) b
    where
        1=1
        and a1.ACTION_ENT in ('SV','SSV','QCSV','LSV')
        --and a1.number_key = 'CE17015692'
    ;

    --order by a.UNIQUE_KEY
--)
;
--create violations
--;with cte_violations as (
;IF OBJECT_ID('tempdb.dbo.#_violations', 'U') IS NOT NULL drop table #_violations
;
select distinct
    a.NUMBER_KEY
    ,a.parent_unique_key
    ,b.item_id --count(distinct b.item_id) ct --,count(b.number_key) ct
into #_violations
from #g a
left join hcfl_src..apd_itms b on b.RECORD_TYPE = 'CD' and b.NUMBER_KEY = a.NUMBER_KEY
--left join greater_dates b2 on b2.number_key = b.number_key and b2.sequence = b.sequence and b2.item_id = b.item_id and b2.the_date = b.the_Date	
where
    1=1
	and b.NUMBER_KEY is not null
	--and b.NUMBER_KEY = @number_key
	and (
		(year(b.THE_DATE) = year(a.THE_DATE) and month(b.THE_DATE) = month(a.THE_DATE) and day(b.THE_DATE) = day(a.THE_DATE) )
		--or (year(b2.greater_date) = year(a.date_ent) and month(b2.greater_date) = month(a.date_ent) and day(b2.greater_date) = day(a.date_ent) )
		--or a.item_id = b.ITEM_ID
	)
	--and a.parent_unique_key not like 'ORPH-%'
	and a.item_id = b.ITEM_ID
	--and b.NUMBER_KEY = 'CE20005395'
--group by a.number_key,a.parent_unique_key
;
insert into #_violations
select distinct
    a.NUMBER_KEY
    ,a.parent_unique_key
    ,b.item_id --count(distinct b.item_id) ct --,count(b.number_key) ct
--into #violations
from #g a
left join hcfl_src..apd_itms b on b.RECORD_TYPE = 'CD' and b.NUMBER_KEY = a.NUMBER_KEY
--left join greater_dates b2 on b2.number_key = b.number_key and b2.sequence = b.sequence and b2.item_id = b.item_id and b2.the_date = b.the_Date	
left join #_violations f on f.number_key = b.number_key and f.parent_unique_key = a.parent_unique_key and f.item_id = b.item_id
where
    1=1
	and b.NUMBER_KEY is not null
    and b.number_key in (
        'CE19003559','CE23009136','CE19009756','CE20002548','CE21004204','CE19003581','CE20012598','CE19012011','CE23005979','CE19015277','CE21016309','CE19011421','CE19012401','CE22014685','CE18005494','CE23010215','CE19012411','CE20009721','CE22013741','CE19014671','CE21011018','CE22014110','CE20007800','CE20005402','CE20009114','CE19002911','CE20018403','CE23011330','CE22015121','CE23007240','CE23013057','CE19010651','CE19018933','CE20014046','CE21009047','CE21007959','CE23004103','CE22001176','CE23006298','CE23010669','CE24000898','CE24000231','CE20004070','CE23009308','CE23010811','CE23010751','CE21014360','CE22012777','CE19009560','CE19012398','CE19008217','CE21000155','CE19010306','CE19006856','CE19005561','CE19008165','CE20003010','CE23013515','CE19019242','CE18019800','CE14014593','CE21004712','CE20002119','CE20011293','CE19012874','CE20007286','CE19010901','CE21016777','CE21015105','CE20017070','CE23011743','CE19006692','CE22014556','CE21002721','CE22012195','CE23014129','CE16008878','CE23014777','CE21014002','CE22002145','CE21014975','CE19000216','CE22012498','CE16010830','CE19007826','CE20017491','CE24001587','CE22014672','CE20004106','CE21013194','CE19011203','CE19005242','CE19008010','CE20005850','CE23014313','CE19009809','CE22007611','CE22014657','CE19002688','CE19004742','CE19019742','CE16012518','CE19005138','CE24002345','CE21002886','CE19005576','CE21010907','CE23000913','CE19015279','CE24000171','CE23013386','CE19004841','CE20003005','CE23013302','CE21010027','CE21003160','CE23011649','CE20002551','CE21012168','CE20001647','CE19015282','CE19010593','CE22005509','CE22002774','CE19000583','CE22009951','CE19012963','CE21013802','CE19006869','CE19007787','CE22010728','CE21014537','CE19015962','CE19002555','CE19009892','CE15004960','CE23007140','CE20012475','CE19011046','CE23013565','CE20002543','CE22010175','CE21007517','CE22012138','CE24002684','CE20015397','CE20014604','CE18008839','CE23012423','CE19001765','CE19014362','CE22013524','CE19012586','CE23002470','CE23014099','CE20012835','CE07006722','CE19015151','CE19000528','CE19014919','CE19011732','CE22005218','CE12012059','CE19013938','CE23003461','CE21010022','CE22008356','CE19005972','CE20000742','CE21003266','CE23002791','CE20004250','CE23006823','CE23006205','CE20006255','CE23005529','CE19015687','CE17020849','CE16011159','CE23008481','CE21010743','CE21000977','CE19012735','CE19013243','CE23009435','CE14002241','CE19019208','CE19003241','CE19010951','CE19007064','CE05008956','CE23000156','CE20011005','CE19015960','CE23006198','CE23000896','CE23009330','CE23003520','CE23013768','CE23013242','CE21012600','CE23006418','CE19019872','CE19009080','CE20017647','CE21008460','CE20003079','CE21004247','CE19016865','CE22014691','CE20000309','CE23009317','CE16009497','CE20012757','CE22013184','CE22012525','CE23002424','CE19011120','CE20004011','CE20018362','CE11001952','CE19008549','CE19002850','CE23003766','CE23011872','CE20016297','CE21012795','CE21010756','CE19014909','CE23004666','CE19011322','CE21006583','CE21003395','CE22002320','CE19001103','CE23010757','CE20002145','CE21010369','CE24001675','CE24001194','CE19019970','CE21008117','CE04002961','CE24000282','CE23000226','CE19011049','CE22002273','CE23010810','CE12009147','CE20013788','CE23001776','CE22012221','CE22008197','CE20006453','CE20007168','CE19014933','CE20017446','CE21002204','CE19013740','CE22008400','CE19006253','CE19015187','CE21013889','CE22012226','CE19006592','CE21008765','CE20009474','CE21000352','CE22011604','CE23011454','CE12004910','CE20005069','CE22012974','CE23007078','CE21011822','CE22002278','CE23014558','CE19006177','CE22014960','CE20014073','CE21010304','CE23012408','CE20006029','CE19005819','CE23009508','CE19009231','CE22003059','CE21012398','CE24001576','CE20002603','CE23013958','CE20004452','CE23004337','CE23007397','CE22009674','CE19010319','CE19020349','CE20004379','CE22011606','CE20001696','CE23001612','CE23013064','CE12003323','CE19018598','CE20003134','CE20008234','CE13011361','CE21014323','CE23010838','CE21005870','CE20002550','CE21014995','CE23010548','CE21012765','CE23001406','CE23002206','CE23009679','CE23001283','CE23012306','CE13013683','CE21005650','CE12001135','CE21011659','CE21016565','CE22004816','CE23005030','CE21009405','CE22012975','CE22010001','CE22011513','CE23013896','CE23002363','CE19005407','CE19008000','CE19009810','CE22007403','CE19007948','CE23009295','CE20001120','CE19014351','CE20000610','CE23002831','CE20014638','CE23013343','CE23014165','CE21016896','CE20003292','CE22015143','CE24001125','CE23002421','CE19009336','CE23002074','CE20002546','CE24001901','CE19001606','CE22009736','CE19010548','CE19008853','CE22010991','CE23014102','CE20016689','CE19004262','CE23009562','CE22009001','CE19019345','CE22006714','CE22011587','CE21008384','CE23001747','CE20011292','CE20001622','CE19016871','CE21006173','CE19011196','CE21003999','CE22014860','CE23002436','CE20006243','CE19013762','CE19014356','CE20008245','CE22012248','CE20012913','CE12010833','CE15004070','CE23000058','CE21012761','CE19002976','CE19009561','CE12003209','CE20003150','CE19001475','CE23005154','CE23010438','CE20018499','CE19014365','CE22012717','CE21015934','CE20013132','CE21011969','CE21006590','CE20010968','CE23003853','CE19006731','CE20012661','CE19014495','CE23004358','CE19008554','CE12003481','CE21010313','CE19005606','CE24002068','CE19012746','CE22006893','CE20000497','CE19004484','CE19019300','CE20007394','CE19004709','CE22009437','CE19003007','CE20003512','CE20008813','CE19006620','CE22013816','CE23012610','CE23000787','CE20008316','CE19018571','CE23008403','CE20008130','CE20013020','CE20014591','CE19002826','CE23003059','CE21012920','CE23010317','CE19001686','CE19001411','CE21012638','CE22001793','CE20002331','CE22003873','CE21008521','CE22006128','CE19009748','CE24002782','CE22011816','CE20017803','CE20006246','CE19010718','CE19005680','CE23000343','CE23007720','CE21010763','CE19015601','CE23011648','CE23011763','CE19018118','CE19007967','CE22012227','CE19013394','CE19016400','CE22004361','CE19002524','CE23010807','CE20003397','CE21011776','CE20004736','CE23005362','CE22014454','CE19005224','CE22011538','CE23010784','CE21003639','CE22008060','CE22014307','CE19006949','CE23014035','CE23000733','CE19007174','CE23009656','CE19011783','CE23002446','CE20012172','CE20018297','CE22015243','CE22012244','CE22005890','CE14010124','CE13011483','CE14001851','CE19001083','CE19007005','CE23013870','CE23013902','CE20012565','CE23008547','CE21012485','CE21014466','CE21009616','CE21015281','CE22010385','CE20004993','CE14005007','CE23008919','CE24002844','CE22007390','CE23010656','CE21004311','CE22001149','CE21013884','CE19014358','CE19015146','CE21008386','CE24002767','CE15000614','CE20014082','CE22014182','CE19009841','CE21015914','CE20006690','CE21012900','CE21008633','CE20017129','CE19018457','CE19016224','CE20007033','CE17020054','CE21006656','CE19007624','CE19007856','CE24000155','CE21003053','CE20017241','CE21011881','CE20008418','CE20010455','CE20004732','CE19014570','CE20006292','CE21015375','CE19011447','CE19000792','CE21016389','CE19014360','CE22014462','CE21006869','CE18016947','CE21000243','CE19005193','CE19015620','CE19009660','CE23009887','CE19009394','CE20010371','CE19016747','CE20012261','CE20016621','CE21005706','CE19015803','CE23001600','CE21009603','CE21001824','CE23008181','CE19002202','CE20013524','CE19000089','CE22004210','CE19005975','CE19011418','CE15005695','CE21015426','CE15014606','CE24001159','CE23000199','CE21005536','CE09010970','CE19008023','CE23011791','CE21009067','CE14011996','CE19010936','CE19016716','CE21011355','CE23003583','CE19011802','CE19010955','CE19016203','CE21010910','CE24002426','CE21016673','CE23012219','CE22013786','CE19009668','CE22011836','CE19009143','CE23000542','CE20008814','CE21004395','CE21004115','CE21002610','CE19012769','CE21010936','CE19009287','CE23001979','CE19012909','CE21011878','CE23002066','CE22001087','CE23006657','CE23006359','CE20016242','CE23004804','CE22003318','CE20004878','CE19008390','CE20012528','CE21008611','CE20011023','CE20011864','CE19014999','CE21011633','CE19006885','CE21005417','CE19003467','CE23002849','CE19012235','CE23014299','CE19014787','CE22012563','CE23000697','CE23011871','CE20000772','CE24001088','CE19011733','CE23014637','CE19001888','CE21015526','CE20003493','CE20014445','CE21006950','CE21004695','CE23011954','CE20006572','CE22008689','CE23009513','CE20003050','CE21012426','CE19009735','CE11005977','CE19014998','CE19010223','CE20007557','CE19018638','CE20015660','CE23011387','CE22007121','CE22000047','CE20004381','CE23009659','CE23008130','CE19019823','CE20007412','CE19008934','CE20004016','CE19013230','CE22005119','CE21001337','CE21000775','CE19016372','CE20001956','CE20013301','CE22013147','CE21003099','CE20014278','CE19013135','CE23002208','CE07001296','CE19019109','CE21015908','CE20001749','CE20015687','CE19018345','CE22002182','CE20018105','CE21011445','CE23008789','CE20014627','CE23004210','CE19009927','CE19011446','CE19011601','CE23005483','CE23000499','CE19000107','CE15001935','CE19020066','CE23009555','CE24003156','CE22008683','CE21015760','CE20011836','CE21010788','CE21015292','CE22005681','CE20014528','CE23011254','CE24000868','CE21012407','CE19018960','CE21009065','CE19014789','CE23011930','CE19015375','CE19013427','CE13015163','CE21003071','CE24000638','CE21012732','CE23005375','CE21007358','CE20007758','CE19011415','CE19008372','CE21013741','CE19006738','CE23002691','CE21010804','CE21010404','CE19004732','CE21003873','CE18009943','CE24003192','CE21002922','CE24002441','CE21011960','CE19011951','CE19015807','CE22004245','CE23013466','CE23005114','CE19019042','CE23004448','CE13001146','CE15003234','CE19000075','CE22014720','CE23005270','CE20007832','CE21011578','CE23011187','CE22001295','CE19016119','CE21015152','CE22014515','CE23013660','CE21003858','CE21005508','CE20013249','CE19000309','CE19015441','CE23013201','CE21008769','CE20008086','CE23001657','CE22000405','CE22006223','CE20003009','CE23006589','CE23011376','CE19013429','CE19014786','CE23014462','CE23005238','CE20005395','CE23004420','CE23003257','CE21002906','CE23006630','CE19005858','CE22012514','CE23012617','CE19009646','CE19013927','CE19011782','CE23012694','CE23005147','CE19007844','CE22012490','CE19020275','CE20002228','CE21011362','CE23011087','CE19009909','CE23003399','CE19014363','CE24000786','CE21005468','CE20008282','CE21001701','CE22001252','CE21010091','CE19016202','CE21011856','CE23010066','CE22001653','CE24002049','CE19011432','CE19014641','CE19015002','CE19006459','CE19018760','CE23002026','CE23001005','CE21007737','CE20004731','CE22012004','CE21010824','CE23002216','CE23001411','CE22005981','CE19002751','CE20005115','CE20012329','CE09013743','CE19010748'
    )
	--and b.NUMBER_KEY = @number_key
	and (
		(year(b.THE_DATE) = year(a.THE_DATE) and month(b.THE_DATE) = month(a.THE_DATE) and day(b.THE_DATE) = day(a.THE_DATE) )
		--or (year(b2.greater_date) = year(a.date_ent) and month(b2.greater_date) = month(a.date_ent) and day(b2.greater_date) = day(a.date_ent) )
		--or a.item_id = b.ITEM_ID
	)
	--and a.parent_unique_key not like 'ORPH-%'
	and a.item_id <> b.ITEM_ID
	--and b.NUMBER_KEY = 'CE04002961'
	and f.number_key is null	
;
insert into #_violations
select distinct
    a.NUMBER_KEY
    ,a.parent_unique_key
    ,b.item_id --count(distinct b.item_id) ct --,count(b.number_key) ct
--into #violations
from #g a
left join hcfl_src..apd_itms b on b.RECORD_TYPE = 'CD' and b.NUMBER_KEY = a.NUMBER_KEY
--left join greater_dates b2 on b2.number_key = b.number_key and b2.sequence = b.sequence and b2.item_id = b.item_id and b2.the_date = b.the_Date	
left join #_violations f on f.number_key = b.number_key and f.parent_unique_key = a.parent_unique_key and f.item_id = b.item_id
where
    1=1
	and b.NUMBER_KEY is not null
    and b.number_key in ('CE20008234' --'CE21005536','CE19019042','CE21009603','CE19011049','CE23013343','CE23012694','CE21009067','CE23011187','CE19010223','CE19005193','CE23005114','CE22012975','CE22014860','CE22008356','CE22013786','CE23003461','CE23014129','CE22014110','CE19011418','CE21005870','CE20006572','CE23001411','CE19011783','CE23004666','CE23000058','CE19004709','CE20001956','CE21000243','CE19012398','CE20008234','CE21014360','CE22009736','CE22014685','CE22014657','CE19009809','CE24002441','CE22006893','CE19014786','CE23000913','CE19011421','CE21010824','CE23009508','CE21011969','CE20009721','CE19007826','CE21014995','CE21003873','CE19012874','CE21007737','CE22013816','CE23009435','CE19005819','CE21016777','CE19007948','CE23014165','CE22012717','CE23000896','CE21011018','CE23002208','CE23001747','CE21004311','CE20001120','CE20004452','CE21015105','CE21009065','CE16010830','CE21000775','CE23003399','CE19011196','CE22003059','CE23009136','CE21013889','CE21002906','CE20000742','CE19015601','CE22010175','CE23013302','CE22012248','CE20002119','CE23000199','CE07006722','CE23011454','CE24002068','CE19011951','CE21012765','CE22001252','CE20014591','CE22003873','CE20011292','CE19011732','CE19011432','CE19005606','CE21010756','CE23003520','CE22002774','CE19001103','CE20003079','CE20007412','CE21004115'
)
	--and b.NUMBER_KEY = @number_key
	and (
		(year(b.THE_DATE) = year(a.date_ent) and month(b.THE_DATE) = month(a.date_ent) and day(b.THE_DATE) = day(a.date_ent) )
		--or (year(b2.greater_date) = year(a.date_ent) and month(b2.greater_date) = month(a.date_ent) and day(b2.greater_date) = day(a.date_ent) )
		--or a.item_id = b.ITEM_ID
	)
	and a.item_id <> b.ITEM_ID
	and f.number_key is null	
;


;with greater_dates as (
	select 
		 b.number_key
		,b.sequence
		,b.item_id
		,b.the_date
		,b2.THE_DATE greater_date
	from hcfl_src..apd_itms b
	outer apply (select top 1 * from hcfl_src..APD_ITMS where record_type = 'cd' and NUMBER_KEY = b.NUMBER_KEY and THE_DATE <> b.THE_DATE) b2
	where
		1=1
		and b.number_key in (--'CE19011421'
			'CE19014786','CE23000913','CE19011421','CE21010824','CE23009508','CE21011969','CE20009721','CE19007826','CE21014995','CE22014110','CE19011418','CE21005870','CE20006572','CE23001411','CE19011783','CE23004666','CE23009435','CE19005819','CE21016777','CE19007948','CE23014165','CE22012717','CE23000896','CE19011432','CE19005606','CE21010756','CE23003520','CE22002774','CE19001103','CE20003079','CE20007412','CE21004115','CE21000775','CE23003399','CE19011196','CE22003059','CE23009136','CE21013889','CE21002906','CE20000742','CE19015601','CE22010175','CE23013302','CE22012248','CE20002119','CE23000199','CE07006722','CE23011454','CE24002068','CE19011951','CE21012765','CE22001252','CE20014591','CE22003873','CE20011292','CE19011732','CE19012398','CE20008234','CE21014360','CE22009736','CE22014685','CE22014657','CE19009809','CE24002441','CE22006893','CE21005536','CE19019042','CE21009603','CE19011049','CE23013343','CE23012694','CE21009067','CE23011187','CE19010223','CE19005193','CE23005114','CE22012975','CE22014860','CE22008356','CE22013786','CE23003461','CE23014129','CE21003873','CE19012874','CE21007737','CE22013816','CE23000058','CE19004709','CE20001956','CE21000243','CE21011018','CE23002208','CE23001747','CE21004311','CE20001120','CE20004452','CE21015105','CE21009065','CE16010830'
            ,'CE24002698','CE24002677','CE24000095','CE24002940','CE24002516','CE24001571','CE24000841','CE24000276','CE21014437','CE24000153','CE24003572','CE24001826','CE24002465','CE24000537','CE24002759','CE24002219','CE24003484','CE23009330','CE24002813','CE24000171','CE24000155','CE24003615','CE23013361','CE19011049','CE21014435','CE24003382','CE24002844','CE24002618','CE24001446','CE24002499','CE23014427','CE24002629','CE24000956','CE24000307','CE23014095','CE24000177','CE23014301','CE24003053','CE23013872','CE23012257','CE24001949','CE24001585','CE24003139'
            ,'CE24007466','CE24004807','CE20017588','CE24000095','CE24003833','CE24004913','CE24007447','CE24005250','CE24007204','CE24007484','CE24004245','CE24004796','CE24004219','CE24003859','CE24007235','CE24006348','CE24005928','CE24007812','CE23014475','CE23009075','CE24004710','CE24005717','CE24006132','CE24006594','CE24000177','CE24006287','CE24004515','CE24004388','CE24004119','CE24006719'
		)
		and b2.the_Date is not null
		and b.RECORD_TYPE = 'cd'
		and not exists (select 1 from #_violations where number_key = b.NUMBER_KEY and item_id = b.ITEM_ID)
)
insert into #_violations
select distinct
	a.NUMBER_KEY
    ,a.parent_unique_key
    ,b.ITEM_ID   	
from #g a
left join hcfl_src..apd_itms b on b.RECORD_TYPE = 'CD' and b.NUMBER_KEY = a.NUMBER_KEY
left join greater_dates b2 on b2.number_key = b.number_key and b2.sequence = b.sequence and b2.item_id = b.item_id and b2.the_date = b.the_Date	
--left join #_violations f on f.parent_unique_key = a.parent_unique_key and f.item_id = a.item_id
where
    1=1
	and b.NUMBER_KEY is not null
	--and b.NUMBER_KEY = 'CE20008234 '
	and (
		--(year(b.THE_DATE) = year(a.date_ent) and month(b.THE_DATE) = month(a.date_ent) and day(b.THE_DATE) = day(a.date_ent) )
		(year(b2.greater_date) = year(a.date_ent) and month(b2.greater_date) = month(a.date_ent) and day(b2.greater_date) = day(a.date_ent) )
	)
	and a.item_id <> b.ITEM_ID
	--and f.number_key is null
;

insert into #_violations
select *
from (VALUES 
('CE19011049','A007910186','S13.2.1.11')
,('CE19011049','A007910186','S13.2.1.5')
,('CE19011049','A007910186','NR10.5.2')
,('CE24000095','A009153805','PM12.3A   ') --arbitrary association to capture them, and it's late
,('CE24000095','A009153805','R11.11.2  ') --arbitrary association to capture them, and it's late
,('CE24000095','A009153805','R11.7.5   ') --arbitrary association to capture them, and it's late
,('CE24000095','A009153805','R11.7.2   ') --arbitrary association to capture them, and it's late
,('CE24000095','A009153805','R11.6.4   ') --arbitrary association to capture them, and it's late
,('CE24000095','A009153805','PM12.4    ') --arbitrary association to capture them, and it's late
,('CE24000177','A009133092','NR10.1    ') --arbitrary association to capture them, and it's late
,('CE24000177','A009133092','PM12.3A   ') --arbitrary association to capture them, and it's late
,('CE24000177','A009133092','R11.5.5   ') --arbitrary association to capture them, and it's late
,('CE24000177','A009133092','R11.7.9   ') --arbitrary association to capture them, and it's late
,('CE24000177','A009133092','PM12.3B   ') --arbitrary association to capture them, and it's late

) t(number_key,parent_unique_key,item_id)
;
delete a
from #_violations a 
join (VALUES 
 ('CE20014591','A008555900','R11.7.4   ')
,('CE19011049','A007962881','S13.2.1.11')
,('CE19011049','A007962881','S13.2.1.5 ')
) d(number_key,parent_unique_key,item_id)
	on d.number_key = a.number_key
	and d.parent_unique_key = a.parent_unique_key 
	and d.item_id = a.item_id
where
	1=1
;


;IF OBJECT_ID('tempdb.dbo.#violations', 'U') IS NOT NULL drop table #violations
select
	number_key 
	,parent_unique_key 
	,count(item_id) ct 
into #violations
from #_violations
group by number_key,parent_unique_key
;
go

    --VERIFY the above
        --shoehorn some things
    update v set 
		ct = a.apd_itms_violations_ct
    from (
        select
            a.NUMBER_KEY
            ,a.violations_ct as apd_itms_violations_ct
            ,sum(b.ct) as my_violations_ct
        from (
            select
                a.number_key
                ,count(*) violations_ct
            from hcfl_src..apd_itms a
            join jms_apd_base_filtered f on f.NUMBER_KEY = a.NUMBER_KEY
            where
                1=1
                and a.RECORD_TYPE = 'CD'
            group by a.NUMBER_KEY
            having count(*) > 0
        ) a
        left join #violations b on b.numbeR_key = a.NUMBER_KEY
        where
            1=1
            --and a.violations_ct <> b.ct
            --and a.NUMBER_KEY = 'CE23007349'
        group by  a.NUMBER_KEY
            ,a.violations_ct-- as apd_itms_violations_ct
		having a.violations_ct <> sum(b.ct)
    ) a
	left join  #violations v on v.NUMBER_KEY = a.NUMBER_KEY and v.ct = a.my_violations_ct
    ;
--if 1 = (
--    select distinct 1 
--    from (
--        select
--            a.NUMBER_KEY
--            ,a.violations_ct as apd_itms_violations_ct
--            ,sum(b.ct) as my_violations_ct
--        from (
--            select
--                a.number_key
--                ,count(*) violations_ct
--            from hcfl_src..apd_itms a
--            join jms_apd_base_filtered f on f.NUMBER_KEY = a.NUMBER_KEY
--            where
--                1=1
--                and a.RECORD_TYPE = 'CD'
--            group by a.NUMBER_KEY
--            having count(*) > 0
--        ) a
--        left join #violations b on b.numbeR_key = a.NUMBER_KEY
--        where
--            1=1
--            --and a.violations_ct <> b.ct
--            --and a.NUMBER_KEY = 'CE23007349'
--        group by  a.NUMBER_KEY
--            ,a.violations_ct-- as apd_itms_violations_ct
--		having a.violations_ct <> sum(b.ct)
--    ) a
--    
--) RAISERROR ('violations counts mismatch', 16, 1)
--;          
go

--rem all in h are the site visits to which subsequent row statuses are applied. Similarly: this is to find the req_opt of the subsequent rows for a given site visit.
;with j as (
	select distinct
        a.NUMBER_KEY
        ,a.parent_unique_key
        ,b.REQ_OPT
    --into #violations
    from #g a
    left join hcfl_src..apd_itms b
        on
			b.RECORD_TYPE = 'CD'
			and b.NUMBER_KEY = a.NUMBER_KEY
			and year(b.THE_DATE) = year(a.the_date) and month(b.THE_DATE) = month(a.the_date) and day(b.THE_DATE) = day(a.THE_DATE)
			and b.ITEM_ID = a.ITEM_ID
		
    where
        1=1
		and b.req_opt is not null
        --and c.NUMBER_KEY = 'CE22010196'
    --group by a.number_key,a.parent_unique_key
), doubles as (
	select parent_unique_key, count(distinct req_opt) ct from j group by parent_unique_key  having count(distinct req_opt) > 1
)
select distinct
	a.number_key
	,a.parent_unique_key
	,case when f.parent_unique_key is not null then 'R' else a.REQ_OPT end req_opt
into #req_opt
from j a
left join doubles f on f.parent_unique_key = a.parent_unique_key
;


;IF OBJECT_ID('hcfl_prod.dbo.jms_inspections_compliantOrNot', 'U') IS NOT NULL drop table hcfl_prod.dbo.jms_inspections_compliantOrNot
;
select distinct 
    a1.number_key
	,a1.UNIQUE_KEY
	,a1.ACTION_ENT
	,a1.inspection_type
	,a1.inspection_result
    ,r.req_opt
	,isnull(v.ct,0) violations_count
	,trim('^|' from stuff((
        select 
            '^|^' + cast(
				trim(replace(replace(replace(replace(   isnull(a2.any_comments,'')   ,'"',''''''),'''',''),char(13),''),char(10),'�')) 
				as varchar(max)
			)
        from #h a2 with(nolock)
        where 
            a2.UNIQUE_key = a1.UNIQUE_key
        group by a2.any_comments
        order by a2.any_comments
        FOR XML PATH('')
     ), 1, 1, '')) as any_comments
into jms_inspections_compliantOrNot
from #h a1 WITH (NOLOCK)
left join #violations v on v.NUMBER_KEY = a1.NUMBER_KEY and v.parent_unique_key = a1.UNIQUE_KEY
left join #req_opt r on r.parent_unique_key = a1.unique_key --a1 is site visits, therefore is parent unique key values.
where
    1=1
;


--ensure no duplicates
update a set
	inspection_type = (case 
            when inspection_type in ('Initial Site Visit','Quality Control Inspection') then inspection_type
            when a.any_comments like '%re%inspect%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when a.any_comments like '%re%check%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when a.any_comments like '%annual%insp%'    then 'Annual Inspection' --I don't know about pre vs post hearing
            when a.any_comments like '%post%hearing%'    then 'Post-Hearing Inspection' --I don't know about pre vs post hearing
            when a.any_comments like '%pre%hearing%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when a.any_comments like '%hear%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when a.any_comments like '%follow%up%'    then 'Follow-up Inspection' --I don't know about pre vs post hearing
            else 'Inspection'
            end		
        )
from jms_inspections_compliantOrNot a
where
	1=1
	--and a.UNIQUE_KEY = 'a008872077'
;

;WITH CTE AS (SELECT *,ROW_NUMBER() OVER (PARTITION BY number_key,unique_key,inspection_type,any_comments ORDER BY number_key) AS RN FROM jms_inspections_compliantOrNot) DELETE FROM CTE WHERE RN<>1 
;


go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0060 0040 aatable_permit_inspection.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0060 0040 aatable_permit_inspection.sql')

;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_INSP
;

;IF OBJECT_ID('tempdb.dbo.#_AATABLE_PERMIT_INSP', 'U') IS NOT NULL drop table #_AATABLE_PERMIT_INSP
;select top 0 * into #_AATABLE_PERMIT_INSP from AATABLE_PERMIT_INSP
;


--apd_insp__and__apd_insp_log
insert into #_AATABLE_PERMIT_INSP
SELECT distinct
    pmap.permitnum as Permitnum
    ,try_convert(datetime,a.the_date) as InspDate
    ,try_convert(datetime,a.the_date) as InspSchedDate
    ,null as InspReqDate
    ,0 as Insp_Number
    ,(case when i.req_opt = 'R' then 'Y' when i.req_opt = 'O' then 'N' else null end) as Insp_Required
    ,null as Phone_Num
    ,null as Latitude
    ,null as Longitude
    ,trim(replace(replace(replace(replace(       i.any_comments       ,'"',''''''),'''',''),char(13),''),char(10),'')) as Insp_Result_Comm
    ,trim(replace(replace(replace(replace(      coalesce(action_ent.description,a.action_ent,'')        ,'"',''''''),'''',''),char(13),''),char(10),'')) as Insp_Sched_Comm
    ,null as Sd_Overtime
    ,null as Display_In_ACA
    ,i.inspection_type as TT_Inspection
    ,i.inspection_result as TT_Inspection_Status
    ,null as CONTACT_NBR
    ,null as INSP_SEQ_NBR
    ,coalesce(user_id.user_name,a.user_id,'Not Set') as User_ID
    ,null as ORDER_BY
    ,null as G6_ACT_T1
    ,null as G6_ACT_T2
    ,null as G6_ACT_END_T1
    ,null as G6_ACT_END_T2
    ,null as G6_ACT_TT
    ,a.beg_time as ESTIMATED_START_TIME
    ,a.end_time as ESTIMATED_END_TIME
    ,null as G6_DESI_DD
    ,null as G6_DESI_TIME
    ,null as G6_DESI_TIME2
    ,null as CONTACT_PHONE_NUM
    ,null as CONTACT_PHONE_NUM_IDD
    ,null as CONTACT_FNAME
    ,null as CONTACT_MNAME
    ,null as CONTACT_LNAME
    ,null as G6_REQ_PHONE_NUM_IDD
    ,null as G6_REQ_PHONE_NUM
    ,i.violations_count as MAJOR_VIOLATION_COUNT
    ,null as UNIT_NBR
    ,null as GRADE
    ,null as TOTAL_SCORE
    ,null as VEHICLE_NUM
    ,null as G6_MILE_T1
    ,null as G6_MILE_T2
    ,null as G6_MILE_TT
    ,null as INSP_CANCELLED
    ,null as INSP_PENDING
    ,a.unique_key as CLIENT_UNIQUE_ID
from jms_apd_insp_filteredToPop a 
join jms_numberKey_permitnum pmap on pmap.number_key = a.NUMBER_KEY
join jms_inspections_compliantOrNot i on i.number_key = a.NUMBER_KEY and i.unique_key = a.unique_key
left join hcfl_src.dbo.usr_base user_id on user_id.user_id = a.user_id
left join jms_actionEnt_passFail action_ent on action_ent.action_ent = a.action_ent 
left join aatable_permit_history pnum on pnum.permitnum = pmap.permitnum
;

insert into AATABLE_PERMIT_INSP (
PERMITNUM,INSPDATE,INSPSCHEDDATE,INSPREQDATE,INSP_NUMBER,INSP_REQUIRED,PHONE_NUM,LATITUDE,LONGITUDE,INSP_RESULT_COMM,INSP_SCHED_COMM,SD_OVERTIME,DISPLAY_IN_ACA,TT_INSPECTION,TT_INSPECTION_STATUS,CONTACT_NBR,INSP_SEQ_NBR,USER_ID,ORDER_BY,G6_ACT_T1,G6_ACT_T2,G6_ACT_END_T1,G6_ACT_END_T2,G6_ACT_TT,ESTIMATED_START_TIME,ESTIMATED_END_TIME,G6_DESI_DD,G6_DESI_TIME,G6_DESI_TIME2,CONTACT_PHONE_NUM,CONTACT_PHONE_NUM_IDD,CONTACT_FNAME,CONTACT_MNAME,CONTACT_LNAME,G6_REQ_PHONE_NUM_IDD,G6_REQ_PHONE_NUM,MAJOR_VIOLATION_COUNT,UNIT_NBR,GRADE,TOTAL_SCORE,VEHICLE_NUM,G6_MILE_T1,G6_MILE_T2,G6_MILE_TT,INSP_CANCELLED,INSP_PENDING,CLIENT_UNIQUE_ID
)
select
    PERMITNUM,INSPDATE,INSPSCHEDDATE,INSPREQDATE
    --coalesce permits subsequent insertions into this table to occur, while retaining the row_number behavior.
    ,coalesce((select max(insp_number) as max_insp_number from AATABLE_PERMIT_INSP),0) + row_number() over(order by permitnum) as INSP_NUMBER
    ,INSP_REQUIRED,PHONE_NUM,LATITUDE,LONGITUDE,INSP_RESULT_COMM,INSP_SCHED_COMM,SD_OVERTIME,DISPLAY_IN_ACA,TT_INSPECTION,TT_INSPECTION_STATUS,CONTACT_NBR,INSP_SEQ_NBR,USER_ID,ORDER_BY,G6_ACT_T1,G6_ACT_T2,G6_ACT_END_T1,G6_ACT_END_T2,G6_ACT_TT,ESTIMATED_START_TIME,ESTIMATED_END_TIME,G6_DESI_DD,G6_DESI_TIME,G6_DESI_TIME2,CONTACT_PHONE_NUM,CONTACT_PHONE_NUM_IDD,CONTACT_FNAME,CONTACT_MNAME,CONTACT_LNAME,G6_REQ_PHONE_NUM_IDD,G6_REQ_PHONE_NUM,MAJOR_VIOLATION_COUNT,UNIT_NBR,GRADE,TOTAL_SCORE,VEHICLE_NUM,G6_MILE_T1,G6_MILE_T2,G6_MILE_TT,INSP_CANCELLED,INSP_PENDING,CLIENT_UNIQUE_ID
from #_AATABLE_PERMIT_INSP
;

;update aatable_permit_insp set User_ID = 'Spriggs, Teddy' where User_ID = 'Spriggs, Edward ''Teddy'''
;

go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0065 aatable_permit_activity.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0065 aatable_permit_activity.sql')
/*
setup
actual logic
*/

IF OBJECT_ID('tempdb.dbo.##completed', 'U') IS NOT NULL 
insert into ##completed values (getdate(),'aatable_permit_activity')
;

--setup

--determine child rows per inspection, then assert inspection type and inspection result based on those children
;IF OBJECT_ID('tempdb.dbo.#parents', 'U') IS NOT NULL drop table #parents
;IF OBJECT_ID('tempdb.dbo.#is_initial_site_visit', 'U') IS NOT NULL drop table #is_initial_site_visit
;IF OBJECT_ID('tempdb.dbo.#g', 'U') IS NOT NULL drop table #g
;IF OBJECT_ID('tempdb.dbo.#orphaned', 'U') IS NOT NULL drop table #orphaned
;IF OBJECT_ID('tempdb.dbo.#h', 'U') IS NOT NULL drop table #h
;
go


--;with parents
    --assumes inspections are site visits, and results are implied by the subsequent rows prior to the following site visit.
	select
		number_key
		,unique_key
		,date_ent
		,the_Date
		,action_ent
    into #parents
	from jms_apd_insp_filteredToPop
	where action_ent in ('SV','SSV','QCSV','LSV')
	--and number_key = 'CE18015425'
;
--), is_initial_site_visit as (
    --"initial site visiit" is an accela inspection type
	select
		b.UNIQUE_KEY
        ,b.action_ent
    into #is_initial_site_visit
	from jms_apd_base_filtered a
	outer apply (select top 1 * from jms_apd_insp_filteredToPop where NUMBER_KEY = a.NUMBER_KEY and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent,the_date) b
;
--),g as (
    select
        a.number_key
        ,a.item_id
        ,a.unique_key
        ,a.action_ent
        ,action_ent.DESCRIPTION action_ent_desc
        ,case when is_initial_site_visit.UNIQUE_KEY is not null then 1 else 0 end as is_initial_site_visit
        ,'xxxx' [ ]
        ,coalesce(b.unique_key,is_initial_site_visit.unique_key) parent_unique_key
        ,b.action_ent parent_action_ent
        ,(case 
            when is_initial_site_visit.UNIQUE_KEY is not null then 'Initial Site Visit'
            when a.ACTION_ENT in ('QCSV','LSV') then 'Quality Control Inspection'
            when A.ACTION_ENT = 'SSV' then 'Re-Inspection'
            --when A.ACTION_ENT = 'CREV' then 'Case Review'
            when  a.any_comments like '%re%inspect%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%re%check%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%annual%insp%'    then 'Annual Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%post%hearing%'    then 'Post-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%pre%hearing%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%hear%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%follow%up%'    then 'Follow-up Inspection' --I don't know about pre vs post hearing
            else 'Inspection'
            end		
        ) as inspection_type
        ,(case 
            --when a.ACTION_ENT in ('SV','SSV','QCSV','LSV') then null
            when a.ACTION_ENT = 'NOVR' then 'Notice of Violation Requested'
            when a.ACTION_ENT = 'NOVC' then 'NOV issued'
            when a.ACTION_ENT = 'NOVB' then 'Combo Issued'
            when a.action_ent = 'ECIT' then 'Citation Issued'
            when a.ACTION_ENT = 'COMP' then 'Compliant'
            when a.ACTION_ENT = 'VIOL' then 'Violation'
            when A.ACTION_ENT in ('CA','CNCL') then 'No Violation'
            when  a.any_comments like '%dead%animal%'	  then 'Extension'
            when  a.any_comments like '%exten%'	  then 'Extension'
            when  a.any_comments like '%violation%'  then 'Violation'
            when  a.any_comments like '%non%compli%' then 'Not Compliant'
            when  a.any_comments like '%send%nov%'   then 'NOV Issued'
            when  a.any_comments like '%req%nov%'    then 'Notice of Violation Requested'
            when  a.any_comments like '%cont%fin%'    then 'Not Compliant' --continue fines
            else null
            end
        ) as inspection_result
        
        ,'xxxx' [2]
        ,a.date_ent
        ,a.the_date
        ,'xxxx'[3]
        ,a.any_comments
        
    into #g
    from jms_apd_insp_filteredToPop a
    outer apply (select top 1 * from #parents where number_key = a.number_key and the_date <= a.the_date and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent desc,the_date desc) b
    left join jms_actionEnt_passFail action_ent on action_ent.action_ent = a.action_ent
    left join #is_initial_site_visit is_initial_site_visit on is_initial_site_visit.UNIQUE_KEY = a.UNIQUE_KEY
    where
        1=1
        --and a.action_ent not in ('SV','SSV','QCSV','LSV')
        --and a.number_key = 
        --	--'CE03003081'
        --	--'CE22014264'
        --	'CE22014971'
    --order by --a.date_ent,a.the_Date,case when a.action_ent in ('SV','SSV','QCSV','LSV') then 1 else 2 end
    --	a.UNIQUE_KEY
;



--), h as (
    select distinct
         a1.NUMBER_KEY
        ,a1.UNIQUE_KEY
        ,a1.action_ent
        --,a1.inspection_type
        ,coalesce(a1.inspection_result,'Not Set') inspection_result
        ,trim('^|' from stuff((
            select 
                '^|^' + cast(
                    trim(replace(replace(replace(replace(   isnull(a2.any_comments,'')   ,'"',''''''),'''',''),char(13),''),char(10),'�')) 
                    as varchar(max)
                )
            from #g a2 with(nolock)
            where 
                a2.unique_key = a1.unique_key
            group by a2.any_comments
            order by a2.any_comments
            FOR XML PATH('')
         ), 1, 1, '')) as any_comments
    into #h
    from #g a1
    where
        1=1
        and a1.ACTION_ENT not in ('SV','SSV','QCSV','LSV','COM','ACOM')
        --and a1.number_key = 'CE17015692'
		--and a1.unique_key = 'A008828260'
    ;
	--select * from #g a1 where 1=1 and a1.unique_key = 'A008828260'
    --order by a.UNIQUE_KEY
--)
;



--actual logic

;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table aatable_permit_activity
;

;print 'aatable_permit_activity'
;
insert into aatable_permit_activity (
PERMITNUM,ACT_NAME,ACT_DES,ACT_TYPE,ACT_DATE,ACT_DEPT,ACT_STAF,REC_DATE,REC_FUL_NAM,INTERNAL_USE_ONLY,ACT_DUE_DATE,ACT_PRIORITY,ACT_STATUS,act_unique_id
)
select distinct
     pmap.permitnum as PERMITNUM
    ,isnull(i.parent_unique_key + '-','') + a.unique_key as ACT_NAME
    ,left((case 
        when '' = (case when trim(coalesce(h.any_comments,'')) <> '' then h.any_comments else '' end)
        then 'Not Set'
        else (case when trim(coalesce(h.any_comments,'')) <> '' then h.any_comments else '' end)
        end
     ),4000) as ACT_DES --probably change this to `left(action_ent.description,30)`
    ,coalesce(item_no.description,i.item_id,'Not Set') as ACT_TYPE --'Meeting' or 'Phone Call'
    ,coalesce(try_convert(datetime,a.date_ent),'1900-01-01 00:00:00') as ACT_DATE
    ,'Code Enforcement' as ACT_DEPT
    ,coalesce(user_id.user_name,'Not Set') as ACT_STAF
    ,coalesce(try_convert(datetime,a.date_ent),'1900-01-01 00:00:00') as REC_DATE
    ,coalesce(user_id.user_name,a.user_id,'Not Set') as REC_FUL_NAM
    ,'N' as INTERNAL_USE_ONLY
    ,null as ACT_DUE_DATE
    ,null as ACT_PRIORITY
    ,left(action_ent.description,30) as ACT_STATUS --'Not Started','In Process','Completed','Waiting on someone else','Deferred'
    ,row_number() over(order by permitnum) act_unique_id
from jms_apd_insp_filteredToPop a
join jms_numberKey_permitnum pmap on pmap.number_key = a.NUMBER_KEY
join #g i on i.number_key = a.NUMBER_KEY and i.unique_key = a.unique_key
left join hcfl_src.dbo.usr_base user_id on user_id.user_id = a.user_id
left join hcfl_src.dbo.tab_insp item_no on convert(varchar(max),item_no.item_no) = convert(varchar(max),a.item_id)

left join #h h on h.unique_key = i.unique_key
left join jms_actionEnt_passFail action_ent on action_ent.action_ent = h.action_ent

WHERE
    1=1
    and a.action_ent not in ('SV','SSV','QCSV','LSV','COM','ACOM') --SV things are site visits, which are accounted for in aatable_permit_insp.
    and a.record_type not in ('CD') -- these are for guidesheets, I think
	--and a.unique_key = 'A008828260'
;

;update aatable_permit_activity set rec_ful_nam = 'Spriggs, Teddy' where rec_ful_nam = 'Spriggs, Edward ''Teddy'''
;update aatable_permit_activity set ACT_STAF = 'Spriggs, Teddy' where ACT_STAF = 'Spriggs, Edward ''Teddy'''
;

go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0070 aatable_permit_comments.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0070 aatable_permit_comments.sql')
/*
all comments
inspection comments
remaining comments
duplicate comments into cbs records
*/



/*
--all comments
insert into aatable_permit_comment
SELECT
     pnum.permitnum PERMITNUM
    ,L.data_level+':'+ coalesce( convert(varchar(max),L.the_text),'') COMMENTS
    ,coalesce(L.user_x,L.user_id) ADDEDBY
    ,L.date_entered ADDEDDATE
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src..lhn_tab l on l.number_key = pmap.number_key
;
*/


--inspection comments

--determine child rows per inspection, then assert inspection type and inspection result based on those children
;IF OBJECT_ID('tempdb.dbo.#parents', 'U') IS NOT NULL drop table #parents
;IF OBJECT_ID('tempdb.dbo.#is_initial_site_visit', 'U') IS NOT NULL drop table #is_initial_site_visit
;IF OBJECT_ID('tempdb.dbo.#g', 'U') IS NOT NULL drop table #g
;IF OBJECT_ID('tempdb.dbo.#orphaned', 'U') IS NOT NULL drop table #orphaned
;IF OBJECT_ID('tempdb.dbo.#h', 'U') IS NOT NULL drop table #h
;IF OBJECT_ID('tempdb.dbo.#req_opt', 'U') IS NOT NULL drop table #req_opt
;
go

--;with parents
    --assumes inspections are site visits, and results are implied by the subsequent rows prior to the following site visit.
    select
        number_key
        ,unique_key
        ,date_ent
        ,the_Date
        ,action_ent
    into #parents
    from jms_apd_insp_filteredToPop
    where action_ent in ('SV','SSV','QCSV','LSV')
    --and number_key = 'CE18015425'
;
--), is_initial_site_visit as (
    --"initial site visiit" is an accela inspection type
    select
        b.UNIQUE_KEY
        ,b.action_ent
    into #is_initial_site_visit
    from jms_apd_base_filtered a
    outer apply (select top 1 * from jms_apd_insp_filteredToPop where NUMBER_KEY = a.NUMBER_KEY and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent,the_date) b
;
--),g as (
    select
        a.number_key
        ,a.item_id
        ,a.unique_key
        ,a.action_ent
        ,action_ent.DESCRIPTION action_ent_desc
        ,case when is_initial_site_visit.UNIQUE_KEY is not null then 1 else 0 end as is_initial_site_visit
        ,'xxxx' [ ]
        ,coalesce(b.unique_key,is_initial_site_visit.unique_key) parent_unique_key
        ,b.action_ent parent_action_ent
        ,(case 
            when is_initial_site_visit.UNIQUE_KEY is not null then 'Initial Site Visit'
            when a.ACTION_ENT in ('QCSV','LSV') then 'Quality Control Inspection'
            when  a.any_comments like '%re%inspect%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%re%check%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%annual%insp%'    then 'Annual Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%post%hearing%'    then 'Post-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%pre%hearing%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%hear%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%follow%up%'    then 'Follow-up Inspection' --I don't know about pre vs post hearing
            else 'Inspection'
            end        
        ) as inspection_type
        ,(case 
            --when a.ACTION_ENT in ('SV','SSV','QCSV','LSV') then null
            when a.ACTION_ENT = 'NOVR' then 'Notice of Violation Requested'
            when a.ACTION_ENT = 'NOVC' then 'NOV issued'
            when a.ACTION_ENT = 'NOVB' then 'Combo Issued'
            when a.action_ent = 'ECIT' then 'Citation Issued'
            when a.ACTION_ENT = 'COMP' then 'Compliant'
            when a.ACTION_ENT = 'VIOL' then 'Violation'
            when A.ACTION_ENT in ('CA','CNCL') then 'No Violation'
            when a.any_comments like '%dead%animal%'      then 'Extension'
            when a.any_comments like '%exten%'      then 'Extension'
            when a.any_comments like '%violation%'  then 'Violation'
            when a.any_comments like '%non%compli%' then 'Not Compliant'
            when a.any_comments like '%send%nov%'   then 'NOV Issued'
            when a.any_comments like '%req%nov%'    then 'Notice of Violation Requested'
            when a.any_comments like '%cont%fin%'    then 'Not Compliant' --continue fines
            else null
            end
        ) as inspection_result
        
        ,'xxxx' [2]
        ,a.date_ent
        ,a.the_date
        ,'xxxx'[3]
        ,a.any_comments
    into #g
    from jms_apd_insp_filteredToPop a
    outer apply (select top 1 * from #parents where number_key = a.number_key and the_date <= a.the_date and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent desc,the_date desc) b
    left join jms_actionEnt_passFail action_ent on action_ent.action_ent = a.action_ent
    left join #is_initial_site_visit is_initial_site_visit on is_initial_site_visit.UNIQUE_KEY = a.UNIQUE_KEY
    where
        1=1
        --and a.action_ent not in ('SV','SSV','QCSV','LSV')
        --and a.number_key = 
        --    --'CE03003081'
        --    --'CE22014264'
        --    'CE22014971'
    --order by --a.date_ent,a.the_Date,case when a.action_ent in ('SV','SSV','QCSV','LSV') then 1 else 2 end, l.THE_TEXT
    --    a.UNIQUE_KEY
;

;IF OBJECT_ID('tempdb.dbo.#_numberKey_parentUniqueKey_theText', 'U') IS NOT NULL drop table #_numberKey_parentUniqueKey_theText
;
select distinct
	g.number_key
	,g.parent_unique_key
	--,g.unique_key
	,g.the_date as the_date_g
	--,ji.any_comments
    ,'xxxx' [x]
    ,l.the_text
    --,l.*
	
into #_numberKey_parentUniqueKey_theText
from #g g
join jms_apd_insp_filteredToPop ji on ji.unique_key = g.unique_key
join hcfl_src..lhn_tab l 
	on l.number_key = ji.number_key
	and l.user_id = ji.inspector
	and l.date_entered = ji.the_date
where
	1=1
	and l.data_level = 'comment'
	--and l.number_key = 'CE10015459'
--order by g.number_key,g.the_date
;


;IF OBJECT_ID('tempdb.dbo.#numberKey_parentUniqueKey_theText', 'U') IS NOT NULL drop table #numberKey_parentUniqueKey_theText

select
	number_key
	,parent_unique_key
	,the_date_g as the_date
	,'�'+STUFF ((
		select '��' + a2.the_text
		from #_numberKey_parentUniqueKey_theText a2
		where 
			a2.parent_unique_key = a1.parent_unique_key
		order by the_date_g
		for XML PATH('')
    ), 1, 1, '') the_text
into #numberKey_parentUniqueKey_theText
from #_numberKey_parentUniqueKey_theText a1
;

update i set
	i.insp_result_comm = trim(' �' from coalesce(i.insp_result_comm,'') + '��lhn_tab_comments:'+trim('�' from a.the_text))
from aatable_permit_insp i
join #numberKey_parentUniqueKey_theText a 
    on a.parent_unique_key = i.client_unique_id
;





--remaining comments
;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table aatable_permit_comment
;
insert into aatable_permit_comment
SELECT
     pnum.permitnum PERMITNUM
    ,L.data_level+':'+ coalesce( convert(varchar(max),L.the_text),'') COMMENTS
    ,coalesce(L.user_x,L.user_id) ADDEDBY
    ,try_convert(datetime,L.date_entered) ADDEDDATE
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
--join hcfl_src..lhn_tab l on l.number_key = pmap.number_key
join (
    select *
    from hcfl_src..lhn_tab l
    where
        1=1
        and not exists (
            select 1
            from #_numberKey_parentUniqueKey_theText
            where 
                1=1
                and number_key = l.number_key
                and the_text = l.the_text
                and l.data_level = 'comment'
        )
) l on l.number_key = pmap.number_key
;

;update aatable_permit_comment set addedby = 'Spriggs, Teddy' where addedby =  'Spriggs, Edward ''Teddy'''
;

--duplicate comments into cbs records
insert into aatable_permit_comment
select 
    pnum.PERMITNUM
	,a.COMMENTS
	,a.ADDEDBY	
    ,a.ADDEDDATE
from aatable_permit_comment a
join jms_numberKey_permitnum pmap on pmap.permitnum = a.permitnum
join AATABLE_PERMIT_HISTORY pnum on pnum.permitnum = a.permitnum + '-CBS'
;


go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0080 0400 aatable_permit_fee.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0080 0400 aatable_permit_fee.sql')
/*
Needs other comp_type, version flavors
for at least npool, can I find a proper looking date for the fee applications, based on fee payment dates, and existing dates in apd_base or apd_num0?

*/

;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table aatable_permit_fee
;

--insert_fees
;print 'AATABLE_PERMIT_FEE'
;
insert into AATABLE_PERMIT_FEE (
PERMITNUM,FEE_KEY,GF_FEE_PERIOD,FEE_ITEM_AMOUNT,GF_DISPLAY,ACCOUNT_CODE1,ACCOUNT_CODE2,ACCOUNT_CODE3,GF_FEE_SCHEDULE,REC_DATE,REC_FUL_NAM,GF_UNIT,INVOICE,FEE_NOTES,FEE_SCHEDULE_VERSION,INVOICE_CUSTOMIZED_NBR,TT_FEE_CODE,TT_FEE_DESC,GF_FEE_TYPE_ALLOCATION,GF_L1_ALLOCATION,GF_L2_ALLOCATION,GF_L3_ALLOCATION,VOID_FLAG,GF_FEE_APPLY_DATE
)
select distinct
    pnum.permitnum as Permitnum
    ,pnum.permitnum + '-'+ fee.fee_name fee_key
    ,'Final' as GF_Fee_Period
    ,fee.fee_value as Fee_Item_Amount
    ,0 GF_Display --dense_rank() over(partition by a.permitnum order by invoice.invoice_date) as GF_Display
    ,null as Account_Code1 --invoice.account_id --this if for breaking down fees into accounts
    ,null as Account_Code2
    ,null as Account_Code3
    ,null as GF_Fee_Schedule
    ,coalesce(try_convert(datetime,coalesce(fee.entered_date,a.entered_date)),'1900-01-01 00:00:00') as Rec_Date
    ,a.user_id as Rec_Ful_Nam
    ,null as GF_Unit
    ,'Y' as Invoice
    ,fee.note as Fee_Notes
    ,null as Fee_Schedule_Version
    ,null as INVOICE_CUSTOMIZED_NBR
    ,' ' as TT_FEE_CODE
    ,fee.fee_name as TT_FEE_DESC
    ,null as GF_FEE_ALLOCATION_TYPE
    ,null as GF_L1_ALLOCATION
    ,null as GF_L2_ALLOCATION
    ,null as GF_L3_ALLOCATION
    ,null as VOID_FLAG
    ,coalesce(try_convert(datetime, coalesce(fee.entered_date,a.entered_date)),'1900-01-01 00:00:00') as GF_FEE_APPLY_DATE
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.PERMITNUM
join hcfl_src.dbo.apd_base a on a.number_key = pmap.number_key --(select number_key as permitnum,user_id,entered_date from hcfl_Src.dbo.apd_base) pnum
--join hcfl_Src.dbo.apd_mon0 m on pnum.permitnum = m.number_key
join hcfl_prod.dbo.jms_numberKey_fee_value_note fee on fee.number_key = pmap.number_key
where
    1=1
;



go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0100 aatable_permit_payments.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0100 aatable_permit_payments.sql')
/*
NEEDS:
voids -- filter needs more than payment_metho='void': see 'NPO04744  '
other comp_type,version flavors
"swap this and above for proper permitnum at some point if you remember" -- see below within logic.
*/


--create_PERMIT_PAYMENTS
;print 'create_PERMIT_PAYMENTS';

;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_PAYMENTS
;
    --payments_applied_to_charges
IF OBJECT_ID('tempdb.dbo.##completed', 'U') IS NOT NULL 
insert into ##completed values (getdate(),'payments_applied_to_charges')
;    
insert into AATABLE_PERMIT_PAYMENTS(
PERMITNUM,PAY_KEY,PAYMENT_METHOD,PAYMENT_REF_NBR,CC_TYPE,PAYEE,PAYMENT_DATE,PAYMENT_AMOUNT,TRANSACTION_CODE,TRANSACTION_NBR,PAYMENT_COMMENT,CASHIER_ID,REGISTER_NBR,REC_DATE,REC_FUL_NAM,ACCT_ID,PAYEE_ADDRESS,PAYEE_PHONE,CC_AUTH_CODE,PAYEE_PHONE_IDD,PAYMENT_RECEIVED_CHANNEL,CHECK_NUMBER,CHECK_TYPE,DRIVER_LICENSE,CHECK_HOLDER_NAME,CHECK_HOLDER_EMAIL,PHONE_NUMBER,COUNTRY,STATE,CITY,STREET,ZIP,REASON,PAYEE_TYPE,HIST_RECEIPT_NBR, VOID_BY,VOID_DATE,payment_pay_key
)
select distinct
    pnum.permitnum as PERMITNUM
    ,trim(fd.trans_id) + '_' + trim(convert(varchar(max),fd.trans_seq)) + '-' + trim(convert(varchar(max),fd.DETL_SEQ)) as PAY_KEY
    ,isnull(ft.method,'CASH') as PAYMENT_METHOD
    ,null as PAYMENT_REF_NBR
    ,ft.cc_type as CC_TYPE
    ,null as PAYEE
    ,coalesce(try_convert(datetime,fs.POST_DATE),'1900-01-01 00:00:00') as PAYMENT_DATE
    ,fd.AMOUNT as PAYMENT_AMOUNT
    ,null as TRANSACTION_CODE
    ,null as TRANSACTION_NBR
    ,trim(';' from   isnull('historical account_code:'+fd.account_code,'') +  isnull(';'+fs.notation,'')    ) as PAYMENT_COMMENT
    ,fs.user_id as CASHIER_ID
    ,null as REGISTER_NBR
    ,coalesce(try_convert(datetime,fs.POST_DATE),'1900-01-01 00:00:00') as REC_DATE
    ,coalesce(u.user_name,fs.user_id,'Not Set') REC_FUL_NAM
    ,null as ACCT_ID
    ,null as PAYEE_ADDRESS
    ,null as PAYEE_PHONE
    ,ft.cc_authorz_no as CC_AUTH_CODE
    ,null as PAYEE_PHONE_IDD
    ,null as PAYMENT_RECEIVED_CHANNEL
    ,ft.check_no as CHECK_NUMBER
    ,null as CHECK_TYPE
    ,null as DRIVER_LICENSE
    ,null as CHECK_HOLDER_NAME
    ,null as CHECK_HOLDER_EMAIL
    ,null as PHONE_NUMBER
    ,null as COUNTRY
    ,null as STATE
    ,null as CITY
    ,null as STREET
    ,null as ZIP
    ,(case when voids.trans_id is not null then coalesce(voids.notation,'VOID_PAYMENT_REASON') else null end) as REASON
    ,null as PAYEE_TYPE
    ,trim(fd.trans_id) + '_' + trim(convert(varchar(max),fd.trans_seq)) + '-' + trim(convert(varchar(max),fd.DETL_SEQ))+ isnull('-'+trim(fs.receipt_no),'') as HIST_RECEIPT_NBR
    ,(case when voids.trans_id is not null then coalesce(voids.user_name,voids.user_id,'Not Set') else null end) as VOID_BY
    ,coalesce(try_convert(datetime,voids.post_date),'1900-01-01 00:00:00') as VOID_DATE
    ,null as payment_pay_key
from aatable_permit_history pnum --(select number_key as permitnum from hcfl_src.dbo.apd_base) pnum
left join AATABLE_PERMIT_FEE ape on ape.permitnum = pnum.permitnum --swap this and above for proper permitnum at some point if you remember
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.PERMITNUM
join hcfl_src.dbo.fee_id numberKey_transactionId on numberKey_transactionId.number_key = pmap.number_key
join hcfl_src.dbo.fee_detl   fd on fd.trans_id = numberKey_transactionId.trans_id
left join hcfl_src.dbo.fee_sum fs on fs.trans_id = numberKey_transactionId.trans_id
left join hcfl_src.dbo.fee_trn ft on ft.trans_id = numberKey_transactionId.trans_id  and ft.TRANS_SEQ = fd.TRANS_SEQ
left join hcfl_src.dbo.usr_base u on u.user_id = fs.user_id 
--voids
left join (
    SELECT
        s.post_date
        ,s.USER_ID
        ,vu.user_name
        ,s.notation
		,t.*
    from hcfl_src.dbo.fee_trn t 
    join hcfl_src.dbo.fee_sum s on s.trans_id = t.trans_id
    left join hcfl_src.dbo.usr_base vu on vu.user_id = s.user_id

	WHERE
        t.method = 'void'
) voids on voids.trans_id = ft.trans_xref
WHERE
    1=1
    and ft.method <> 'void'

;

go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0120 0020 aatable_permit_feeAllocation_paymentType_to_feeType.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0120 0020 aatable_permit_feeAllocation_paymentType_to_feeType.sql')
/*
hbcode_4__codeEnforcement_LOCKSMTH
--hbcode_5 -- irrelevant cuz one record, no tot_fee or tot_pay or balance
--hbcode_6 -- irrelevant cuz one record, no tot_fee or tot_pay or balance
--HBREHAB_1 -- irrelevant cuz one record, no tot_fee or tot_pay or balance
HBNSG_1__codeEnforcement
HBSNIPE_1__codeEnforcement
HBTEMP_1__codeEnforcement
npool__101_19801
    npool_101
    npool_9801
RCDAPP_1__LCKSMITH
RCDVIOL_1__LCKSMITH
wrviol_1

note_for_me1
note_for_me2

----TO DO:
AGE     	2012
ASBUILT 	9901
ATF     	201
ATF     	2008
ATF     	2019
ATF     	2020
AUTOPBAK	202
AUTOPROJ	201
AUTOPROJ	2007
AUTOPROJ	2011
AUTOPROJ	2016
AUTOPROJ	2018
AUTOPROJ	8901
BFL     	2012
CBSFA   	1
CBSNR   	1
CHG     	2015
CODECOMP	101
CODECOMP	2018
CODECOMP	2019
CODECOMP	8901
CODECOMP	9901
COMREV  	8901
CONSTSUB	8901
CONSUMER	1
CPOOL   	201
CPOOL   	2007
CPOOL   	2011
DAT     	202
DEMO    	8901
DEV     	1
DRIVE   	201
DRIVE   	9601
DRIVE   	9701
EMER    	8901
EXAM    	9801
FCGB    	201
FCGB    	202
FCGB    	2007
FCGB    	2011
FCGB    	2016
FCGB    	2018
FCGB    	2019
FCOM    	1
FCOM    	101
FCOM    	201
FCOM    	202
FCOM    	2007
FCOM    	2011
FCOM    	2016
FCOM    	2018
FCOM    	8901
FCOM    	9706
FCOM    	9707
FCOM    	9801
FCOM    	9901
FCONDO  	202
FCONDO  	203
FCONDO  	2007
FCONDO  	2011
FCONDO  	2018
FDUP    	201
FDUP    	203
FDUP    	2007
FDUP    	2011
FDUP    	2018
FEMAPRO 	201
FENCE   	201
FENCE   	8901
FENCE   	9701
FENCE   	9801
FENCE   	9901
FGB     	101
FGB     	8901
FGB     	9706
FGB     	9707
FGB     	9801
FGB     	9901
FHM     	201
FHM     	2007
FHM     	2011
FHM     	9801
FHM     	9901
FINSITE 	9801
FINSITE 	9901
FINSUB  	8901
FIREALRM	202
FIREALRM	9901
FIREINV 	202
FIRESPKL	202
FIREUSER	202
FIRMREV 	8901
FIRMREV 	9702
FIRMREVP	8901
FMF     	1
FMF     	101
FMF     	202
FMF     	2007
FMF     	2011
FMF     	2016
FMF     	2018
FMF     	2021
FMF     	8901
FMF     	9707
FMF     	9801
FMF     	9901
FMH     	201
FMH     	202
FMH     	2007
FMH     	2011
FMH     	8901
FMH     	9706
FMH     	9801
FMH     	9901
FOUND   	8901
FPOF    	9902
FR      	9901
FRGB    	201
FRGB    	202
FRGB    	2007
FRGB    	2011
FRGB    	2016
FRGB    	2018
FSFR    	1
FSFR    	101
FSFR    	201
FSFR    	202
FSFR    	2007
FSFR    	8901
FSFR    	9706
FSFR    	9707
FSFR    	9801
FSFT    	101
FSFT    	202
FSFT    	2007
FSFT    	2011
FSFT    	2016
FSFT    	2018
FSHELL  	101
FSHELL  	201
FSHELL  	202
FSHELL  	203
FSHELL  	2007
FSHELL  	2011
FSHELL  	2016
FSHELL  	2018
FSHELL  	8901
FSHELL  	9801
FSHELL  	9901
FTF     	201
FTF     	2008
GAS     	8901
GLASS   	202
GLASS   	2007
GLASS   	2011
GLASS   	2019
HBCBRD  	1
HBCBRD  	3
HBCBS   	1
HBCNDM  	1
HBCODE  	1
HBOUTRCH	1
INTFIN  	101
INTFIN  	201
INTFIN  	202
INTFIN  	2007
INTFIN  	2011
INTFIN  	2016
INTFIN  	2018
INTFIN  	2019
INTFIN  	2020
INTFIN  	2021
INTFIN  	8901
INTFIN  	9706
INTFIN  	9707
INTFIN  	9801
INTFIN  	9901
INTREM  	101
INTREM  	201
INTREM  	202
INTREM  	2007
INTREM  	2011
INTREM  	2016
INTREM  	2018
INTREM  	2019
INTREM  	2020
INTREM  	8901
INTREM  	9706
INTREM  	9707
INTREM  	9801
INTREM  	9901
LAL     	8901
MF      	8901
MFST    	2011
MFST    	2012
MFST    	2016
MFST    	2018
MHPARK  	201
MHPARK  	8901
MHPARK  	9801
MHPARKA 	8901
MHPK    	9612
MISC    	201
MISC    	202
MISCNEW 	202
MISCNEW 	203
MSFR    	2011
MSFR    	2012
MSFR    	2016
MSFR    	2018
MSFR    	2021
MSFRBU  	2012
MSFT    	2011
MSFT    	2012
MSFT    	2016
MSFT    	2018
NCGB    	20
NCGB    	201
NCGB    	202
NCGB    	2007
NCGB    	2011
NCGB    	2016
NCGB    	2018
NCGB    	2019
NCGB    	2020
NCOM    	1
NCOM    	101
NCOM    	201
NCOM    	202
NCOM    	2007
NCOM    	2011
NCOM    	2016
NCOM    	2018
NCOM    	2019
NCOM    	2020
NCOM    	2021
NCOM    	8901
NCOM    	9701
NCOM    	9707
NCOM    	9801
NCOM    	9901
NCONDO  	202
NCONDO  	203
NCONDO  	2007
NCONDO  	2011
NCONDO  	2016
NCONDO  	2018
NDEM    	2007
NDEM    	2011
NDEM    	8901
NDEM    	9701
NDEM    	9801
NDUP    	201
NDUP    	202
NDUP    	203
NDUP    	2007
NDUP    	2011
NDUP    	2016
NDUP    	2018
NEL     	101
NEL     	201
NEL     	2007
NEL     	2011
NEL     	8901
NEL     	9701
NEL     	9801
NGAS    	201
NGAS    	2007
NGAS    	2011
NGAS    	9607
NGAS    	9801
NGAS    	9901
NGB     	101
NGB     	8901
NGB     	9701
NGB     	9707
NGB     	9801
NGB     	9901
NGFR    	2007
NGFR    	2011
NHM     	101
NHM     	201
NHM     	2007
NHM     	2011
NHM     	8901
NHM     	9706
NHM     	9801
NME     	101
NME     	201
NME     	2007
NME     	2011
NME     	8901
NME     	9701
NME     	9801
NMF     	1
NMF     	101
NMF     	201
NMF     	202
NMF     	2007
NMF     	2011
NMF     	2016
NMF     	2018
NMF     	2021
NMF     	8901
NMF     	9701
NMF     	9707
NMF     	9801
NMF     	9901
NMFBAK  	2007
NMH     	201
NMH     	202
NMH     	2007
NMH     	2011
NMH     	2019
NMH     	2020
NMH     	2021
NMH     	8901
NMH     	9701
NMH     	9801
NMH     	9901
NOSP    	201
NOSP    	2007
NOSP    	2011
NOSP    	8901
NOSP    	9701
NOSP    	9801
NPENC   	101
NPENC   	201
NPENC   	2007
NPENC   	2011
NPL     	201
NPL     	2007
NPL     	2011
NPL     	8901
NPL     	9701
NPL     	9801
NPOOL   	201
NPOOL   	2007
NPOOL   	2011
NPOOL   	8901
NPOOL   	9701
NPREMH  	202
NRGB    	201
NRGB    	202
NRGB    	2007
NRGB    	2011
NRGB    	2016
NRGB    	2018
NRGB    	2019
NRGB    	2020
NRGB    	2021
NSFR    	1
NSFR    	101
NSFR    	201
NSFR    	202
NSFR    	2007
NSFR    	2008
NSFR    	2011
NSFR    	2016
NSFR    	2018
NSFR    	2019
NSFR    	2020
NSFR    	2021
NSFR    	8901
NSFR    	9701
NSFR    	9801
NSFR10  	2008
NSFT    	101
NSFT    	201
NSFT    	202
NSFT    	2007
NSFT    	2011
NSFT    	2016
NSFT    	2018
NSFT    	2019
NSFT    	2021
NSG     	101
NSG     	201
NSG     	2007
NSG     	2011
NSG     	2019
NSG     	8901
NSG     	9701
NSG     	9801
NSVA    	2012
NSVA    	2016
NSVA    	2018
NSVA    	2021
NWP     	201
NWP     	2007
NWP     	2011
PLANFILE	2007
PLANFILE	9607
PREPLAN 	201
PRESITE 	9801
PRESITE 	9901
PRESUB  	8901
PROCREV 	201
PROCREV 	202
PROCREV 	2011
PROCREV 	2012
PROCREV 	2018
PROCREV 	2020
PROJ    	1
PUMP    	101
PUMP    	201
PUMP    	2007
PUMP    	2011
PUMP    	9701
PUMP    	9801
PVS     	2010
PVS     	2011
RENEWAL 	201
RENEWAL 	8901
RENEWAL 	9607
RENEWAL 	9801
ROOF    	101
ROOF    	201
ROOF    	2007
ROOF    	2011
ROOF    	8901
ROOF    	9701
ROOF    	9801
ROW     	201
ROW     	8901
ROW     	9701
ROWD    	8901
ROWD    	9701
ROWNEW  	202
ROW-PGM 	201
RPOOL   	201
RPOOL   	2007
RPOOL   	2011
RWD     	2010
RWD     	2011
RWP     	2011
SCREEN  	101
SCREEN  	201
SCREEN  	2007
SCREEN  	2011
SCREEN  	8901
SCREEN  	9701
SCREEN  	9801
SHELL   	101
SHELL   	201
SHELL   	202
SHELL   	203
SHELL   	2007
SHELL   	2011
SHELL   	2016
SHELL   	2018
SHELL   	2019
SHELL   	2020
SHELL   	2021
SHELL   	8901
SHELL   	9801
SHELL   	9901
SIGN    	8901
SITESUB 	9801
SITESUB 	9901
SPP     	2010
SPP     	2011
SUB     	2003
SUBREV  	8901
TENT    	8901
TENT    	9701
TST-EMER	9607
TTC     	201
WWCS    	101
WWCS    	9001
WWCS    	9701
WWCS    	9801
ZONING  	3
ZONING  	2019
ZONING  	2020
*/
IF OBJECT_ID('hcfl_prod.dbo.jms_compType_version_feeItemNo_description_accountCode_feeKey', 'U') IS NOT NULL drop table hcfl_prod.dbo.jms_compType_version_feeItemNo_description_accountCode_feeKey
;
create table hcfl_prod.dbo.jms_compType_version_feeItemNo_description_accountCode_feeKey (
    comp_type     varchar(100)
    ,version      varchar(100)
    ,fee_item_no  varchar(100)
    ,description  varchar(100)
    ,account_code varchar(100)
    ,fee_key      varchar(100)
);





--hbcode_4__codeEnforcement_LOCKSMTH
--some records have curPart1/2/3/4 and maybe addl_fees/other_fees and nothing else
-- some records have curPart1/2/3/4 and the other fees, but only the curPart1/2/3/4 is considered
-- some records have curPart1/2/3/4 and other fees, and I think the other fees sometimes matter.
-- some records have no curPart1 but do have curPart2.
-- Some records have no curPart1/2/3/4 and do have other fee data.
-- some records have no explicit fee data, but have addl_fees and a tot_fee, or only a tot_fee
-- How the fees are considered seems to be determinable only based on how the payments are made.
-- THEREFORE: I shoehorn everything into TOT_FEE; I use calculated curPart1/2/3/4 to get a calculated total based on the logic they informed me of regarding start/endDates.
insert into hcfl_prod.dbo.jms_compType_version_feeItemNo_description_accountCode_feeKey
SELECT
    comp_type
    ,version
    ,fee_item_no
    ,description
    ,account_code
    ,fee_key
from (VALUES
-- ('HBCODE  ','4','500','CEB FINES/COSTS','','TOT_FEE'),('HBCODE  ','4','500','CEB FINES/COSTS','354105','TOT_FEE'),('HBCODE  ','4','540','Additional CEB Charges','','TOT_FEE'),('HBCODE  ','4','510','Demo Principle Remaining','','Addl_Fees'),('HBCODE  ','4','520','Condemnation Interest','','Addl_Fees'),('HBCODE  ','4','601','OVERGROWTH ABATEMENT','PPO','curOGFee'),('HBCODE  ','4','602','ACCUMULATION DISPOSAL','PPO','curDumpFee'),('HBCODE  ','4','603','DEBRIS DISPOSAL','PPO','curDebrisDisp'),('HBCODE  ','4','604','TIRE DISPOSAL','PPO','curTireDisp'),('HBCODE  ','4','700','CARRIAGE BOLTS','PPO','curAbate2'),('HBCODE  ','4','702','FENCING','PPO','curAbate3'),('HBCODE  ','4','703','FENCE POSTS','PPO','curAbate4'),('HBCODE  ','4','704','GARBAGE BAGS','PPO','curAbate5'),('HBCODE  ','4','706','PLYWOOD','PPO','curAbate7'),('HBCODE  ','4','706','PLYWOOD','PPO','curAbate1'),('HBCODE  ','4','707','SCREWS','PPO','curAbate8'),('HBCODE  ','4','708','TWO BY FOURS','PPO','curAbate9'),('HBCODE  ','4','709','ZIP TIES','PPO','curAbate10'),('HBCODE  ','4','710','PIP RECORDING COSTS','PPO','curSEUrecording'),('HBCODE  ','4','711','DUMPSTER DELIVERY','PPO','curSeuDumpster'),('HBCODE  ','4','712','INTEREST ON ABATEMENT','PPO','curAbateInterest'),('HBCODE  ','4','713','CERTIFIED MAIL','PPO','curAbateMail'),('HBCODE  ','4','714','NON PRICED ITEM','PPO','curNpi'),('HBCODE  ','4','715','Locksmith Registration','','Addl_Fees')
 ('HBCODE  ','4','500','CEB FINES/COSTS','','TOT_FEE')
,('HBCODE  ','4','500','CEB FINES/COSTS','354105','TOT_FEE')
,('HBCODE  ','4','540','Additional CEB Charges','','TOT_FEE')
,('HBCODE  ','4','510','Demo Principle Remaining','','TOT_FEE')
,('HBCODE  ','4','520','Condemnation Interest','','TOT_FEE')
,('HBCODE  ','4','601','OVERGROWTH ABATEMENT','PPO','TOT_FEE')
,('HBCODE  ','4','602','ACCUMULATION DISPOSAL','PPO','TOT_FEE')
,('HBCODE  ','4','603','DEBRIS DISPOSAL','PPO','TOT_FEE')
,('HBCODE  ','4','604','TIRE DISPOSAL','PPO','TOT_FEE')
,('HBCODE  ','4','700','CARRIAGE BOLTS','PPO','TOT_FEE')
,('HBCODE  ','4','702','FENCING','PPO','TOT_FEE')
,('HBCODE  ','4','703','FENCE POSTS','PPO','TOT_FEE')
,('HBCODE  ','4','704','GARBAGE BAGS','PPO','TOT_FEE')
,('HBCODE  ','4','706','PLYWOOD','PPO','TOT_FEE')
,('HBCODE  ','4','706','PLYWOOD','PPO','TOT_FEE')
,('HBCODE  ','4','707','SCREWS','PPO','TOT_FEE')
,('HBCODE  ','4','708','TWO BY FOURS','PPO','TOT_FEE')
,('HBCODE  ','4','709','ZIP TIES','PPO','TOT_FEE')
,('HBCODE  ','4','710','PIP RECORDING COSTS','PPO','TOT_FEE')
,('HBCODE  ','4','711','DUMPSTER DELIVERY','PPO','TOT_FEE')
,('HBCODE  ','4','712','INTEREST ON ABATEMENT','PPO','TOT_FEE')
,('HBCODE  ','4','713','CERTIFIED MAIL','PPO','TOT_FEE')
,('HBCODE  ','4','714','NON PRICED ITEM','PPO','TOT_FEE')
,('HBCODE  ','4','715','Locksmith Registration','','TOT_FEE')
) t(comp_type,version,fee_item_no,description,account_code,fee_key)
;


--HBNSG_1__codeEnforcement
insert into hcfl_prod.dbo.jms_compType_version_feeItemNo_description_accountCode_feeKey
SELECT
    comp_type
    ,version
    ,fee_item_no
    ,description
    ,account_code
    ,fee_key
from (VALUES
--This can't be correct. But what else do I direct the payments for the two number_key values to? (number_key values 111 and 154)
('HBNSG   ','1','2054','Trust Account Code Hist','TRUST ACCOUNT DEPOSIT GLNUM','fee_temp_sign') 
) t(comp_type,version,fee_item_no,description,account_code,fee_key)
;

--HBSNIPE_1__codeEnforcement
--No fees exist. No payments exist.


--HBTEMP_1__codeEnforcement
insert into hcfl_prod.dbo.jms_compType_version_feeItemNo_description_accountCode_feeKey
SELECT
    comp_type
    ,version
    ,fee_item_no
    ,description
    ,account_code
    ,fee_key
from (VALUES
('HBTEMP  ','1','500','CEB FINES/COSTS','','TOT_FEE')
,('HBTEMP  ','1','530','CEB/HCCE Costs','','TOT_FEE' )
) t(comp_type,version,fee_item_no,description,account_code,fee_key)
;

--npool__101_19801
    --npool_101
insert into hcfl_prod.dbo.jms_compType_version_feeItemNo_description_accountCode_feeKey
SELECT
    comp_type
    ,version
    ,fee_item_no
    ,description
    ,account_code
    ,fee_key
from (VALUES
 ('NPOOL','101','2001','NOC Fees','BLDG','FEE_NOTICE')
,('NPOOL','101','2001','NOC Fees','PGR00215    0186','FEE_NOTICE')
,('NPOOL','101','2080','Pool-Permits','BLDG','TOTAL_POOL')
,('NPOOL','101','2080','Pool-Permits','CUR00208    0034','TOTAL_POOL')
,('NPOOL','101','2080','Pool-Permits','PGR00208    0034','TOTAL_POOL')
,('NPOOL','101','2085','Pool-Misc Fees','CUR00208    0034','FEE_MISC')
,('NPOOL','101','2085','Pool-Misc Fees','PGR00208    0034','FEE_MISC')
,('NPOOL','101','2085','Pool-Misc Fees','POOL','FEE_MISC')
,('NPOOL','101','2130','Plumbing-Permit','PGR00210    0034','FEE_PLUMB')
,('NPOOL','101','2130','Plumbing-Permit','PLUMB','FEE_PLUMB')
,('NPOOL','101','2135','Plumbing-Reinspection','CUR00214    0034','FEE_REINSP')
,('NPOOL','101','2135','Plumbing-Reinspection','PGR00214    0034','FEE_REINSP')
,('NPOOL','101','2135','Plumbing-Reinspection','PRG00214    0034','FEE_REINSP')
,('NPOOL','101','2135','Plumbing-Reinspection','REINSPCT','FEE_REINSP')
,('NPOOL','101','2150','Electrical-Permit','CUR00204    0034','FEE_GENELE')
,('NPOOL','101','2150','Electrical-Permit','ELEC','FEE_ELEC')
,('NPOOL','101','2150','Electrical-Permit','PGR00204    0034','FEE_ELEC')
,('NPOOL','101','2155','Electrical-Reinspection','CUR00214    0034','FEE_ELREIN')
,('NPOOL','101','2155','Electrical-Reinspection','PGR00214    0034','FEE_ELREIN')
,('NPOOL','101','2155','Electrical-Reinspection','REINSPCT','FEE_ELREIN')
) t(comp_type,version,fee_item_no,description,account_code,fee_key)
;

    --npool_9801
insert into hcfl_prod.dbo.jms_compType_version_feeItemNo_description_accountCode_feeKey
SELECT
    comp_type
    ,version
    ,fee_item_no
    ,description
    ,account_code
    ,fee_key
from (VALUES
('NPOOL','9801','2040','Bldg Reinspection','REINSPCT','FEE_REINSP')
,('NPOOL','9801','2040','Bldg Reinspection','CUR00214    0034','ADDL_FEES')
,('NPOOL','9801','2080','Pool-Permits','PGR00208    0034','FEE_POOL')
,('NPOOL','9801','2080','Pool-Permits','CUR00208    0034','FEE_GENL')
,('NPOOL','9801','2080','Pool-Permits','BLDG','FEE_POOL')
,('NPOOL','9801','2085','Pool-Misc Fees','CUR00208    0034','FEE_MISC')
,('NPOOL','9801','2085','Pool-Misc Fees','PGR00208    0034','FEE_MISC')
,('NPOOL','9801','2085','Pool-Misc Fees','POOL','FEE_MISC')
,('NPOOL','9801','2130','Plumbing-Permit','PLUMB','FEE_PLUMB')
,('NPOOL','9801','2130','Plumbing-Permit','PGR00210    0034','FEE_PLUMB')
,('NPOOL','9801','2130','Plumbing-Permit','CUR00210    0034','FEE_PLUMB')
,('NPOOL','9801','2135','Plumbing-Reinspection','REINSPCT','FEE_REINSP')
,('NPOOL','9801','2135','Plumbing-Reinspection','CUR00214    0034','FEE_REINSP')
,('NPOOL','9801','2135','Plumbing-Reinspection','PGR00214    0034','FEE_REINSP')
,('NPOOL','9801','2135','Plumbing-Reinspection','PRG00214    0034','FEE_REINSP')
,('NPOOL','9801','2150','Electrical-Permit','CUR00204    0034','FEE_GENELE')
,('NPOOL','9801','2150','Electrical-Permit','PGR00204    0034','FEE_GENELE')
,('NPOOL','9801','2150','Electrical-Permit','ELEC','FEE_ELEC')
,('NPOOL','9801','2155','Electrical-Reinspection','PGR00214    0034','FEE_ELREIN')
,('NPOOL','9801','2155','Electrical-Reinspection','REINSPCT','FEE_ELREIN')
,('NPOOL','9801','2155','Electrical-Reinspection','CUR00214    0034','FEE_ELREIN')
,('NPOOL','9801','9000','ADJUSTMENTS','','')
) t(comp_type,version,fee_item_no,description,account_code,fee_key)
;


--RCDAPP_1__LCKSMITH
--trick question. This has no payments in the source data.


--RCDVIOL_1__LCKSMITH
insert into hcfl_prod.dbo.jms_compType_version_feeItemNo_description_accountCode_feeKey
select 
    comp_type
    ,version
    ,fee_item_no
    ,description
    ,account_code
    ,fee_key
from (VALUES
 ('RCDVIOL ','1','100','RCDCitations','','TOT_FEE')
,('RCDVIOL ','1','500','CEB FINES/COSTS','354105','TOT_FEE')
,('RCDVIOL ','1','501','Administrative Costs','','TOT_FEE')
,('RCDVIOL ','1','900','VEHHIRE - TPASS TOW FINE','','TOT_FEE')
) t(comp_type,version,fee_item_no,description,account_code,fee_key)
;

--wrviol_1
insert into hcfl_prod.dbo.jms_compType_version_feeItemNo_description_accountCode_feeKey
select 
    comp_type
    ,version
    ,fee_item_no
    ,description
    ,account_code
    ,fee_key
from (VALUES
('WRVIOL','1','500','CEB FINES/COSTS','','TOT_FEE')
,('WRVIOL','1','500','CEB FINES/COSTS','354105','TOT_FEE')
,('WRVIOL','1','501','Administrative Costs','','TOT_FEE')
,('WRVIOL','1','800','Watering Violation','','TOT_FEE')
) t(comp_type,version,fee_item_no,description,account_code,fee_key)
;

--verify all relevant fee_key values are derived from a string which exists in aatable_permit_fee
if 1 = (
	select distinct
		a.fee_key
	from aatable_permit_fee a
	join jms_numberKey_permitnum pmap on (pmap.permitnum = a.PERMITNUM) or (pmap.permitnum + '-CBS' = a.permitnum)
	left join jms_compType_version_feeItemNo_description_accountCode_feeKey f on f.fee_key = reverse(substring(reverse(a.FEE_KEY),0,CHARINDEX('-',reverse(a.FEE_KEY))))
	join jms_apd_base_filtered b on b.NUMBER_KEY = pmap.number_key
	where
		1=1
		and f.fee_key is null
		and not (b.COMP_TYPE = 'RCDAPP' and b.version = 1) --this one has no payments, so it doesnt need to match anything (due to no aatable_permit_feeAllocation rows)
) RAISERROR ('values in jms_compType_version_feeItemNo_description_accountCode_feeKey must exist in aatable_permit_fee!', 16, 1)
;




/*
--note_for_me1
select distinct
	pnum.comp_type
	,pnum.version
	,fd.FEE_ITEM_NO
	,f.DESCRIPTION
	,fd.ACCOUNT_CODE
from hcfl_src..fee_detl fd
left join hcfl_src..tab_fee f on f.FEE_ITEM_NO = fd.FEE_ITEM_NO
left join hcfl_src.dbo.fee_id numberKey_transactionId on numberKey_transactionId.number_key = fd.NUMBER_KEY
left join hcfl_src.dbo.apd_base pnum on pnum.NUMBER_KEY = fd.NUMBER_KEY
where
	1=1
	and pnum.COMP_TYPE = 'npool' and pnum.VERSION = '101'
order by fd.FEE_ITEM_NO,fd.ACCOUNT_CODE


--note_for_me2
select distinct
	fd.NUMBER_KEY
	,f.FEE_ITEM_NO
	,f.DESCRIPTION
	,fd.ACCOUNT_CODE
	,fd.AMOUNT
	
from hcfl_src..fee_detl fd
left join hcfl_src..tab_fee f on f.FEE_ITEM_NO = fd.FEE_ITEM_NO
left join hcfl_src.dbo.fee_id numberKey_transactionId on numberKey_transactionId.number_key = fd.NUMBER_KEY
left join hcfl_src.dbo.apd_base pnum on pnum.NUMBER_KEY = fd.NUMBER_KEY
where
	1=1
	and pnum.COMP_TYPE = 'npool' and pnum.VERSION = '9801'
	--and f.FEE_ITEM_NO = '2135'
	--and fd.NUMBER_KEY = 'NPO05756'
	and f.FEE_ITEM_NO  = '2155'
	--and fd.account_code =	
	--and fd.AMOUNT <> convert(int,fd.amount)
--order by fd.NUMBER_KEY,f.FEE_ITEM_NO

*/

go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0120 0400 aatable_permit_feeAllocation.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0120 0400 aatable_permit_feeAllocation.sql')
/*
prelim
create_PERMIT_FEEALLOCATION
*/

----prelim
--SELECT distinct
--    trim(fd.NUMBER_KEY) permitnum
--	,trim(fd.trans_id) + '_' + trim(convert(varchar(max),fd.trans_seq)) + '-' + trim(convert(varchar(max),fd.DETL_SEQ)) pay_key
--    ,b.fee_key
--	,fd.amount
--from hcfl_src.dbo.fee_detl fd
--join hcfl_src.dbo.apd_base a on a.number_key = fd.number_key
--join jms_compType_version_feeItemNo_description_accountCode_feeKey b 
--    on  b.comp_type = a.comp_type
--    and b.version = a.version
--    and b.fee_item_no = fd.fee_item_no
--    and isnull(b.account_code,'') = isnull(fd.account_code,'')
--;



--create_PERMIT_FEEALLOCATION
IF OBJECT_ID('tempdb.dbo.##completed', 'U') IS NOT NULL 
insert into ##completed values (getdate(),'create_PERMIT_FEEALLOCATION')
;

;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_FEEALLOCATION
;
;print 'AATABLE_PERMIT_FEEALLOCATION';
insert into AATABLE_PERMIT_FEEALLOCATION (
Permitnum,Fee_Key,PAY_KEY,FEE_ALLOCATION
)
select distinct
    pmap.permitnum permitnum 
    ,pnum.permitnum + '-'+  b.fee_key 
    ,trim(fd.trans_id) + '_' + trim(convert(varchar(max),fd.trans_seq)) + '-' + trim(convert(varchar(max),fd.DETL_SEQ)) pay_key
    ,fd.amount 
from hcfl_src.dbo.fee_detl fd
join hcfl_src.dbo.apd_base a on a.number_key = fd.number_key
join jms_compType_version_feeItemNo_description_accountCode_feeKey b 
    on b.comp_type = a.comp_type
    and b.version = a.version
    and b.fee_item_no = fd.fee_item_no
    and b.account_code = isnull(fd.account_code,'')
join jms_numberKey_permitnum pmap on pmap.number_key = fd.number_key
join aatable_permit_history pnum on pnum.permitnum = pmap.permitnum

;
    --ensure no payments are allocated which havent been put in the payment table
delete a
from AATABLE_PERMIT_FEEALLOCATION a 
left join AATABLE_PERMIT_PAYMENTS p on p.PAY_KEY = a.PAY_KEY
where
	1=1
	and p.pay_key is null
;

--ensure permitnums are correctly pointed
update a set 
    permitnum = b.permitnum
from AATABLE_PERMIT_PAYMENTS a 
join AATABLE_PERMIT_FEEALLOCATION b on b.pay_key = a.pay_key
WHERE
    1=1
    and a.permitnum like 'CE%'
;


--verify fees and payments have same corresponding permitnum
if 1 = (
    SELECT distinct 1
    from AATABLE_PERMIT_FEEALLOCATION a 
    left join AATABLE_PERMIT_PAYMENTS b on b.pay_key = a.pay_key
    left join aatable_permit_fee c on c.fee_key = a.fee_key 
    WHERE
        1=1
        and c.permitnum like 'CE%'
        and b.permitnum like 'CE%'
        and c.permitnum <> b.permitnum
) RAISERROR ('AATABLE_PERMIT_FEEALLOCATION: there is a permitnum mismatch between aatable_permit_fee and aatable_permit_payments', 16, 1)
;

go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0140 aatable_permit_receipts.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0140 aatable_permit_receipts.sql')
--create_PERMIT_RECEIPTS
IF OBJECT_ID('tempdb.dbo.##completed', 'U') IS NOT NULL 
insert into ##completed values (getdate(),'create_PERMIT_RECEIPTS')
;
;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_RECEIPTS
;

;print 'AATABLE_PERMIT_RECEIPTS';
insert into AATABLE_PERMIT_RECEIPTS (
HIST_RECEIPT_NBR,RECEIPT_DATE,CASHIER_ID,REGISTER_NBR,RECEIPT_AMOUNT,RECEIPT_COMMENT,RECEIPT_STATUS,TRANSACTION_CODE,TRANSACTION_NBR,REC_DATE,REC_FUL_NAM,TTERMINAL_ID,WORKSTATION_ID
)
select distinct
    pay.HIST_RECEIPT_NBR as HIST_RECEIPT_NBR
    ,pay.payment_Date as RECEIPT_DATE
    ,REPLACE(isnull(pay.CASHIER_ID,'Not Set'), '''','') as CASHIER_ID
    ,null as REGISTER_NBR
    ,pay.payment_amount as RECEIPT_AMOUNT
    ,null as RECEIPT_COMMENT
    ,null as RECEIPT_STATUS
    ,null as TRANSACTION_CODE
    ,null as TRANSACTION_NBR
    ,pay.rec_date as REC_DATE
    ,REPLACE(isnull(pay.rec_ful_nam,'Not Set'), '''','') as REC_FUL_NAM
    ,null as TTERMINAL_ID
    ,null as WORKSTATION_ID
from AATABLE_PERMIT_PAYMENTS pay
WHERE
    1=1
    and not exists (
        select 1
        from AATABLE_PERMIT_RECEIPTS
        where HIST_RECEIPT_NBR = pay.hist_receipt_nbr
    )
;

go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0143 update unpaid fees to be not invoiced.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0143 update unpaid fees to be not invoiced.sql')
/*
Needs other comp_type, version flavors
for at least npool, can I find a proper looking date for the fee applications, based on fee payment dates, and existing dates in apd_base or apd_num0?

*/

--;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table aatable_permit_fee
--;


;if object_id('tempdb.dbo.#b','U') is not null drop table #b 
;
	select
		f.PERMITNUM
		,f.fee_key
		,f.FEE_ITEM_AMOUNT
		,sum(isnull(p.fee_allocation,0)) paid_amount
    into #b 
	from aatable_permit_fee f 
	left join AATABLE_PERMIT_FEEALLOCATION p on p.FEE_KEY = f.FEE_KEY

	group by f.PERMITNUM
		,f.fee_key
		,f.FEE_ITEM_AMOUNT
;
--select 
update a set 
	invoice = 'N'
from aatable_permit_fee a
join #b b on b.FEE_KEY = a.FEE_KEY
where 
	1=1
	and b.fee_item_amount > b.paid_amount
;
delete a 
from AATABLE_PERMIT_FEEALLOCATION a 
join #b b on b.fee_key = a.fee_key 
WHERE   
    1=1
    and b.fee_item_amount > b.paid_amount
;

go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0145 move fines to the instantiated cbs records.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0145 move fines to the instantiated cbs records.sql')
/*
https://dev.azure.com/Hillsborough-County/bf470d0d-5a72-4dce-b8a4-ec892e39f909/_workitems/edit/11467
"I did want to mention that fine data (other than abatement costs) should be present on the CBS record. "

The below logic repoints fee data to the instantated CBS records.
the cbs records also get those custom lists with the curStr values.
*/
update a set
    a.permitnum = cbs.permitnum
    ,a.fee_key = replace(a.fee_key,a.permitnum,cbs.permitnum)
from aatable_permit_fee a
join jms_numberKey_permitnum pmap on pmap.permitnum = a.permitnum
join aatable_permit_history cbs on cbs.permitnum = a.permitnum + '-CBS'
;

update a set
    a.permitnum = cbs.permitnum
from AATABLE_PERMIT_PAYMENTS a
join jms_numberKey_permitnum pmap on pmap.permitnum = a.permitnum
join aatable_permit_history cbs on cbs.permitnum = a.permitnum + '-CBS'
;

update a set
    a.permitnum = cbs.permitnum
    ,a.fee_key = replace(a.fee_key,a.permitnum,cbs.permitnum)
from AATABLE_PERMIT_FEEALLOCATION a
join jms_numberKey_permitnum pmap on pmap.permitnum = a.permitnum
join aatable_permit_history cbs on cbs.permitnum = a.permitnum + '-CBS'
;

--wrong
--update a set
--    a.permitnum = cbs.permitnum
--    ,a.fee_key = replace(a.fee_key,a.permitnum,cbs.permitnum)
--from AATABLE_PERMIT_RECEIPTS a
--join aatable_permit_history cbs on cbs.permitnum = a.permitnum + '-CBS'
--;


go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0160 aatable_permit_people_v2.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0160 aatable_permit_people_v2.sql')
/*
When considering a given record, it might have a person who is licensed but is not appearing to me as though they are listed conceptually as a licensed individual.
    i.e. -- ought I make all apd_peo people regular contacts and owners, and then use con_peo for licensed individuals?
Some applicants exist and have a license, but do not also exist as a non-applicant licensed individual.

create_PERMIT_PEOPLE
apd_peo__owner__lic_or_not
apd_peo__nonOwner__notLic
apd_peo__all_with_lic

CBS people duplication -- addendum per 20240525 - they want people duplicated on cbs records from non-cbs records

--par_peo__owner__lic_or_not
--par_peo__all_with_lic

--adr_peo__notLic



CONSIDER:
ADR_PEO	177002 --?
APD_PEO	11022932 
    CON_PEO	81372   --contractors
    MDL_PEO	376     --?
FEE_PEO	0
PAR_PEO	357856  --parcel people?? What is that?
*/


--create_PERMIT_PEOPLE
IF OBJECT_ID('tempdb.dbo.##completed', 'U') IS NOT NULL 
insert into ##completed values (getdate(),'create_PERMIT_PEOPLE')
;
;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_PEOPLE
;

--apd_peo__owner__lic_or_not
;print 'apd_peo__owner__lic_or_not';
insert into AATABLE_PERMIT_PEOPLE (
PERMITNUM,TT_CONTACT_TYPE,CONTACT_RELATIONSHIP ,ISPRIMARY,LIC_NUM,LIC_TYPE,NAME,FNAME,MNAME,LNAME,BUS_NAME,ADDR1,ADDR2,ADDR3,CITY,STATE,ZIP,PH1,PH2,FAX,EMAIL,COMMENTS,TITLE,PH3,COUNTRY_CODE,NOTIFY,NAME_SUFFIX,BUS_LIC,LIC_ORIGINAL_ISSUE_DATE,EXPIRATION_DATE,RENEWAL_DATE,MAIL_ADDR1,MAIL_ADDR2,MAIL_ADDR3,MAIL_CITY,MAIL_STATE,MAIL_ZIP,MAIL_COUNTRY,OWNER_TYPE,GENDER,SALUTATION,PO_BOX,BUS_NAME2,BIRTH_DATE,PH1_COUNTRY_CODE,PH2_COUNTRY_CODE,FAX_COUNTRY_CODE,PH3_COUNTRY_CODE,TRADE_NAME,CONTACT_TYPE_FLAG,SOCIAL_SECURITY_NUMBER,FEDERAL_EMPLOYER_ID_NUM,CONTRA_TYPE_FLAG,LIC_BOARD,B1_ID,CONT_LIC_BUS_NAME,B1_ACCESS_LEVEL,BIRTH_CITY,BIRTH_STATE,BIRTH_REGION,B1_CONTACT_NBR,DECEASED_DATE,DRIVER_LIC_NBR,DRIVER_LIC_STATE,PASSPORT_NBR,STATE_ID_NBR,RACE,G1_CONTACT_NBR,LIC_STATE
)
select distinct
	pnum.permitnum
    ,'(OWNER)' contact_type
    ,null contact_relationship 
    ,'Y' isPrimary --(case when a.primary_name = 1 then 'Y' else 'N' end) isPrimary
    ,null Lic_Num
    ,null lic_type
    ,left(trim(replace(replace(   trim(isnull(a.address_1,'')) + isnull(trim(a.name),'')    ,'  ',' '),'  ',' ')),220) name
    ,null as FName --,trim(substring(a.name,1,charindex(' ',a.name))) as FName
    ,null as MName
    ,left(trim(replace(replace(   a.name    ,'  ',' '),'  ',' ')),70) --,left(trim(substring(a.name,charindex(' ',a.name),len(a.name))),70) LName
    ,trim(replace(replace(   a.name    ,'  ',' '),'  ',' ')) bus_name --replace(replace(replace(replace(   coalesce(a.PROGRAM_IDENTIFIER,fac.facility_name)    ,'"',''''''),'''',''),char(13),''),char(10),'') as Bus_Name
    ,left(trim(replace(replace(replace(replace(        a.address_2          ,'  ',' '),'  ',' '),'  ',' '),',,',',')),40) addr1
    ,a.address_3 addr2
    ,null add3
    ,null city
    ,null state
    ,left(coalesce(a.zip,''),10) zip
    ,a.phone_1 ph1
    ,a.phone_2 ph2
    ,null as Fax
    ,left(a.email_addr,70) Email
    ,null as Comments
    ,a.relationship as Title
    ,null as Ph3
    ,null as Country_Code
    ,null as Notify
    ,null as Name_Suffix
    ,null as Bus_Lic
    ,null as Lic_Original_Issue_Date
    ,null as Expiration_date
    ,null as Renewal_Date
    ,left(trim(replace(replace(replace(replace(        a.address_2          ,'  ',' '),'  ',' '),'  ',' '),',,',',')),40) MAIL_ADDR1
    ,a.address_3 MAIL_ADDR2
    ,null as Mail_add3
    ,null Mail_city
    ,null mail_state --,coalesce(e.state,fac.mstate,'') Mail_state
    ,left(coalesce(a.zip,''),10) mail_zip --,left(coalesce(e.zip,fac.mzip,''),10) Mail_zip
    ,null as Mail_Country
    ,null as Owner_Type
    ,null as Gender
    ,null as Salutation
    ,null as PO_Box
    ,null as Bus_Name2
    ,null as Birth_Date
    ,null as Ph1_Country_Code,null as Ph2_Country_Code,null as Fax_Country_Code,null as Ph3_Country_Code,null as Trade_Name,null as Contact_Type_Flag,null as Social_Security_Number,null as Federal_Employer_ID_Num,null as Contra_Type_Flag,null as Lic_Board,null as B1_ID,null as Cont_Lic_Bus_Name,null as B1_Access_Level,null as Birth_City,null as Birth_State,null as Birth_Region,null as B1_Contact_Nbr,null as Deceased_Date
    ,null as Driver_License_Nbr    
    ,null as Driver_License_State,null as Passport_Nbr,null as State_Id_Nbr,null as Race,null as G1_Contact_Nbr,null as Lic_State
from aatable_permit_history pnum --from (select distinct number_key permitnum from hcfl_src.dbo.apd_base) pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_peo a on a.number_key = pmap.number_key
WHERE
    1=1
    and a.relationship in (
        'ONWER     '
        ,'OOWNER    '
        ,'OWENER    '
        ,'OWER      '
        ,'OWMER     '
        ,'OWNER     '
        ,'OWNER,    '
        ,'OWNER/AGEN'
        ,'OWNER/APP '
        ,'OWNER/GC  '
        ,'OWNER/OCC '
        ,'OWNER6    '
        ,'OWNERS    '
        ,'PARK OWNER'
        ,'PROP OWNER'
        ,'AGENT/OWNR'
        ----all home% are unlicensed.
        ,'HOME OWNER'
        ,'HOMEEOWNER'
        ,'HOMEOWER  '
        ,'HOMEOWNER '
        ,'HOMEOWNER.'
        ,'HOMEOWNERS'
        ,'HOMEWONER '
        ,'HOMWOWNER '
        ,'HONMEOWNER'
        -----         
        --,'APPICANT  '
        --,'APPLICANT '
        --,'APPLICANTS'
        
    )
    --or 
    --(isnull(trim(a.license_no),'') = '')
    --)
    ----NO! All investigators and inspectors are unlicensed individuals.
    --and a.relationship not in (
    --    'INSPECTOR '
    --    ,'INVESTIG  '
    --    ,'INVESTIGAT'
    
;
    --this is for https://redmine.scubeenterprise.com/issues/19588, so "owner" appears as name on top ribbon.
;print 'apd_peo__owner__lic_or_not part2';
insert into AATABLE_PERMIT_PEOPLE (
PERMITNUM,TT_CONTACT_TYPE,CONTACT_RELATIONSHIP ,ISPRIMARY,LIC_NUM,LIC_TYPE,NAME,FNAME,MNAME,LNAME,BUS_NAME,ADDR1,ADDR2,ADDR3,CITY,STATE,ZIP,PH1,PH2,FAX,EMAIL,COMMENTS,TITLE,PH3,COUNTRY_CODE,NOTIFY,NAME_SUFFIX,BUS_LIC,LIC_ORIGINAL_ISSUE_DATE,EXPIRATION_DATE,RENEWAL_DATE,MAIL_ADDR1,MAIL_ADDR2,MAIL_ADDR3,MAIL_CITY,MAIL_STATE,MAIL_ZIP,MAIL_COUNTRY,OWNER_TYPE,GENDER,SALUTATION,PO_BOX,BUS_NAME2,BIRTH_DATE,PH1_COUNTRY_CODE,PH2_COUNTRY_CODE,FAX_COUNTRY_CODE,PH3_COUNTRY_CODE,TRADE_NAME,CONTACT_TYPE_FLAG,SOCIAL_SECURITY_NUMBER,FEDERAL_EMPLOYER_ID_NUM,CONTRA_TYPE_FLAG,LIC_BOARD,B1_ID,CONT_LIC_BUS_NAME,B1_ACCESS_LEVEL,BIRTH_CITY,BIRTH_STATE,BIRTH_REGION,B1_CONTACT_NBR,DECEASED_DATE,DRIVER_LIC_NBR,DRIVER_LIC_STATE,PASSPORT_NBR,STATE_ID_NBR,RACE,G1_CONTACT_NBR,LIC_STATE
)
select distinct
	pnum.permitnum
    ,'Owner' contact_type
    ,null contact_relationship 
    ,'Y' isPrimary
    ,null Lic_Num
    ,null lic_type
    ,left(trim(replace(replace(   trim(isnull(a.address_1,'')) + isnull(trim(a.name),'')    ,'  ',' '),'  ',' ')),220) name
    ,null as FName --,trim(substring(a.name,1,charindex(' ',a.name))) as FName
    ,null as MName
    ,left(trim(replace(replace(   a.name    ,'  ',' '),'  ',' ')),70) --,left(trim(substring(a.name,charindex(' ',a.name),len(a.name))),70) LName
    ,trim(replace(replace(   a.name    ,'  ',' '),'  ',' ')) bus_name --replace(replace(replace(replace(   coalesce(a.PROGRAM_IDENTIFIER,fac.facility_name)    ,'"',''''''),'''',''),char(13),''),char(10),'') as Bus_Name
    ,left(trim(replace(replace(replace(replace(        a.address_2          ,'  ',' '),'  ',' '),'  ',' '),',,',',')),40) addr1
    ,a.address_3 addr2
    ,null add3
    ,null city
    ,null state
    ,left(coalesce(a.zip,''),10) zip
    ,a.phone_1 ph1
    ,a.phone_2 ph2
    ,null as Fax
    ,left(a.email_addr,70) Email
    ,null as Comments
    ,a.relationship as Title
    ,null as Ph3
    ,null as Country_Code
    ,null as Notify
    ,null as Name_Suffix
    ,null as Bus_Lic
    ,null as Lic_Original_Issue_Date
    ,null as Expiration_date
    ,null as Renewal_Date
    ,left(trim(replace(replace(replace(replace(        a.address_2          ,'  ',' '),'  ',' '),'  ',' '),',,',',')),40) addr1
    ,a.address_3 addr2
    ,null as Mail_add3
    ,null Mail_city
    ,null mail_state --,coalesce(e.state,fac.mstate,'') Mail_state
    ,left(coalesce(a.zip,''),10) mail_zip --,left(coalesce(e.zip,fac.mzip,''),10) Mail_zip
    ,null as Mail_Country
    ,null as Owner_Type
    ,null as Gender
    ,null as Salutation
    ,null as PO_Box
    ,null as Bus_Name2
    ,null as Birth_Date
    ,null as Ph1_Country_Code,null as Ph2_Country_Code,null as Fax_Country_Code,null as Ph3_Country_Code,null as Trade_Name,null as Contact_Type_Flag,null as Social_Security_Number,null as Federal_Employer_ID_Num,null as Contra_Type_Flag,null as Lic_Board,null as B1_ID,null as Cont_Lic_Bus_Name,null as B1_Access_Level,null as Birth_City,null as Birth_State,null as Birth_Region,null as B1_Contact_Nbr,null as Deceased_Date
    ,null as Driver_License_Nbr    
    ,null as Driver_License_State,null as Passport_Nbr,null as State_Id_Nbr,null as Race,null as G1_Contact_Nbr,null as Lic_State
from aatable_permit_history pnum --from (select distinct number_key permitnum from hcfl_src.dbo.apd_base) pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_peo a on a.number_key = pmap.number_key
WHERE
    1=1
    and a.relationship in (
        'ONWER     '
        ,'OOWNER    '
        ,'OWENER    '
        ,'OWER      '
        ,'OWMER     '
        ,'OWNER     '
        ,'OWNER,    '
        ,'OWNER/AGEN'
        ,'OWNER/APP '
        ,'OWNER/GC  '
        ,'OWNER/OCC '
        ,'OWNER6    '
        ,'OWNERS    '
        ,'PARK OWNER'
        ,'PROP OWNER'
        ,'AGENT/OWNR'
        ----all home% are unlicensed.
        ,'HOME OWNER'
        ,'HOMEEOWNER'
        ,'HOMEOWER  '
        ,'HOMEOWNER '
        ,'HOMEOWNER.'
        ,'HOMEOWNERS'
        ,'HOMEWONER '
        ,'HOMWOWNER '
        ,'HONMEOWNER'
        -----         
        --,'APPICANT  '
        --,'APPLICANT '
        --,'APPLICANTS'
        
    )
    --or 
    --(isnull(trim(a.license_no),'') = '')
    --)
    ----NO! All investigators and inspectors are unlicensed individuals.
    --and a.relationship not in (
    --    'INSPECTOR '
    --    ,'INVESTIG  '
    --    ,'INVESTIGAT'
    
;
--apd_peo__nonOwner__notLic
;print 'apd_peo__nonOwner__notLic';
insert into AATABLE_PERMIT_PEOPLE (
PERMITNUM,TT_CONTACT_TYPE,CONTACT_RELATIONSHIP ,ISPRIMARY,LIC_NUM,LIC_TYPE,NAME,FNAME,MNAME,LNAME,BUS_NAME,ADDR1,ADDR2,ADDR3,CITY,STATE,ZIP,PH1,PH2,FAX,EMAIL,COMMENTS,TITLE,PH3,COUNTRY_CODE,NOTIFY,NAME_SUFFIX,BUS_LIC,LIC_ORIGINAL_ISSUE_DATE,EXPIRATION_DATE,RENEWAL_DATE,MAIL_ADDR1,MAIL_ADDR2,MAIL_ADDR3,MAIL_CITY,MAIL_STATE,MAIL_ZIP,MAIL_COUNTRY,OWNER_TYPE,GENDER,SALUTATION,PO_BOX,BUS_NAME2,BIRTH_DATE,PH1_COUNTRY_CODE,PH2_COUNTRY_CODE,FAX_COUNTRY_CODE,PH3_COUNTRY_CODE,TRADE_NAME,CONTACT_TYPE_FLAG,SOCIAL_SECURITY_NUMBER,FEDERAL_EMPLOYER_ID_NUM,CONTRA_TYPE_FLAG,LIC_BOARD,B1_ID,CONT_LIC_BUS_NAME,B1_ACCESS_LEVEL,BIRTH_CITY,BIRTH_STATE,BIRTH_REGION,B1_CONTACT_NBR,DECEASED_DATE,DRIVER_LIC_NBR,DRIVER_LIC_STATE,PASSPORT_NBR,STATE_ID_NBR,RACE,G1_CONTACT_NBR,LIC_STATE
)
select distinct 
	pnum.permitnum
    ,coalesce(case when trim(a.relationship)='' then null else a.relationship end,'Contact') contact_type
    ,null contact_relationship 
    ,(case when a.primary_name = 1 then 'Y' else 'N' end) isPrimary
    ,null Lic_Num
    ,null lic_type
    ,left(trim(replace(replace(   trim(isnull(a.address_1,'')) + isnull(trim(a.name),'')    ,'  ',' '),'  ',' ')),220) name
    ,null as FName --,trim(substring(a.name,1,charindex(' ',a.name))) as FName
    ,null as MName
    ,left(trim(replace(replace(   a.name    ,'  ',' '),'  ',' ')),70) --,left(trim(substring(a.name,charindex(' ',a.name),len(a.name))),70) LName
    ,trim(replace(replace(   a.name    ,'  ',' '),'  ',' ')) bus_name --replace(replace(replace(replace(   coalesce(a.PROGRAM_IDENTIFIER,fac.facility_name)    ,'"',''''''),'''',''),char(13),''),char(10),'') as Bus_Name
    ,left(trim(replace(replace(replace(replace(        a.address_2          ,'  ',' '),'  ',' '),'  ',' '),',,',',')),40) addr1
    ,a.address_3 addr2
    ,null add3
    ,null city
    ,null state
    ,left(coalesce(a.zip,''),10) zip
    ,a.phone_1 ph1
    ,a.phone_2 ph2
    ,null as Fax
    ,left(a.email_addr,70) Email
    ,null as Comments
    ,a.relationship as Title
    ,null as Ph3
    ,null as Country_Code
    ,null as Notify
    ,null as Name_Suffix
    ,null as Bus_Lic
    ,null as Lic_Original_Issue_Date
    ,null as Expiration_date
    ,null as Renewal_Date
    ,left(trim(replace(replace(replace(replace(        a.address_2          ,'  ',' '),'  ',' '),'  ',' '),',,',',')),40) Mail_addr1
    ,a.address_3 as Mail_addr2
    ,null as Mail_add3
    ,null Mail_city
    ,null mail_state --,coalesce(e.state,fac.mstate,'') Mail_state
    ,left(coalesce(a.zip,''),10) mail_zip --,left(coalesce(e.zip,fac.mzip,''),10) Mail_zip
    ,null as Mail_Country
    ,null as Owner_Type
    ,null as Gender
    ,null as Salutation
    ,null as PO_Box
    ,null as Bus_Name2
    ,null as Birth_Date
    ,null as Ph1_Country_Code,null as Ph2_Country_Code,null as Fax_Country_Code,null as Ph3_Country_Code,null as Trade_Name,null as Contact_Type_Flag,null as Social_Security_Number,null as Federal_Employer_ID_Num,null as Contra_Type_Flag,null as Lic_Board,null as B1_ID,null as Cont_Lic_Bus_Name,null as B1_Access_Level,null as Birth_City,null as Birth_State,null as Birth_Region,null as B1_Contact_Nbr,null as Deceased_Date
    ,null as Driver_License_Nbr    
    ,null as Driver_License_State,null as Passport_Nbr,null as State_Id_Nbr,null as Race,null as G1_Contact_Nbr,null as Lic_State
from aatable_permit_history pnum --from (select distinct number_key permitnum from hcfl_src.dbo.apd_base) pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_peo a on a.number_key = pmap.number_key
WHERE
    1=1
    and a.relationship not in (
        'ONWER     '
        ,'OOWNER    '
        ,'OWENER    '
        ,'OWER      '
        ,'OWMER     '
        ,'OWNER     '
        ,'OWNER,    '
        ,'OWNER/AGEN'
        ,'OWNER/APP '
        ,'OWNER/GC  '
        ,'OWNER/OCC '
        ,'OWNER6    '
        ,'OWNERS    '
        ,'PARK OWNER'
        ,'PROP OWNER'
        ,'AGENT/OWNR'
        ----all home% are unlicensed.
        ,'HOME OWNER'
        ,'HOMEEOWNER'
        ,'HOMEOWER  '
        ,'HOMEOWNER '
        ,'HOMEOWNER.'
        ,'HOMEOWNERS'
        ,'HOMEWONER '
        ,'HOMWOWNER '
        ,'HONMEOWNER'
        -----         
        --,'APPICANT  '
        --,'APPLICANT '
        --,'APPLICANTS'
        
    )
    and isnull(trim(a.license_no),'') = ''
;


--apd_peo__all_with_lic
;print 'apd_peo__all_with_lic';
insert into AATABLE_PERMIT_PEOPLE (
PERMITNUM,TT_CONTACT_TYPE,CONTACT_RELATIONSHIP ,ISPRIMARY,LIC_NUM,LIC_TYPE,NAME,FNAME,MNAME,LNAME,BUS_NAME,ADDR1,ADDR2,ADDR3,CITY,STATE,ZIP,PH1,PH2,FAX,EMAIL,COMMENTS,TITLE,PH3,COUNTRY_CODE,NOTIFY,NAME_SUFFIX,BUS_LIC,LIC_ORIGINAL_ISSUE_DATE,EXPIRATION_DATE,RENEWAL_DATE,MAIL_ADDR1,MAIL_ADDR2,MAIL_ADDR3,MAIL_CITY,MAIL_STATE,MAIL_ZIP,MAIL_COUNTRY,OWNER_TYPE,GENDER,SALUTATION,PO_BOX,BUS_NAME2,BIRTH_DATE,PH1_COUNTRY_CODE,PH2_COUNTRY_CODE,FAX_COUNTRY_CODE,PH3_COUNTRY_CODE,TRADE_NAME,CONTACT_TYPE_FLAG,SOCIAL_SECURITY_NUMBER,FEDERAL_EMPLOYER_ID_NUM,CONTRA_TYPE_FLAG,LIC_BOARD,B1_ID,CONT_LIC_BUS_NAME,B1_ACCESS_LEVEL,BIRTH_CITY,BIRTH_STATE,BIRTH_REGION,B1_CONTACT_NBR,DECEASED_DATE,DRIVER_LIC_NBR,DRIVER_LIC_STATE,PASSPORT_NBR,STATE_ID_NBR,RACE,G1_CONTACT_NBR,LIC_STATE
)
select distinct 
    pnum.permitnum
    ,null contact_type
    ,null contact_relationship
    ,(case when isnull(isPrimary.isPrimary,'') = 'Y' then 'N' when a.primary_name = 1 then 'Y' else 'N' end) isPrimary
    ,a.license_no Lic_Num
    ,a.relationship lic_type
    ,left(trim(replace(replace(   trim(isnull(a.address_1,'')) + isnull(trim(a.name),'')    ,'  ',' '),'  ',' ')),220) name
    ,null as FName --,trim(substring(a.name,1,charindex(' ',a.name))) as FName
    ,null as MName
    ,left(trim(replace(replace(   a.name    ,'  ',' '),'  ',' ')),70) --,left(trim(substring(a.name,charindex(' ',a.name),len(a.name))),70) LName
	,a.name as Bus_Name
    ,left(trim(replace(replace(replace(replace(        a.address_2          ,'  ',' '),'  ',' '),'  ',' '),',,',',')),40) addr1
    ,a.address_3 addr2
    ,null add3
    ,null city
    ,null state
    ,left(coalesce(a.zip,''),10) zip
    ,a.phone_1 ph1
    ,a.phone_2 ph2
    ,cp.phone_fax as Fax
    ,left(a.email_addr,70) Email
    ,trim(';' from isnull(';element_key:'+cb.element_key,'')+isnull(';ins_policy:'+cb.ins_policy,'')+isnull(';ins_amt:'+convert(varchar(max),cb.ins_amt),'')+isnull(';ins_carrier:'+cb.ins_carrier,'')) --comments.comment_text as Comments
    ,null as Title
    ,null as Ph3
    ,null as Country_Code
    ,null as Notify
    ,null as Name_Suffix
    ,cb.BUSINESS_LIC as Bus_Lic
    ,cb.entered_date as Lic_Original_Issue_Date
    ,cb.lic_exp_date as Expiration_date
    ,null as renewal_date
    ,left(trim(replace(replace(replace(replace(        a.address_2          ,'  ',' '),'  ',' '),'  ',' '),',,',',')),40) Mail_addr1
    ,a.address_3 as Mail_addr2
    ,null as Mail_add3
    ,null Mail_city
    ,null mail_state --,coalesce(e.state,fac.mstate,'') Mail_state
    ,left(coalesce(a.zip,''),10) mail_zip --,left(coalesce(e.zip,fac.mzip,''),10) Mail_zip
    ,'USA' as Mail_Country
    ,null as Owner_Type,null as Gender,null as Salutation,null as PO_Box,null as Bus_Name2
    ,null as Birth_Date
    ,null as Ph1_Country_Code,null as Ph2_Country_Code,null as Fax_Country_Code,null as Ph3_Country_Code,null as Trade_Name,null as Contact_Type_Flag,null as Social_Security_Number,null as Federal_Employer_ID_Num,null as Contra_Type_Flag,null as Lic_Board,null as B1_ID,null as Cont_Lic_Bus_Name,null as B1_Access_Level,null as Birth_City,null as Birth_State,null as Birth_Region,null as B1_Contact_Nbr,null as Deceased_Date
    ,null as Driver_License_Nbr    
    ,null as Driver_License_State,null as Passport_Nbr,null as State_Id_Nbr,null as Race,null as G1_Contact_Nbr,null as Lic_State
from aatable_permit_history pnum --from (select distinct number_key permitnum from hcfl_src.dbo.apd_base) pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_peo a on a.number_key = pmap.number_key
left join aatable_permit_people isPrimary 
    on isPrimary.permitnum = pnum.permitnum
    and isPrimary.name = trim(replace(replace(   a.name    ,'  ',' '),'  ',' '))
    and isPrimary.addr1 = left(trim(replace(replace(replace(replace(         case when coalesce(trim(a.address_1),'') <> '' then a.address_1 else 'Not Set' end          ,'  ',' '),'  ',' '),'  ',' '),',,',',')),40)
left join hcfl_src.dbo.con_peo cp on cp.LICENSE_NO = a.LICENSE_NO and cp.name = a.name
left join hcfl_src.dbo.CON_BASE cb on cb.ELEMENT_KEY = cp.ELEMENT_KEY
WHERE
    1=1
    and (isnull(trim(a.license_no),'') <> '')
;


--CBS people duplication -- addendum per 20240525 - they want people duplicated on cbs records from non-cbs records
delete a
from AATABLE_PERMIT_PEOPLE a
join AATABLE_PERMIT_HISTORY pnum on pnum.PERMITNUM = a.PERMITNUM
join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum 
;
go

insert into aatable_permit_people
select
	pnum.PERMITNUM,
	a.TT_CONTACT_TYPE,a.CONTACT_RELATIONSHIP,a.ISPRIMARY,a.LIC_NUM,a.LIC_TYPE,a.NAME,a.FNAME,a.MNAME,a.LNAME,a.BUS_NAME,a.ADDR1,a.ADDR2,a.ADDR3,a.CITY,a.STATE,a.ZIP,a.PH1,a.PH2,a.FAX,a.EMAIL,a.COMMENTS,a.TITLE,a.PH3,a.COUNTRY_CODE,a.NOTIFY,a.NAME_SUFFIX,a.BUS_LIC,a.LIC_ORIGINAL_ISSUE_DATE,a.EXPIRATION_DATE,a.RENEWAL_DATE,a.MAIL_ADDR1,a.MAIL_ADDR2,a.MAIL_ADDR3,a.MAIL_CITY,a.MAIL_STATE,a.MAIL_ZIP,a.MAIL_COUNTRY,a.OWNER_TYPE,a.GENDER,a.SALUTATION,a.PO_BOX,a.BUS_NAME2,a.BIRTH_DATE,a.PH1_COUNTRY_CODE,a.PH2_COUNTRY_CODE,a.FAX_COUNTRY_CODE,a.PH3_COUNTRY_CODE,a.TRADE_NAME,a.CONTACT_TYPE_FLAG,a.SOCIAL_SECURITY_NUMBER,a.FEDERAL_EMPLOYER_ID_NUM,a.CONTRA_TYPE_FLAG,a.LIC_BOARD,a.B1_ID,a.CONT_LIC_BUS_NAME,a.B1_ACCESS_LEVEL,a.BIRTH_CITY,a.BIRTH_STATE,a.BIRTH_REGION,a.B1_CONTACT_NBR,a.DECEASED_DATE,a.DRIVER_LIC_NBR,a.DRIVER_LIC_STATE,a.PASSPORT_NBR,a.STATE_ID_NBR,a.RACE,a.G1_CONTACT_NBR,a.LIC_STATE
from AATABLE_PERMIT_PEOPLE a
join AATABLE_PERMIT_HISTORY pnum on pnum.PERMITNUM = a.PERMITNUM + '-CBS'
join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum 
where
	1=1	
;
go





go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0180 aatable_permit_addresses.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0180 aatable_permit_addresses.sql')
/*
create_AATABLE_PERMIT_ADDRESS
locksmith_addresses
apd_adr__addresses
remove_duplicate_numberKey_fullAddress
Address_addendum__parsing
address_assemble_all
remove_str_suffix
CBS address duplication
*/
--create_AATABLE_PERMIT_ADDRESS
IF OBJECT_ID('tempdb.dbo.##completed', 'U') IS NOT NULL 
insert into ##completed values (getdate(),'create_AATABLE_PERMIT_ADDRESS')
;
;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_ADDRESS
;
;IF OBJECT_ID('tempdb.dbo.#AATABLE_PERMIT_ADDRESS', 'U') IS NOT NULL drop table #AATABLE_PERMIT_ADDRESS
--;select top 0 * into #AATABLE_PERMIT_ADDRESS from AATABLE_PERMIT_ADDRESS
;CREATE TABLE #AATABLE_PERMIT_ADDRESS (
	[PERMITNUM] [varchar](30) NOT NULL,
	[ISPRIMARY] [varchar](1) NULL,
	[STR_NUM_START] [numeric](9, 0) NULL,
	[STR_NUM_END] [numeric](9, 0) NULL,
	[STR_FRAC_START] [varchar](20) NULL,
	[STR_FRAC_END] [varchar](20) NULL,
	[STR_DIR] [varchar](20) NULL,
	[STR_NAME] [varchar](100) NULL,
	[STR_SUFFIX] [varchar](30) NULL,
	[STR_SUFFIX_DIR] [varchar](20) NULL,
	[STR_PREFIX] [varchar](20) NULL,
	[STR_UNIT_START] [varchar](10) NULL,
	[STR_UNIT_END] [varchar](10) NULL,
	[STR_UNIT_TYPE] [varchar](20) NULL,
	[SITUS_CITY] [varchar](40) NULL,
	[SITUS_STATE] [varchar](30) NULL,
	[SITUS_ZIP] [varchar](10) NULL,
	[SITUS_COUNTY] [varchar](30) NULL,
	[SITUS_COUNTRY] [varchar](30) NULL,
	[SITUS_COUNTRY_CODE] [varchar](2) NULL,
	[X_COORD] [numeric](20, 8) NULL,
	[Y_COORD] [numeric](20, 8) NULL,
	[ADDR_DESC] [varchar](255) NULL,
	[FULL_ADDRESS] [varchar](600) NOT NULL,
	[ADDRESS1] [varchar](200) NULL,
	[ADDRESS2] [varchar](200) NULL,
	[SITUS_NBRHD] [varchar](30) NULL,
	[EXT_ADDRESS_UID] [varchar](100) NULL,
	[STREET_NAME_START] [varchar](200) NULL,
	[STREET_NAME_END] [varchar](200) NULL,
	[CROSS_STREET_NAME_START] [varchar](200) NULL,
	[CROSS_STREET_NAME_END] [varchar](200) NULL,
	[HSE_NBR_ALPHA_START] [varchar](20) NULL,
	[HSE_NBR_ALPHA_END] [varchar](20) NULL,
	[LEVEL_PREFIX] [varchar](20) NULL,
	[LEVEL_NBR_START] [varchar](20) NULL,
	[LEVEL_NBR_END] [varchar](20) NULL
)
;

--locksmith_addresses
;print 'locksmith_addresses';
    --client (represented this time by shane varnum) explicitly asked for locksmith records to use apd_Base.location
insert into #AATABLE_PERMIT_ADDRESS (
PERMITNUM,ISPRIMARY,STR_NUM_START,STR_NUM_END,STR_FRAC_START,STR_FRAC_END,STR_DIR,STR_NAME,STR_SUFFIX,STR_SUFFIX_DIR,STR_PREFIX,STR_UNIT_START,STR_UNIT_END,STR_UNIT_TYPE,SITUS_CITY,SITUS_STATE,SITUS_ZIP,SITUS_COUNTY,SITUS_COUNTRY,SITUS_COUNTRY_CODE,X_COORD,Y_COORD,ADDR_DESC,FULL_ADDRESS,ADDRESS1,ADDRESS2,SITUS_NBRHD,EXT_ADDRESS_UID,STREET_NAME_START, STREET_NAME_END, CROSS_STREET_NAME_START,CROSS_STREET_NAME_END, HSE_NBR_ALPHA_START,HSE_NBR_ALPHA_END,LEVEL_PREFIX,	LEVEL_NBR_START,LEVEL_NBR_END
)
select distinct
    pnum.PERMITNUM
    ,'Y' --(case when a.primary_addr = 1 then 'Y' else 'N' end) as ISPRIMARY
    ,null --try_convert(int,a.street_no) as STR_NUM_START
    ,null as STR_NUM_END
    ,null --a.addr_fraction as STR_FRAC_START
    ,null as STR_FRAC_END
    ,null --a.street_direction as STR_DIR
    ,null --left( a.street_name ,40) as STR_NAME
    ,null as STR_SUFFIX
    ,null as STR_SUFFIX_DIR
    ,null as STR_PREFIX
    ,null --(case when trim(isnull(a.unit_id,'')) <> '' then a.unit_id else null end) as STR_UNIT_START
    ,null as STR_UNIT_END
    ,null as STR_UNIT_TYPE
    ,null --isnull(left(city_id.city_name,40),left(city_id.city_name,40)) as SITUS_CITY
    ,null --'FL' as SITUS_STATE
    ,null --left(b.zip_code,10) as SITUS_ZIP
    ,null SITUS_COUNTY --,left(district.description,30) as SITUS_COUNTY
    ,'US' as SITUS_COUNTRY
    ,null as SITUS_COUNTRY_CODE
    ,null --b.x_coord as X_COORD
    ,null --b.y_coord as Y_COORD
    ,'Physical Location' as ADDR_DESC
    ,ab.location --coalesce(  CONCAT_WS(' ',a.street_no,a.street_name,a.street_direction,a.addr_fraction,'unit ' + a.unit_id,city_id.city_name,',FL',b.zip_code)  ,'Not Set') as FULL_ADDRESS 
    ,null --coalesce(  CONCAT_WS(' ',a.street_no,a.street_name,a.street_direction,a.addr_fraction,'unit ' + a.unit_id),'Not Set' ) as ADDRESS1
    ,null --coalesce(  CONCAT_WS(' ',city_id.city_name,',FL',b.zip_code),null ) as ADDRESS2
    ,null as SITUS_NBRHD
    ,null as EXT_ADDRESS_UID
    ,null as STREET_NAME_START
    ,null as STREET_NAME_END
    ,null as CROSS_STREET_NAME_START
    ,null as CROSS_STREET_NAME_END
    ,null as HSE_NBR_ALPHA_START
    ,null as HSE_NBR_ALPHA_END
    ,null as LEVEL_PREFIX
    ,null as LEVEL_NBR_START
    ,null as LEVEL_NBR_END
from aatable_permit_history pnum --from (select number_key as permitnum from hcfl_src.dbo.apd_base) pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_base ab on ab.number_key = pmap.number_key
--join hcfl_src.dbo.apd_adr a on a.number_key = pmap.number_key
--left join hcfl_src.dbo.CIT_BASE city_id on city_id.city_id = a.city_id
--left join hcfl_src.dbo.ADR_BASE b on b.ELEMENT_KEY = a.SITE_ELEMENT_KEY
WHERE
    1=1
    and pnum.tt_Record like 'locksmith%'
	and ab.location is not null
;


--apd_adr__addresses
;print 'apd_adr__addresses';
insert into #AATABLE_PERMIT_ADDRESS (
PERMITNUM,ISPRIMARY,STR_NUM_START,STR_NUM_END,STR_FRAC_START,STR_FRAC_END,STR_DIR,STR_NAME,STR_SUFFIX,STR_SUFFIX_DIR,STR_PREFIX,STR_UNIT_START,STR_UNIT_END,STR_UNIT_TYPE,SITUS_CITY,SITUS_STATE,SITUS_ZIP,SITUS_COUNTY,SITUS_COUNTRY,SITUS_COUNTRY_CODE,X_COORD,Y_COORD,ADDR_DESC,FULL_ADDRESS,ADDRESS1,ADDRESS2,SITUS_NBRHD,EXT_ADDRESS_UID,STREET_NAME_START, STREET_NAME_END, CROSS_STREET_NAME_START,CROSS_STREET_NAME_END, HSE_NBR_ALPHA_START,HSE_NBR_ALPHA_END,LEVEL_PREFIX,	LEVEL_NBR_START,LEVEL_NBR_END
)
select distinct
    pnum.PERMITNUM
    ,(case when a.primary_addr = 1 then 'Y' else 'N' end) as ISPRIMARY
    ,try_convert(int,a.street_no) as STR_NUM_START
    ,null as STR_NUM_END
    ,a.addr_fraction as STR_FRAC_START
    ,null as STR_FRAC_END
    ,a.street_direction as STR_DIR
    ,left( a.street_name ,40) as STR_NAME
    ,null as STR_SUFFIX
    ,null as STR_SUFFIX_DIR
    ,null as STR_PREFIX
    ,(case when trim(isnull(a.unit_id,'')) <> '' then a.unit_id else null end) as STR_UNIT_START
    ,null as STR_UNIT_END
    ,null as STR_UNIT_TYPE
    ,isnull(left(city_id.city_name,40),left(city_id.city_name,40)) as SITUS_CITY
    ,'FL' as SITUS_STATE
    ,left(b.zip_code,10) as SITUS_ZIP
    ,null SITUS_COUNTY --,left(district.description,30) as SITUS_COUNTY
    ,'US' as SITUS_COUNTRY
    ,null as SITUS_COUNTRY_CODE
    ,b.x_coord as X_COORD
    ,b.y_coord as Y_COORD
    ,'Physical Location' as ADDR_DESC
    ,replace(replace(replace(replace(replace(replace(coalesce(  CONCAT_WS(' ',a.street_no,a.street_name,a.street_direction,a.addr_fraction,case when trim(isnull(a.unit_id,'')) <> '' then 'unit ' + a.unit_id else null end,city_id.city_name,', FL',b.zip_code)  ,'Not Set'),'  ',' '),'  ',' '),'  ',' '),'  ',' '),'  ',' '),' , ',', ') as FULL_ADDRESS 
    ,coalesce(  CONCAT_WS(' ',a.street_no,a.street_name,a.street_direction,a.addr_fraction,case when trim(isnull(a.unit_id,'')) <> '' then 'unit ' + a.unit_id else null end),'Not Set' ) as ADDRESS1
    ,replace(coalesce(  CONCAT_WS(' ',city_id.city_name,', FL',b.zip_code),null ),' , ',', ') as ADDRESS2
    ,null as SITUS_NBRHD
    ,null as EXT_ADDRESS_UID
    ,null as STREET_NAME_START
    ,null as STREET_NAME_END
    ,null as CROSS_STREET_NAME_START
    ,null as CROSS_STREET_NAME_END
    ,null as HSE_NBR_ALPHA_START
    ,null as HSE_NBR_ALPHA_END
    ,null as LEVEL_PREFIX
    ,null as LEVEL_NBR_START
    ,null as LEVEL_NBR_END
from aatable_permit_history pnum --from (select number_key as permitnum from hcfl_src.dbo.apd_base) pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_adr a on a.number_key = pmap.number_key
left join hcfl_src.dbo.CIT_BASE city_id on city_id.city_id = a.city_id
left join hcfl_src.dbo.ADR_BASE b on b.ELEMENT_KEY = a.SITE_ELEMENT_KEY
;



--remove_duplicate_numberKey_fullAddress
--aatable_permit_Address unique_key on permitnum,fulladdress. Some in source data have same address as both primary and non-primary.
-- Therefore: delete the duplicate keys.
-- note: in source, the two rows have different auto_key values, and different site_element_key values.
-- rem: I think that CE09015735 is the only duplicating row.
;print 'address permitnum,full_Address unique-collision-preventing-deletions'
;WITH cte AS (
  SELECT 
	permitnum
	,full_address
    ,ROW_NUMBER() OVER(PARTITION BY permitnum,full_address ORDER BY isprimary desc) AS Rn
  FROM #aatable_permit_address
)
DELETE cte WHERE Rn > 1



--Address_addendum__parsing
;print 'Address_addendum__parsing';
    --set str_name based on full address
update t set
	STR_NAME = (case 
		when full_address like '%,%' then trim(' ,' from substring(full_address,1,charindex(',',full_address)))
		else full_address 
		end
    )
from #AATABLE_PERMIT_ADDRESS t
where 
	(str_name = 'not set' or str_name is null)
	and 
	(  full_address like '%road%'
	or full_address like '%rd%'
	or full_address like '%lane%'
	or full_address like '%ln%'
	or full_address like '%drive%'
	or full_address like '%dr%'
	or full_address like '%drives%'
	or full_address like '%drs%'
	or full_address like '%street%'
	or full_address like '%st%'
	or full_address like '%boulevard%'
	or full_address like '%blvd%'
	or full_address like '%avenue%'
	or full_address like '%ave%'
	or full_address like '%court%'
	or full_address like '%ct%'
	or full_address like '%circle%'
	or full_address like '%cir%'
	or full_address like '%way%'
	or full_address like '%wy%'
	or full_address like '%run%'
	or full_address like '%trail%'
	or full_address like '%trl%'
	or full_address like '%terrace%'
	or full_address like '%ter%'
	or full_address like '%highway%'
	or full_address like '%hwy%'
	or full_address like '%walk%'
	or full_address like '%path%'
	or full_address like '%place%'
	or full_address like '%pl%'
	or full_address like '%meadow%'
	or full_address like '%mdw%'
	or full_address like '%mdws%'
	)
;

    --remove cardinal direction
update t set
	str_dir = trim(reverse(substring(reverse(str_name),1,charindex(' ',reverse(str_name)))))
	,str_name = trim(replace(str_name,trim(reverse(substring(reverse(str_name),1,charindex(' ',reverse(str_name))))),''))
from #AATABLE_PERMIT_ADDRESS t
where
	str_dir is null
	and
	trim(reverse(substring(reverse(str_name),1,charindex(' ',reverse(str_name))))) in ('north','east','SOUTH','west','n','e','s','w') 
;

    --remove str number
update t set
	str_num_start = convert(int,substring(STR_NAME,1,charindex(' ',str_name))) 
	,STR_NAME = trim(substring(STR_NAME,charindex(' ',str_name),len(str_name)))
from #AATABLE_PERMIT_ADDRESS t
where 
	STR_NUM_START is null
	and 
    try_convert(int,substring(STR_NAME,1,charindex(' ',str_name))) is not null
;

    --remove str suffix
update t set
	str_suffix = reverse(trim(substring(reverse(str_name),1,charindex(' ',reverse(str_name)))))
	,STR_NAME = trim(reverse(substring(
			reverse(str_name)
			,charindex(' ',reverse(str_name))
			,len(reverse(str_name))
		)))
from #AATABLE_PERMIT_ADDRESS t
where 
	str_suffix is null
	and 
	reverse(trim(substring(reverse(str_name),1,charindex(' ',reverse(str_name)))))
	in ('road','rd','lane','ln','drive','dr','drives','drs','street','st','boulevard','blvd','avenue','ave','court','ct','circle','cir','way','wy','run','trail','trl','terrace','ter','highway','hwy','walk','path','place','pl','meadow','mdw','mdws')
;

--    --add county if city matches to existing districts
--update t set
--	situs_county = situs_city
--from #AATABLE_PERMIT_ADDRESS t
--join CD_CORE_DISTRICT_CODE district on district.description = t.situs_city
--WHERE
--    t.situs_county is null
--    or t.situs_county = 'not set'
--;

    --add full address based on primary address data
update t set
	full_address = trim(isnull(
        (  isnull(try_convert(varchar(max),STR_NUM_START),'')
            + isnull(' '+STR_DIR,'')
            + isnull(' '+STR_NAME,'')
            + isnull(' '+STR_SUFFIX,'')
            + isnull(' '+STR_UNIT_START,'')
            + isnull(', '+SITUS_CITY,'')
            + isnull(', '+SITUS_STATE,'')
            + isnull(' '+situs_zip,'')
        ) 
        ,'Not Set'
     ))
from #AATABLE_PERMIT_ADDRESS t
where
	FULL_ADDRESS = 'Not Set'
;
    
    --remove some empty fields
update t set
    str_suffix_dir = case when trim(str_suffix_dir) = '' then null else str_suffix_dir end
    ,str_unit_start = case when trim(str_unit_start) = '' then null else str_unit_start end
    ,str_unit_type = case when trim(str_unit_type) = '' then null else str_unit_type end
from #AATABLE_PERMIT_ADDRESS t
where
    1=1
    and (
        str_suffix_dir is not null
        or str_unit_start is not null
        or str_unit_type  is not null
    )
;





--address_assemble_all
;print 'address_assemble_all';
;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_ADDRESS
;insert into AATABLE_PERMIT_ADDRESS (
PERMITNUM,ISPRIMARY,STR_NUM_START,STR_NUM_END,STR_FRAC_START,STR_FRAC_END,STR_DIR,STR_NAME,STR_SUFFIX,STR_SUFFIX_DIR,STR_PREFIX,STR_UNIT_START,STR_UNIT_END,STR_UNIT_TYPE,SITUS_CITY,SITUS_STATE,SITUS_ZIP,SITUS_COUNTY,SITUS_COUNTRY,SITUS_COUNTRY_CODE,X_COORD,Y_COORD,ADDR_DESC,FULL_ADDRESS,ADDRESS1,ADDRESS2,SITUS_NBRHD,EXT_ADDRESS_UID,STREET_NAME_START, STREET_NAME_END, CROSS_STREET_NAME_START,CROSS_STREET_NAME_END, HSE_NBR_ALPHA_START,HSE_NBR_ALPHA_END,LEVEL_PREFIX,	LEVEL_NBR_START,LEVEL_NBR_END
)
SELECT
    PERMITNUM,ISPRIMARY,STR_NUM_START,STR_NUM_END,STR_FRAC_START,STR_FRAC_END,STR_DIR
	,left(STR_NAME,40),STR_SUFFIX,STR_SUFFIX_DIR,STR_PREFIX,STR_UNIT_START,STR_UNIT_END,STR_UNIT_TYPE,SITUS_CITY,SITUS_STATE,SITUS_ZIP,SITUS_COUNTY,SITUS_COUNTRY,SITUS_COUNTRY_CODE,X_COORD,Y_COORD,ADDR_DESC,FULL_ADDRESS,ADDRESS1,ADDRESS2,SITUS_NBRHD,EXT_ADDRESS_UID,STREET_NAME_START, STREET_NAME_END, CROSS_STREET_NAME_START,CROSS_STREET_NAME_END, HSE_NBR_ALPHA_START,HSE_NBR_ALPHA_END,LEVEL_PREFIX,	LEVEL_NBR_START,LEVEL_NBR_END
from #AATABLE_PERMIT_ADDRESS
;





    --remove_str_suffix
update t set
	str_suffix = reverse(trim(substring(reverse(str_name),1,charindex(' ',reverse(str_name)))))
	,STR_NAME = trim(reverse(substring(
			reverse(str_name)
			,charindex(' ',reverse(str_name))
			,len(reverse(str_name))
		)))
from AATABLE_PERMIT_ADDRESS t
where 
	str_suffix is null
	and 
	reverse(trim(substring(reverse(str_name),1,charindex(' ',reverse(str_name)))))
	in ('road','rd','lane','ln','drive','dr','drives','drs','street','st','boulevard','blvd','avenue','ave','court','ct','circle','cir','way','wy','run','trail','trl','terrace','ter','highway','hwy','walk','path','place','pl','meadow','mdw','mdws')
;

--CBS address duplication
insert into aatable_permit_Address
SELECT
	pnum.PERMITNUM
	,a.ISPRIMARY,a.STR_NUM_START,a.STR_NUM_END,a.STR_FRAC_START,a.STR_FRAC_END,a.STR_DIR,a.STR_NAME,a.STR_SUFFIX,a.STR_SUFFIX_DIR,a.STR_PREFIX,a.STR_UNIT_START,a.STR_UNIT_END,a.STR_UNIT_TYPE,a.SITUS_CITY,a.SITUS_STATE,a.SITUS_ZIP,a.SITUS_COUNTY,a.SITUS_COUNTRY,a.SITUS_COUNTRY_CODE,a.X_COORD,a.Y_COORD,a.ADDR_DESC,a.FULL_ADDRESS,a.ADDRESS1,a.ADDRESS2,a.SITUS_NBRHD,a.EXT_ADDRESS_UID,a.STREET_NAME_START,a.STREET_NAME_END,a.CROSS_STREET_NAME_START,a.CROSS_STREET_NAME_END,a.HSE_NBR_ALPHA_START,a.HSE_NBR_ALPHA_END,a.LEVEL_PREFIX,a.LEVEL_NBR_START,a.LEVEL_NBR_END
from aatable_permit_address a 
join jms_numberKey_permitnum pmap on pmap.permitnum = a.permitnum
join AATABLE_PERMIT_HISTORY pnum on pnum.permitnum = a.permitnum + '-CBS'
;


go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0200 aatable_permit_parcel.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0100 0200 aatable_permit_parcel.sql')
/*
create_aatable_PERMIT_PARCEL
duplicate the parcel information into the cbs record
*/

--create_aatable_PERMIT_PARCEL
IF OBJECT_ID('tempdb.dbo.##completed', 'U') IS NOT NULL 
insert into ##completed values (getdate(),'create_aatable_PERMIT_PARCEL')
;
;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_PARCEL
;
;print 'AATABLE_PERMIT_PARCEL';
insert into AATABLE_PERMIT_PARCEL (
PERMITNUM,PARCELNUM,BOOK,PAGE,PARCEL,LOT,BLOCK,TRACT,LEGAL_DESC,PARCEL_AREA,PLAN_AREA,CENSUS_TRACT,COUNCIL_DISTRICT,SUPERVISOR_DISTRICT,INSPECTION_DISTRICT,LAND_VALUE,IMPROVED_VALUE,EXEMPT_VALUE,MAP_REFERENCE,MAP_NUMBER,SUBDIVISION,PRIMARY_FLAG,TOWNSHIP,RANGE,SECTION,EXT_PARCEL_UID
)
select distinct
    pnum.permitnum as [PERMITNUM]
	,left(numberKey_parcelNo.PARCEL_NO,24) as [PARCELNUM]
	,null as [BOOK]
	,null as [PAGE]
	,null as [PARCEL]
	,left(a.lot,40) as [LOT]
	,left(a.census_block,15) as [BLOCK]
	,a.tra as [TRACT]
	,left(a.legal_desc,2000) as [LEGAL_DESC]
	,a.acres as [PARCEL_AREA]
	,a.area as [PLAN_AREA]
	,a.census_tract as [CENSUS_TRACT]
	,null as [COUNCIL_DISTRICT]
	,null as [SUPERVISOR_DISTRICT]
	,null as [INSPECTION_DISTRICT]
	,null --a.land_Value as [LAND_VALUE]
	,null --a.imp_value as [IMPROVED_VALUE]
	,null --a.tot_exemp as [EXEMPT_VALUE]
	,null as [MAP_REFERENCE]
	,null as [MAP_NUMBER]
	,a.subdiv as [SUBDIVISION]
	,0 as [PRIMARY_FLAG] --update this value (below)
	,null as [TOWNSHIP]
	,null as [RANGE]
	,null as [SECTION]
	,null as [EXT_PARCEL_UID]
from aatable_permit_history pnum --from (select number_key permitnum from hcfl_src.dbo.apd_base) pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
join hcfl_src.dbo.par_base a on a.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
;


update a set
    a.PRIMARY_FLAG = 1
from AATABLE_PERMIT_PARCEL a
join (
    SELECT
        d.permitnum
        ,a.parcelNum
    from (select distinct parcelNum from AATABLE_PERMIT_PARCEL) a
    outer apply (select top 1 * from AATABLE_PERMIT_PARCEL where parcelNum = a.parcelNum) d
) f on f.permitnum = a.permitnum and f.parcelNum = a.parcelNum
;
go

--duplicate the parcel information into the cbs record
insert into aatable_permit_parcel
select
    pnum.PERMITNUM
    ,a.PARCELNUM,a.BOOK,a.PAGE,a.PARCEL,a.LOT,a.BLOCK,a.TRACT,a.LEGAL_DESC,a.PARCEL_AREA,a.PLAN_AREA,a.CENSUS_TRACT,a.COUNCIL_DISTRICT,a.SUPERVISOR_DISTRICT,a.INSPECTION_DISTRICT,a.LAND_VALUE,a.IMPROVED_VALUE,a.EXEMPT_VALUE,a.MAP_REFERENCE,a.MAP_NUMBER,a.SUBDIVISION,a.PRIMARY_FLAG,a.TOWNSHIP,a.RANGE,a.SECTION,a.EXT_PARCEL_UID
from aatable_permit_parcel a
join jms_numberKey_permitnum pmap on pmap.permitnum = a.permitnum
join aatable_permit_history pnum on pnum.permitnum = a.permitnum + '-CBS'
;


go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0120 0100 workflows.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0120 0100 workflows.sql')
/* 
rem: the apd_insp table: I am conceptualizing it like... a site visit happens, and subsequent actions/results are in subsequent rows.
Therefore: omit SV,SSV,QCSV,LSV rows, and omit COM,ACOM rows.

Citizens_Board_Support__ENF_CBS
Complaint__ENF_GEN_CPT_V5
Locksmith_Initial_Application__ENF_LOCK_LIC_V1
Locksmith_License__NO_WORKFLOW
Locksmith_Renewal__ENF_LOCK_RENEW_V2
Other__ENF_GEN_CPT_V5
Violation__PMT_VIOLATION
Water_Enforcement__ENF_GEN_CPT_V5
comment apostrophes
*/

;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_WORKFLOW
;


--Citizens_Board_Support__ENF_CBS
;IF OBJECT_ID('tempdb.dbo.#dataStatus_task_status_enf_cbs', 'U') IS NOT NULL drop table #dataStatus_task_status_enf_cbs
go
select
*
into #dataStatus_task_status_enf_cbs
from (VALUES
-- ('PREHRNG' ,'CBS Case Review',
--,('PRECEB'  ,'CBS Case Review',
 ('INSP','CBS Case Review','Request to Post At Property')
,('ADJUDIC','Post Hearing','Adjudicated')
,('CMPLFINE','Post-Hearing','Adjudicated')
,('FINERUN' ,'Post-Hearing','Adjudicated')
,('NWOWNFIN','Post-Hearing','Adjudicated')
,('CAONC'   ,'Post-Hearing','Adjudicated')
,('CAOPR'   ,'Post-Hearing','Adjudicated')
,('COMPLIED','Fee Intake','Fees Received')
,('CLOSED'  ,'Fee Intake','Fees Received')
,('CMPLCEB' ,'Fee Intake','Fees Received')
,('CNCL'    ,'Fee Intake','Fees Received')
,('DISMISS' ,'Fee Intake','Fees Received')
) t(data_status,tt_workflow_task,tt_workflow_status)
;
;insert into AATABLE_PERMIT_WORKFLOW (
PERMITNUM,TASKUPDATED,COMMENTS,ASGN_DATE,DUE_DATE,TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS,USER_ID,ID,SD_HOURS_SPENT,SD_BILLABLE,SD_OVERTIME,ESTIMATED_HOURS,ASGN_EMAIL_DISPLAY_FOR_ACA ,RESTRICT_COMMENT_FOR_ACA,RESTRICT_ROLE,TASK_UNIQUE_ID
)
select distinct
    pnum.permitnum as PERMITNUM
    ,COALESCE(try_convert(datetime,pnum.dateopened),'1900-01-01 00:00:00') as TASKUPDATED
    ,null as COMMENTS
    ,null as ASGN_DATE
    ,null as DUE_DATE
    ,f.tt_workflow_task as TT_WORKFLOW_TASK
    ,f.tt_workflow_status as TT_WORKFLOW_STATUS
    ,coalesce(asgn_staff.user_name,created_by.user_name,'Not Set') as USER_ID
    ,null as ID
    ,null as SD_HOURS_SPENT
    ,null as SD_BILLABLE
    ,null as SD_OVERTIME
    ,null as ESTIMATED_HOURS
    ,null as ASGN_EMAIL_DISPLAY_FOR_ACA
    ,null as RESTRICT_COMMENT_FOR_ACA
    ,null as RESTRICT_ROLE
    ,pnum.permitnum +'_initWorkflow' as TASK_UNIQUE_ID
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
left join jms_userid_username created_by on created_by.user_id = a.user_id
left join jms_userid_username asgn_staff on asgn_staff.user_id = a.insp_area
join #dataStatus_task_status_enf_cbs f on f.data_status = a.data_status
where 
    1=1
    and pnum.tt_record in ('Citizen Board Support')
;


--Complaint__ENF_GEN_CPT_V5
    --I think this is irrelevant:
;IF OBJECT_ID('tempdb.dbo.#actionEnt_map', 'U') IS NOT NULL drop table #actionEnt_map
;
SELECT
    action_ent
    ,action_ent_desc
    ,tt_workflow_task
    ,tt_workflow_status
into #actionEnt_map
from (VALUES 
    ('ADMN','Non inspection time'       ,'Supervisor Review','Note')
    ,('AFFN','Affidavit Non Compliance' ,'Case Affadavit','Case of Affidavit Sent')
    ,('AP','APPROVED'                   ,'Supervisor Review','Note')
    ,('CA','CANCELED'                   ,'Supervisor Review','Administratively Closed')   --final action
    --,('CA','CANCELED'                   ,'Supervisor Approval','Administratively Closed') --final action
    ,('CEB','Referred for CEB hearing'  ,'Citizen Board Support','Inspection')
    ,('CERT','CertifiedLetter'          ,'Admin Send Letter','Action Status Complete')
    ,('CEWD','OUTREACH WORKDAY'         ,'Supervisor Review','Note')
    ,('CMP','Compliance'                ,'Follow-up Investigation','In Compliance')
    ,('CMP','Compliance'                ,'Supervisor Review','In Compliance') --final action
    ,('CNCL','ITEM CANCELLED'           ,'Supervisor Review','Administratively Closed')  --final action
    --,('CNCL','ITEM CANCELLED'           ,'Supervisor Approval','Administratively Closed')--final action
    ,('CO','CORRECTION'                 ,'Supervisor Review','Corrections Applied')
    ,('COMP','Item Complied'            ,'Follow-up Investigation','In Compliance') --SV
    ,('COMP','Item Complied'            ,'Supervisor Review','In Compliance') --SSV
    ,('CONF','Conflict'                 ,'Follow-up Investigation','Request Re-inspection')
    ,('CPST','Posting Prepared'         ,'Supervisor Approval','NOV Issued')
    ,('CREV','Case Review'              ,'Supervisor Review','Note')
    ,('CRTY','Courtesy Notice Deliver'  ,'Supervisor Approval','NOV Issued')
    ,('DFLT','NOTICE OF DEFAULT'        ,'Supervisor Approval','NOV Issued')
    ,('DUMP','RRT Dumping'              ,'Initial Investigation','Administratively Closed')
    ,('EXT','Extension Granted (noSV)'  ,'Initial Investigation','Extension')
    ,('FCON','Field Contact'            ,'Case Intake','Note')
    ,('HAND','Hand Delivery of NOV'     ,'Supervisor Approval','NOV Issued')
    ,('INOC','I-Non Compliant'          ,'Initial Investigation','Owner on site - NOV/SN issued')
    ,('INVC','INVOICE FOR PPO'          ,'Supervisor Review','Note')
    ,('MHAS','Minimum Housing Appointm' ,'Supervisor Review','Note')
    ,('MISC','Miscellaneous Time'       ,'Supervisor Review','Note')
    ,('NOH','Notice of Hearing'         ,'Citizen Board Support','Inspection')
    ,('NOT2','Posted NOV'               ,'Supervisor Approval','NOV Issued')
    ,('NOV','Notice of Violation'       ,'Supervisor Approval','NOV Issued')
    ,('NOVA','Abatement Notice Complet' ,'Supervisor Approval','NOV Issued')
    ,('NOVB','COMBO NOTICES'            ,'Follow-up Investigation','Combo Issued')
    ,('NOVC','Notice Completed'         ,'Supervisor Approval','NOV Issued')
    ,('NOVF','final notice completed'   ,'Supervisor Review','Final Letter Approved')
    ,('NOVR','NOTICE REQUESTED'         ,'Follow-Up Investigation','NOV Requested')
    ,('NOVS','SITE NOTICE'              ,'Follow-Up Investigation','SN Issued')
    ,('NREV','NOTICE REVIEW'            ,'Supervisor Review','Final Letter Approved')
    ,('PC','PHONE CALL'                 ,'Initial Investigation','Requesting Call Back')
    ,('POST','Notice Posted'            ,'Follow-up Investigation','SN Issued')
    ,('PRT1','PART ONE OF AN ORDER'     ,'Citizen Board Support','Inspection')
    ,('PRT2','PART TWO OF AN ORDER'     ,'Citizen Board Support','Inspection')
    ,('PRT3','PART 3 OF AN ORDER'       ,'Citizen Board Support','Inspection')
    ,('REG','Regular Letter'            ,'Admin Send Letter','Action Status Complete')
    ,('REPT','REPEAT NOTICE OF VIOLATI' ,'Follow-up Investigation','SN Issued')
    ,('RIC','REMAIN IN COMPLIANCE'      ,'Follow-up','Request Re-inspection')
    ,('STLO','CEB Settlement Offered'   ,'Citizen Board Support','Inspection')
    ,('STLS','CEB Settlement Begins'    ,'Citizen Board Support','Inspection')
    ,('SWVN','Solid Waste NOV'          ,'Supervisor Approval','NOV Issued')
    ,('TRPL','TRIPLE PLAY NOTICE'       ,'Follow-up Investigation','SN Issued')
    ,('VIOL','Violation Added'          ,'Initial Investigation','Owner on site - NOV/SN issued')
) t(action_ent,action_ent_desc,tt_workflow_task,tt_workflow_status)
;

    --This is relevant:
;IF OBJECT_ID('tempdb.dbo.#dataStatus_task_status_ENF_GEN_CPT_V5', 'U') IS NOT NULL drop table #dataStatus_task_status_ENF_GEN_CPT_V5
;
go
select
*
into #dataStatus_task_status_ENF_GEN_CPT_V5
from (VALUES
 ('ABATED','Follow up Investigation','Administratively Closed')
,('CLNO','Supervisor Approval','Approval to Close')
,('CLSD','Supervisor Approval','Administratively Closed')
,('CMPL','Follow up Investigation','In Compliance')
,('CMPLABAT','Follow up Investigation','Administratively Closed')
,('CMPLCEB','Citizen Board Support','Close')
,('CMPLFINE','Citizen Board Support','Close')
,('DONE','Initial Investigation','Dead Animal Removal')
,('DISMISS','Citizen Board Support','Case Dismissed')
,('REMOVED','Initial Investigation','Dead Animal Removal')
,('INSP','Admin Send Letter','Action Status Complete')  --'Follow up Investigation','Request Re-Inspection') --ACTIVE')
,('ADJUDIC',  'Case Affadavit','Case of Affidavit Sent')  --'Citizen Board Support','Inspection') --'ACTIVE'
,('CAONC',    'Case Affadavit','Case of Affidavit Sent')  --'Citizen Board Support','Inspection') --???
,('CAOPR',    'Case Affadavit','Case of Affidavit Sent')  --'Citizen Board Support','Inspection') --???
,('CODEBRD',  'Case Affadavit','Case of Affidavit Sent')  --'Citizen Board Support','Inspection') --???
,('FINERUN',  'Case Affadavit','Case of Affidavit Sent')  --'Citizen Board Support','Inspection') --???
,('NWOWNFIN', 'Case Affadavit','Case of Affidavit Sent')  --'Citizen Board Support','Inspection') --???
,('PREHRNG',  'Case Affadavit','Case of Affidavit Sent')  --'Citizen Board Support','Inspection') --???
,('PRECEB',   'Case Affadavit','Case of Affidavit Sent')  --'Citizen Board Support','Inspection') --???
,('PENDING','Initial Investigation','Combo Notice Issued')  --'Supervisor Approval','ACTIVE')
,('REFERRED','Follow up Investigation','Request for Final Letter Notice') --'Supervisor Review','ACTIVE')
,('XFER',  'Initial Investigation','Combo Notice Issued') --'Supervisor Approval','ACTIVE'
,('RECITE','Initial Investigation','Combo Notice Issued') --'Supervisor Approval','ACTIVE'
,('OPEN','Case Intake','Assigned') --'Initial Investigation','ACTIVE'
) t(data_status,tt_workflow_task,tt_workflow_status)
;


;insert into AATABLE_PERMIT_WORKFLOW (
PERMITNUM,TASKUPDATED,COMMENTS,ASGN_DATE,DUE_DATE,TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS,USER_ID,ID,SD_HOURS_SPENT,SD_BILLABLE,SD_OVERTIME,ESTIMATED_HOURS,ASGN_EMAIL_DISPLAY_FOR_ACA ,RESTRICT_COMMENT_FOR_ACA,RESTRICT_ROLE,TASK_UNIQUE_ID
)
select distinct
    pnum.permitnum as PERMITNUM
    ,COALESCE(try_convert(datetime,pnum.dateopened),'1900-01-01 00:00:00') as TASKUPDATED
    ,null as COMMENTS
    ,null as ASGN_DATE
    ,null as DUE_DATE
    ,f.tt_workflow_task as TT_WORKFLOW_TASK
    ,f.tt_workflow_status as TT_WORKFLOW_STATUS
    ,coalesce(asgn_staff.user_name,created_by.user_name,'Not Set') as USER_ID
    ,null as ID
    ,null as SD_HOURS_SPENT
    ,null as SD_BILLABLE
    ,null as SD_OVERTIME
    ,null as ESTIMATED_HOURS
    ,null as ASGN_EMAIL_DISPLAY_FOR_ACA
    ,null as RESTRICT_COMMENT_FOR_ACA
    ,null as RESTRICT_ROLE
    ,pnum.permitnum +'_initWorkflow' as TASK_UNIQUE_ID
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
left join jms_userid_username created_by on created_by.user_id = a.user_id
left join jms_userid_username asgn_staff on asgn_staff.user_id = a.insp_area
join #dataStatus_task_status_ENF_GEN_CPT_V5 f on f.data_status = a.data_status
where 
    (pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive') or pnum.tt_record like 'Other%')
;



--Locksmith_Initial_Application__ENF_LOCK_LIC_V1

;IF OBJECT_ID('tempdb.dbo.#locksmith_app_presumption_data', 'U') IS NOT NULL drop table #locksmith_app_presumption_data
;
select
	'' [ ]
	,(case 
		when the_text like '%deficien%' then 'Application Intake/Additional Info Required'
		when the_text like '%need%' then 'Application Intake/Additional Info Required'
		when the_text like '%request%' then 'Application Intake/Additional Info Required'
		when the_text like '%license%issue%%' then 'License Issuance/Issued'
		when the_text like '%approv%' then 'License Issuance/Issued'
		when the_text like '%renew%' then 'License Issuance/Issued'
		when the_text like '%visit%' then 'Inspections/Inspections Completed'
		when the_text like '%met%' then 'Inspections/Inspections Completed'
						
		when the_text like '%current%' then 'Application Intake/Review Complete'
		when the_text like '%receiv%' then 'Application Intake/Review Complete'

		when the_text like '%inactive%' then 'Application Intake/Denied'
		when the_text like '%does not fit%' then 'Application Intake/Denied'
		when the_text like '%NOV%' then 'Application Intake/Denied'
		when the_text like '%closed%' then 'License Issuance/Issued'
		when the_text like '%generated%' then 'Inspections/Not Applicable'
		else 'Application Intake/Additional Info Required'
		end
	) presumption
	,l.NUMBER_KEY
	,DATE_ENTERED
	, the_text
	,coalesce(l.USER_X,convert(varchar(max),l.user_id),'Not Set') [ASGN_STAFF]
    ,convert(varchar(max),l.auto_key) as auto_key
into #locksmith_app_presumption_data
from hcfl_Src..LHN_TAB l
join AATABLE_PERMIT_HISTORY p on p.permitnum = l.NUMBER_KEY
where
	1=1
	and p.TT_RECORD = 'Locksmith Initial Application'
	--and NUMBER_KEY = 'CE18005969'

union 

select
	'' [ ]
	,'Inspections/Inspections Completed' presumption
	,i.NUMBER_KEY
	,i.DATE_ENT
	,i.any_comments
	,coalesce(user_id.USER_NAME,i.user_id,'Not Set') [ASGN_STAFF]
    ,i.unique_key as auto_key
from jms_apd_insp_filteredToPop i
join AATABLE_PERMIT_HISTORY p on p.permitnum = i.NUMBER_KEY
left join hcfl_src.dbo.usr_base user_id on user_id.user_id = i.user_id
where
	1=1
	and p.tt_record = 'Locksmith Initial Application'
	and i.UNIQUE_KEY not like 'ORPH-%'
	and i.ACTION_ENT in ('sv','ssv','qcsv','lsv')
;


insert into AATABLE_PERMIT_WORKFLOW (
PERMITNUM,TASKUPDATED,COMMENTS,ASGN_DATE,DUE_DATE,TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS,USER_ID,ID,SD_HOURS_SPENT,SD_BILLABLE,SD_OVERTIME,ESTIMATED_HOURS,ASGN_EMAIL_DISPLAY_FOR_ACA ,RESTRICT_COMMENT_FOR_ACA,RESTRICT_ROLE,TASK_UNIQUE_ID
)
select distinct
    pnum.permitnum as PERMITNUM
    ,COALESCE(try_convert(datetime,pnum.dateopened),'1900-01-01 00:00:00') as TASKUPDATED
    ,null as COMMENTS
    ,null as ASGN_DATE
    ,null as DUE_DATE
    ,'Application Intake' as TT_WORKFLOW_TASK
    ,'Additional Info Required' as TT_WORKFLOW_STATUS
    ,coalesce(asgn_staff.user_name,created_by.user_name,'Not Set') as USER_ID
    ,null as ID
    ,null as SD_HOURS_SPENT
    ,null as SD_BILLABLE
    ,null as SD_OVERTIME
    ,null as ESTIMATED_HOURS
    ,null as ASGN_EMAIL_DISPLAY_FOR_ACA
    ,null as RESTRICT_COMMENT_FOR_ACA
    ,null as RESTRICT_ROLE
    ,pnum.permitnum +'_initWorkflow' as TASK_UNIQUE_ID
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
left join jms_userid_username created_by on created_by.user_id = a.user_id
left join jms_userid_username asgn_staff on asgn_staff.user_id = a.insp_area
--join jms_apd_insp_filteredToPop i on i.number_key = pmap.number_key
--join #actionEnt_map am on am.action_ent = i.action_ent 
where 
    pnum.tt_record in ('Locksmith Initial Application')
;

insert into AATABLE_PERMIT_WORKFLOW (
PERMITNUM,TASKUPDATED,COMMENTS,ASGN_DATE,DUE_DATE,TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS,USER_ID,ID,SD_HOURS_SPENT,SD_BILLABLE,SD_OVERTIME,ESTIMATED_HOURS,ASGN_EMAIL_DISPLAY_FOR_ACA ,RESTRICT_COMMENT_FOR_ACA,RESTRICT_ROLE,TASK_UNIQUE_ID
)
select distinct
    pnum.permitnum as PERMITNUM
    ,COALESCE(a.date_entered,'1900-01-01 00:00:00') as TASKUPDATED
    ,left(replace(replace(a.the_text,char(10),'�'),char(13),''),4000) as COMMENTS
    ,null as ASGN_DATE
    ,null as DUE_DATE
    ,trim('/ ' from substring(a.presumption,1,charindex('/',a.presumption))					) as TT_WORKFLOW_TASK
    ,trim('/ ' from substring(a.presumption,charindex('/',a.presumption),len(a.presumption)) ) as TT_WORKFLOW_STATUS
    ,a.ASGN_STAFF as USER_ID
    ,null as ID
    ,null as SD_HOURS_SPENT
    ,null as SD_BILLABLE
    ,null as SD_OVERTIME
    ,null as ESTIMATED_HOURS
    ,null as ASGN_EMAIL_DISPLAY_FOR_ACA
    ,null as RESTRICT_COMMENT_FOR_ACA
    ,null as RESTRICT_ROLE
    ,convert(varchar(max),a.auto_key) as TASK_UNIQUE_ID --,pnum.permitnum +'_' + convert(varchar(max),a.auto_key) as TASK_UNIQUE_ID
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join #locksmith_app_presumption_data a on a.number_key = pmap.number_key
where 
    pnum.tt_record in ('Locksmith Initial Application')
;


--Locksmith_License__NO_WORKFLOW

--Locksmith_Renewal__ENF_LOCK_RENEW_V2


;IF OBJECT_ID('tempdb.dbo.#locksmith_ren_presumption_data', 'U') IS NOT NULL drop table #locksmith_ren_presumption_data
;
select
	'' [ ]
	,(case 
		when the_text like '%fail%' then 'Application Intake/Withdrawn'
		when the_text like '%await%' then 'Application Intake/Additional Info Required'
		when the_text like '%request%' then 'Application Intake/Additional Info Required'
		when the_text like '%return%call%' then 'Application Intake/Additional Info Required'
		when the_text like '%spoke with%' then 'Application Intake/Additional Info Required'
		when the_text like '%Research%' then 'Application Intake/Additional Info Required'
		
		when the_text like '%business no long%' then 'Application Intake/Withdrawn'
		when the_text like '%creat%err%' then 'Application Intake/Withdrawn'
		when the_text like '%no%resp%' then 'Application Intake/Additional Info Required'
		when the_text like '%met%' then 'Inspections/Inspections Completed'
		when the_text like '%emailed investigators%' then 'Inspections/Schedule Site Visit'
		when the_text like '%for an inspect%' then 'Inspections/Schedule Site Visit'
		when the_text like '%proof of%' then 'Application Intake/Review Complete'
		when the_text like '%received%' then 'Application Intake/Review Complete'
		when the_text like '%entering%' then 'Inspections/Inspections Complete'
		when the_text like '%inspect%' then 'Inspections/Schedule Site Visit'
		when the_text like '%get together%' then 'Inspections/Schedule Site Visit'

		
		when the_text like '%renew%' then 'Renew License/Issued'
		when the_text like '%issue%' then 'Renew License/Issued'
		when the_text like '%generated lic%' then 'Renew License/Issued'
		when the_text like '%clos%' then 'Application Intake/Withdrawn'
		when the_text like '%NOV%' then 'Application Intake/Withdrawn'
		when the_text like '%pulled%' then 'Application Intake/Withdrawn'
		
		else 'Application Intake/Additional Info Required'
		end
	) presumption
	,l.NUMBER_KEY
	,DATE_ENTERED
	, the_text
	,coalesce(l.USER_X,convert(varchar(max),l.user_id),'Not Set') [ASGN_STAFF]
    ,convert(varchar(max),l.auto_key) as auto_key
into #locksmith_ren_presumption_data
from hcfl_Src..LHN_TAB l
join AATABLE_PERMIT_HISTORY p on p.permitnum = l.NUMBER_KEY
where
	1=1
	and p.TT_RECORD = 'Locksmith Renewal'
	--and NUMBER_KEY = 'CE18005969'

union 

select
	'' [ ]
	,'Inspections/Inspections Completed' presumption
	,i.NUMBER_KEY
	,i.DATE_ENT
	,i.any_comments
	,coalesce(user_id.USER_NAME,i.user_id,'Not Set') [ASGN_STAFF]
    ,i.unique_key as auto_key
from jms_apd_insp_filteredToPop i
join AATABLE_PERMIT_HISTORY p on p.permitnum = i.NUMBER_KEY
left join hcfl_src.dbo.usr_base user_id on user_id.user_id = i.user_id
where
	1=1
	and p.tt_record = 'Locksmith Renewal'
	and i.UNIQUE_KEY not like 'ORPH-%'
	and i.ACTION_ENT in ('sv','ssv','qcsv','lsv')
;





insert into AATABLE_PERMIT_WORKFLOW (
PERMITNUM,TASKUPDATED,COMMENTS,ASGN_DATE,DUE_DATE,TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS,USER_ID,ID,SD_HOURS_SPENT,SD_BILLABLE,SD_OVERTIME,ESTIMATED_HOURS,ASGN_EMAIL_DISPLAY_FOR_ACA ,RESTRICT_COMMENT_FOR_ACA,RESTRICT_ROLE,TASK_UNIQUE_ID
)
select distinct
    pnum.permitnum as PERMITNUM
    ,COALESCE(try_convert(datetime,pnum.dateopened),'1900-01-01 00:00:00') as TASKUPDATED
    ,null as COMMENTS
    ,null as ASGN_DATE
    ,null as DUE_DATE
    ,'Application Intake' as TT_WORKFLOW_TASK
    ,'Additional Info Required' as TT_WORKFLOW_STATUS
    ,coalesce(asgn_staff.user_name,created_by.user_name,'Not Set') as USER_ID
    ,null as ID
    ,null as SD_HOURS_SPENT
    ,null as SD_BILLABLE
    ,null as SD_OVERTIME
    ,null as ESTIMATED_HOURS
    ,null as ASGN_EMAIL_DISPLAY_FOR_ACA
    ,null as RESTRICT_COMMENT_FOR_ACA
    ,null as RESTRICT_ROLE
    ,pnum.permitnum +'_initWorkflow' as TASK_UNIQUE_ID
from AATABLE_PERMIT_HISTORY pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
left join jms_userid_username created_by on created_by.user_id = a.user_id
left join jms_userid_username asgn_staff on asgn_staff.user_id = a.insp_area
where 
    pnum.tt_record in ('Locksmith Renewal')
;


insert into AATABLE_PERMIT_WORKFLOW (
PERMITNUM,TASKUPDATED,COMMENTS,ASGN_DATE,DUE_DATE,TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS,USER_ID,ID,SD_HOURS_SPENT,SD_BILLABLE,SD_OVERTIME,ESTIMATED_HOURS,ASGN_EMAIL_DISPLAY_FOR_ACA ,RESTRICT_COMMENT_FOR_ACA,RESTRICT_ROLE,TASK_UNIQUE_ID
)
select distinct
    pnum.permitnum as PERMITNUM
    ,COALESCE(a.date_entered,'1900-01-01 00:00:00') as TASKUPDATED
    ,left(replace(replace(a.the_text,char(10),'�'),char(13),''),4000) as COMMENTS
    ,null as ASGN_DATE
    ,null as DUE_DATE
    ,trim('/ ' from substring(a.presumption,1,charindex('/',a.presumption))					) as TT_WORKFLOW_TASK
    ,trim('/ ' from substring(a.presumption,charindex('/',a.presumption),len(a.presumption)) ) as TT_WORKFLOW_STATUS
    ,a.ASGN_STAFF as USER_ID
    ,null as ID
    ,null as SD_HOURS_SPENT
    ,null as SD_BILLABLE
    ,null as SD_OVERTIME
    ,null as ESTIMATED_HOURS
    ,null as ASGN_EMAIL_DISPLAY_FOR_ACA
    ,null as RESTRICT_COMMENT_FOR_ACA
    ,null as RESTRICT_ROLE
    ,convert(varchar(max),a.auto_key) as TASK_UNIQUE_ID --,pnum.permitnum +'_'+convert(varchar(max),a.auto_key) as TASK_UNIQUE_ID
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join #locksmith_ren_presumption_data a on a.number_key = pmap.number_key
where 
    pnum.tt_record in ('Locksmith Renewal')
;


--Other__ENF_GEN_CPT_V5
;insert into AATABLE_PERMIT_WORKFLOW (
PERMITNUM,TASKUPDATED,COMMENTS,ASGN_DATE,DUE_DATE,TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS,USER_ID,ID,SD_HOURS_SPENT,SD_BILLABLE,SD_OVERTIME,ESTIMATED_HOURS,ASGN_EMAIL_DISPLAY_FOR_ACA ,RESTRICT_COMMENT_FOR_ACA,RESTRICT_ROLE,TASK_UNIQUE_ID
)
select distinct
    pnum.permitnum as PERMITNUM
    ,COALESCE(try_convert(datetime,pnum.dateopened),'1900-01-01 00:00:00') as TASKUPDATED
    ,null as COMMENTS
    ,null as ASGN_DATE
    ,null as DUE_DATE
    ,'Case Intake' as TT_WORKFLOW_TASK
    ,'Assigned' as TT_WORKFLOW_STATUS
    ,coalesce(asgn_staff.user_name,created_by.user_name,'Not Set') as USER_ID
    ,null as ID
    ,null as SD_HOURS_SPENT
    ,null as SD_BILLABLE
    ,null as SD_OVERTIME
    ,null as ESTIMATED_HOURS
    ,null as ASGN_EMAIL_DISPLAY_FOR_ACA
    ,null as RESTRICT_COMMENT_FOR_ACA
    ,null as RESTRICT_ROLE
    ,pnum.permitnum +'_initWorkflow' as TASK_UNIQUE_ID
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
left join jms_userid_username created_by on created_by.user_id = a.user_id
left join jms_userid_username asgn_staff on asgn_staff.user_id = a.insp_area
--join jms_apd_insp_filteredToPop i on i.number_key = pmap.number_key
--join #actionEnt_map am on am.action_ent = i.action_ent 
where 
    pnum.tt_record like 'Other%'
;

;insert into AATABLE_PERMIT_WORKFLOW (
PERMITNUM,TASKUPDATED,COMMENTS,ASGN_DATE,DUE_DATE,TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS,USER_ID,ID,SD_HOURS_SPENT,SD_BILLABLE,SD_OVERTIME,ESTIMATED_HOURS,ASGN_EMAIL_DISPLAY_FOR_ACA ,RESTRICT_COMMENT_FOR_ACA,RESTRICT_ROLE,TASK_UNIQUE_ID
)
select distinct
    pnum.permitnum as PERMITNUM
    ,COALESCE(try_convert(datetime,i.date_ent),'1900-01-01 00:00:00') as TASKUPDATED
    ,left(replace(replace(i.any_comments,char(10),'�'),char(13),''),4000) as COMMENTS
    ,null as ASGN_DATE
    ,null as DUE_DATE
    ,am.tt_workflow_task as TT_WORKFLOW_TASK
    ,am.tt_workflow_status as TT_WORKFLOW_STATUS
    ,coalesce(user_id.user_name,i.user_id,'Not Set') as USER_ID
    ,null as ID
    ,null as SD_HOURS_SPENT
    ,null as SD_BILLABLE
    ,null as SD_OVERTIME
    ,null as ESTIMATED_HOURS
    ,null as ASGN_EMAIL_DISPLAY_FOR_ACA
    ,null as RESTRICT_COMMENT_FOR_ACA
    ,null as RESTRICT_ROLE
    ,i.UNIQUE_KEY as TASK_UNIQUE_ID
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_insp_filteredToPop i on i.number_key = pmap.number_key
join #actionEnt_map am on am.action_ent = i.action_ent 
left join hcfl_src.dbo.usr_base user_id on user_id.user_id = i.user_id
where 
    pnum.tt_record like 'Other%'
    and i.action_ent not in ('sv','ssv','qcsv','lsv','com','acom')
;

--Violation__PMT_VIOLATION
;IF OBJECT_ID('tempdb.dbo.#violation_presumption_data', 'U') IS NOT NULL drop table #violation_presumption_data

select 
	'' [ ]
	,(case 
		when action_ent like 'NOV%' or action_ent in ('CERT','NOT2','HAND','CRTY','SWVN','POST','SUB','DUMP','CPST') then 'Pending Violation Review/Violation Issued'
		when action_ent in ('COMP','CMP','AP') then 'Review Violation/Complied'
		when action_ent in ('EXT','BCMP') then 'Review Violation/Extension Granted'
		when action_ent = 'VIOL' then 'Pending Violation Review/Violation Issued'
		when action_ent in ('REPT','NCMP','PC','INVC') then 'Review Violation/Note'
		when action_ent = 'CEB' then 'Review Violation/File PCCB'
		when action_ent = 'CO' then 'Review Violation/Complied'
		when action_ent in ('STLO','STLS','RIC','DFLT') then 'Case Closure/Note'
		when action_ent in ('ABAT','TRPL','NREV','CONF','CREV','COM','ACOM','TRNG','ADMN','MISC') then 'Review Violation/Note'
		when action_ent in ('PRT1','PRT2','PRT3','AFFN') then 'PCCB/In Violation'
		when action_ent in ('CA','CNCL','NA','CEWD') then 'Case Closure/Closed'
		when action_ent in ('OVT','ASTA','MHAS','UNIT','COSV') then 'Pending Violation Review/Note'
		else null
		end
	) presumption
	,i.NUMBER_KEY
	,i.DATE_ENT
	,i.any_comments
	,coalesce(user_id.USER_NAME,i.user_id,'Not Set') [ASGN_STAFF]
	,i.ACTION_ENT
    ,i.UNIQUE_KEY
	,i.item_id
into #violation_presumption_data
from jms_apd_insp_filteredToPop i
join AATABLE_PERMIT_HISTORY p on p.permitnum = i.NUMBER_KEY
left join hcfl_src.dbo.usr_base user_id on user_id.user_id = i.user_id
where
	1=1
	and p.tt_record = 'violation'
	and i.UNIQUE_KEY not like 'ORPH-%'
	and i.ACTION_ENT not in ('sv','ssv','qcsv','lsv')
	--and i.NUMBER_KEY = 'CE12001626'
	--and i.ACTION_ENT = 'co'
--order by i.date_ent
;
delete from #violation_presumption_data where presumption is null
;


insert into AATABLE_PERMIT_WORKFLOW (
PERMITNUM,TASKUPDATED,COMMENTS,ASGN_DATE,DUE_DATE,TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS,USER_ID,ID,SD_HOURS_SPENT,SD_BILLABLE,SD_OVERTIME,ESTIMATED_HOURS,ASGN_EMAIL_DISPLAY_FOR_ACA ,RESTRICT_COMMENT_FOR_ACA,RESTRICT_ROLE,TASK_UNIQUE_ID
)
select distinct
    pnum.permitnum as PERMITNUM
    ,COALESCE(try_convert(datetime,pnum.dateopened),'1900-01-01 00:00:00') as TASKUPDATED
    ,null as COMMENTS
    ,null as ASGN_DATE
    ,null as DUE_DATE
    ,'Application Intake' as TT_WORKFLOW_TASK
    ,'Additional Info Required' as TT_WORKFLOW_STATUS
    ,coalesce(asgn_staff.user_name,created_by.user_name,'Not Set') as USER_ID
    ,null as ID
    ,null as SD_HOURS_SPENT
    ,null as SD_BILLABLE
    ,null as SD_OVERTIME
    ,null as ESTIMATED_HOURS
    ,null as ASGN_EMAIL_DISPLAY_FOR_ACA
    ,null as RESTRICT_COMMENT_FOR_ACA
    ,null as RESTRICT_ROLE
    ,pnum.permitnum +'_initWorkflow' as TASK_UNIQUE_ID
from AATABLE_PERMIT_HISTORY pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
left join jms_userid_username created_by on created_by.user_id = a.user_id
left join jms_userid_username asgn_staff on asgn_staff.user_id = a.insp_area
where 
    pnum.tt_record in ('Violation')
;

insert into AATABLE_PERMIT_WORKFLOW (
PERMITNUM,TASKUPDATED,COMMENTS,ASGN_DATE,DUE_DATE,TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS,USER_ID,ID,SD_HOURS_SPENT,SD_BILLABLE,SD_OVERTIME,ESTIMATED_HOURS,ASGN_EMAIL_DISPLAY_FOR_ACA ,RESTRICT_COMMENT_FOR_ACA,RESTRICT_ROLE,TASK_UNIQUE_ID
)
select distinct
    pnum.permitnum as PERMITNUM
    ,COALESCE(try_convert(datetime,a.date_ent),'1900-01-01 00:00:00') as TASKUPDATED
    ,left(replace(replace(a.any_comments,char(10),'�'),char(13),''),4000) as COMMENTS
    ,null as ASGN_DATE
    ,null as DUE_DATE
    ,trim('/ ' from substring(a.presumption,1,charindex('/',a.presumption))					) as TT_WORKFLOW_TASK
    ,trim('/ ' from substring(a.presumption,charindex('/',a.presumption),len(a.presumption)) ) as TT_WORKFLOW_STATUS
    ,a.ASGN_STAFF as USER_ID
    ,null as ID
    ,null as SD_HOURS_SPENT
    ,null as SD_BILLABLE
    ,null as SD_OVERTIME
    ,null as ESTIMATED_HOURS
    ,null as ASGN_EMAIL_DISPLAY_FOR_ACA
    ,null as RESTRICT_COMMENT_FOR_ACA
    ,null as RESTRICT_ROLE
    ,a.unique_key as TASK_UNIQUE_ID
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join #violation_presumption_data a on a.number_key = pmap.number_key
where 
    pnum.tt_record in ('Violation')
;

--What if the case is closed and there is no closure step?
--What if the case has a hearing or order date in apd_base, and no occurrence of "hearing" or similar in apd_insp?



--Water_Enforcement__ENF_GEN_CPT_V5
--use #actionEnt_map

insert into AATABLE_PERMIT_WORKFLOW (
PERMITNUM,TASKUPDATED,COMMENTS,ASGN_DATE,DUE_DATE,TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS,USER_ID,ID,SD_HOURS_SPENT,SD_BILLABLE,SD_OVERTIME,ESTIMATED_HOURS,ASGN_EMAIL_DISPLAY_FOR_ACA ,RESTRICT_COMMENT_FOR_ACA,RESTRICT_ROLE,TASK_UNIQUE_ID
)
select distinct
    pnum.permitnum as PERMITNUM
    ,COALESCE(try_convert(datetime,pnum.dateopened),'1900-01-01 00:00:00') as TASKUPDATED
    ,null as COMMENTS
    ,null as ASGN_DATE
    ,null as DUE_DATE
    ,'Case Intake' as TT_WORKFLOW_TASK
    ,'Assigned' as TT_WORKFLOW_STATUS
    ,coalesce(asgn_staff.user_name,created_by.user_name,'Not Set') as USER_ID
    ,null as ID
    ,null as SD_HOURS_SPENT
    ,null as SD_BILLABLE
    ,null as SD_OVERTIME
    ,null as ESTIMATED_HOURS
    ,null as ASGN_EMAIL_DISPLAY_FOR_ACA
    ,null as RESTRICT_COMMENT_FOR_ACA
    ,null as RESTRICT_ROLE
    ,pnum.permitnum +'_initWorkflow' as TASK_UNIQUE_ID
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
left join jms_userid_username created_by on created_by.user_id = a.user_id
left join jms_userid_username asgn_staff on asgn_staff.user_id = a.insp_area
--join jms_apd_insp_filteredToPop i on i.number_key = pmap.number_key
--join #actionEnt_map am on am.action_ent = i.action_ent 
where 
    pnum.tt_record in ('Water Enforcement')
;

;insert into AATABLE_PERMIT_WORKFLOW (
PERMITNUM,TASKUPDATED,COMMENTS,ASGN_DATE,DUE_DATE,TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS,USER_ID,ID,SD_HOURS_SPENT,SD_BILLABLE,SD_OVERTIME,ESTIMATED_HOURS,ASGN_EMAIL_DISPLAY_FOR_ACA ,RESTRICT_COMMENT_FOR_ACA,RESTRICT_ROLE,TASK_UNIQUE_ID
)
select distinct
    pnum.permitnum as PERMITNUM
    ,COALESCE(try_convert(datetime,i.date_ent),'1900-01-01 00:00:00') as TASKUPDATED
    ,left(replace(replace(i.any_comments,char(10),'�'),char(13),''),4000) as COMMENTS
    ,null as ASGN_DATE
    ,null as DUE_DATE
    ,am.tt_workflow_task as TT_WORKFLOW_TASK
    ,am.tt_workflow_status as TT_WORKFLOW_STATUS
    ,coalesce(user_id.user_name,i.user_id,'Not Set') as USER_ID
    ,null as ID
    ,null as SD_HOURS_SPENT
    ,null as SD_BILLABLE
    ,null as SD_OVERTIME
    ,null as ESTIMATED_HOURS
    ,null as ASGN_EMAIL_DISPLAY_FOR_ACA
    ,null as RESTRICT_COMMENT_FOR_ACA
    ,null as RESTRICT_ROLE
    ,i.UNIQUE_KEY as TASK_UNIQUE_ID
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_insp_filteredToPop i on i.number_key = pmap.number_key
join #actionEnt_map am on am.action_ent = i.action_ent 
left join hcfl_src.dbo.usr_base user_id on user_id.user_id = i.user_id
where 
    pnum.tt_record in ('Water Enforcement')
    and i.action_ent not in ('sv','ssv','qcsv','lsv','com','acom')
;


--comment apostrophes
update aatable_permit_workflow set
    comments = replace(comments,'''','�')
;
    --and user_id's, apparently...
update aatable_permit_workflow set
    user_id = 'Spriggs, Teddy'
WHERE
    1=1
    and user_id = 'Spriggs, Edward ''Teddy'''
;

go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0140 0100 custom fields.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0140 0100 custom fields.sql')
/*
Citizen Board Support - ENF_CBS
Enforcement Complaint - ENF_COMPLAIN
Locksmith Initial Application - ENF_LOCK
Locksmith License - ENF_LOCK
Locksmith Renewal - ENF_LOCK
Violation - PMT_VIO
*/

--Citizen Board Support - ENF_CBS
;IF OBJECT_ID('tempdb.dbo.##completed', 'U') is not null insert into ##completed values (getdate(),'0140 0100 custom fields.sql -- cbs')
;print 'Citizen Board Support - ENF_CBS';

;IF OBJECT_ID('tempdb.dbo.#green_card_date', 'U') IS NOT NULL DROP TABLE #green_card_date
;select
    t.NUMBER_KEY
    ,min(t.date_entered) date_entered
into #green_card_date
from hcfl_src.dbo.lhn_tab t
join jms_numberKey_permitnum pmap on pmap.number_key = t.number_key
join aatable_permit_history pnum on pnum.permitnum = pmap.number_key + '-CBS'
where 
    1=1
    and pnum.tt_record in ('Citizen Board Support')
    and the_text like '%green card%' 
    and the_text not like '%not REC%D%' 
    and the_text not like '%missing%' 
    and the_text not like '%not%return%' 
    and the_text not like '%no green%'
group by t.NUMBER_KEY
;--30sec
;IF OBJECT_ID('tempdb.dbo.#a', 'U') IS NOT NULL DROP TABLE #a
;SELECT
    a.number_key
    ,a.date_d
    ,a.date_g
    ,a.date_h
    ,a.date_i
into #a
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
where 
	pnum.tt_record = 'Citizen Board Support'
    and coalesce(a.date_d,a.date_g,a.date_h,a.date_i) is not null
;--0sec
;IF OBJECT_ID('tempdb.dbo.#m0', 'U') IS NOT NULL DROP TABLE #m0
;SELECT
    m.number_key
    ,m.mon_080
    ,m.MON_045
    ,m.MON_046
    ,m.MON_047
    ,m.MON_048    
into #m0
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
join hcfl_src.dbo.apd_mon0 m on m.number_key = pmap.number_key
where 
	pnum.tt_record = 'Citizen Board Support'
	and coalesce(m.mon_080,m.MON_045,m.MON_046,m.MON_047,m.MON_048) is not null
;--30sec
;IF OBJECT_ID('tempdb.dbo.#n0', 'U') IS NOT NULL DROP TABLE #n0
;SELECT
     n0.number_key
    ,n0.Date_031 dtCertSent        
    ,n0.date_054 dtLastVisitNot    
    ,n0.date_057 dtPosting1    
    ,n0.date_052 dtCEBOrder
    ,n0.date_094 dtLienRec1  --Date principal lien recorded
    ,n0.date_096 dtLienRel1  --Date principal lien released
    ,(case when n0.date_052 is not null then 'Yes' else 'No' end) as repeat_violator
    ,n0.Date_095 dtLienRec2       
    ,n0.date_097 dtLienRel2  --Date principal lien released
    
    ,n0.date_099 as dtCBSReceived     
    ,n0.DATE_084
    ,n0.DATE_085
    ,n0.DATE_099
    ,n0.date_077
into #n0
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
join hcfl_src.dbo.apd_num0 n0 on n0.number_key = pmap.number_key
where 
	pnum.tt_record = 'Citizen Board Support'
	and coalesce(n0.Date_031,n0.date_054,n0.date_057,n0.date_052,n0.date_094,n0.date_096,n0.date_052,n0.Date_095,n0.date_097,n0.DATE_084,n0.DATE_085,n0.DATE_099,n0.date_077) is not null
;--50sec
;IF OBJECT_ID('tempdb.dbo.#n1', 'U') IS NOT NULL DROP TABLE #n1
;SELECT
     n1.number_key
    ,n1.Date_101 as dtPostingPrep
    ,n0.date_099 as dtCBSReceived
into #n1
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
left join hcfl_src.dbo.apd_num1 n1 on n1.number_key = pmap.number_key
left join hcfl_src.dbo.apd_num0 n0 on n0.number_key = pmap.number_key
where 
	pnum.tt_record = 'Citizen Board Support'
	and coalesce(n1.date_101,n0.date_099) is not null
;--20sec
;IF OBJECT_ID('tempdb.dbo.#t0', 'U') IS NOT NULL DROP TABLE #t0
;SELECT
     t.number_key
    ,t.text_018 txtAffiant        
    ,t.text_029 strDefendantHrng  
    ,t.text_031 strCountyWitness  
    ,t.text_038 strRecOR2         
    ,t.text_039 strRelOR2         
    ,t.Text_042 strHearingType    
    ,t.Text_013 strCEBNoticeType
    ,t.TEXT_032
    ,t.TEXT_040
    ,t.TEXT_041    
    ,t.YN_007
    ,t.YN_051
into #t0
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
join hcfl_src.dbo.apd_txt0 t on t.number_key = pmap.number_key
where 
	pnum.tt_record = 'Citizen Board Support'
	and coalesce(t.text_018,t.text_029,t.text_031,t.text_038,t.text_039,t.Text_042,t.Text_013,t.TEXT_032,t.TEXT_040,t.TEXT_041,t.YN_007,t.YN_051,null) is not null
;--8sec
;IF OBJECT_ID('tempdb.dbo.#t1', 'U') IS NOT NULL DROP TABLE #t1
;SELECT
     t.number_key
    ,t.text_054 
    ,t.text_080 NOTICE_TYPE       
    ,t.text_082 strCetLetter      
    ,t.TEXT_077
    ,t.TEXT_098
into #t1
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
join hcfl_src.dbo.apd_txt1 t on t.number_key = pmap.number_key
where 
	pnum.tt_record = 'Citizen Board Support'
	and coalesce(t.text_054,t.text_080,t.text_082,t.TEXT_077,t.TEXT_098) is not null
;--3sec
;IF OBJECT_ID('tempdb.dbo.#STRINSTRUMENTREC', 'U') IS NOT NULL DROP TABLE #STRINSTRUMENTREC
;SELECT
    pmap.number_key --STRINSTRUMENTREC.vdi_key
    ,STRINSTRUMENTREC.text_value
	,t0.text_031 strCountyWitness 
into #STRINSTRUMENTREC
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
left join hcfl_src.dbo.vdi_detl STRINSTRUMENTREC on STRINSTRUMENTREC.vdi_key = pmap.number_key and STRINSTRUMENTREC.aka_name = 'STRINSTRUMENTREC'
left join hcfl_src.dbo.APD_Txt0 t0 on t0.NUMBER_KEY = pmap.number_key 
where 
    pnum.tt_record = 'Citizen Board Support'
	and coalesce(STRINSTRUMENTREC.TEXT_VALUE,t0.text_031) is not null
;--22sec
;IF OBJECT_ID('tempdb.dbo.#STRINSTRUMENTREL', 'U') IS NOT NULL DROP TABLE #STRINSTRUMENTREL
;SELECT
    pmap.number_key --STRINSTRUMENTREL.vdi_key
    ,STRINSTRUMENTREL.text_value
	,t0.Text_037 strRelOR1
into #STRINSTRUMENTREL
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
left join hcfl_src.dbo.vdi_detl STRINSTRUMENTREL on STRINSTRUMENTREL.vdi_key = pmap.number_key and STRINSTRUMENTREL.aka_name = 'STRINSTRUMENTREL'
left join hcfl_src.dbo.APD_Txt0 t0 on t0.number_key = pmap.number_key
where 
    pnum.tt_record = 'Citizen Board Support'
	and coalesce(STRINSTRUMENTREL.text_value,t0.text_037) is not null
;--22sec
;IF OBJECT_ID('tempdb.dbo.#primary_name', 'U') IS NOT NULL DROP TABLE #primary_name
;WITH RankedResults AS (
    SELECT 
        pmap.number_key --STRINSTRUMENTREL.vdi_key
        ,p.name
        ,ROW_NUMBER() OVER(PARTITION BY  pmap.number_key ORDER BY p.primary_name,p.name ) AS Rank
    from aatable_permit_history pnum
    join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
    join hcfl_src.dbo.apd_peo p on p.number_key = pmap.number_key 
)
SELECT 
    *
into #primary_name
FROM RankedResults
WHERE
    1=1
    and Rank = 1
;--22sec
;IF OBJECT_ID('tempdb.dbo.#primary_address', 'U') IS NOT NULL DROP TABLE #primary_address
;WITH RankedResults AS (
  SELECT 
	permitnum
	,full_address
    ,ROW_NUMBER() OVER(PARTITION BY permitnum ORDER BY case when isprimary='Y' then 1 else 2 end) AS Rank
  FROM AATABLE_PERMIT_ADDRESS
)
SELECT 
	*
into #primary_address
FROM RankedResults
WHERE
	1=1
	and Rank = 1
;--xx sec
;IF OBJECT_ID('tempdb.dbo.#legal_descs', 'U') IS NOT NULL DROP TABLE #legal_descs
;create table #legal_descs ( permitnum varchar(50), legal_desc varchar(max) )
;with cte_many as (
	select 
		pmap.permitnum + '-cbs' permitnum
		,count(LEGAL_DESC) ct
	from aatable_permit_history pnum
	join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
	join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
	left join hcfl_src.dbo.par_base pb on pb.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
	where
		1=1
		and pnum.tt_record in ('Citizen Board Support')
	group by pmap.permitnum
	having count(LEGAL_DESC) > 1
), g as (
	select distinct
		pmap.permitnum + '-CBS' permitnum
		,pb.LEGAL_DESC
	from aatable_permit_history pnum
	join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
	join cte_many f on f.permitnum =  pmap.permitnum+'-CBS'
	join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
	left join hcfl_src.dbo.par_base pb on pb.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
	where
		1=1
		and pnum.tt_record in ('Citizen Board Support')
),h as (
	SELECT
		permitnum
		,trim('^| ' from 
			  STUFF(
				(SELECT ' ^|^ ' + LEGAL_DESC
				 FROM g AS innerTable
				 WHERE innerTable.permitnum = outerTable.permitnum
				 FOR XML PATH(''), TYPE
				).value('.', 'NVARCHAR(MAX)'), 1, 2, '') 
		) AS legal_desc
	FROM g AS outerTable
	where
		1=1
		--and permitnum = 'CE19003259-cbs'
	GROUP BY permitnum
)
insert into #legal_descs
select * from h

union

select 
	pmap.permitnum + '-CBS' permitnum
	,trim(pb.LEGAL_DESC) legal_desc
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
left join hcfl_src.dbo.par_base pb on pb.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
where
	1=1
	and pnum.tt_record in ('Citizen Board Support')
	and not exists (
		select 1
		from h
		where permitnum =  pmap.permitnum+'-CBS'
	)
;
go



;IF OBJECT_ID('cf_Citizen_Board_Support', 'U') IS NOT NULL DROP TABLE cf_Citizen_Board_Support
;
SELECT distinct
    pnum.permitNum
    ,pnum.tt_record
 
    --DATA FIELDS
    ,n0.dtLastVisitNot as [Notice Date]
    --,n0.dtLastVisitNot as [Date of Service] --Date  --'dtLastVisitNot    ',' Date of the last visitor service'
    ,t0.strCEBNoticeType as [Method of Service] --t1.NOTICE_TYPE as [Method of Service] --Text --'NOTICE_TYPE       ','Type of service '
    ,a.date_i as [Date of Affidavit] --Date 
    ,a.date_d as [Hearing Date] --Date 
    ,n0.dtCertSent as [Postmark Date] --Date  --'dtCertSent        ',' DateCertified Letter Sent to Violator'
    ,n1.dtCBSReceived as [Date received for Hearing] --Date  --'dtHearingSched    ','Scheduled date for hearing (not actual)'
    ,a.date_h as [Date of Board Order] --Date 
    ,t0.strDefendantHrng as [who appeared for hearing] --Text  --'strDefendantHrng  ',' Defendant Name Appearing at Hearing'
    ,m0.mon_080 as [Cap Value] --Number --curFineCap
    ,t0.strCountyWitness as [Name of the officer giving testimony] --Text  --'txtAffiant        ','Name of Officer for NCA'
    ,null as [hearing location]
    ,n0.dtLienRec1 as [Recording Date] --Date 
    ,n0.dtLienRec2 as [Secondary Recording Date] --Date 
    ,n0.dtLienRel1 as [Release Date] --Date 
    ,n0.dtLienRel2 as [Secondary Release Date] --Date 
    ,t1.text_054 as [Book Page for Liens] --Text Area  --'strPPOBook        ',' Book for recording PPO lien'
    ,coalesce(STRINSTRUMENTREC.text_value,t0.text_032,null) as [Instrument Number for Recording Date] --Text  --'STRINSTRUMENTREC  '
    ,t0.strRecOR2 as [Secondary Instrument Number for Recording Date] --Text 
    ,coalesce(STRINSTRUMENTREL.text_value,STRINSTRUMENTREL.strRelOR1) as [Instrument Number for Release Date] --Text 
    
    
    ,t0.strRelOR2 as [Secondary Instrument Number for Release Date] --Text 
    ,t1.strCetLetter as [Tracking Number] --Text  --'strCetLetter      ',' USPS Tracking number'
    ,n0.dtPosting1 as [Date Posted at Property] --Date --'dtPosting1        '
    --,null as [Card Received] --Yes/No 
    --,null as [Reason Letter was not received] --Text Area 
    ,a.date_g as [Date Notice of Hearing Posted] --Date 
    --,null as [Change of Address] --CheckBox 
    ,g.date_entered as [Green Card Received] --Date 
    --,null as [Date Posted at Courthouse] --Date 
    
    ,t0.strHearingType as [Type of Hearing]
    
    ,null [Notice of Hearing Date Verified by Mail Date]
    ,null [Officer Phone Number]
    ,null [Code Record]
    ,null [Officer Assigned]
    ,null [Hearing Time]
    ,a.date_g [Notice of Hearing Date]
    ,null [Hearing Date Continued]
    ,null [Officer Email]
    ,null [Extension Order]
    ,null [Name of person that signed Affidavit]
    
    --HISTORICAL PERMITS PLUS FIELDS
    ,m0.MON_045
    ,m0.MON_046
    ,m0.MON_047
    ,m0.MON_048
    ,n0.DATE_084
    ,n0.DATE_085
    ,n0.DATE_099
    ,t0.TEXT_032
    ,t0.TEXT_040
    ,t0.TEXT_041 
    ,t1.TEXT_098
    ,n1.dtPostingPrep as DATE_101
    ,t0.YN_007
    ,case when t0.YN_051 = 'N' then null else 'CHECKED' end YN_051
    ,pb.LEGAL_DESC
    ,a.CALC_FEES
    ,a.ADDL_FEES
    ,aa.full_address PRIMARY_ADDR
    ,ap.name PRIMARY_NAME
    ,ai.APPROVED
    ,coalesce(user_id.user_name,a.user_id) [user_id]
    ,a.ENTERED_DATE as THE_DATE
    ,a.sub_type [SUB_TYPE]
    ,a.DATE_A [DATE_A]
    ,n0.date_077 [PIP hearing date]
into cf_Citizen_Board_Support
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
left join #green_card_date g on g.number_key = pmap.number_key
left join #m0 m0 on m0.number_key =   pmap.number_key
left join #n0 n0 on n0.number_key =   pmap.number_key
left join #n1 n1 on n1.number_key = pmap.number_key
left join #t0 t0 on t0.number_key =   pmap.number_key
left join #t1 t1 on t1.number_key =  pmap.number_key
left join #STRINSTRUMENTREC STRINSTRUMENTREC on STRINSTRUMENTREC.number_key = pmap.number_key
left join #STRINSTRUMENTREL STRINSTRUMENTREL on STRINSTRUMENTREL.number_key = pmap.number_key
left join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
left join #legal_descs pb on pb.permitnum = pmap.permitnum ---left join hcfl_src.dbo.par_base pb on pb.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
left join #primary_address aa on aa.permitnum = pmap.permitnum --left join hcfl_src.dbo.apd_adr aa on aa.number_key = pmap.number_key
left join #primary_name ap on ap.number_key = pmap.number_key --left join hcfl_src.dbo.apd_peo ap on ap.number_key = pmap.number_key
outer apply (select top 1 * from hcfl_src.dbo.APD_ITMS where number_key = pmap.number_key order by case when APPROVED = 'N' then 1 else 2 end) ai
left join jms_userid_username user_id on user_id.user_id = a.user_id
where
    1=1
    and pnum.tt_record in ('Citizen Board Support')
;

 
    --ensure_fields_arent_too_long
declare @table_name varchar(100) = 'cf_Citizen_Board_Support' 

declare @cutoff int = 50;
DECLARE long_colname_cursor CURSOR for (
	select 
		column_name
	from INFORMATION_SCHEMA.columns 
	where 
		table_name = @table_name
		and len(column_name) > @cutoff
);

declare @column_name_old varchar(200);
declare @modString varchar(200);
declare @newname varchar(200);


OPEN long_colname_cursor
FETCH NEXT FROM long_colname_cursor INTO @column_name_old
    WHILE @@FETCH_STATUS = 0  
		begin
			set @modString = 'dbo.' + @table_name + '.' + @column_name_old;
			set @newname = left(@column_name_old, @cutoff)
			EXEC sp_rename @modString, @newname, 'COLUMN';
			FETCH NEXT FROM long_colname_cursor   INTO @column_name_old
		end
CLOSE long_colname_cursor
DEALLOCATE long_colname_cursor
;
go
;




--Enforcement Complaint - ENF_COMPLAIN
;IF OBJECT_ID('tempdb.dbo.##completed', 'U') is not null insert into ##completed values (getdate(),'0140 0100 custom fields.sql -- complaint')
;print 'Complaint - ENF_COMPLAIN';

;IF OBJECT_ID('tempdb.dbo.#a', 'U') IS NOT NULL DROP TABLE #a
;SELECT
    a.number_key
    ,a.date_d
    ,a.sub_Type
into #a
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
where 
	pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive')
;--0sec
;IF OBJECT_ID('tempdb.dbo.#d', 'U') IS NOT NULL DROP TABLE #d
;SELECT
    d.number_key
    ,d.description
into #d
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_desc d on d.number_key = pmap.number_key
where 
	pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive')
;--4sec
;IF OBJECT_ID('tempdb.dbo.#n0', 'U') IS NOT NULL DROP TABLE #n0
;SELECT
    n0.number_key
    ,n0.num_013 days_to_comply    
    ,n0.num_025 numLastTimeToCompl
    ,n0.num_065 numADXSR  
    ,(case when n0.date_052 is not null then 'Yes' else 'No' end) as repeat_violator
    ,n0.Date_052 dtCEBOrder       
    ,n0.date_077 
into #n0
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_num0 n0 on n0.number_key = pmap.number_key
where 
	pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive')
	and coalesce(n0.num_013,n0.num_065) is not null
;--50sec
;IF OBJECT_ID('tempdb.dbo.#n1', 'U') IS NOT NULL DROP TABLE #n1
;SELECT
    n.number_key
    ,n.DATE_103
    ,n.DATE_109
    ,n.DATE_118
into #n1
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_num1 n on n.number_key = pmap.number_key
where 
	pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive')
;
;IF OBJECT_ID('tempdb.dbo.#t0', 'U') IS NOT NULL DROP TABLE #t0
;SELECT
     t.number_key
    ,t.text_002 txt_location                  
    ,t.text_006 txt_occupancy 
    ,t.YN_001 ynForeclosure
    ,t.Text_013 strCEBNoticeType
    ,t.TEXT_000
    ,t.TEXT_004
    ,t.TEXT_014
into #t0
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_txt0 t on t.number_key = pmap.number_key
where 
	pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive')
	and coalesce(t.text_002,t.text_006) is not null
;--9sec
;IF OBJECT_ID('tempdb.dbo.#t1', 'U') IS NOT NULL DROP TABLE #t1
;SELECT
     t.number_key
    ,t.text_059 ZONING       
    ,t.text_076 str_type    
    ,t.TEXT_077      
	
    ,t.TEXT_050
    ,t.TEXT_067
    ,t.TEXT_069
    ,t.TEXT_072
    ,t.TEXT_060
into #t1
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_txt1 t on t.number_key = pmap.number_key
where 
	pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive')
	and coalesce(t.text_059,t.text_076,t.TEXT_077,t.TEXT_050,t.TEXT_067,t.TEXT_069,t.TEXT_072,t.TEXT_060,null) is not null
;--0sec
;IF OBJECT_ID('tempdb.dbo.#m0', 'U') IS NOT NULL DROP TABLE #m0
;SELECT
     m.number_key
    ,m.MON_066
into #m0
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_mon0 m on m.number_key = pmap.number_key
where 
	pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive')
;--0sec
;IF OBJECT_ID('tempdb.dbo.#primary_name', 'U') IS NOT NULL DROP TABLE #primary_name
select
	pmap.number_key
	,a.NAME
into #primary_name
from AATABLE_PERMIT_HISTORY pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.APD_PEO a on a.number_key = pmap.number_key
where
	1=1
	and PRIMARY_NAME = 1
    and pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive')
;
;IF OBJECT_ID('tempdb.dbo.#approved', 'U') IS NOT NULL DROP TABLE #approved
;with g as (
	SELECT distinct
        pmap.number_key
		,a.APPROVED
		,a.THE_DATE
    from AATABLE_PERMIT_HISTORY pnum
	join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
	join hcfl_src.dbo.APD_ITMS a on a.number_key = pmap.number_key
	where
		1=1
		and a.APPROVED is not null
), CTE AS (
    SELECT distinct
        a.number_key
		,a.APPROVED
		,a.THE_DATE
        ,ROW_NUMBER() OVER (PARTITION BY a.number_key ORDER BY a.the_date desc) AS row_num
    from g a
)
SELECT 
    *
into #approved
FROM CTE
WHERE 
    1=1
	and row_num = 1
;

;IF OBJECT_ID('tempdb.dbo.#primary_address', 'U') IS NOT NULL DROP TABLE #primary_address
;WITH RankedResults AS (
  SELECT 
	permitnum
	,full_address
    ,ROW_NUMBER() OVER(PARTITION BY permitnum ORDER BY case when isprimary='Y' then 1 else 2 end) AS Rank
  FROM AATABLE_PERMIT_ADDRESS
)
SELECT 
	*
into #primary_address
FROM RankedResults
WHERE
	1=1
	and Rank = 1
;
;IF OBJECT_ID('tempdb.dbo.#legal_descs', 'U') IS NOT NULL DROP TABLE #legal_descs
;create table #legal_descs ( permitnum varchar(50), legal_desc varchar(max) )
;with cte_many as (
	select 
		pmap.permitnum + '' permitnum
		,count(LEGAL_DESC) ct
	from aatable_permit_history pnum
	join jms_numberKey_permitnum pmap on pmap.permitnum+'' = pnum.permitnum
	join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
	left join hcfl_src.dbo.par_base pb on pb.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
	where
		1=1
		and pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive')
	group by pmap.permitnum
	having count(LEGAL_DESC) > 1
), g as (
	select distinct
		pmap.permitnum + '' permitnum
		,pb.LEGAL_DESC
	from aatable_permit_history pnum
	join jms_numberKey_permitnum pmap on pmap.permitnum+'' = pnum.permitnum
	join cte_many f on f.permitnum =  pmap.permitnum+''
	join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
	left join hcfl_src.dbo.par_base pb on pb.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
	where
		1=1
		and pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive')
),h as (
	SELECT
		permitnum
		,trim('^| ' from 
			  STUFF(
				(SELECT ' ^|^ ' + LEGAL_DESC
				 FROM g AS innerTable
				 WHERE innerTable.permitnum = outerTable.permitnum
				 FOR XML PATH(''), TYPE
				).value('.', 'NVARCHAR(MAX)'), 1, 2, '') 
		) AS legal_desc
	FROM g AS outerTable
	where
		1=1
		--and permitnum = 'CE21009275'
	GROUP BY permitnum
)
insert into #legal_descs
select * from h
where
	1=1 
	and legal_desc is not null

union

select 
	pmap.permitnum + '' permitnum
	,trim(pb.LEGAL_DESC) legal_desc
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum+'' = pnum.permitnum
join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
left join hcfl_src.dbo.par_base pb on pb.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
where
	1=1
	and pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive')
	and not exists (
		select 1
		from h
		where permitnum =  pmap.permitnum+''
	)
	and legal_desc is not null
;
go

;IF OBJECT_ID('cf_Complaint', 'U') IS NOT NULL DROP TABLE cf_Complaint
;
select distinct
    pnum.permitNum
    ,pnum.tt_record
 
    --HISTORICAL PERMITS PLUS FIELDS
    ,aa.FULL_ADDRESS as PRIMARY_ADDR
    ,t1.TEXT_077
    ,NOTATION.notation
    ,PRIMARY_NAME.name as primary_name
    ,ai.APPROVED
    ,a.CALC_FEES
    ,a.ADDL_FEES
    ,t0.TEXT_000
    ,m0.MON_066
    ,t0.TEXT_004
    ,t0.TEXT_014
    ,n1.DATE_103
    ,n1.DATE_109
    ,n1.DATE_118
    ,t1.TEXT_050
    ,t1.TEXT_067
    ,t1.TEXT_069
    ,t1.TEXT_072
    ,pb.LEGAL_DESC
    ,t1.TEXT_060
    ,ai.THE_DATE
    ,a.date_k 
    
    ,null ADDRESS_4
    ,null DATE_L
    ,a.insp_area INSP_AREA
    ,null VIOLATIONS
    ,a.sub_type [SUB_TYPE]
    ,a.DATE_A [DATE_A]
    ,n0.date_077 [PIP hearing date]
    
    
    --COMPLAINT INFO
    ,pnum.Asgn_Staff [Assigned To] 
     --( case 
     --   when 1=1 then 'Donald Duck'
     --    when 1=1 then 'Mickey Mouse'
     --   end
     --) as [Assigned To] --Drop Down  req 
    ,( case 
         when d.description like '%abandon%sign%' then 'Abandoned Sign'
         when a.sub_type = 'FTBC    ' or (d.description like '%blight%' and d.description like '%commerc%prop%') then 'Blighted Commercial Property'
         when d.description like '%commercial%vehicle%' then 'Commercial Vehicle Complaint'
         when d.description like '%construct%permit%' and (d.description like '% no %' or d.description like '%without%') then 'Construction without a Permit'
         when d.description like '%contractor%complain%' then 'Contractor Complaint'
         when 1=1 then 'Digital Billboard Permit/Inspection'
         when d.description like '%educat%outrea%' then 'Educational Outreach'
         when d.description like '%fenc%violat%' then 'Fence Violations'
         when a.sub_type = 'GRAFFITI' then 'Graffiti Complaint'
         when d.description like '%hazard%' and d.description like '%tree%' then 'Hazard Tree'
         when d.description like '%homeless%encamp%' then 'Homeless Encampment'
         when a.sub_type = 'ILDUMP  ' then 'Illegal Dumping of Trash or Debris'
         when 1=0 then 'Illegal Fill Complaint'
         when 1=0 then 'Illicit Discharge Violation'
         when d.description like '%inop%vehicl%' then 'Inoperable Vehicle'
         when 1=0 then 'New Regulatory Sign Enforcement'
         when d.description like '%noise%ordinance%' then 'Noise Ordinance Violation'
         when d.description like '%obstructed%roadway%' then 'Obstructed Roadway'
         when 1=0 then 'Operating without a B.T.R.'
         when d.description like '%overgrown%condition%' then 'Overgrown Conditions'
         when d.description like '%permitted use viol%' then 'Permitted Use Violation'
         when 1=0 then 'Request for Demolition'
         when d.description like '%sign%ordinance%viol%' then 'Sign Ordinance Violation'
         when d.description like '%sign permit%' then 'Sign Permit'
         when d.description like '%signs%' then 'Signs - Misc. Complaints'
         when 1=0 then 'Site Development Violation'
         when 1=0 then 'Stinging Insects'
         when d.description like '%street numbers%' then 'Street Numbers Complaint'
         when d.description like '%towing%' then 'Towing'
         when d.description like '%trash%' then 'Trash and Junk'
         when 1=0 then 'Tree Permit'
         when d.description like '%tree%removal%' and (d.description like '%no%permit%' or d.description like '%without%permit%') then 'Tree Removal without Permit'
         when d.description like '%unlicensed%contractor%' then 'Unlicensed Contractors'
         when d.description like '%unmaint%pool%' then 'Unmaintained Swimming Pool'
         when d.description like '%unpermitted%' then 'Unpermitted Work'
         when d.description like '%Unsecured%applian%' then 'Unsecured Appliances'
         when d.description like '%Unsecured%pool%' then 'Unsecured Pool'
         when 1=0 then 'Violation of Foreclosure Registry'
         when d.description like '%watering%' then 'Watering Complaint'
         when d.description like '%waterway%' then 'Waterway Issues'
         
         when d.description like '%misc%viol%' then 'Miscellaneous Code Violations'
         when d.description like '%minimum%standards%' then 'Minimum Standards'
         when d.description like '%boat%' or d.description like '%rv%' or d.description like '%trailer%' then 'Boats, Trailers and RV''s'
         when 0=1 then 'Clear Sight Triangle Violation'
        
         else 'Other'
         
        end
     ) as [General Type of Complaint] --Drop Down  req 240
    ,null as [Description of Legal Code] --Text Area 
    ,null as [Res or Non Res]
    --,( case 
    --     when 1=0 then 'Citizen'
    --     when 1=0 then 'Government Official'
    --     when 1=0 then 'Law Enforcement Office'
    --     when 1=0 then 'Staff'
    --    else null
    --    end
    -- ) as [Source] --Drop Down 
    --,( case 
    --    when 1=0 then 'Email'
    --     when 1=0 then 'FAX'
    --     when 1=0 then 'In Person'
    --     when 1=0 then 'Online'
    --     when 1=0 then 'Phone'
    --     when 1=0 then 'Postal Mail'
    --     when 1=0 then 'Unknown'
    --    else null
    --    end
    -- ) as [Type of Submittal] --Drop Down 
    ,t0.ynForeclosure as [Lis pendence] --Yes/No 
    --,null as [Add Comments] --Text Area 240
    --,null as [Is this a Home Owner Associate complaint?] --Yes/No 
    --,null as [If yes, is the letter attached?] --Yes/No 
    --,null as [Officer''s Comments] --Text Area 
    --,null as [Create Violator from Owner] --CheckBox 
    --,null as [Court Case Number] --Text 
    ,n0.repeat_violator as [Repeat Violator(complaint info)] --Yes/No 
    --,null as [Compliant] --Yes/No 
 
    --DATA FIELDS
    ,n0.numADXSR as [ADX Number] --Text  --'numADXSR          ',' ADX SR Number'
    ,(case t1.str_type
        when 'BLK' then 'Block'
        when 'FR'  then 'Frame'
        when 'MH'  then 'Mobile Home'
        else t1.str_type
        end
    ) as [structure type]
    ,t0.txt_occupancy as [Occupancy] --Text --'txt_occupancy     ','occupancy from table'
    ,t1.ZONING as [Zoning] --Text --'ZONING            ','ZONE DISTRICT'
    ,null as [Code Inspection Area]
    ,n0.days_to_comply as [Days for Initial Compliance] --Number    --'days_to_comply    ',' transferred from qty_reinsp_days'
    ,n0.dtCEBOrder as [Order date for repeat violator] --Date 
    ,a.location [Description of Location] --t0.txt_location as [Description of Location] --Text Area --'txt_location      ','from location table'
    ,null [Type of Submittal(DATA FIELDS)]
    ,t0.ynForeclosure as [Lis pendens] --Yes/No 
    ,n0.repeat_violator as [Repeat Violator(data fields)] --Yes/No 
    ,null as [Occupancy Type]
    --,null as [Days for Pre-Hearing Inspection] --Number 
    ,a.date_d as [Hearing Date] --Date 
    ,null as [Method of Service]
    ,null as [Notice Date]
    ,null as [Date of Affidavit]
    --,null as [Hearing] 
 
    --SWEEP INFO
    --,'Yes' as [Is this complaint related to a sweep operation?] --Yes/No  req 
    --,( case 
    --    when 1=0 then '1'
    --     when 1=0 then '2'
    --     when 1=0 then '3'
    --     when 1=0 then '4'
    --    else null
    --    end
    -- ) as [Sweep Number] --Drop Down 
    --,null as [Date of Sweep] --Date 
    --,null as [Location of Sweep Operation] --Text Area 
    
    
into cf_Complaint
from AATABLE_PERMIT_HISTORY pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
left join #n0 n0 on n0.number_key = a.number_key
left join #t0 t0 on t0.number_key = a.number_key
left join #t1 t1 on t1.number_key = a.number_key
left join #d d on d.number_key = a.number_key
left join #m0 m0 on m0.NUMBER_KEY = a.NUMBER_KEY
left join #n1 n1 on n1.NUMBER_KEY = a.NUMBER_KEY

left join #legal_descs pb on pb.permitnum = pmap.permitnum --left join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key      left join hcfl_src.dbo.par_base pb on pb.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
left join #primary_address aa on aa.permitnum = pmap.permitnum --left join (select * from aatable_permit_address where isprimary = 'Y') aa on aa.permitnum = pmap.permitnum --left join hcfl_src.dbo.apd_adr aa on aa.number_key = pmap.number_key
--left join hcfl_src.dbo.apd_peo ap on ap.number_key = pmap.number_key
left join hcfl_src.dbo.tab_cond notation on notation.element_key = pmap.number_key
left join #primary_name primary_name on primary_name.number_key = pmap.number_key
left join #approved ai on ai.number_key = pmap.number_key
where
    1=1
    and pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive')
;

 
    --ensure_fields_arent_too_long
declare @table_name varchar(100) = 'cf_Complaint' 

declare @cutoff int = 50;
DECLARE long_colname_cursor CURSOR for (
	select 
		column_name
	from INFORMATION_SCHEMA.columns 
	where 
		table_name = @table_name
		and len(column_name) > @cutoff
);

declare @column_name_old varchar(200);
declare @modString varchar(200);
declare @newname varchar(200);


OPEN long_colname_cursor
FETCH NEXT FROM long_colname_cursor INTO @column_name_old
    WHILE @@FETCH_STATUS = 0  
		begin
			set @modString = 'dbo.' + @table_name + '.' + @column_name_old;
			set @newname = left(@column_name_old, @cutoff)
			EXEC sp_rename @modString, @newname, 'COLUMN';
			FETCH NEXT FROM long_colname_cursor   INTO @column_name_old
		end
CLOSE long_colname_cursor
DEALLOCATE long_colname_cursor
;
go
;

--LOCKSMITH THINGS
;IF OBJECT_ID('tempdb.dbo.#t0', 'U') IS NOT NULL DROP TABLE #t0
;SELECT
     pmap.number_key
    ,case when t0.YN_038 = 'Y' then 'CHECKED' else NULL end ckBusinessTax      -- Business Tax Receipt
    ,case when t0.YN_037 = 'Y' then 'CHECKED' else NULL end ckLiabilityInsur -- Copy of Liability Insurance
    ,case when t0.YN_006 = 'Y' then 'CHECKED' else NULL end salesTaxCertificate
    ,case when t0.YN_015 = 'Y' then 'CHECKED' else NULL end leaseAgreement
into #t0
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_txt0 t0 on t0.number_key = pmap.number_key
where 
	pnum.tt_record in (
        'Locksmith Initial Application'
        ,'Locksmith License'
        ,'Locksmith Renewal'
    )
	and coalesce(t0.YN_006,t0.YN_015,t0.YN_037,t0.YN_038,null) is not null
;
;IF OBJECT_ID('tempdb.dbo.#t1', 'U') IS NOT NULL DROP TABLE #t1
;SELECT
     pmap.number_key
    ,t1.text_093 S8_CE
into #t1
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_txt1 t1 on t1.number_key = pmap.number_key
where 
	pnum.tt_record in (
        'Locksmith Initial Application'
        ,'Locksmith License'
        ,'Locksmith Renewal'
    )
	and coalesce(t1.text_093,null) is not null
;--0sec
;IF OBJECT_ID('tempdb.dbo.#n1', 'U') IS NOT NULL DROP TABLE #n1
;SELECT
     pmap.number_key
    ,n1.DATE_121 Received
    ,n1.date_122 Issued
    ,n1.date_123 Expires
into #n1
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_num1 n1 on n1.number_key = pmap.number_key
where 
	pnum.tt_record in (
        'Locksmith Initial Application'
        ,'Locksmith License'
        ,'Locksmith Renewal'
    )
	and coalesce(n1.DATE_121,n1.date_122,n1.date_123,null) is not null
;--0sec
;IF OBJECT_ID('tempdb.dbo.#m0', 'U') IS NOT NULL DROP TABLE #m0
;SELECT
     pmap.number_key
    ,m0.MON_019 Application_Amount 
into #m0
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_mon0 m0 on m0.number_key = pmap.number_key
where 
	pnum.tt_record in (
        'Locksmith Initial Application'
        ,'Locksmith License'
        ,'Locksmith Renewal'
    )
	and coalesce(m0.MON_019,null) is not null
;--0sec
;IF OBJECT_ID('tempdb.dbo.#n0', 'U') IS NOT NULL DROP TABLE #n0
;SELECT
     pmap.number_key
    ,n0.DATE_005 Date_paid
    ,n0.date_054 dtLastVisitNot
into #n0
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_num0 n0 on n0.number_key = pmap.number_key
where 
	pnum.tt_record in (
        'Locksmith Initial Application'
        ,'Locksmith License'
        ,'Locksmith Renewal'
    )
	and coalesce(n0.DATE_005,n0.date_054,null) is not null
;--0sec

go

    --Locksmith Initial Application - ENF_LOCK
print 'Locksmith Initial Application - ENF_LOCK';
IF OBJECT_ID('cf_Locksmith_Initial_Application', 'U') IS NOT NULL DROP TABLE cf_Locksmith_Initial_Application
;
select distinct
    pnum.permitNum
    ,pnum.tt_record
 
    --LICENSE INFORMATION
    ,t1.S8_CE as [License number] --Text 
    
    ----APPLICATION
    --,( case 
    --     when 1=0 then '1-5 employees'
    --     when 1=0 then '11 or more employees'
    --     when 1=0 then '6-10 employees'
    --    end
    -- ) as [Number of employees] --Drop Down  req 
    --,( case 
    --    when  1=0 then 'Mobile'
    --     when 1=0 then 'Site & Mobile'
    --    end
    -- ) as [Category] --Drop Down  req 
 
    --HISTORICAL FIELDS
    ,n1.Received as [received]
    ,n1.issued [Issued]
    ,n1.Expires [Expires]
    ,m0.Application_Amount [Application_Amount]
    ,n0.Date_paid [Date_paid]
    ,a.sub_type [SUB_TYPE]
    
    
    ,a.location as [LOCATION]
    ,null as [Follow Up]
    ,n0.dtLastVisitNot as [Last Visit]
    ,t0.ckBusinessTax as [Business Tax Receipt]
    ,t0.salesTaxCertificate as [Sales Tax Receipt]
    ,t0.ckLiabilityInsur   as [Liability Insurance]
    ,t0.leaseAgreement as [Lease Agreement]
into cf_Locksmith_Initial_Application
from AATABLE_PERMIT_HISTORY pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
left join #t0 t0 on t0.number_key = pmap.number_key
left join #t1 t1 on t1.number_key = pmap.number_key
left join #n0 n0 on n0.number_key = pmap.number_key
left join #n1 n1 on n1.number_key = pmap.number_key
left join #m0 m0 on m0.number_key = pmap.number_key
where
    1=1
    and pnum.tt_record = 'Locksmith Initial Application'
;
 
    --ensure_fields_arent_too_long
declare @table_name varchar(100) = 'cf_Locksmith_Initial_Application' 

declare @cutoff int = 50;
DECLARE long_colname_cursor CURSOR for (
	select 
		column_name
	from INFORMATION_SCHEMA.columns 
	where 
		table_name = @table_name
		and len(column_name) > @cutoff
);

declare @column_name_old varchar(200);
declare @modString varchar(200);
declare @newname varchar(200);


OPEN long_colname_cursor
FETCH NEXT FROM long_colname_cursor INTO @column_name_old
    WHILE @@FETCH_STATUS = 0  
		begin
			set @modString = 'dbo.' + @table_name + '.' + @column_name_old;
			set @newname = left(@column_name_old, @cutoff)
			EXEC sp_rename @modString, @newname, 'COLUMN';
			FETCH NEXT FROM long_colname_cursor   INTO @column_name_old
		end
CLOSE long_colname_cursor
DEALLOCATE long_colname_cursor
;
go
;
    --Locksmith License - ENF_LOCK
print 'Locksmith License - ENF_LOCK';
IF OBJECT_ID('cf_Locksmith_License', 'U') IS NOT NULL DROP TABLE cf_Locksmith_License
;
select distinct
    pnum.permitNum
    ,pnum.tt_record
 
    --LICENSE INFORMATION
    ,t1.S8_CE as [License number] --Text 
    
    ----APPLICATION
    --,( case 
    --     when 1=0 then '1-5 employees'
    --     when 1=0 then '11 or more employees'
    --     when 1=0 then '6-10 employees'
    --    end
    -- ) as [Number of employees] --Drop Down  req 
    --,( case 
    --     when 1=0 then 'Mobile'
    --     when 1=0 then 'Site &amp; Mobile'
    --    end
    -- ) as [Category] --Drop Down  req 
 
    --HISTORICAL FIELDS
    ,n1.Received as [received]
    ,n1.issued [Issued]
    ,n1.Expires [Expires]
    ,m0.Application_Amount [Application_Amount]
    ,n0.Date_paid [Date_paid]
    ,a.sub_type [SUB_TYPE]
    
    ,a.location as [LOCATION]
    ,null as [Follow Up]
    ,n0.dtLastVisitNot as [Last Visit]
    ,t0.ckBusinessTax as [Business Tax Receipt]
    ,null as [Sales Tax Receipt]
    ,t0.ckLiabilityInsur   as [Liability Insurance]
    ,null as [Lease Agreement]
into cf_Locksmith_License
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
left join #t0 t0 on t0.number_key = pmap.number_key
left join #t1 t1 on t1.number_key = pmap.number_key
left join #n0 n0 on n0.number_key = pmap.number_key
left join #n1 n1 on n1.number_key = pmap.number_key
left join #m0 m0 on m0.number_key = pmap.number_key
where
    1=1
    and pnum.tt_record = 'Locksmith License'
;
 
    --ensure_fields_arent_too_long
declare @table_name varchar(100) = 'cf_Locksmith_License' 

declare @cutoff int = 50;
DECLARE long_colname_cursor CURSOR for (
	select 
		column_name
	from INFORMATION_SCHEMA.columns 
	where 
		table_name = @table_name
		and len(column_name) > @cutoff
);

declare @column_name_old varchar(200);
declare @modString varchar(200);
declare @newname varchar(200);


OPEN long_colname_cursor
FETCH NEXT FROM long_colname_cursor INTO @column_name_old
    WHILE @@FETCH_STATUS = 0  
		begin
			set @modString = 'dbo.' + @table_name + '.' + @column_name_old;
			set @newname = left(@column_name_old, @cutoff)
			EXEC sp_rename @modString, @newname, 'COLUMN';
			FETCH NEXT FROM long_colname_cursor   INTO @column_name_old
		end
CLOSE long_colname_cursor
DEALLOCATE long_colname_cursor
;
go
;
    --Locksmith Renewal - ENF_LOCK
print 'Locksmith Renewal - ENF_LOCK';
IF OBJECT_ID('cf_Locksmith_Renewal', 'U') IS NOT NULL DROP TABLE cf_Locksmith_Renewal
;
select distinct
    pnum.permitNum
    ,pnum.tt_record
    
    --LICENSE INFORMATION
    ,t1.S8_CE as [License number] --Text 
 
    ----APPLICATION
    --,( case 
    --     when 1=0 then '1-5 employees'
    --     when 1=0 then '11 or more employees'
    --     when 1=0 then '6-10 employees'
    --    end
    -- ) as [Number of employees] --Drop Down  req 
    --,( case 
    --     when 1=0 then 'Mobile'
    --     when 1=0 then 'Site &amp; Mobile'
    --    end
    -- ) as [Category] --Drop Down  req   

    --HISTORICAL FIELDS
    ,n1.Received as [received]
    ,n1.issued [Issued]
    ,n1.Expires [Expires]
    ,m0.Application_Amount [Application_Amount]
    ,n0.Date_paid [Date_paid]
    ,a.sub_type [SUB_TYPE]
    
    ,a.location as [LOCATION]
    ,null as [Follow Up]
    ,n0.dtLastVisitNot as [Last Visit]
    ,t0.ckBusinessTax as [Business Tax Receipt]
    ,null as [Sales Tax Receipt]
    ,t0.ckLiabilityInsur   as [Liability Insurance]
    ,null as [Lease Agreement]
into cf_Locksmith_Renewal
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
left join #t0 t0 on t0.number_key = pmap.number_key
left join #t1 t1 on t1.number_key = pmap.number_key
left join #n0 n0 on n0.number_key = pmap.number_key
left join #n1 n1 on n1.number_key = pmap.number_key
left join #m0 m0 on m0.number_key = pmap.number_key
where
    1=1
    and pnum.tt_record = 'Locksmith Renewal'
;
 
    --ensure_fields_arent_too_long
declare @table_name varchar(100) = 'cf_Locksmith_Renewal' 

declare @cutoff int = 50;
DECLARE long_colname_cursor CURSOR for (
	select 
		column_name
	from INFORMATION_SCHEMA.columns 
	where 
		table_name = @table_name
		and len(column_name) > @cutoff
);

declare @column_name_old varchar(200);
declare @modString varchar(200);
declare @newname varchar(200);


OPEN long_colname_cursor
FETCH NEXT FROM long_colname_cursor INTO @column_name_old
    WHILE @@FETCH_STATUS = 0  
		begin
			set @modString = 'dbo.' + @table_name + '.' + @column_name_old;
			set @newname = left(@column_name_old, @cutoff)
			EXEC sp_rename @modString, @newname, 'COLUMN';
			FETCH NEXT FROM long_colname_cursor   INTO @column_name_old
		end
CLOSE long_colname_cursor
DEALLOCATE long_colname_cursor
;
go
;

/*
--Violation - PMT_VIO
;IF OBJECT_ID('tempdb.dbo.##completed', 'U') is not null insert into ##completed values (getdate(),'0140 0100 custom fields.sql -- violation')
;print 'Violation - PMT_VIO';

;IF OBJECT_ID('tempdb.dbo.#a', 'U') IS NOT NULL DROP TABLE #a
;SELECT
    a.number_key
    ,a.date_d
into #a
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
where 
	pnum.tt_record = 'Violation'
    and a.date_d is not null
;--0sec
;IF OBJECT_ID('tempdb.dbo.#n0', 'U') IS NOT NULL DROP TABLE #n0
;SELECT
     n.number_key
    ,n.date_010
    ,n.date_028
    ,n.date_031
    ,n.date_094
    ,n.date_096
into #n0
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_num0 n on n.number_key = pmap.number_key
where 
	pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive')
	and coalesce(n.date_010,n.date_028,n.date_031,n.date_094,n.date_096) is not null
;--50s
;IF OBJECT_ID('tempdb.dbo.#t1', 'U') IS NOT NULL DROP TABLE #t1
;SELECT
     t1.number_key
    ,t1.text_054
    ,t1.text_062
into #t1
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
join hcfl_src.dbo.apd_txt1 t1 on t1.number_key = pmap.number_key
where 
	pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive')
	and coalesce(t1.text_054,t1.text_062) is not null
;--0sec
go




;IF OBJECT_ID('cf_Violation', 'U') IS NOT NULL DROP TABLE cf_Violation
;
select distinct
     pnum.permitNum
    ,pnum.tt_record
 
    --VIOLATION INFORMATION - PCCB
    --,null as [Structure Type]
    --,null as [Warning Notice Date]
    --,null as [Warning Notice Time]
    --,null as [Follow Up Date]
    --,null as [Inspector Number]
    --,null as [Inspector]
    --,null as [Inspector Number 2]
    --,null as [Inspector 2]

    ----GIS INFORMATION
    --,null as [Taxing Authority] --Text 
    --,null as [FEMA] --Text 
    --,null as [Actual Year Built] --Text 
    --,null as [Wind Speed] --Text 
    --,null as [Depreciated Value 50%] --Text 
    --,null as [Easements] --Text 
    --,null as [Transportation Analysis Zone] --Text 
    --,null as [Wetlands] --Text 
    --,null as [Zoning District] --Text 
    --,null as [Appraised Value] --Text 
    --,null as [Base Flood Elevation] --Text 
    --,null as [Depreciated Value] --Text 
    --,null as [Future Land Use District] --Text 
    --,null as [Lot Size] --Text 
    --,null as [Navigable Bodies of Water] --Text 
    --,null as [Special Flood Hazard Areas] --Text 

    --BOARD ACTION INFORMATION
    ,n0.Date_028 as [Notice Date] --Date --'date_first_notice '
    ,n0.Date_031 as [NOV Certified Mail Address] --Text --'dtCertSent        ',' DateCertified Letter Sent to Violator'
    --,null as [NOV Certified Mail Registered Agent] --Text
    ,n0.Date_010 as [NOV Received Date] --Date  --'date_cert_1       ','certifide letter received 1'
    --,( case 
    --     when 1=0 then 'CCEB'
    --     when 1=0 then 'CLB'
    --     when 1=0 then 'PCCB'
    --    else null
    --    end
    -- ) as [Board] --Drop Down 
    ,a.date_d as [Hearing Date] --Date 
 
    --,null as [Primary Violation] --Text 
    --,null as [Date of Service] --Date 
    --,null as [Date of Alternate Service First Class] --Date 
    --,( case 
    --     when 1=0 then 'Debbie Russo'
    --     when 1=0 then 'Gary Smith'
    --     when 1=0 then 'Holly Fritts'
    --     when 1=0 then 'Jesse Stuiso'
    --     when 1=0 then 'Philip Dufour'
    --     when 1=0 then 'Shon Kriel'
    --    else null
    --    end
    -- ) as [Alternate Service First Class Employee] --Drop Down 
    --,null as [Date of Alternate Service Posting GVT] --Date 
    --,( case 
    --    when 1=0 then 'Debbie Russo'
    --     when 1=0 then 'Gary Smith'
    --     when 1=0 then 'Holly Fritts'
    --     when 1=0 then 'Jesse Stuiso'
    --     when 1=0 then 'Philip Dufour'
    --     when 1=0 then 'Shon Kriel'
    --    else null
    --    end
    -- ) as [Alternate Service Posting GVT Employee] --Drop Down 
    --,null as [Date of Alternate Service Posting at site] --Date 
    --,( case 
    --    when 1=0 then 'Debbie Russo'
    --     when 1=0 then 'Gary Smith'
    --     when 1=0 then 'Holly Fritts'
    --     when 1=0 then 'Jesse Stuiso'
    --     when 1=0 then 'Philip Dufour'
    --     when 1=0 then 'Shon Kriel'
    --    else null
    --    end
    -- ) as [Alternate Service Posting at Site Employee] --Drop Down 
 
    ----BOARD ONLY FIELDS PCCB
    --,null as [Present] --Yes/No 
    --,null as [Found in Violation] --Yes/No 
    --,null as [Days for Compliance] --Number 
    --,null as [Finding of Facts] --Text Area 
    --,null as [Conclusion of Law] --Text Area 
    --,null as [Penalty Date] --Date 
    --,null as [Per Day] --Yes/No 
    --,null as [Fine] -- 
    --,null as [BO Certified Mail Address of Record] --Text 
    --,null as [BO Certified Mail Registered Agent] --Text 
    --,null as [BO Certified Mail Return Date] --Date 
    --,null as [BO Certified Mail Registered Date] --Date 
    --,null as [Amount to Date] -- 
    --,null as [Affidavit of Comp] --Date 
    --,null as [Affidavit of Non Comp] --Date 
    --,null as [Lien Date] --Date 
    --,null as [Lien Amount] -- 
    ,t1.Text_054 as [Book] --Text --'strPPOBook        ',' Book for recording PPO lien'
    ,t1.Text_062 as [Page] --Text --'strPPOPage        ',' Page for PPO lien recording'
    ,n0.Date_094 as [Lien Recorded Date] --Text --'dtLienRec1        '
    --,null as [Lien Mailed Date] --Date 
    ,n0.Date_096 as [Lien Release Date] --Date --'dtLienRel1        '
    --,null as [Lien Release Book] --Text 
    --,null as [Lien Release Page] --Text 
    --,null as [BOCC Board Reduction Date] --Date 
    --,null as [BOCC Override Amount] -- 
    --,null as [Override Due] --Date 
    --,null as [Payments] --Yes/No 
    --,null as [Payment Desc] --Text Area 
    --,null as [PCCB Ordered Fine] -- 
    --,null as [PCCB Ordered Payment] --Text 
 

 
    ----VIOLATION INFORMATION - PCCB
    --,'1900-01-01' as [Warning Notice Date] --Date  req 
    --,null as [Warning Notice Time] -- 
    --,null as [Follow Up Date] --Date 
    --,null as [Inspector Number] --Text 
    --,null as [Inspector] --Text 
    --,null as [Inspector Number 2] --Text 
    --,null as [Inspector 2] --Text 
into cf_Violation
from AATABLE_PERMIT_HISTORY pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
left join #n0 n0 on n0.number_key =  pmap.number_key
left join #t1 t1 on t1.number_key = pmap.number_key
where
    1=1
    and pnum.tt_record in ('Violation')
;
 
    --ensure_fields_arent_too_long
declare @table_name varchar(100) = 'cf_Violation' 

declare @cutoff int = 50;
DECLARE long_colname_cursor CURSOR for (
	select 
		column_name
	from INFORMATION_SCHEMA.columns 
	where 
		table_name = @table_name
		and len(column_name) > @cutoff
);

declare @column_name_old varchar(200);
declare @modString varchar(200);
declare @newname varchar(200);


OPEN long_colname_cursor
FETCH NEXT FROM long_colname_cursor INTO @column_name_old
    WHILE @@FETCH_STATUS = 0  
		begin
			set @modString = 'dbo.' + @table_name + '.' + @column_name_old;
			set @newname = left(@column_name_old, @cutoff)
			EXEC sp_rename @modString, @newname, 'COLUMN';
			FETCH NEXT FROM long_colname_cursor   INTO @column_name_old
		end
CLOSE long_colname_cursor
DEALLOCATE long_colname_cursor
;
go
;
*/


go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0180 0100 0050 custom lists deceased animals.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0180 0100 0050 custom lists deceased animals.sql')
--deceased animals
;IF OBJECT_ID('hcfl_prod.dbo.cl_deceased_animal_type', 'U') IS NOT NULL drop table cl_deceased_animal_type
;
with g as (
select distinct
	pnum.permitnum
	,pnum.tt_record
	,case	
		when t0.YN_019 = 'Y' then 'Dog'
		when t0.yn_020 = 'Y' then 'Cat'
		when t0.yn_021 = 'Y' then 'Other'
		when t0.yn_022 = 'Y' then 'Other'
		else null
		end
		as animal_type    
--into cl_deceased_animal_type
from hcfl_Src.dbo.apd_txt0 t0
join hcfl_prod..jms_apd_base_filtered f on f.NUMBER_KEY = t0.NUMBER_KEY
join hcfl_prod..jms_numberKey_permitnum pmap on pmap.number_key = f.NUMBER_KEY
join hcfl_prod..aatable_permit_history pnum on pnum.permitnum = pmap.permitnum
where
	1=1
	--and YN_023 is not null
	and case	
		when t0.YN_019 = 'Y' then 'Dog'
		when t0.yn_020 = 'Y' then 'Cat'
		when t0.yn_021 = 'Y' then 'Other'
		when t0.yn_022 = 'Y' then 'Other'
		else null
		end is not null
)
select
	*
	,ROW_NUMBER() OVER(PARTITION BY pnum.permitnum order by pnum.permitnum) AS row_num
into cl_deceased_animal_type
from g pnum
;


/*
--debris removal
;IF OBJECT_ID('hcfl_prod.dbo.cl_debris_removal', 'U') IS NOT NULL drop table cl_debris_removal
;
select 
	pnum.permitnum
	,pnum.tt_record
	
    ,t0.Num_048 numTires          
    
into cl_deceased_animal_type
from hcfl_Src.dbo.apd_txt0 t0
join hcfl_prod..jms_apd_base_filtered f on f.NUMBER_KEY = t0.NUMBER_KEY
join hcfl_prod..jms_numberKey_permitnum pmap on pmap.number_key = f.NUMBER_KEY
join hcfl_prod..aatable_permit_history pnum on pnum.permitnum = pmap.permitnum
where
	1=1
;
*/

go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0180 0100 0100 custom lists complaints and cbs_complaints.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0180 0100 0100 custom lists complaints and cbs_complaints.sql')
/* I intended for this to be guidesheets
but conversation yields that most of the violations , based on how accela is configured, are not guidesheet items, rather they seem to belong to comments on an inspection.
Logic copied from elsewhere; calls given site visit a parent inspection, and subsequent rows (comments, other) its children.
For the violations: associates violations with their rows on apd_insp, then to the parent inspection.
Requires post-conversion logic to ensure line breaks occur.
*/
--determine child rows per inspection, then assert inspection type and inspection result based on those children
;IF OBJECT_ID('tempdb.dbo.#parents', 'U') IS NOT NULL drop table #parents
;IF OBJECT_ID('tempdb.dbo.#is_initial_site_visit', 'U') IS NOT NULL drop table #is_initial_site_visit
;IF OBJECT_ID('tempdb.dbo.#g', 'U') IS NOT NULL drop table #g
;IF OBJECT_ID('tempdb.dbo.#orphaned', 'U') IS NOT NULL drop table #orphaned
;IF OBJECT_ID('tempdb.dbo.#h', 'U') IS NOT NULL drop table #h
;IF OBJECT_ID('tempdb.dbo.#req_opt', 'U') IS NOT NULL drop table #req_opt
;
go

--;with parents
    --assumes inspections are site visits, and results are implied by the subsequent rows prior to the following site visit.
    select
        number_key
        ,unique_key
        ,date_ent
        ,the_Date
        ,action_ent
    into #parents
    from jms_apd_insp_filteredToPop
    where action_ent in ('SV','SSV','QCSV','LSV')
    --and number_key = 'CE18015425'
;
--), is_initial_site_visit as (
    --"initial site visiit" is an accela inspection type
    select
        b.UNIQUE_KEY
        ,b.action_ent
    into #is_initial_site_visit
    from jms_apd_base_filtered a
    outer apply (select top 1 * from jms_apd_insp_filteredToPop where NUMBER_KEY = a.NUMBER_KEY and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent,the_date) b
;
--),g as (
    select
        a.number_key
        ,a.item_id
        ,a.unique_key
        ,a.action_ent
        ,action_ent.DESCRIPTION action_ent_desc
        ,case when is_initial_site_visit.UNIQUE_KEY is not null then 1 else 0 end as is_initial_site_visit
        ,'xxxx' [ ]
        ,coalesce(b.unique_key,is_initial_site_visit.unique_key) parent_unique_key
        ,b.action_ent parent_action_ent
        ,(case 
            when is_initial_site_visit.UNIQUE_KEY is not null then 'Initial Site Visit'
            when a.ACTION_ENT in ('QCSV','LSV') then 'Quality Control Inspection'
            when  a.any_comments like '%re%inspect%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%re%check%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%annual%insp%'    then 'Annual Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%post%hearing%'    then 'Post-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%pre%hearing%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%hear%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%follow%up%'    then 'Follow-up Inspection' --I don't know about pre vs post hearing
            else 'Inspection'
            end        
        ) as inspection_type
        ,(case 
            --when a.ACTION_ENT in ('SV','SSV','QCSV','LSV') then null
            when a.ACTION_ENT = 'NOVR' then 'Notice of Violation Requested'
            when a.ACTION_ENT = 'NOVC' then 'NOV issued'
            when a.ACTION_ENT = 'NOVB' then 'Combo Issued'
            when a.action_ent = 'ECIT' then 'Citation Issued'
            when a.ACTION_ENT = 'COMP' then 'Compliant'
            when a.ACTION_ENT = 'VIOL' then 'Violation'
            when A.ACTION_ENT in ('CA','CNCL') then 'No Violation'
            when a.any_comments like '%dead%animal%'      then 'Extension'
            when a.any_comments like '%exten%'      then 'Extension'
            when a.any_comments like '%violation%'  then 'Violation'
            when a.any_comments like '%non%compli%' then 'Not Compliant'
            when a.any_comments like '%send%nov%'   then 'NOV Issued'
            when a.any_comments like '%req%nov%'    then 'Notice of Violation Requested'
            when a.any_comments like '%cont%fin%'    then 'Not Compliant' --continue fines
            else null
            end
        ) as inspection_result
        
        ,'xxxx' [2]
        ,a.date_ent
        ,a.the_date
        ,'xxxx'[3]
        ,a.any_comments
    into #g
    from jms_apd_insp_filteredToPop a
    outer apply (select top 1 * from #parents where number_key = a.number_key and the_date <= a.the_date and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent desc,the_date desc) b
    left join jms_actionEnt_passFail action_ent on action_ent.action_ent = a.action_ent
    left join #is_initial_site_visit is_initial_site_visit on is_initial_site_visit.UNIQUE_KEY = a.UNIQUE_KEY
    where
        1=1
        --and a.action_ent not in ('SV','SSV','QCSV','LSV')
        --and a.number_key = 
        --    --'CE03003081'
        --    --'CE22014264'
        --    'CE22014971'
    --order by --a.date_ent,a.the_Date,case when a.action_ent in ('SV','SSV','QCSV','LSV') then 1 else 2 end, l.THE_TEXT
    --    a.UNIQUE_KEY
;




--), h as (
    select distinct
         a1.NUMBER_KEY
        ,a1.UNIQUE_KEY
        ,a1.action_ent
        ,a1.inspection_type
        ,coalesce(b.inspection_result,a1.inspection_result,'Not Set') inspection_result
        ,trim('^|' from stuff((
            select 
                '^|^' + cast(
                    trim(replace(replace(replace(replace(   isnull(a2.any_comments,'')   ,'"',''''''),'''',''),char(13),''),char(10),'�')) 
                    as varchar(max)
                )
            from #g a2 with(nolock)
            where 
                a2.parent_unique_key = a1.parent_unique_key
            group by a2.any_comments
            order by a2.any_comments
            FOR XML PATH('')
         ), 1, 1, '')) as any_comments
    into #h
    from #g a1
    outer apply (
        select top 1 *
        from #g
        where
            parent_unique_key = a1.UNIQUE_KEY
            and inspection_result is not null
        order by case inspection_result when 'Cancel' then 1 when 'Issue Citation' then 2 when 'Issue Warning' then 3 when 'No Violation' then 4 else 5 end
    ) b
    where
        1=1
        and a1.ACTION_ENT in ('SV','SSV','QCSV','LSV')
        --and a1.number_key = 'CE17015692'
    ;

    --order by a.UNIQUE_KEY
--)
;

--create violations
--;with cte_violations as (
;IF OBJECT_ID('tempdb.dbo.#_violations_ce_customLists_violations', 'U') IS NOT NULL drop table #_violations_ce_customLists_violations
;
go
select distinct
     a.NUMBER_KEY
    ,a.parent_unique_key
    ,a.unique_key --the inspection the violation will be associated with
    ,a.item_id
    ,a.the_date
    ,convert(varchar(max),tc.notation) notation
    ,convert(varchar(max),tc.the_text) the_text
    ,b.approved
into #_violations_ce_customLists_violations
from #g a
left join hcfl_src..apd_itms b on b.RECORD_TYPE = 'CD' and b.NUMBER_KEY = a.NUMBER_KEY
--left join greater_dates b2 on b2.number_key = b.number_key and b2.sequence = b.sequence and b2.item_id = b.item_id and b2.the_date = b.the_Date	
left join hcfl_src..tab_cond tc on tc.ELEMENT_KEY = b.ITEM_ID
where
    1=1
	and b.NUMBER_KEY is not null
	--and b.NUMBER_KEY = @number_key
	and (
		(year(b.THE_DATE) = year(a.THE_DATE) and month(b.THE_DATE) = month(a.THE_DATE) and day(b.THE_DATE) = day(a.THE_DATE) )
		--or (year(b2.greater_date) = year(a.date_ent) and month(b2.greater_date) = month(a.date_ent) and day(b2.greater_date) = day(a.date_ent) )
		--or a.item_id = b.ITEM_ID
	)
	--and a.parent_unique_key not like 'ORPH-%'
	and a.item_id = b.ITEM_ID
	--and b.NUMBER_KEY = 'CE20005395'
--group by a.number_key,a.parent_unique_key
;
insert into #_violations_ce_customLists_violations
select distinct
     a.NUMBER_KEY
    ,a.parent_unique_key
    ,a.unique_key --the inspection the violation will be associated with
    ,a.item_id
    ,a.the_date
    ,convert(varchar(max),tc.notation) notation
    ,convert(varchar(max),tc.the_text) the_text
    ,b.approved
--into #violations_ce_customLists_violations
from #g a
left join hcfl_src..apd_itms b on b.RECORD_TYPE = 'CD' and b.NUMBER_KEY = a.NUMBER_KEY
--left join greater_dates b2 on b2.number_key = b.number_key and b2.sequence = b.sequence and b2.item_id = b.item_id and b2.the_date = b.the_Date	
left join #_violations_ce_customLists_violations f on f.number_key = b.number_key and f.parent_unique_key = a.parent_unique_key and f.item_id = b.item_id
left join hcfl_src..tab_cond tc on tc.ELEMENT_KEY = b.ITEM_ID
where
    1=1
	and b.NUMBER_KEY is not null
    and b.number_key in (
        'CE19003559','CE23009136','CE19009756','CE20002548','CE21004204','CE19003581','CE20012598','CE19012011','CE23005979','CE19015277','CE21016309','CE19011421','CE19012401','CE22014685','CE18005494','CE23010215','CE19012411','CE20009721','CE22013741','CE19014671','CE21011018','CE22014110','CE20007800','CE20005402','CE20009114','CE19002911','CE20018403','CE23011330','CE22015121','CE23007240','CE23013057','CE19010651','CE19018933','CE20014046','CE21009047','CE21007959','CE23004103','CE22001176','CE23006298','CE23010669','CE24000898','CE24000231','CE20004070','CE23009308','CE23010811','CE23010751','CE21014360','CE22012777','CE19009560','CE19012398','CE19008217','CE21000155','CE19010306','CE19006856','CE19005561','CE19008165','CE20003010','CE23013515','CE19019242','CE18019800','CE14014593','CE21004712','CE20002119','CE20011293','CE19012874','CE20007286','CE19010901','CE21016777','CE21015105','CE20017070','CE23011743','CE19006692','CE22014556','CE21002721','CE22012195','CE23014129','CE16008878','CE23014777','CE21014002','CE22002145','CE21014975','CE19000216','CE22012498','CE16010830','CE19007826','CE20017491','CE24001587','CE22014672','CE20004106','CE21013194','CE19011203','CE19005242','CE19008010','CE20005850','CE23014313','CE19009809','CE22007611','CE22014657','CE19002688','CE19004742','CE19019742','CE16012518','CE19005138','CE24002345','CE21002886','CE19005576','CE21010907','CE23000913','CE19015279','CE24000171','CE23013386','CE19004841','CE20003005','CE23013302','CE21010027','CE21003160','CE23011649','CE20002551','CE21012168','CE20001647','CE19015282','CE19010593','CE22005509','CE22002774','CE19000583','CE22009951','CE19012963','CE21013802','CE19006869','CE19007787','CE22010728','CE21014537','CE19015962','CE19002555','CE19009892','CE15004960','CE23007140','CE20012475','CE19011046','CE23013565','CE20002543','CE22010175','CE21007517','CE22012138','CE24002684','CE20015397','CE20014604','CE18008839','CE23012423','CE19001765','CE19014362','CE22013524','CE19012586','CE23002470','CE23014099','CE20012835','CE07006722','CE19015151','CE19000528','CE19014919','CE19011732','CE22005218','CE12012059','CE19013938','CE23003461','CE21010022','CE22008356','CE19005972','CE20000742','CE21003266','CE23002791','CE20004250','CE23006823','CE23006205','CE20006255','CE23005529','CE19015687','CE17020849','CE16011159','CE23008481','CE21010743','CE21000977','CE19012735','CE19013243','CE23009435','CE14002241','CE19019208','CE19003241','CE19010951','CE19007064','CE05008956','CE23000156','CE20011005','CE19015960','CE23006198','CE23000896','CE23009330','CE23003520','CE23013768','CE23013242','CE21012600','CE23006418','CE19019872','CE19009080','CE20017647','CE21008460','CE20003079','CE21004247','CE19016865','CE22014691','CE20000309','CE23009317','CE16009497','CE20012757','CE22013184','CE22012525','CE23002424','CE19011120','CE20004011','CE20018362','CE11001952','CE19008549','CE19002850','CE23003766','CE23011872','CE20016297','CE21012795','CE21010756','CE19014909','CE23004666','CE19011322','CE21006583','CE21003395','CE22002320','CE19001103','CE23010757','CE20002145','CE21010369','CE24001675','CE24001194','CE19019970','CE21008117','CE04002961','CE24000282','CE23000226','CE19011049','CE22002273','CE23010810','CE12009147','CE20013788','CE23001776','CE22012221','CE22008197','CE20006453','CE20007168','CE19014933','CE20017446','CE21002204','CE19013740','CE22008400','CE19006253','CE19015187','CE21013889','CE22012226','CE19006592','CE21008765','CE20009474','CE21000352','CE22011604','CE23011454','CE12004910','CE20005069','CE22012974','CE23007078','CE21011822','CE22002278','CE23014558','CE19006177','CE22014960','CE20014073','CE21010304','CE23012408','CE20006029','CE19005819','CE23009508','CE19009231','CE22003059','CE21012398','CE24001576','CE20002603','CE23013958','CE20004452','CE23004337','CE23007397','CE22009674','CE19010319','CE19020349','CE20004379','CE22011606','CE20001696','CE23001612','CE23013064','CE12003323','CE19018598','CE20003134','CE20008234','CE13011361','CE21014323','CE23010838','CE21005870','CE20002550','CE21014995','CE23010548','CE21012765','CE23001406','CE23002206','CE23009679','CE23001283','CE23012306','CE13013683','CE21005650','CE12001135','CE21011659','CE21016565','CE22004816','CE23005030','CE21009405','CE22012975','CE22010001','CE22011513','CE23013896','CE23002363','CE19005407','CE19008000','CE19009810','CE22007403','CE19007948','CE23009295','CE20001120','CE19014351','CE20000610','CE23002831','CE20014638','CE23013343','CE23014165','CE21016896','CE20003292','CE22015143','CE24001125','CE23002421','CE19009336','CE23002074','CE20002546','CE24001901','CE19001606','CE22009736','CE19010548','CE19008853','CE22010991','CE23014102','CE20016689','CE19004262','CE23009562','CE22009001','CE19019345','CE22006714','CE22011587','CE21008384','CE23001747','CE20011292','CE20001622','CE19016871','CE21006173','CE19011196','CE21003999','CE22014860','CE23002436','CE20006243','CE19013762','CE19014356','CE20008245','CE22012248','CE20012913','CE12010833','CE15004070','CE23000058','CE21012761','CE19002976','CE19009561','CE12003209','CE20003150','CE19001475','CE23005154','CE23010438','CE20018499','CE19014365','CE22012717','CE21015934','CE20013132','CE21011969','CE21006590','CE20010968','CE23003853','CE19006731','CE20012661','CE19014495','CE23004358','CE19008554','CE12003481','CE21010313','CE19005606','CE24002068','CE19012746','CE22006893','CE20000497','CE19004484','CE19019300','CE20007394','CE19004709','CE22009437','CE19003007','CE20003512','CE20008813','CE19006620','CE22013816','CE23012610','CE23000787','CE20008316','CE19018571','CE23008403','CE20008130','CE20013020','CE20014591','CE19002826','CE23003059','CE21012920','CE23010317','CE19001686','CE19001411','CE21012638','CE22001793','CE20002331','CE22003873','CE21008521','CE22006128','CE19009748','CE24002782','CE22011816','CE20017803','CE20006246','CE19010718','CE19005680','CE23000343','CE23007720','CE21010763','CE19015601','CE23011648','CE23011763','CE19018118','CE19007967','CE22012227','CE19013394','CE19016400','CE22004361','CE19002524','CE23010807','CE20003397','CE21011776','CE20004736','CE23005362','CE22014454','CE19005224','CE22011538','CE23010784','CE21003639','CE22008060','CE22014307','CE19006949','CE23014035','CE23000733','CE19007174','CE23009656','CE19011783','CE23002446','CE20012172','CE20018297','CE22015243','CE22012244','CE22005890','CE14010124','CE13011483','CE14001851','CE19001083','CE19007005','CE23013870','CE23013902','CE20012565','CE23008547','CE21012485','CE21014466','CE21009616','CE21015281','CE22010385','CE20004993','CE14005007','CE23008919','CE24002844','CE22007390','CE23010656','CE21004311','CE22001149','CE21013884','CE19014358','CE19015146','CE21008386','CE24002767','CE15000614','CE20014082','CE22014182','CE19009841','CE21015914','CE20006690','CE21012900','CE21008633','CE20017129','CE19018457','CE19016224','CE20007033','CE17020054','CE21006656','CE19007624','CE19007856','CE24000155','CE21003053','CE20017241','CE21011881','CE20008418','CE20010455','CE20004732','CE19014570','CE20006292','CE21015375','CE19011447','CE19000792','CE21016389','CE19014360','CE22014462','CE21006869','CE18016947','CE21000243','CE19005193','CE19015620','CE19009660','CE23009887','CE19009394','CE20010371','CE19016747','CE20012261','CE20016621','CE21005706','CE19015803','CE23001600','CE21009603','CE21001824','CE23008181','CE19002202','CE20013524','CE19000089','CE22004210','CE19005975','CE19011418','CE15005695','CE21015426','CE15014606','CE24001159','CE23000199','CE21005536','CE09010970','CE19008023','CE23011791','CE21009067','CE14011996','CE19010936','CE19016716','CE21011355','CE23003583','CE19011802','CE19010955','CE19016203','CE21010910','CE24002426','CE21016673','CE23012219','CE22013786','CE19009668','CE22011836','CE19009143','CE23000542','CE20008814','CE21004395','CE21004115','CE21002610','CE19012769','CE21010936','CE19009287','CE23001979','CE19012909','CE21011878','CE23002066','CE22001087','CE23006657','CE23006359','CE20016242','CE23004804','CE22003318','CE20004878','CE19008390','CE20012528','CE21008611','CE20011023','CE20011864','CE19014999','CE21011633','CE19006885','CE21005417','CE19003467','CE23002849','CE19012235','CE23014299','CE19014787','CE22012563','CE23000697','CE23011871','CE20000772','CE24001088','CE19011733','CE23014637','CE19001888','CE21015526','CE20003493','CE20014445','CE21006950','CE21004695','CE23011954','CE20006572','CE22008689','CE23009513','CE20003050','CE21012426','CE19009735','CE11005977','CE19014998','CE19010223','CE20007557','CE19018638','CE20015660','CE23011387','CE22007121','CE22000047','CE20004381','CE23009659','CE23008130','CE19019823','CE20007412','CE19008934','CE20004016','CE19013230','CE22005119','CE21001337','CE21000775','CE19016372','CE20001956','CE20013301','CE22013147','CE21003099','CE20014278','CE19013135','CE23002208','CE07001296','CE19019109','CE21015908','CE20001749','CE20015687','CE19018345','CE22002182','CE20018105','CE21011445','CE23008789','CE20014627','CE23004210','CE19009927','CE19011446','CE19011601','CE23005483','CE23000499','CE19000107','CE15001935','CE19020066','CE23009555','CE24003156','CE22008683','CE21015760','CE20011836','CE21010788','CE21015292','CE22005681','CE20014528','CE23011254','CE24000868','CE21012407','CE19018960','CE21009065','CE19014789','CE23011930','CE19015375','CE19013427','CE13015163','CE21003071','CE24000638','CE21012732','CE23005375','CE21007358','CE20007758','CE19011415','CE19008372','CE21013741','CE19006738','CE23002691','CE21010804','CE21010404','CE19004732','CE21003873','CE18009943','CE24003192','CE21002922','CE24002441','CE21011960','CE19011951','CE19015807','CE22004245','CE23013466','CE23005114','CE19019042','CE23004448','CE13001146','CE15003234','CE19000075','CE22014720','CE23005270','CE20007832','CE21011578','CE23011187','CE22001295','CE19016119','CE21015152','CE22014515','CE23013660','CE21003858','CE21005508','CE20013249','CE19000309','CE19015441','CE23013201','CE21008769','CE20008086','CE23001657','CE22000405','CE22006223','CE20003009','CE23006589','CE23011376','CE19013429','CE19014786','CE23014462','CE23005238','CE20005395','CE23004420','CE23003257','CE21002906','CE23006630','CE19005858','CE22012514','CE23012617','CE19009646','CE19013927','CE19011782','CE23012694','CE23005147','CE19007844','CE22012490','CE19020275','CE20002228','CE21011362','CE23011087','CE19009909','CE23003399','CE19014363','CE24000786','CE21005468','CE20008282','CE21001701','CE22001252','CE21010091','CE19016202','CE21011856','CE23010066','CE22001653','CE24002049','CE19011432','CE19014641','CE19015002','CE19006459','CE19018760','CE23002026','CE23001005','CE21007737','CE20004731','CE22012004','CE21010824','CE23002216','CE23001411','CE22005981','CE19002751','CE20005115','CE20012329','CE09013743','CE19010748'
    )
	--and b.NUMBER_KEY = @number_key
	and (
		(year(b.THE_DATE) = year(a.THE_DATE) and month(b.THE_DATE) = month(a.THE_DATE) and day(b.THE_DATE) = day(a.THE_DATE) )
		--or (year(b2.greater_date) = year(a.date_ent) and month(b2.greater_date) = month(a.date_ent) and day(b2.greater_date) = day(a.date_ent) )
		--or a.item_id = b.ITEM_ID
	)
	--and a.parent_unique_key not like 'ORPH-%'
	and a.item_id <> b.ITEM_ID
	--and b.NUMBER_KEY = 'CE04002961'
	and f.number_key is null	
    and not exists (
		select 1
		from #_violations_ce_customLists_violations
		where
			1=1
			and number_key = a.number_key
			and parent_unique_key = a.parent_unique_key
			and item_id = a.item_id
			and the_date = a.the_date
			--and convert(varchar(max),notation) = tc.notation
	)
;
insert into #_violations_ce_customLists_violations
select distinct
     a.NUMBER_KEY
    ,a.parent_unique_key
    ,a.unique_key --the inspection the violation will be associated with
    ,a.item_id
    ,a.the_date
    ,convert(varchar(max),tc.notation) notation
    ,convert(varchar(max),tc.the_text) the_text
    ,b.approved
from #g a
left join hcfl_src..apd_itms b on b.RECORD_TYPE = 'CD' and b.NUMBER_KEY = a.NUMBER_KEY
--left join greater_dates b2 on b2.number_key = b.number_key and b2.sequence = b.sequence and b2.item_id = b.item_id and b2.the_date = b.the_Date	
left join #_violations_ce_customLists_violations f on f.number_key = b.number_key and f.parent_unique_key = a.parent_unique_key and f.item_id = b.item_id
left join hcfl_src..tab_cond tc on tc.ELEMENT_KEY = b.ITEM_ID
where
    1=1
	and b.NUMBER_KEY is not null
    and b.number_key in ('CE20008234' --'CE21005536','CE19019042','CE21009603','CE19011049','CE23013343','CE23012694','CE21009067','CE23011187','CE19010223','CE19005193','CE23005114','CE22012975','CE22014860','CE22008356','CE22013786','CE23003461','CE23014129','CE22014110','CE19011418','CE21005870','CE20006572','CE23001411','CE19011783','CE23004666','CE23000058','CE19004709','CE20001956','CE21000243','CE19012398','CE20008234','CE21014360','CE22009736','CE22014685','CE22014657','CE19009809','CE24002441','CE22006893','CE19014786','CE23000913','CE19011421','CE21010824','CE23009508','CE21011969','CE20009721','CE19007826','CE21014995','CE21003873','CE19012874','CE21007737','CE22013816','CE23009435','CE19005819','CE21016777','CE19007948','CE23014165','CE22012717','CE23000896','CE21011018','CE23002208','CE23001747','CE21004311','CE20001120','CE20004452','CE21015105','CE21009065','CE16010830','CE21000775','CE23003399','CE19011196','CE22003059','CE23009136','CE21013889','CE21002906','CE20000742','CE19015601','CE22010175','CE23013302','CE22012248','CE20002119','CE23000199','CE07006722','CE23011454','CE24002068','CE19011951','CE21012765','CE22001252','CE20014591','CE22003873','CE20011292','CE19011732','CE19011432','CE19005606','CE21010756','CE23003520','CE22002774','CE19001103','CE20003079','CE20007412','CE21004115'
)
	--and b.NUMBER_KEY = @number_key
	and (
		(year(b.THE_DATE) = year(a.date_ent) and month(b.THE_DATE) = month(a.date_ent) and day(b.THE_DATE) = day(a.date_ent) )
		--or (year(b2.greater_date) = year(a.date_ent) and month(b2.greater_date) = month(a.date_ent) and day(b2.greater_date) = day(a.date_ent) )
		--or a.item_id = b.ITEM_ID
	)
	and a.item_id <> b.ITEM_ID
	and f.number_key is null	
;


;with greater_dates as (
	select 
		 b.number_key
		,b.sequence
		,b.item_id
		,b.the_date
		,b2.THE_DATE greater_date
	from hcfl_src..apd_itms b
	outer apply (select top 1 * from hcfl_src..APD_ITMS where record_type = 'cd' and NUMBER_KEY = b.NUMBER_KEY and THE_DATE <> b.THE_DATE) b2
	where
		1=1
		and b.number_key in (--'CE19011421'
			'CE19014786','CE23000913','CE19011421','CE21010824','CE23009508','CE21011969','CE20009721','CE19007826','CE21014995','CE22014110','CE19011418','CE21005870','CE20006572','CE23001411','CE19011783','CE23004666','CE23009435','CE19005819','CE21016777','CE19007948','CE23014165','CE22012717','CE23000896','CE19011432','CE19005606','CE21010756','CE23003520','CE22002774','CE19001103','CE20003079','CE20007412','CE21004115','CE21000775','CE23003399','CE19011196','CE22003059','CE23009136','CE21013889','CE21002906','CE20000742','CE19015601','CE22010175','CE23013302','CE22012248','CE20002119','CE23000199','CE07006722','CE23011454','CE24002068','CE19011951','CE21012765','CE22001252','CE20014591','CE22003873','CE20011292','CE19011732','CE19012398','CE20008234','CE21014360','CE22009736','CE22014685','CE22014657','CE19009809','CE24002441','CE22006893','CE21005536','CE19019042','CE21009603','CE19011049','CE23013343','CE23012694','CE21009067','CE23011187','CE19010223','CE19005193','CE23005114','CE22012975','CE22014860','CE22008356','CE22013786','CE23003461','CE23014129','CE21003873','CE19012874','CE21007737','CE22013816','CE23000058','CE19004709','CE20001956','CE21000243','CE21011018','CE23002208','CE23001747','CE21004311','CE20001120','CE20004452','CE21015105','CE21009065','CE16010830'
            ,'CE24002698','CE24002677','CE24000095','CE24002940','CE24002516','CE24001571','CE24000841','CE24000276','CE21014437','CE24000153','CE24003572','CE24001826','CE24002465','CE24000537','CE24002759','CE24002219','CE24003484','CE23009330','CE24002813','CE24000171','CE24000155','CE24003615','CE23013361','CE19011049','CE21014435','CE24003382','CE24002844','CE24002618','CE24001446','CE24002499','CE23014427','CE24002629','CE24000956','CE24000307','CE23014095','CE24000177','CE23014301','CE24003053','CE23013872','CE23012257','CE24001949','CE24001585','CE24003139'
		)
		and b2.the_Date is not null
		and b.RECORD_TYPE = 'cd'
		and not exists (select 1 from #_violations_ce_customLists_violations where number_key = b.NUMBER_KEY and item_id = b.ITEM_ID)
)
insert into #_violations_ce_customLists_violations
select distinct
     a.NUMBER_KEY
    ,a.parent_unique_key
    ,a.unique_key --the inspection the violation will be associated with
    ,a.item_id
    ,a.the_date
    ,convert(varchar(max),tc.notation) notation
    ,convert(varchar(max),tc.the_text) the_text
    ,b.approved
from #g a
left join hcfl_src..apd_itms b on b.RECORD_TYPE = 'CD' and b.NUMBER_KEY = a.NUMBER_KEY
left join greater_dates b2 on b2.number_key = b.number_key and b2.sequence = b.sequence and b2.item_id = b.item_id and b2.the_date = b.the_Date	
--left join #_violations_ce_customLists_violations f on f.parent_unique_key = a.parent_unique_key and f.item_id = a.item_id
left join hcfl_src..tab_cond tc on tc.ELEMENT_KEY = b.ITEM_ID
where
    1=1
	and b.NUMBER_KEY is not null
	--and b.NUMBER_KEY = 'CE20008234 '
	and (
		--(year(b.THE_DATE) = year(a.date_ent) and month(b.THE_DATE) = month(a.date_ent) and day(b.THE_DATE) = day(a.date_ent) )
		(year(b2.greater_date) = year(a.date_ent) and month(b2.greater_date) = month(a.date_ent) and day(b2.greater_date) = day(a.date_ent) )
	)
	and a.item_id <> b.ITEM_ID
	--and f.number_key is null
;

insert into #_violations_ce_customLists_violations
select *
from (VALUES 
 ('CE19011049','A007910186','A007910186','S13.2.1.11','2019-07-23 00:00:00.0000000','POOL BARRIER GATES','ITEM S13.2.1.11: POOL BARRIER / ACCESS GATES�HILLSBOROUGH COUNTY CODE OF ORDINANCES AND LAWS, PART A, SECTION 8-117(b)1k-SWIMMING POOLS��ACTION REQUIRED: PROVIDE TO CODE�','Y')
,('CE19011049','A007910186','A007910186','S13.2.1.5' ,'2019-07-23 00:00:00.0000000','POOL BARRIER GAPS OVER 4"','ITEM S13.2.1.5: POOL BARRIER / GAPS, OPENINGS, INDENTATIONS, OR PROTRUSIONS�HILLSBOROUGH COUNTY CODE OF ORDINANCES AND LAWS, PART A, SECTION 8-117(b)1e-SWIMMING POOLS��ACTION REQUIRED: REDUCE CLEARANCE TO 4 INCHES OR LESS�','Y')
,('CE19011049','A007910186','A007910186','NR10.5.2'  ,'2019-08-07 00:00:00.0000000','GFCI PROTECTION NON RES','ITEM NR10.5.2: GFCI PROTECTION�HILLSBOROUGH COUNTY CODE OF ORDINANCES AND LAWS, PART A, SECTION 8-114(b)2- STRUCTURAL STANDARDS FOR NONRESIDENTIAL STRUCTURES��ACTION REQUIRED: REMOVE OR PROVIDE GFCI PROTECTION�','Y')
,('CE24000095','A009153805','A009153805','PM12.3A   ','2024-04-29 00:00:00.0000000','NUISANCE CONDITIONS','ITEM PM12.3A: NUISANCE CONDITIONS�HILLSBOROUGH COUNTY CODE OF ORDINANCES AND LAWS, PART A, SECTION 8-116(c)- PROPERTY STANDARDS��ACTION REQUIRED: REMOVE�','Y')
,('CE24000095','A009153805','A009153805','R11.11.2  ','2024-04-15 00:00:00.0000000','HANDRAILS RES','ITEM R11.11.2: HANDRAILS�HILLSBOROUGH COUNTY CODE OF ORDINANCES AND LAWS, PART A, SECTION 8-115(j)2- STRUCTURAL STANDARDS FOR DWELLINGS��ACTION REQUIRED: REPAIR/PROVIDE TO CODE�','Y')
,('CE24000095','A009153805','A009153805','R11.7.5   ','2024-04-15 00:00:00.0000000','DECORATIVE FEATURES RES','ITEM R11.7.5: DECORATIVE FEATURES�HILLSBOROUGH COUNTY CODE OF ORDINANCES AND LAWS, PART A, SECTION 8-115(f)5- STRUCTURAL STANDARDS FOR DWELLINGS ��ACTION REQUIRED: REPAIR OR REMOVE�','Y')
,('CE24000095','A009153805','A009153805','R11.7.2   ','2024-04-15 00:00:00.0000000','EXTERIOR WALLS RES','ITEM R11.7.2: EXTERIOR WALLS�HILLSBOROUGH COUNTY CODE OF ORDINANCES AND LAWS, PART A, SECTION 8-115(f)2- STRUCTURAL STANDARDS FOR DWELLINGS ��ACTION REQUIRED: REPAIR TO CODE (PERMIT MAY BE REQUIRED)�','Y')
,('CE24000095','A009153805','A009153805','R11.6.4   ','2024-04-15 00:00:00.0000000','CONNECTION TO DRAINAGE RES','ITEM R11.6.4: CONNECTION TO DRAINAGE SYSTEMS�HILLSBOROUGH COUNTY CODE OF ORDINANCES AND LAWS, PART A, SECTION 8-115(e)4- STRUCTURAL STANDARDS FOR DWELLINGS��ACTION REQUIRED: PROVIDE ADEQUATE CONNECTION TO DRAINAGE SYSTEM�','Y')
,('CE24000095','A009153805','A009153805','PM12.4    ','2024-04-15 00:00:00.0000000','CONDITION OF FENCES','ITEM PM12.4: FENCES�HILLSBOROUGH COUNTY CODE OF ORDINANCES AND LAWS, PART A, SECTION 8-116(d)- PROPERTY STANDARDS��ACTION REQUIRED: REMOVE OR REPAIR (FENCES REQUIRED FOR SCREENING OR POOL SECURITY MAY NOT BE REMOVED)�','Y')
,('CE24000177','A009133092','A009133092','NR10.1    ','2024-03-27 00:00:00.0000000','GENERAL STANDARDS NON RES ','ITEM NR10.1: GENERAL STANDARDS FOR NON RESIDENTIAL STRUCTURES�HILLSBOROUGH COUNTY CODE OF ORDINANCES AND LAWS, PART A, SECTION 8-114(a)- STRUCTURAL STANDARDS FOR NONRESIDENTIAL STRUCTURES��ACTION REQUIRED: REMOVE OR COMPLY WITH THE REQUIREMENTS OF THE ORDINANCE�','Y')
,('CE24000177','A009133092','A009133092','PM12.3A   ','2024-03-28 00:00:00.0000000','NUISANCE CONDITIONS','ITEM PM12.3A: NUISANCE CONDITIONS�HILLSBOROUGH COUNTY CODE OF ORDINANCES AND LAWS, PART A, SECTION 8-116(c)- PROPERTY STANDARDS��ACTION REQUIRED: REMOVE�','Y')
,('CE24000177','A009133092','A009133092','R11.5.5   ','2024-03-26 00:00:00.0000000','ELECTRICAL WIRING RES','ITEM R11.5.5: ELECTRICAL WIRING�HILLSBOROUGH COUNTY CODE OF ORDINANCES AND LAWS, PART A, SECTION 8-115(d)5- STRUCTURAL STANDARDS FOR DWELLINGS��ACTION REQUIRED: REMOVE/ENCLOSE�','Y')
,('CE24000177','A009133092','A009133092','R11.7.9   ','2024-03-26 00:00:00.0000000','WINDOWS AND EXT DOORS RES','ITEM R11.7.9: WINDOWS AND EXTERIOR DOORS�HILLSBOROUGH COUNTY CODE OF ORDINANCES AND LAWS, PART A, SECTION 8-115(f)9- STRUCTURAL STANDARDS FOR DWELLINGS ��ACTION REQUIRED: REPAIR TO CODE�','Y')
,('CE24000177','A009133092','A009133092','PM12.3B   ','2024-03-30 00:00:00.0000000','UNSECURED STRUCTURE','ITEM PM12.3B: NUISANCE CONDITIONS: UNSECURED STRUCTURE�HILLSBOROUGH COUNTY CODE OF ORDINANCES AND LAWS, PART A, SECTION 8-116(c)- PROPERTY STANDARDS��ACTION REQUIRED: SECURE','Y')
) t(number_key,parent_unique_key,unique_key,item_id,the_date,notation,the_text,approved)
;
delete a
from #_violations_ce_customLists_violations a 
join (VALUES 
 ('CE20014591','A008555900','R11.7.4   ')
,('CE19011049','A007962881','S13.2.1.11')
,('CE19011049','A007962881','S13.2.1.5 ')
) d(number_key,parent_unique_key,item_id)
	on d.number_key = a.number_key
	and d.parent_unique_key = a.parent_unique_key 
	and d.item_id = a.item_id
where
	1=1
;

;IF OBJECT_ID('tempdb.dbo.#violations_ce_customLists_violations', 'U') IS NOT NULL drop table #violations_ce_customLists_violations
;
go
select distinct
     a.NUMBER_KEY
    ,a.parent_unique_key
    ,a.item_id
    ,a.the_date
    ,replace(replace(replace(replace(     convert(varchar(max),a.notation)     ,'"',''''''),'''',''),char(13),''),char(10),'�') notation
    ,replace(replace(replace(replace(     convert(varchar(max),a.the_text)     ,'"',''''''),'''',''),char(13),''),char(10),'�') the_text
    ,a.approved
    ,b.any_comments
into #violations_ce_customLists_violations
from #_violations_ce_customLists_violations a
join #g b on b.UNIQUE_KEY = a.UNIQUE_KEY
WHERE
    1=1
;
/*
from here:
notation => guide sheets asi
I think, then: the_text => guide sheet asit ?
I think guidesheet things arent configured?
Is the record type or subtype or something mappable into the guidesheets? 
then the notation to ASI
then the_text to ASIT:inspector_comments?

*/

;IF OBJECT_ID('hcfl_prod.dbo.cl_complaints', 'U') IS NOT NULL drop table cl_complaints
go
;with g as (
    select
        pnum.permitnum
        ,pnum.tt_record
        --,ROW_NUMBER() OVER(PARTITION BY pnum.permitnum order by v.the_date) AS num_row

        ,the_date date_added
        ,(case notation
            when 'A/C INOPERATIVE' then 'R AIR CONDITIONER DEFECTIVE/INOPERATIVE'
            when 'ABANDONED PROPERTY REGISTRATIO' then 'OTH FORECLOSED PROPERTY REGISTRATION'
            when 'ACCESS REQUIRED BY SITE DEVELO' then 'Z ACCESS REQUIRED BY SITE DEVELOPMENT'
            when 'ACCESSIBILITY RQ - NO SIGNAGE' then 'Z VIOLATING SIGN PLACEMENT STANDARDS'
            when 'ACCESSORY  STRUCTURE COVERAGE' then 'Z ACCESSORY STRUCTURE: REAR YARD COVERAGE (>20%)'
            when 'ACCESSORY DWELLING STANDARDS' then 'R GENERAL STANDARDS FOR DWELLINGS'
            when 'ACCESSORY STRUCTURE SETBACKS' then 'Z ACCESSORY STRUCTURE: SETBACK'
            when 'ACCESSORY STRUCTURE: SETBACK' then 'Z ACCESSORY STRUCTURE: SETBACK'
            when 'ACCESSORY USE W/O PRIMARY' then 'Z ACCESSORY USE W / O PRIMARY USE'
            when 'ACCUMULAT: JUNK,TRASH,DEBRIS' then 'PM ACCUMULATIONS'
            when 'ACCUMULATIONS' then 'PM ACCUMULATIONS'
            when 'ADDRESS VIOLATION' then 'OTH NO ADDRESS POSTED / IMPROPERLY POSTED'
            when 'ADEQUATE SECURITY' then 'PM NUISANCE CONDITIONS: UNSECURED STRUCTURE'
            when 'AG ANIMALS IN RES' then 'Z AGRICULTURAL ANIMALS IN RESIDENTIAL DISTRICTS'
            when 'AG STAND / PERMIT REQUIRED' then 'Z PERMIT REQUIRED: AGRICULTURAL STAND'
            when 'ATTIC ACCESS RES' then 'NR ATTIC ACCESS'
            when 'AUDIT INSPECTION' then notation
            when 'BACKYARD CHICKENS' then 'Z BACKYARD CHICKENS'
            when 'BOAT: PRIVATE PLEASURE CRAFT' then 'Z RV/UTILITY TRAILER/PLEASURE CRAFT: ON RIGHT OF WAY'
            when 'BUFFER SCREENING REQUIRMENTS' then 'Z BUFFER SCREENING REQUIRED'
            when 'BUILDING FOUNDATIONS NON RES' then 'NR BUILDING FOUNDATION'
            when 'BUILDING SECURITY RES' then 'R BUILDING SECURITY'
            when 'BURGLAR BARS RES' then 'R BURGLAR BARS'
            when 'CEILINGS NON RES' then 'NR CEILINGS'
            when 'CEILINGS RES' then 'R CEILINGS'
            when 'CERTIFICATES OF OCCUPANCY' then 'OTH CERTIFICATES OF OCCUPANCY AND COMPLETION'
            when 'CHIMNEYS AND TOWERS RES' then 'R CHIMNEYS AND TOWERS'
            when 'COMMERCIAL VEHICLE' then 'Z COMMERCIAL VEHICLE'
            when 'CONDITION OF FENCES' then 'PM FENCES'
            when 'CONDITIONS/COND USE' then 'Z FAILURE TO COMPLY WITH CONDITIONS OF CONDITIONAL USE'
            when 'CONNECTION TO DRAINAGE NON RES' then 'NR CONNECTION TO DRAINAGE SYSTEMS'
            when 'CONNECTION TO DRAINAGE RES' then 'R CONNECTION TO DRAINAGE SYSTEMS'
            when 'CONSTRUCTION W/O PERMITS' then notation
            when 'COOKING EQUIPMENT INSTALL RES' then 'R COOKING EQUIPMENT (INSTALLATIONS)'
            when 'COOKING EQUIPMENT RES' then 'R COOKING EQUIPMENT'
            when 'CROSS ACCESS CONNECTION' then 'Z CROSS ACCESS REQUIREMENTS'
            when 'DECORATIVE FEATURES RES' then 'NR DECORATIVE FEATURES'
            when 'DEVELOPMENT IN THE ROW' then 'Z DEVELOPMENT IN THE RIGHT OF WAY'
            when 'DISABLED PARKING' then 'Z DISABLED PARKING'
            when 'DISHWASHER' then 'R DISHWASHER DEFECTIVE/INOPERATIVE'
            when 'DOORS INTERIOR RES' then 'R DOORS'
            when 'DUMPSTER LOCATION' then 'Z DUMPSTER'
            when 'ELECTRICAL' then 'R GENERAL MECHANICAL-ELECTRICAL REQUIREMENTS'
            when 'ELECTRICAL FACIL RES' then 'R ELECTRICAL FACILITIES'
            when 'ELECTRICAL INSTALLATION & MAIN' then 'NR ELECTRICAL INSTALLATION AND MAINTENANCE'
            when 'ELECTRICAL SERVI RES' then 'R ELECTRICAL SERVICE'
            when 'ELECTRICAL WIRING NON RES' then 'NR ELECTRICAL WIRING'
            when 'ELECTRICAL WIRING RES' then 'R ELECTRICAL WIRING'
            when 'ELECTRICAL: FIXTURES' then 'R INTERIOR LIGHT FIXTURE DEFECTIVE/INOPERATIVE'
            when 'ENTER TEXT HERE' then notation
            when 'EXCESSIVE ANIMALS AG ONLY' then 'Z EXCESSIVE ANIMALS'
            when 'EXCESSIVE DWELLINGS' then 'Z EXCESSIVE DWELLINGS'
            when 'EXTERIOR LIGHT RES' then 'R EXTERIOR LIGHT FIXTURES'
            when 'EXTERIOR LIGHTING ZONING' then 'Z IMPROPER USE OF ZONE'
            when 'EXTERIOR WALLS NON RES' then 'NR EXTERIOR WALLS'
            when 'EXTERIOR WALLS RES' then 'R EXTERIOR WALLS'
            when 'Failure to accept Cash/Debit C' then notation
            when 'FAILURE TO MAINTAIN FORECLOSED' then 'OTH FAILURE TO MAINTAIN FORECLOSED PROPERTY'
            when 'FENCE (ZONING)' then 'Z FENCE ZONING VIOLATION'
            when 'FENCE - CONSTRUCTION' then 'PM FENCES'
            when 'FENCES (ZONING)' then 'Z FENCE ZONING VIOLATION'
            when 'FIRE CODE VIOLATION' then 'R FIRE EXTINGUISHERS'
            when 'FIRE EXTINGUISHER R' then 'R FIRE EXTINGUISHERS'
            when 'FIRE EXTINGUISHERS RES' then 'R FIRE EXTINGUISHERS'
            when 'FIRE SPRINKLER SYSTEM TAG/SERV' then 'R FIRE EXTINGUISHERS'
            when 'FORECLOSED PROPERTY AGENT' then 'OTH FORECLOSED PROPERTY AGENT'
            when 'FOUNDATION RES' then 'R FOUNDATION'
            when 'FUEL FIRED HEAT RES' then 'NR FUEL FIRED HEATERS'
            when 'GARAGE DOOR' then 'R GARAGE DOOR'
            when 'GAS PUMPING ASSISTANCE' then 'OTH VIOLATING REQUIREMENTS OF: GAS PUMPING ASSISTANCE FOR PERSONS WITH DISABILITIES ORDINANCE'
            when 'GENERAL  MAINTENANCE NON RES' then 'NR GENERAL MAINTENANCE OF EQUIPMENT, SYSTEMS DEVICES AND/OR SAFEGAURDS'
            when 'GENERAL MAINTENANCE RES' then 'R GENERAL MAINTENANCE OF EQUIPMENT, SYSTEMS DEVICES AND/OR SAFEGAURDS'
            when 'GENERAL MEANS OF ESCAPE RES' then 'R MEANS OF ESCAPE'
            when 'GENERAL MECHANICAL RES' then 'R GENERAL MECHANICAL-ELECTRICAL REQUIREMENTS'
            when 'GENERAL PERMIT REQUIREMENTS' then notation
            when 'GENERAL PLUMBING' then 'NR GENERAL PLUMBING'
            when 'GENERAL PLUMBING RES' then 'R GENERAL PLUMBING REQUIREMENTS'
            when 'GENERAL STANDARDS NON RES ' then 'NR GENERAL STANDARDS FOR NON RESIDENTIAL STRUCTURES'
            when 'GENERAL STANDARDS RES' then 'R GENERAL STANDARDS FOR DWELLINGS'
            when 'GFCI OUTLETS REQUIRED EXTERIOR' then 'R GFCI PROTECTION'
            when 'GFCI PROTECTION NON RES' then 'NR GFCI PROTECTION'
            when 'GFCI PROTECTION RES' then 'R GFCI PROTECTION'
            when 'GRAFFITI' then notation
            when 'GUARDS NON RES' then 'NR GUARDS'
            when 'GUARDS RES' then 'R GUARDS'
            when 'HAND SANITIZER' then 'R SANITARY CONDITIONS'
            when 'HANDRAILS NON RES' then 'NR HANDRAILS'
            when 'HANDRAILS RES' then 'R HANDRAILS'
            when 'HAZARDOUS CONDITIONS' then notation
            when 'HEATING EQUIPMENT RES' then 'R  HEATING EQUIPMENT (TEMPERATURE)'
            when 'HEATING FACIL RES' then 'R HEATING FACILITIES'
            when 'HEATING INSTALL RES' then 'R HEATING EQUIPMENT INSTALLATION'
            when 'HOME BASED BUS W/O APPRVL' then 'Z HOME BASED BUSINESS [CONDITIONAL USE] W/O APPROVAL'
            when 'HOOKAH - ALCOHOL PROH' then 'OTH HOOKAH - ALCOHOL PROHIBITED'
            when 'HOOKAH - HOURS OF OPER' then 'OTH HOOKAH LOUNGE - HOURS OF OPERATION'
            when 'IMPROPER HOUSING TYPE' then 'Z NON CONFORMING HOUSING TYPE'
            when 'IMPROPER USE OF ZONE' then 'Z IMPROPER USE OF ZONE'
            when 'IMPROPER USE OF ZONE/SITE PLAN' then 'Z IMPROPER USE OF ZONE'
            when 'IMPROPER USE/OCCUPANCY ROW' then 'Z IMPROPER USE / OCCUPANCY OF THE PUBLIC RIGHT OF WAY'
            when 'IMPROPER USE: TOO MANY DWLGS' then 'Z EXCESSIVE DWELLINGS'
            when 'INFESTATION BED BUGS' then 'R INFESTATION OF INTERIOR SPACE (BED BUGS)'
            when 'INFESTATION NON RES' then 'NR INFESTATION OF INTERIOR SPACE'
            when 'INFESTATION RES' then 'R INFESTATION OF INTERIOR SPACE'
            when 'INOPERABLE VEHICLES' then 'PM INOPERABLE VEHICLES'
            when 'INTERIOR DOORS NON RES' then 'NR INTERIOR DOORS'
            when 'INTERIOR FLOORS RES' then 'R INTERIOR FLOORS AND WALLS'
            when 'INTERIOR LIGHT FIXTURE' then 'R INTERIOR LIGHT FIXTURE DEFECTIVE/INOPERATIVE'
            when 'INTERIOR SURFACES NON RES' then 'NR INTERIOR SURFACES'
            when 'INTERIOR SURFACES RES' then 'R INTERIOR SURFACES'
            when 'ITEM 6.11.04 B (Accessory Stru' then 'Z ACCESSORY STRUCTURE: SETBACK'
            when 'ITEM NR10.7.5: DECORATIVE FEAT' then 'R DECORATIVE FEATURES'
            when 'ITEM Z300: RSB GROUP LIVING' then 'Z STANDARDS FOR GROUP LIVING (RSB)'
            when 'KENNEL W/O APPROVALS' then 'Z KENNEL'
            when 'KITCHEN RES' then 'R KITCHEN'
            when 'LANDSCAPING, IRRIGATION AND BU' then 'Z LANDSCAPING, IRRIGATION AND BUFFERING REQUIREMENTS'
            when 'LANSCAPING CONTRACTOR NURSERY' then 'Z LANDSCAPING, IRRIGATION AND BUFFERING REQUIREMENTS'
            when 'LAVATORY AREA RES' then 'R LAVATORY AREA'
            when 'LIGHT AND VENT LAVATOR NON RES' then 'NR LIGHT AND VENTILATION IN LAVATORIES'
            when 'LIGHT AND VENTIL LAVS RES' then 'R LIGHT AND VENTILATION IN LAVATORIES'
            when 'LIGHT IN COMMON HALLS RES' then 'R LIGHT IN COMMON HALLS AND STAIRWAYS'
            when 'LIGHT IN COMMON HALLSNON RES ' then 'NR LIGHT IN COMMON HALLS AND STAIRWAYS'
            when 'LIGHT IN HAB ROOMS RES' then 'R LIGHT IN HABITABLE ROOMS'
            when 'LOCKSMITH SERVICES BUSINESSES' then notation
            when 'MAINTENANCE OF PARKING SURFACE' then 'Z FAILURE TO MAINTAIN PARKING SURFACES'
            when 'MEANS OF ESCAPE RES' then 'R MEANS OF ESCAPE'
            when 'MICROWAVE' then 'R MICROWAVE OVEN DEFECTIVE/INOPERATIVE'
            when 'MINIMUM CEILING RES' then 'R MINIMUM CEILING HEIGHTS'
            when 'MINIMUM ROOM WIDTHS RES' then 'R MINIMUM ROOM WIDTHS'
            when 'MOBILE HOME' then 'Z MOBILE HOME / RV PARK SETBACKS'
            when 'MOBILE HOME/RV PARK SETBACKS' then 'Z MOBILE HOME / RV PARK SETBACKS'
            when 'MOBILE HOMES' then 'Z MOBILE HOME / RV PARK SETBACKS'
            when 'NCU VIOLATION' then notation
            when 'NO PHOTOS' then notation
            when 'NO STAGING VEHICLES' then notation
            when 'NUISANCE CONDITIONS' then 'PM NUISANCE CONDITIONS'
            when 'OPERATION W/O PERMIT' then notation
            when 'OUTSIDE/OPEN STORAGE' then 'Z OUTSIDE/OPEN STORAGE'
            when 'OVERGROWN CONDITIONS' then 'PM OVERGROWTH'
            when 'OVERGROWTH' then 'PM OVERGROWTH'
            when 'OVERHANG EXTENSION RES' then 'R OVERHANG EXTENSIONS'
            when 'OVERHANG EXTENSIONS NON RES' then 'NR OVERHANG EXTENSIONS'
            when 'PARCEL NOT MEETING SIZE' then 'Z PARCEL NOT MEETING SIZE REQUIRMENTS'
            when 'PATH OF TRAVEL RES' then 'R PATH OF TRAVEL'
            when 'PAVING' then 'Z PAVING REQUIREMENTS'
            when 'PLUMBING FIXTURES' then 'R PLUMBING FIXTURE DEFECTIVE'
            when 'PLUMBING LINES' then 'R PLUMBING FIXTURE DEFECTIVE'
            when 'POOL BARRIER ABOVE GROUND' then 'SP POOL BARRIER / ABOVEGROUND POOL STRUCTURES'
            when 'POOL BARRIER ACCESSORIES' then 'SP POOL BARRIER / PLACEMENT OF ACCESSORIES'
            when 'POOL BARRIER EXIT ALARMS' then 'SP EXIT ALARM REQUIREMENTS'
            when 'POOL BARRIER GAPS OVER 4' then 'SP POOL BARRIER / GAPS, OPENINGS, INDENTATIONS, OR PROTRUSIONS'
            when 'POOL BARRIER GATES' then       'SP POOL BARRIER / ACCESS GATES'
            when 'POOL BARRIER HEIGHT' then      'SP POOL BARRIER / HEIGHT'
            when 'POOL BARRIER LATTICE' then     'SP POOL BARRIER / OPENINGS OF LATTICE STYLE FENCE'
            when 'POOL BARRIER MEMBER SPACING' then 'SP POOL BARRIER / GAPS, OPENINGS, INDENTATIONS, OR PROTRUSIONS'
            when 'POOL BARRIER MESH SIZE' then 'SP POOL BARRIER / MESH SIZE'
            when 'POOL BARRIER PLACEMENT' then 'SP POOL BARRIER / PLACEMENT'
            when 'POOL BARRIER PROTRUSIONS' then 'SP PUBLIC POOL BARRIERS'
            when 'POOL BARRIER VERTICAL CLEARANC' then 'SP POOL BARRIER / VERTICAL CLEARANCE'
            when 'POOL DRAIN COVERS' then 'SP DRAIN COVERS'
            when 'POOL EXIT ALARM STANDARDS' then 'SP EXIT ALARM REQUIREMENTS'
            when 'POOL PUBLIC BARRIER' then 'SP PUBLIC POOL BARRIERS'
            when 'POOL SANITATION' then 'SP POOL SANITATION'
            when 'POOL SIGNAGE' then 'SP POOL SIGNAGE'
            when 'POOL UNSECURED' then 'SP PUBLIC POOL BARRIERS'
            when 'PORCH' then 'R STAIRS, PORCHES, AND APPURTENANCES'
            when 'PORTABLE TEMP STORAGE PTSU' then 'Z PORTABLE TEMP STORAGE UNITS'
            when 'POTABLE WATER RES' then 'R POTABLE WATER'
            when 'PRESSURE RELIEF NON RES' then 'NR PRESSURE RELIEF VALVE'
            when 'PRESSURE RELIEF RES' then 'R PRESSURE RELIEF VALVE'
            when 'PRIMARY STRUCTURE SETBACKS' then 'Z PRIMARY STRUCTURE SETBACK'
            when 'PROPERTY AGREEMENT' then notation
            when 'PROTECTIVE TREATMENT NON RES' then 'NR PROTECTIVE TREATMENT'
            when 'PROTECTIVE TREATMENT RES' then 'R PROTECTIVE TREATMENT'
            when 'RAILINGS GEBERAL RES' then 'R GENERAL STANDARDS FOR PROTECTIVE RAILINGS'
            when 'RANGE HOOD' then 'R RANGE HOOD DEFECTIVE/INOPERATIVE'
            when 'RECEPTACLES RES' then 'R RECEPTACLES'
            when 'RECREATIONAL VEHICLES' then 'Z RECREATIONAL VEHICLES'
            when 'REQUIRED SPACE RES' then 'R REQUIRED SPACE, DWELLINGS'
            when 'RESIDENTIAL COLLECTION SERVICE' then 'OTH RESIDENTIAL COLLECTION SERVICE'
            when 'Rights of Way Use Permit' then 'Z DEVELOPMENT IN THE RIGHT OF WAY'
            when 'ROOFS (PARTS THEREOF) RES' then 'R ROOFS AND/OR PARTS THEREOF'
            when 'ROOFS NON RES' then 'NR ROOFS'
            when 'RV / ROW' then 'Z RV/UTILITY TRAILER/PLEASURE CRAFT: ON RIGHT OF WAY'
            when 'RV / SETBACKS' then 'Z MOBILE HOME / RV PARK SETBACKS'
            when 'RV/UTILITY EXCESSIVE' then 'Z LOT NOT MEETING SIZE REQUIREMENTS FOR AVAILABLE UTILITIES'
            when 'SANITARY CONDITIONS RES' then 'R SANITARY CONDITIONS'
            when 'SANITARY FACILIT REQUIRED RES' then 'R SANITARY FACILITIES REQUIRED'
            when 'SANITATION OF PLUMBING NON RES' then 'NR SANITATION OF PLUMBING FIXTURES'
            when 'SANITATION OF PLUMBING RES' then 'R SANITATION OF PLUMBING FIXTURES'
            when 'SCREENS' then 'R SCREENS'
            when 'SCREENS ON WINDOWS RES' then 'R SCREENS'
            when 'SERVICE LACKING: WATER' then 'OTH WATER USE VIOLATION'
            when 'SEWAGE/CLEANOUT CAP MISSING' then 'R SEWAGE/CLEANOUT CAP MISSING, BROKEN OR NOT PROPERLY INSTALLED'
            when 'SEXAULLY ORIENTED BUSINESS' then 'OTH VIOLATING REQUIREMENTS OF THE SEXUALLY ORIENTED BUSINESS'
            when 'SHOPPING CART ORD VIOLATION' then 'OTH VIOLATING REQUIREMENTS OF THE SHOPPING CART ORD'
            when 'SHORT TERM RENTALS' then 'Z SHORT TERM RENTALS - IMPROPER USE OF ZONE'
            when 'SIGN PERMIT / TAG' then 'Z SIGN PERMIT / TAG'
            when 'SIGN SETBACK' then 'Z SIGN SETBACK'
            when 'SIGN: BANNER/PENNANT/STREAMER/' then 'Z SIGN: BANNER / PENNANT / STREAMER / BALLOON'
            when 'SIGN: EXCESSIVE  AREA' then 'Z EXCESSIVE SIGN AREA'
            when 'SIGN: MAINTENANCE OF' then 'Z MAINTENANCE OF SIGNS'
            when 'SIGN: ON ROW' then 'Z PROHIBITED SIGN: ON RIGHT OF WAY'
            when 'SIGN: PERMIT REQUIRED' then 'Z SIGN: PERMIT REQUIRED'
            when 'SIGN: PLACEMENT STANDARDS' then 'Z VIOLATING SIGN PLACEMENT STANDARDS'
            when 'SIGN: PROHIBITED ' then 'Z PROHIBITED SIGN'
            when 'SIGNAGE: EXCESSIVE ' then 'Z EXCESSIVE SIGNAGE'
            when 'SIMULATED GAMBLING DEVICE' then 'OTH UNPERMITTED SIMULATED GAMBLING DEVICE'
            when 'SINK BASE/ CABINETS' then 'R SINK BASE/CABINETS (KITCHEN AND/OR BATH) DAMAGED/DETERIORATED'
            when 'SITE DEVELOPENT PLAN' then 'Z SITE DEVELOPMENT PLAN'
            when 'SITE DEVELOPMENT PLAN REQUIRED' then 'Z SITE DEVELOPMENT REVIEW / PLAN REQUIRED'
            when 'SLEEPING AREAS RES' then 'R SLEEPING AREAS'
            when 'SMOKE DETECTORS RES' then 'R SMOKE DETECTORS'
            when 'SOLID WASTE STORAGE' then 'Z SOLID WASTE STORAGE: SCREENING'
            when 'SPECIAL/COND USE W/O APPROVAL' then 'Z SPECIAL / CONDITIONAL USE WITHOUT APPROVAL'
            when 'STAIRS, PORCHES NON RES' then 'NR STAIRS, PORCHES, AND APPURTENANCES'
            when 'STAIRS, PORCHES, RES' then 'R STAIRS, PORCHES, AND APPURTENANCES'
            when 'STANDARDS FOR RECLAMATION' then 'Z STANDARDS FOR RECLAMATION'
            when 'STRUCTURAL MEMBERS NON RES' then 'NR STRUCTURAL MEMBERS'
            when 'STRUCTURAL MEMBERS RES' then 'R STRUCTURAL MEMBERS'
            when 'STRUCTURAL: ROOF' then 'R ROOFS AND/OR PARTS THEREOF'
            when 'STRUCTURAL: WALLS' then 'R INTERIOR FLOORS AND WALLS'
            when 'STRUCTURE NOT MEETING REQ DWEL' then 'Z NOT MEETING STANDARDS OF A DWELLING'
            when 'STRUCTURE: UNSECURED' then 'PM NUISANCE CONDITIONS: UNSECURED STRUCTURE'
            when 'SUBDIVISION ROW' then 'Z RIGHT OF WAY IMPROVEMENTS/OBSTRUCTIONS WITHIN SUBDIVISIONS'
            when 'SWIMMING POOLS: INFESTATION' then 'NR INFESTATION OF INTERIOR SPACE'
            when 'SWIMMING POOLS: UNSECURE' then 'PM NUISANCE CONDITIONS: UNSECURED STRUCTURE'
            when 'UNPERMITTED STRUCTURE' then 'NR GENERAL STANDARDS FOR NON RESIDENTIAL STRUCTURES'
            when 'UNSANITARY CONDITIONS' then 'R SANITARY CONDITIONS'
            when 'UNSECURED STRUCTURE' then 'PM NUISANCE CONDITIONS: UNSECURED STRUCTURE'
            when 'VAGRANTS/TRANSIENTS' then 'PM VAGRANTS/TRANSIENTS'
            when 'VEHICLE REPAIRS IN RES' then 'Z VEHICLE REPAIRS IN RESIDENTIAL DISTRICTS'
            when 'VEHICLES: INOPERABLE' then 'PM INOPERABLE VEHICLES'
            when 'VEHICLES: PARTS' then 'Z VEHICLE REPAIRS IN RESIDENTIAL DISTRICTS'
            when 'VENDOR CONDITIONS' then 'Z TEMPORARY VENDOR / CONDITIONS OF APPROVAL'
            when 'VENDOR WRONG ZONE' then 'Z IMPROPER USE: VENDOR'
            when 'VENTILATION IN HAB ROOMS RES' then 'R VENTILATION IN HABITABLE ROOMS'
            when 'VIOLATING CONDITION PD' then 'Z VIOLATING CONDITIONS OF APRVL / PLANNED DEVELOPMENT'
            when 'WATER HEATING FACIL RES' then 'R WATER HEATING FACILITIES'
            when 'WATER SUPPLY NON RES' then 'NR WATER SUPPLY'
            when 'WATER SUPPLY RES' then 'R WATER SUPPLY'
            when 'WATER TEMPERATURE RES' then 'R WATER TEMPERATURE RANGE'
            when 'WATER USE VIOLATION' then 'OTH WATER USE VIOLATION'
            when 'WINDOW SASH NON RES' then 'NR WINDOW SASH'
            when 'WINDOW SASH RES' then 'R WINDOW SASH'
            when 'WINDOWS' then 'R WINDOWS AND EXTERIOR DOORS'
            when 'WINDOWS AND EXT DOORS NON RES' then 'NR WINDOWS AND EXTERIOR DOORS'
            when 'WINDOWS AND EXT DOORS RES' then 'R WINDOWS AND EXTERIOR DOORS'
            when 'YARD SALE EXCESSIVE' then 'Z EXCESSIVE YARD SALE'
            else null
            end
        ) as type_of_complaint
        ,replace(replace(replace(replace(
            (case 
                when CHARINDEX('ACTION REQUIRED: ',the_text) > 0
                then SUBSTRING(the_text,1,CHARINDEX('ACTION REQUIRED: ',the_text)-1)
                else the_text
                end
        ),'"',''''''),'''',''),char(13),''),char(10),'�') as description_of_legal_code
        ,trim(' _�' from
            replace(replace(replace(replace(
                replace(
                    case when CHARINDEX('ACTION REQUIRED: ',the_text) <> 0 then substring(the_text,CHARINDEX('ACTION REQUIRED: ',the_text),len(the_text)) else null end
                    ,'ACTION REQUIRED: '
                    ,''
                )
            ,'"',''''''),'''',''),char(13),''),char(10),'�')
        ) as action_required
        ,v.any_comments as officers_comments
        ,(case when approved = 'Y' then 'Yes' else 'No' end) as compliant
        ,(case when approved='Y' then the_date else null end) as compliance_date
    --into cl_complaints
    from #violations_ce_customLists_violations v
    join jms_numberKey_permitnum pmap on pmap.number_key = v.NUMBER_KEY
    join aatable_permit_history pnum on pnum.permitnum = pmap.permitnum
)
select
	*
	,ROW_NUMBER() OVER(PARTITION BY pnum.permitnum order by pnum.date_added) AS row_num
into cl_complaints
from g pnum
;
alter table cl_complaints alter column date_added datetime
alter table cl_complaints alter column date_added date
alter table cl_complaints alter column compliance_date datetime
alter table cl_complaints alter column compliance_date date
;
go

--select 
update a set 
	compliance_date = convert(varchar(10),compliance_date)
from cl_complaints a
;

--verify
if 1 = (
	select distinct 1
	from (
        SELECT
            a.permitnum 
            ,a.ct_a
            ,b.ct_b
        from (
            select 
                pmap.permitnum
                ,count(distinct a.item_id) ct_a
                --,a.*
            from hcfl_src..apd_itms a 
            join jms_apd_insp_filteredToPop f on f.number_key = a.number_key
            join jms_numberKey_permitnum pmap on pmap.number_key = a.NUMBER_KEY
            WHERE
                1=1
                and a.record_type = 'CD'
                and a.NUMBER_KEY = 'WR2102935'
            group by pmap.permitnum
        ) a --violations_per_numberKey 
        left join (
            select 
                a.permitnum
                ,max(a.row_num) ct_b
            from cl_complaints a 
            group by a.permitnum
        ) b on b.permitnum = a.permitnum  --captured_violations
        WHERE
            1=1
            and a.ct_a <> b.ct_b
    ) z
) RAISERROR ('cl_complaints: there is a violation count mismatch between source and what was captured', 16, 1)
;

--meeting on 20240525.txt - Violation not reliably carring over from CE to CE-CBS record
;IF OBJECT_ID('hcfl_prod.dbo.cl_complaints_cbs', 'U') IS NOT NULL drop table cl_complaints_cbs
go
select
	 b.permitnum
	,'Citizen Board Support' tt_record
	,a.date_added
	,a.type_of_complaint
	,a.description_of_legal_code
	,a.action_required
	,a.officers_comments
	,a.compliant
	,a.compliance_date
	,a.row_num
into cl_complaints_cbs
from cl_complaints a
join AATABLE_PERMIT_HISTORY b on b.PERMITNUM = a.permitnum + '-CBS'
where 
	1=1
	--and a.permitnum = 'CE19016563'
;


go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0180 0100 0150 custom lists cbs feeCalculation.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0180 0100 0150 custom lists cbs feeCalculation.sql')
--cbs
;IF OBJECT_ID('tempdb.dbo.#hbcode4_aatablePermitFeeSetup', 'U') IS NOT NULL drop table #hbcode4_aatablePermitFeeSetup
;
select distinct
	 pnum.permitnum
    ,pnum.tt_record
    
	,'xx' [1]
	,n0.Date_080 as dtPart1           
	,m0.Mon_037 as curPart1          
	,n0.Date_086 as dtPart1Start      
	,n0.Date_090 as dtPart1End        
	,t0.Text_019 as strOrderPart1     
	,m0.Mon_041 as curPart1Sub     
	,(datediff(day,n0.Date_086 , coalesce(n0.Date_090,getdate()) )  ) * m0.mon_037 curPart1Sub_calc
	
	,'xx' [2]
	,n0.Date_081 as dtPart2           
	,m0.Mon_038 as curPart2          
	,n0.Date_087 as dtPart2Start      
	,n0.Date_091 as dtPart2End        
	,t0.Text_024 as strOrderPart2     
	,m0.Mon_042 as curPart2Sub       
	,(datediff(day,n0.Date_087 , coalesce(n0.Date_091,getdate()) )  ) * m0.Mon_038 curPart2Sub_calc
	
	,'xx' [3]
	,n0.Date_082 as dtPart3           
	,m0.Mon_039 as curPart3          
	,n0.Date_088 as dtPart3Start          
	,n0.Date_092 as dtPart3End     
	,t0.Text_025 as strOrderPart3     
	,m0.Mon_043 as curPart3Sub       
	,(datediff(day,n0.Date_088 , coalesce(n0.Date_092,getdate()) )  ) * m0.Mon_039 curPart3Sub_calc
	
	,'xx' [4]
	,n0.Date_083 as dtPart4           
	,m0.Mon_040 as curPart4     
	,n0.Date_089 as dtPart4Start   
	,n0.Date_093 as dtPart4End      
	,t0.Text_028 as strOrderPart4     
	,m0.Mon_044 as curPart4Sub       
	,(datediff(day,n0.Date_089 , coalesce(n0.Date_093,getdate()) )  ) * m0.Mon_040 curPart4Sub_calc
	   
into #hbcode4_aatablePermitFeeSetup
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum+'-cbs' = pnum.PERMITNUM
join jms_apd_base_filtered a on a.NUMBER_KEY = pmap.number_key
join hcfl_src.dbo.apd_mon0 m0 on m0.NUMBER_KEY = a.NUMBER_KEY
left join hcfl_src.dbo.apd_num0 n0 on n0.number_key = a.number_key
left join hcfl_src.dbo.apd_txt0 t0 on t0.number_key = a.number_key
where
	1=1
	and pnum.permitnum like'%-cbs'
    --and pmap.number_key = 'CE11005977'
;

;IF OBJECT_ID('hcfl_prod.dbo.cl_cbs_feeCalculation', 'U') IS NOT NULL drop table cl_cbs_feeCalculation
;
with g as (
    select distinct
        pnum.permitnum
        ,pnum.tt_record
        
        ,'Part I' as order_part 
        ,dtPart1 onOrBeforeDate
        ,curPart1 fineAmount
        ,strOrderPart1 orderText
        ,dtPart1Start startDate
        ,dtPart1End endDate
        --,curPart1Sub subtotal
        ,curPart1Sub_calc subtotal
        ,(case when dtPart1End is null then 'Yes' else 'No' end) addFee
    from #hbcode4_aatablePermitFeeSetup pnum
    WHERE
        1=1
        and dtpart1 is not null

    UNION

    select distinct
        pnum.permitnum
        ,pnum.tt_record
        
        ,'Part II' as order_part 
        ,dtPart2 onOrBeforeDate
        ,curPart2 fineAmount
        ,strOrderPart2 orderText
        ,dtPart2Start startDate
        ,dtPart2End endDate
        --,curPart2Sub subtotal 
        ,curPart2Sub_calc subtotal
        ,(case when dtPart2End is null then 'Yes' else 'No' end) addFee
    from #hbcode4_aatablePermitFeeSetup pnum
    WHERE
        2=2
        and dtpart2 is not null

    UNION

    select distinct
        pnum.permitnum
        ,pnum.tt_record
        
        ,'Part III' as order_part 
        ,dtPart3 onOrBeforeDate
        ,curPart3 fineAmount
        ,strOrderPart3 orderText
        ,dtPart3Start startDate
        ,dtPart3End endDate
        --,curPart3Sub subtotal
        ,curPart3Sub_calc subtotal
        ,(case when dtPart3End is null then 'Yes' else 'No' end) addFee
    from #hbcode4_aatablePermitFeeSetup pnum
    WHERE
        3=3
        and dtpart3 is not null

    UNION

    select distinct
        pnum.permitnum
        ,pnum.tt_record
        
        ,'Part IV' as order_part 
        ,dtPart4 onOrBeforeDate
        ,curPart4 fineAmount
        ,strOrderPart4 orderText
        ,dtPart4Start startDate
        ,dtPart4End endDate
        --,curPart4Sub subtotal 
        ,curPart4Sub_calc subtotal
        ,(case when dtPart4End is null then 'Yes' else 'No' end) addFee
    from #hbcode4_aatablePermitFeeSetup pnum
    WHERE
        4=4
        and dtpart4 is not null

)
select
	 pnum.permitnum
    ,pnum.tt_record
    
    ,pnum.order_part
    ,convert(varchar(10),pnum.onOrBeforeDate,101) onOrBeforeDate
    ,pnum.fineAmount
    ,pnum.orderText
    ,convert(varchar(10),pnum.startDate,101) startDate
    ,convert(varchar(10),pnum.endDate,101) endDate
    ,pnum.subtotal
    ,pnum.addFee
	,ROW_NUMBER() OVER(PARTITION BY pnum.permitnum order by pnum.permitnum) AS row_num
into cl_cbs_feeCalculation
from g pnum
where
	1=1
    --and permitnum = 'CE11005977-CBS'
;

go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0180 related_records.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0100 hbcode4_rcdapp1\0180 related_records.sql')
/*

*/


;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_PROJECTS
;
insert into AATABLE_PERMIT_PROJECTS (
PARENTACTIVITYNUM,CHILDACTIVITYNUM,RELATIONSHIP,STATUS
)   
--general_programs
SELECT
     replace(a.permitnum,'-CBS','') as PARENTACTIVITYNUM
    ,a.permitnum as CHILDACTIVITYNUM 
    ,'R' relationship
    ,null status
FROM aatable_permit_history a
WHERE
    1=1
    and right(a.permitnum,4) = '-CBS'
    and a.permitnum like '%-CBS'
;


go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0000 0000 0000 edits.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0000 0000 0000 edits.sql')
--apostraphe--officer's comments
;update R2CHCKBOX set R1_CHECKBOX_DESC = 'Officer�s Comments' where R1_CHECKBOX_DESC = 'Officer''s Comments'
;


go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0040 aatable_permit_history.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0040 aatable_permit_history.sql')
/*
I need to square up the comp_type,version to the specific actual accela record types.
rem: refer to permitHistory_setup
do I need to instantiate records for the citizens board hearing idea? Client expects double records. But do I then double the information, and the charges? Is CBS record effectively a dummy record, related to its parent?

regular history
cbs instantiation
*/



--regular history
;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_HISTORY
;
insert into aatable_permit_history
select distinct
    trim(a.number_key) as permitnum
    ,null as CONTRACTOR_VALUATION
    ,coalesce(a.entered_date,'1900-01-01 00:00:00') as DATEOPENED
    ,null as Expiration_date --,permit_info.date_123 as Expiration_date
    ,null as app_status
    ,coalesce(trim(left(replace(replace(     convert(varchar(max),d.description)    ,char(10),''),char(13),''),4000)),'Not Set') as work_desc --,left(replace(replace( coalesce(  convert(varchar(max),comp_type.description)    ,convert(varchar(max),a.type_title)    ) + isnull(' - '+convert(varchar(max),d.description),'') ,char(10),''),char(13),''),4000)  as work_desc
    ,trim(coalesce(App_Name.name,'Not Set')) as App_Name
    ,a.house_cnt as House_Count
    ,a.bld_cnt as Building_Count
    ,null as Public_Owned
    ,null as Const_Type_Code
    ,null as short_notes --,isnull(a.sub_type,'')+isnull(';'+a.location,'') as short_notes --facname.text_010 as Short_Notes
    ,null as asgn_dept --,a.status_class as Asgn_Dept
    ,null as asgn_staff --,coalesce(asgn_staff.user_name,a.insp_area,'Not Set') as Asgn_Staff
    ,null asgn_date --,a.date_a as Asgn_Date --Populates the first visit date, and store for history
    ,null as Completed_Dept
    ,null as Completed_By
    ,a.date_f as Completed_Date --date_f --The �Closing� date of the record
    ,null as scheduled_date --a.date_k as Scheduled_Date --The �Due� date for the next inspection ----https://redmine.scubeenterprise.com/issues/19564
    ,null as Priority
    ,null as Total_Job_Cost
    ,a.date_f as Closed_Date --date_f --The �Closing� date of the record
    ,null as closed_by --,case when a.date_f is null then null else coalesce(asgn_staff.user_name,a.insp_area,'Not Set') end as Closed_By
    ,null as VR_Tracking_Num
    ,null as created_by --,coalesce(created_by.user_name,a.user_id,'Not Set') as Created_By
    ,null as Reported_Channel
    ,null Created_By_Dept --,'Code Enforcement' as Created_By_Dept
    ,null as first_issued_date --,permit_info.date_122 as First_Issued_Date --an assumption based on HBCODE_DATA.pdf
    ,null as Anonymous_Flag
    ,null as Reference_Type
    ,null as Appearance_Dayofweek
    ,null as Appearance_Date
    ,null as Booking_Flag
    ,null as Defendant_Signature_Flag
    ,null as Enforce_Officer_ID
    ,null as Enforce_Officer_Name
    ,null as Infraction_Flag
    ,null as Inspector_ID
    ,null as Misdemeanor_Flag
    ,null as Offence_Witnessed_Flag
    ,null as Inspector_Name
    ,null as Enforce_Dept
    ,null as Inspector_Dept
    ,null as Valuation_Multiplier
    ,null as Valuation_Extra_Amt
    ,null as Last_Audit_Date
    ,try_convert(datetime,f.entered_date_max) as App_Status_Date
    ,null as Delegate_User_ID
    ,a.data_status as TT_Record_Status
    ,(case when a.SUB_TYPE in ('RTN','SWEEP') then f.tt_record + ' - Proactive' else f.tt_record end) as tt_record
    ,0 as Balance
    ,0 as Total_Fee
    ,0 as Total_Pay
    ,null as Last_Update_By
    ,null as Last_Update_Date
from jms_apd_base_filtered__wrviol1 a --hcfl_src.dbo.apd_base a
join jms_pre_aatablePermitHistory_filter__wrviol1 f on f.NUMBER_KEY = a.NUMBER_KEY
left join jms_permit_info__wrviol1 permit_info on permit_info.number_key = a.number_key 
left join jms_comp_type__wrviol1 comp_type on comp_type.version = a.version and comp_type.comp_type = a.comp_type
left join hcfl_src.dbo.apd_desc d on d.number_key = a.number_key
left join jms_numberKey_primaryOrdering__wrviol1 app_name on app_name.number_key = a.NUMBER_KEY
--left join jms_facname__wrviol1 facname on facname.number_key = a.number_key -- all null
left join jms_userid_username__wrviol1 created_by on created_by.user_id = a.user_id
left join jms_userid_username__wrviol1 asgn_staff on asgn_staff.user_id = a.insp_area
where
    1=1
;

--cbs instantiation
;with cbs_records_cte as (
    select distinct
        a.number_key
    from jms_apd_base_filtered__wrviol1 a 
    join hcfl_src..apd_num0 n0 on n0.number_key = a.number_key
    where 
        1=1
        and n0.Date_075 is not null
)
insert into AATABLE_PERMIT_HISTORY
select distinct
    trim(a.number_key)+'-CBS' as permitnum
    ,null as CONTRACTOR_VALUATION
    ,coalesce(a.date_g,a.entered_date,'1900-01-01 00:00:00') as DATEOPENED --date_g=hearing date
    ,null as Expiration_date --permit_info.date_123 as Expiration_date
    ,null as Expiration_Status
    ,left(replace(replace(     convert(varchar(max),d.description)    ,char(10),''),char(13),''),4000)  as work_desc --,left(replace(replace( coalesce(  convert(varchar(max),comp_type.description)    ,convert(varchar(max),a.type_title)    ) + isnull(' - '+convert(varchar(max),d.description),'') ,char(10),''),char(13),''),4000)  as work_desc
    ,coalesce(App_Name.name,'') as App_Name
    ,a.house_cnt as House_Count
    ,a.bld_cnt as Building_Count
    ,null as Public_Owned
    ,null as Const_Type_Code
    ,null as short_notes --,isnull(a.sub_type,'')+isnull(';'+a.location,'') as short_notes --facname.text_010 as Short_Notes
    ,null as asgn_dept --,a.status_class as Asgn_Dept
    ,coalesce(asgn_staff.user_name,a.insp_area,'Not Set') as Asgn_Staff
    ,a.Date_H as Asgn_Date --date_h=Date of Board order%%
    ,null as Completed_Dept
    ,null as Completed_By
    ,a.date_i as Completed_Date --date_i=Date of affidavit execution**
    ,case when a.date_D > a.date_i then null else a.date_d end as Scheduled_Date --date_d=Hearing date for the specified record%%
    ,null as Priority
    ,null as Total_Job_Cost
    ,a.date_f as Closed_Date --date_f --The �Closing� date of the record
    ,null as closed_by --,case when a.date_f is null then null else coalesce(asgn_staff.user_name,a.insp_area,'Not Set') end as Closed_By
    ,null as VR_Tracking_Num
    ,null as created_By --,coalesce(created_by.user_name,a.user_id,'Not Set') as Created_By
    ,null as Reported_Channel
    ,null as created_by_dept --,'Code Enforcement' as Created_By_Dept
    ,null as First_Issued_Date --,permit_info.date_122 as First_Issued_Date --an assumption based on HBCODE_DATA.pdf
    ,null as Anonymous_Flag
    ,null as Reference_Type
    ,null as Appearance_Dayofweek
    ,null as Appearance_Date
    ,null as Booking_Flag
    ,null as Defendant_Signature_Flag
    ,null as Enforce_Officer_ID
    ,null as Enforce_Officer_Name
    ,null as Infraction_Flag
    ,null as Inspector_ID
    ,null as Misdemeanor_Flag
    ,null as Offence_Witnessed_Flag
    ,null as Inspector_Name
    ,null as Enforce_Dept
    ,null as Inspector_Dept
    ,null as Valuation_Multiplier
    ,null as Valuation_Extra_Amt
    ,null as Last_Audit_Date
    ,try_convert(datetime,f.entered_date_max) as App_Status_Date
    ,null as Delegate_User_ID
    ,a.data_status as TT_Record_Status
    ,'Citizen Board Support Water Enforcement' --f.tt_record
    ,0 as Balance
    ,0 as Total_Fee
    ,0 as Total_Pay
    ,null as Last_Update_By
    ,null as Last_Update_Date
from jms_apd_base_filtered__wrviol1 a --hcfl_src.dbo.apd_base a
join jms_pre_aatablePermitHistory_filter__wrviol1 f on f.NUMBER_KEY = a.NUMBER_KEY
join cbs_records_cte ff on ff.numbeR_key = a.number_key
left join jms_permit_info__wrviol1 permit_info on permit_info.number_key = a.number_key 
left join jms_comp_type__wrviol1 comp_type on comp_type.version = a.version and comp_type.comp_type = a.comp_type
left join hcfl_src.dbo.apd_desc d on d.number_key = a.number_key
left join jms_numberKey_primaryOrdering__wrviol1 app_name on app_name.number_key = a.NUMBER_KEY
--left join jms_facname__wrviol1 facname on facname.number_key = a.number_key -- all null
left join jms_userid_username__wrviol1 created_by on created_by.user_id = a.user_id
left join jms_userid_username__wrviol1 asgn_staff on asgn_staff.user_id = a.insp_area
where
    1=1
;







;update aatable_permit_history set Asgn_Staff = 'Spriggs, Teddy' where Asgn_Staff = 'Spriggs, Edward ''Teddy'''
;


----debug
--delete from aatable_permit_history where permitnum not in (
--    ''
--    --,'WR2301110'
--    --,'WR2301110-CBS'
--    --,'WR1700107'
--    --,'WR1700107-CBS'
--    --,'WR2301331'
--    --,'WR2001217'
--    --,'WR2001217-CBS'
--)
--;
--


go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0060 0020 aatable_permit_inspection setup.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0060 0020 aatable_permit_inspection setup.sql')
/*
setup to get any orphaned rows (rows without some kind of site visit preceding them)
    setup parents
    setup is_initial_site_visit
    setup g
    which number_key values have orphaned inspection rows?
    setup orphan parents
NOW REDO ABOVE LOGIC AND USE REMAINING LOGIC
    (determine child rows per inspection, then assert inspection type and inspection result based on those children)
    create parents
    create is_initial_site_visit
    create g
    create h
    create violations
    VERIFY the above
ensure no duplicates
*/


--setup to get any orphaned rows (rows without some kind of site visit preceding them)
/* SET UP:
I found 511 unique_key values in apd_insp that dont have a preceding site visit. 
So I run the logic, identify those without the preceding SV et al, then add them to my apd_insp.
*/


;delete from jms_apd_insp_filteredToPop__wrviol1 where unique_key like 'ORPH-%'

--determine child rows per inspection, then assert inspection type and inspection result based on those children
;IF OBJECT_ID('tempdb.dbo.#parents', 'U') IS NOT NULL drop table #parents
;IF OBJECT_ID('tempdb.dbo.#is_initial_site_visit', 'U') IS NOT NULL drop table #is_initial_site_visit
;IF OBJECT_ID('tempdb.dbo.#g', 'U') IS NOT NULL drop table #g
;IF OBJECT_ID('tempdb.dbo.#orphaned', 'U') IS NOT NULL drop table #orphaned
;IF OBJECT_ID('tempdb.dbo.#h', 'U') IS NOT NULL drop table #h
;IF OBJECT_ID('tempdb.dbo.#violations', 'U') IS NOT NULL drop table #violations
;
go

--setup parents
--;with parents
    --assumes inspections are site visits, and results are implied by the subsequent rows prior to the following site visit.
	select
		number_key
		,unique_key
		,date_ent
		,the_Date
		,action_ent
    into #parents
	from jms_apd_insp_filteredToPop__wrviol1
	where action_ent in ('SV','SSV','QCSV','LSV')
	--and number_key = 'CE18015425'
;
--setup is_initial_site_visit
--), is_initial_site_visit as (
    --"initial site visiit" is an accela inspection type
	select
		b.UNIQUE_KEY
        ,b.action_ent
    into #is_initial_site_visit
	from jms_apd_base_filtered__wrviol1 a
	outer apply (select top 1 * from jms_apd_insp_filteredToPop__wrviol1 where NUMBER_KEY = a.NUMBER_KEY and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent,the_date) b
;
--setup g
--),g as (
    select
        a.number_key
        ,a.item_id
        ,a.unique_key
        ,a.action_ent
        ,action_ent.DESCRIPTION action_ent_desc
        ,case when is_initial_site_visit.UNIQUE_KEY is not null then 1 else 0 end as is_initial_site_visit
        ,'xxxx' [ ]
        ,coalesce(b.unique_key,is_initial_site_visit.unique_key) parent_unique_key
        ,b.action_ent parent_action_ent
        ,(case 
            when is_initial_site_visit.UNIQUE_KEY is not null then 'Initial Site Visit'
            when a.ACTION_ENT in ('QCSV','LSV') then 'Quality Control Inspection'
            when  a.any_comments like '%re%inspect%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%re%check%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%annual%insp%'    then 'Annual Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%post%hearing%'    then 'Post-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%pre%hearing%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%hear%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%follow%up%'    then 'Follow-up Inspection' --I don't know about pre vs post hearing
            else 'Inspection'
            end		
        ) as inspection_type
        ,(case 
            --when a.ACTION_ENT in ('SV','SSV','QCSV','LSV') then null
            when a.action_ent in ('CERT','DFLT') then 'Issue Citation' --CERT = issue citation
            when a.action_ent in ('CRTY') then 'Issue Warning' --CRTY = warning (courtesy) 
            when a.action_ent in ('CNCL') then 'Cancel'
            --when a.action_ent in ('STLS','STLO') then 'Extension'
            --when a.action_ent in ('ADMN','CREV','NREV') then 'No Violation' --Move this to time accounting? Associate with inspection? I put ADMN here cuz it is not a violation or similar
            --when a.action_ent in ('AP','CMP','COMP') then 'Approved' --maybe "complied"
            --when a.action_ent in ('AFFN','DFLT','ACOM') then 'Disapproved' -- ACOM seemed to all be problems
		
			when a.any_comments like '%created in err%' then 'Cancel' --CNCL
            when a.any_comments like '%CLNO%' then 'No Violation' --yes
            when a.any_comments like '%no viol%' then 'No Violation' --yes 
            when a.any_comments like '%courtesy notice%' then 'Issue Warning'

			--when a.any_comments like '%warn%' then 'Issue Warning'
            --when a.any_comments like '%POST%PROP%' then 'Issue Warning' --post would mean we are getting it ready for a hearing
            --when a.any_comments like '%DOOR%HANG%' then 'Issue Warning' --doesnt necessarily mean a warning is issued; it means we're gonna come back
            --when a.any_comments like '%hand%deliv%' then 'Issue Citation' --could definitely be issue cit
            --when a.any_comments like '%watering days%' then 'Issue Citation' --could be citation or warning
            --when a.any_comments like '%post%' then 'Issue Citation' --sure ok
            --when a.any_comments like '%property was found%' then 'Issue Citation' --not necessarily. Could be a warning.
            --when a.any_comments like '%watering %' then 'Issue Citation' --not necessarily. Could be a warning.
            --when a.any_comments like '%irrigation%restr%' then 'Issue Citation' --not necessarily. Could be a warning
            else 'No Violation'
            end
        ) as inspection_result
        
        ,'xxxx' [2]
        ,a.date_ent
        ,a.the_date
        ,'xxxx'[3]
        ,a.any_comments
    into #g
    from jms_apd_insp_filteredToPop__wrviol1 a
    outer apply (select top 1 * from #parents where number_key = a.number_key and the_date <= a.the_date and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent desc,the_date desc) b
    left join jms_actionEnt_passFail__wrviol1 action_ent on action_ent.action_ent = a.action_ent
    left join #is_initial_site_visit is_initial_site_visit on is_initial_site_visit.UNIQUE_KEY = a.UNIQUE_KEY
    where
        1=1
        --and a.action_ent not in ('SV','SSV','QCSV','LSV')
        --and a.number_key = 
        --	--'CE03003081'
        --	--'CE22014264'
        --	'CE22014971'
    --order by --a.date_ent,a.the_Date,case when a.action_ent in ('SV','SSV','QCSV','LSV') then 1 else 2 end, l.THE_TEXT
    --	a.UNIQUE_KEY
;

----which number_key values have orphaned inspection rows?
--select 
--	a.NUMBER_KEY
--	,a.parent_unique_key
--	,count(b.number_key) ct
--    
--into #orphaned
--from #g a
--left join hcfl_src..apd_itms b 
--	on b.RECORD_TYPE = 'CD'
--	and b.NUMBER_KEY = a.NUMBER_KEY
--	and year(b.THE_DATE) = year(a.the_date) and month(b.THE_DATE) = month(a.the_date) and day(b.THE_DATE) = day(a.THE_DATE)
--	and b.ITEM_ID = a.ITEM_ID
--where
--	b.NUMBER_KEY is not null
--    and a.parent_unique_key is null
--group by a.numbeR_key,a.parent_unique_key
--;
select 
	a.NUMBER_KEY
	,a.UNIQUE_KEY
    
into #orphaned
from #g a
where
	a.parent_unique_key is null
;

--setup orphan parents
--;delete from jms_apd_insp_filteredToPop__wrviol1 where unique_key like 'ORPH-%' --moved up top. Otherwise, can on alternating conversions yield nothing, while deleting the relevant records.
;
insert into jms_apd_insp_filteredToPop__wrviol1
SELECT distinct
     f.NUMBER_KEY
    ,'A' DATA_LEVEL
    ,'IN' RECORD_TYPE
    ,'14320' ITEM_ID
    ,'ORPH-' + convert(varchar(max),row_number() over(order by f.number_key) ) unique_key 
    ,null INSPECTOR
    ,null USER_ID
    ,'KE' ENTRY_METHOD
    ,null REMOTE_USER_ID
    ,min(a.date_ent) DATE_ENT
    ,'SV' ACTION_ENT
    ,'N' APPROVAL
    ,min(a.THE_DATE) the_date
    ,null BEG_TIME
    ,null END_TIME
    ,null TOTAL_TIME
    ,0 VIOLATIONS
    ,null MILAGE
    ,convert(varchar(max),a.ANY_COMMENTS) any_comments
    ,'14320' ITEM_NO
    ,null REQUEST_ID
    ,null BEG_MILEAGE
    ,null END_MILEAGE
    ,null VEHICLE_ID
    ,null SUBMIT_TIME
    ,null SUBMIT_DATE
from #orphaned f --on f.number_key = a.number_key
outer apply (select top 1 * from jms_apd_insp_filteredToPop__wrviol1 where number_key = f.number_key order by the_date,date_ent) a
WHERE
    1=1
group by f.NUMBER_KEY,convert(varchar(max),a.ANY_COMMENTS)
;

-----------------------
--NOW REDO ABOVE LOGIC AND USE REMAINING LOGIC
-----------------------

--determine child rows per inspection, then assert inspection type and inspection result based on those children
;IF OBJECT_ID('tempdb.dbo.#parents', 'U') IS NOT NULL drop table #parents
;IF OBJECT_ID('tempdb.dbo.#is_initial_site_visit', 'U') IS NOT NULL drop table #is_initial_site_visit
;IF OBJECT_ID('tempdb.dbo.#g', 'U') IS NOT NULL drop table #g
;IF OBJECT_ID('tempdb.dbo.#orphaned', 'U') IS NOT NULL drop table #orphaned
;IF OBJECT_ID('tempdb.dbo.#h', 'U') IS NOT NULL drop table #h
;IF OBJECT_ID('tempdb.dbo.#violations', 'U') IS NOT NULL drop table #violations
;IF OBJECT_ID('tempdb.dbo.#req_opt', 'U') IS NOT NULL drop table #req_opt
;
go

--create parents
--;with parents
    --assumes inspections are site visits, and results are implied by the subsequent rows prior to the following site visit.
	select
		number_key
		,unique_key
		,date_ent
		,the_Date
		,action_ent
    into #parents
	from jms_apd_insp_filteredToPop__wrviol1
	where action_ent in ('SV','SSV','QCSV','LSV')
	--and number_key = 'CE18015425'
;
--create is_initial_site_visit
--), is_initial_site_visit as (
    --"initial site visiit" is an accela inspection type
	select
		b.UNIQUE_KEY
        ,b.action_ent
    into #is_initial_site_visit
	from jms_apd_base_filtered__wrviol1 a
	outer apply (select top 1 * from jms_apd_insp_filteredToPop__wrviol1 where NUMBER_KEY = a.NUMBER_KEY and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent,the_date) b
;
--create g
--),g as (
    select
        a.number_key
        ,a.item_id
        ,a.unique_key
        ,a.action_ent
        ,action_ent.DESCRIPTION action_ent_desc
        ,case when is_initial_site_visit.UNIQUE_KEY is not null then 1 else 0 end as is_initial_site_visit
        ,'xxxx' [ ]
        ,coalesce(b.unique_key,is_initial_site_visit.unique_key) parent_unique_key
        ,b.action_ent parent_action_ent
        ,(case 
            when is_initial_site_visit.UNIQUE_KEY is not null then 'Initial Site Visit'
            when a.ACTION_ENT in ('QCSV','LSV') then 'Quality Control Inspection'
            when  a.any_comments like '%re%inspect%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%re%check%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%annual%insp%'    then 'Annual Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%post%hearing%'    then 'Post-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%pre%hearing%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%hear%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%follow%up%'    then 'Follow-up Inspection' --I don't know about pre vs post hearing
            else 'Inspection'
            end		
        ) as inspection_type
        ,(case 
            --when a.ACTION_ENT in ('SV','SSV','QCSV','LSV') then null
            when a.action_ent in ('CERT','DFLT') then 'Issue Citation' --CERT = issue citation
            when a.action_ent in ('CRTY') then 'Issue Warning' --CRTY = warning (courtesy) 
            when a.action_ent in ('CNCL') then 'Cancel'
            --when a.action_ent in ('STLS','STLO') then 'Extension'
            --when a.action_ent in ('ADMN','CREV','NREV') then 'No Violation' --Move this to time accounting? Associate with inspection? I put ADMN here cuz it is not a violation or similar
            --when a.action_ent in ('AP','CMP','COMP') then 'Approved' --maybe "complied"
            --when a.action_ent in ('AFFN','DFLT','ACOM') then 'Disapproved' -- ACOM seemed to all be problems
		
			when a.any_comments like '%created in err%' then 'Cancel' --CNCL
            when a.any_comments like '%CLNO%' then 'No Violation' --yes
            when a.any_comments like '%no viol%' then 'No Violation' --yes 
            when a.any_comments like '%courtesy notice%' then 'Issue Warning'

			--when a.any_comments like '%warn%' then 'Issue Warning'
            --when a.any_comments like '%POST%PROP%' then 'Issue Warning' --post would mean we are getting it ready for a hearing
            --when a.any_comments like '%DOOR%HANG%' then 'Issue Warning' --doesnt necessarily mean a warning is issued; it means we're gonna come back
            --when a.any_comments like '%hand%deliv%' then 'Issue Citation' --could definitely be issue cit
            --when a.any_comments like '%watering days%' then 'Issue Citation' --could be citation or warning
            --when a.any_comments like '%post%' then 'Issue Citation' --sure ok
            --when a.any_comments like '%property was found%' then 'Issue Citation' --not necessarily. Could be a warning.
            --when a.any_comments like '%watering %' then 'Issue Citation' --not necessarily. Could be a warning.
            --when a.any_comments like '%irrigation%restr%' then 'Issue Citation' --not necessarily. Could be a warning
            else 'No Violation'
            end
        ) as inspection_result
        ,'xxxx' [2]
        ,a.date_ent
        ,a.the_date
        ,'xxxx'[3]
        ,a.any_comments
    into #g
    from jms_apd_insp_filteredToPop__wrviol1 a
    outer apply (select top 1 * from #parents where number_key = a.number_key and the_date <= a.the_date and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent desc,the_date desc) b
    left join jms_actionEnt_passFail__wrviol1 action_ent on action_ent.action_ent = a.action_ent
    left join #is_initial_site_visit is_initial_site_visit on is_initial_site_visit.UNIQUE_KEY = a.UNIQUE_KEY
    where
        1=1
        --and a.action_ent not in ('SV','SSV','QCSV','LSV')
        --and a.number_key = 
        --	--'CE03003081'
        --	--'CE22014264'
        --	'CE22014971'
    --order by --a.date_ent,a.the_Date,case when a.action_ent in ('SV','SSV','QCSV','LSV') then 1 else 2 end, l.THE_TEXT
    --	a.UNIQUE_KEY
;



















--create h
--), h as (
    select distinct
         a1.NUMBER_KEY
        ,a1.UNIQUE_KEY
        ,a1.action_ent
        ,a1.inspection_type
        ,coalesce(b.inspection_result,a1.inspection_result,'Not Set') inspection_result
        ,trim('^|' from stuff((
            select 
                '^|^' + cast(
                    trim(replace(replace(replace(replace(   isnull(a2.any_comments,'')   ,'"',''''''),'''',''),char(13),''),char(10),'�')) 
                    as varchar(max)
                )
            from #g a2 with(nolock)
            where 
                a2.parent_unique_key = a1.parent_unique_key
            group by a2.any_comments
            order by a2.any_comments
            FOR XML PATH('')
         ), 1, 1, '')) as any_comments
    into #h
    from #g a1
    outer apply (
        select top 1 *
        from #g
        where
            parent_unique_key = a1.UNIQUE_KEY
            and inspection_result is not null
        order by case inspection_result when 'Cancel' then 1 when 'Issue Citation' then 2 when 'Issue Warning' then 3 when 'No Violation' then 4 else 5 end
    ) b
    where
        1=1
        and a1.ACTION_ENT in ('SV','SSV','QCSV','LSV')
        --and a1.number_key = 'CE17015692'
    ;

    --order by a.UNIQUE_KEY
--)
;
--create violations
--;with cte_violations as (
;with lesser_dates as (
	select 
		 b.number_key
		,b.sequence
		,b.item_id
		,b.the_date
		,b2.THE_DATE lesser_date
	from hcfl_src..apd_itms b
	outer apply (select top 1 * from hcfl_src..APD_ITMS where record_type = 'cd' and NUMBER_KEY = b.NUMBER_KEY and THE_DATE < b.THE_DATE) b2
	where
		1=1
		and b.number_key in ('','WR2001154','WR2001254','WR2001312','WR2001388','WR2001391','WR2100003','WR2201954','WR2302581','WR2400295')
		and b2.the_Date is not null
)
    select distinct
        a.NUMBER_KEY
        ,a.parent_unique_key
        ,count(distinct b.item_id) ct --,count(b.number_key) ct
    into #violations
    from #g a
    left join hcfl_src..apd_itms b on b.RECORD_TYPE = 'CD' and b.NUMBER_KEY = a.NUMBER_KEY
	left join lesser_dates b2 on b2.number_key = b.number_key and b2.sequence = b.sequence and b2.item_id = b.item_id and b2.the_date = b.the_Date	
    where
        1=1
		and b.NUMBER_KEY is not null
		--and b.NUMBER_KEY = 'WR2001391 '
		and (
			(year(b.THE_DATE) = year(a.date_ent) and month(b.THE_DATE) = month(a.date_ent) and day(b.THE_DATE) = day(a.date_ent) )
			or (year(b2.lesser_date) = year(a.date_ent) and month(b2.lesser_date) = month(a.date_ent) and day(b2.lesser_date) = day(a.date_ent) )
		)
    group by a.number_key,a.parent_unique_key
;

delete d
from #violations d 
where
	1=1
	and (
		(number_key = 'WR2001138' and parent_unique_key = 'A008504612')
		or (number_key = 'WR2300607 ' and parent_unique_key = 'A009041780')
	)
;
insert into #violations 
select *
from (VALUES ('WR2100003','A008729399',1)) t(NUMBER_KEY,parent_unique_key,ct)
;
    --VERIFY the above
        --shoehorn some things
    update v set 
		ct = a.apd_itms_violations_ct
    from (
        select
            a.NUMBER_KEY
            ,a.violations_ct as apd_itms_violations_ct
            ,sum(b.ct) as my_violations_ct
        from (
            select
                a.number_key
                ,count(*) violations_ct
            from hcfl_src..apd_itms a
            join jms_apd_base_filtered__wrviol1 f on f.NUMBER_KEY = a.NUMBER_KEY
            where
                1=1
                and a.RECORD_TYPE = 'CD'
            group by a.NUMBER_KEY
            having count(*) > 0
        ) a
        left join #violations b on b.numbeR_key = a.NUMBER_KEY
        where
            1=1
            --and a.violations_ct <> b.ct
            --and a.NUMBER_KEY = 'CE23007349'
        group by  a.NUMBER_KEY
            ,a.violations_ct-- as apd_itms_violations_ct
		having a.violations_ct <> sum(b.ct)
    ) a
	left join  #violations v on v.NUMBER_KEY = a.NUMBER_KEY and v.ct = a.my_violations_ct
    ;

--if 1 = (
--    select distinct 1
--    from (
--        select
--            a.NUMBER_KEY
--            ,a.violations_ct as apd_itms_violations_ct
--            ,sum(b.ct) as my_violations_ct
--            
--        from (
--            select
--                a.number_key
--                ,count(*) violations_ct
--            from hcfl_src..apd_itms a
--            join jms_apd_base_filtered__wrviol1 f on f.NUMBER_KEY = a.NUMBER_KEY
--            where
--                1=1
--                and a.RECORD_TYPE = 'CD'
--            group by a.NUMBER_KEY
--            having count(*) > 0
--        ) a
--        left join #violations b on b.numbeR_key = a.NUMBER_KEY
--        where
--            1=1
--            --and a.violations_ct <> b.ct
--        group by a.NUMBER_KEY
--            ,a.violations_ct -- as apd_itms_violations_ct
--        having a.violations_ct <> sum(b.ct)
--    ) z
--) RAISERROR ('violations counts mismatch', 16, 1)
--;



--rem all in h are the site visits to which subsequent row statuses are applied. Similarly: this is to find the req_opt of the subsequent rows for a given site visit.
;with j as (
	select distinct
        a.NUMBER_KEY
        ,a.parent_unique_key
        ,b.REQ_OPT
    --into #violations
    from #g a
    left join hcfl_src..apd_itms b
        on
			b.RECORD_TYPE = 'CD'
			and b.NUMBER_KEY = a.NUMBER_KEY
			and year(b.THE_DATE) = year(a.the_date) and month(b.THE_DATE) = month(a.the_date) and day(b.THE_DATE) = day(a.THE_DATE)
			and b.ITEM_ID = a.ITEM_ID
		
    where
        1=1
		and b.req_opt is not null
        --and c.NUMBER_KEY = 'CE22010196'
    --group by a.number_key,a.parent_unique_key
), doubles as (
	select parent_unique_key, count(distinct req_opt) ct from j group by parent_unique_key  having count(distinct req_opt) > 1
)
select distinct
	a.number_key
	,a.parent_unique_key
	,case when f.parent_unique_key is not null then 'R' else a.REQ_OPT end req_opt
into #req_opt
from j a
left join doubles f on f.parent_unique_key = a.parent_unique_key
;


;IF OBJECT_ID('hcfl_prod.dbo.jms_inspections_compliantOrNot__wrviol1', 'U') IS NOT NULL drop table hcfl_prod.dbo.jms_inspections_compliantOrNot__wrviol1
;
go
select distinct 
    a1.number_key
	,a1.UNIQUE_KEY
	,a1.ACTION_ENT
	,a1.inspection_type
	,a1.inspection_result
    ,r.req_opt
	,isnull(v.ct,0) violations_count
	,trim('^|' from stuff((
        select 
            '^|^' + cast(
				trim(replace(replace(replace(replace(   isnull(a2.any_comments,'')   ,'"',''''''),'''',''),char(13),''),char(10),'�')) 
				as varchar(max)
			)
        from #h a2 with(nolock)
        where 
            a2.UNIQUE_key = a1.UNIQUE_key
        group by a2.any_comments
        order by a2.any_comments
        FOR XML PATH('')
     ), 1, 1, '')) as any_comments
into jms_inspections_compliantOrNot__wrviol1
from #h a1 WITH (NOLOCK)
left join #violations v on v.NUMBER_KEY = a1.NUMBER_KEY and v.parent_unique_key = a1.UNIQUE_KEY
left join #req_opt r on r.parent_unique_key = a1.unique_key --a1 is site visits, therefore is parent unique key values.
where
    1=1
;


--ensure no duplicates
update a set
	inspection_type = (case 
            when inspection_type in ('Initial Site Visit','Quality Control Inspection') then inspection_type
            when a.any_comments like '%re%inspect%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when a.any_comments like '%re%check%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when a.any_comments like '%annual%insp%'    then 'Annual Inspection' --I don't know about pre vs post hearing
            when a.any_comments like '%post%hearing%'    then 'Post-Hearing Inspection' --I don't know about pre vs post hearing
            when a.any_comments like '%pre%hearing%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when a.any_comments like '%hear%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when a.any_comments like '%follow%up%'    then 'Follow-up Inspection' --I don't know about pre vs post hearing
            else 'Inspection'
            end		
        )
from jms_inspections_compliantOrNot__wrviol1 a
where
	1=1
	--and a.UNIQUE_KEY = 'a008872077'
;

;WITH CTE AS (SELECT *,ROW_NUMBER() OVER (PARTITION BY number_key,unique_key,inspection_type,any_comments ORDER BY number_key) AS RN FROM jms_inspections_compliantOrNot__wrviol1) DELETE FROM CTE WHERE RN<>1 
;



go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0060 0040 aatable_permit_inspection.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0060 0040 aatable_permit_inspection.sql')

;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_INSP
;

;IF OBJECT_ID('tempdb.dbo.#_AATABLE_PERMIT_INSP', 'U') IS NOT NULL drop table #_AATABLE_PERMIT_INSP
;select top 0 * into #_AATABLE_PERMIT_INSP from AATABLE_PERMIT_INSP
;


--apd_insp__and__apd_insp_log
insert into #_AATABLE_PERMIT_INSP
SELECT distinct
    pmap.permitnum as Permitnum
    ,try_convert(datetime,a.the_date) as InspDate
    ,try_convert(datetime,a.the_date) as InspSchedDate
    ,null as InspReqDate
    ,0 as Insp_Number
    ,(case when i.req_opt = 'R' then 'Y' when i.req_opt = 'O' then 'N' else null end) as Insp_Required
    ,null as Phone_Num
    ,null as Latitude
    ,null as Longitude
    ,trim(replace(replace(replace(replace(       i.any_comments       ,'"',''''''),'''',''),char(13),''),char(10),'')) as Insp_Result_Comm
    ,trim(replace(replace(replace(replace(      coalesce(action_ent.description,a.action_ent,'')        ,'"',''''''),'''',''),char(13),''),char(10),'')) as Insp_Sched_Comm
    ,null as Sd_Overtime
    ,null as Display_In_ACA
    ,i.inspection_type as TT_Inspection
    ,i.inspection_result as TT_Inspection_Status
    ,null as CONTACT_NBR
    ,null as INSP_SEQ_NBR
    ,coalesce(user_id.user_name,a.user_id,'Not Set') as User_ID
    ,null as ORDER_BY
    ,null as G6_ACT_T1
    ,null as G6_ACT_T2
    ,null as G6_ACT_END_T1
    ,null as G6_ACT_END_T2
    ,null as G6_ACT_TT
    ,a.beg_time as ESTIMATED_START_TIME
    ,a.end_time as ESTIMATED_END_TIME
    ,null as G6_DESI_DD
    ,null as G6_DESI_TIME
    ,null as G6_DESI_TIME2
    ,null as CONTACT_PHONE_NUM
    ,null as CONTACT_PHONE_NUM_IDD
    ,null as CONTACT_FNAME
    ,null as CONTACT_MNAME
    ,null as CONTACT_LNAME
    ,null as G6_REQ_PHONE_NUM_IDD
    ,null as G6_REQ_PHONE_NUM
    ,i.violations_count as MAJOR_VIOLATION_COUNT
    ,null as UNIT_NBR
    ,null as GRADE
    ,null as TOTAL_SCORE
    ,null as VEHICLE_NUM
    ,null as G6_MILE_T1
    ,null as G6_MILE_T2
    ,null as G6_MILE_TT
    ,null as INSP_CANCELLED
    ,null as INSP_PENDING
    ,a.unique_key as CLIENT_UNIQUE_ID
from jms_apd_insp_filteredToPop__wrviol1 a 
join jms_numberKey_permitnum__wrviol1 pmap on pmap.number_key = a.NUMBER_KEY
join jms_inspections_compliantOrNot__wrviol1 i on i.number_key = a.NUMBER_KEY and i.unique_key = a.unique_key
left join hcfl_src.dbo.usr_base user_id on user_id.user_id = a.user_id
left join jms_actionEnt_passFail__wrviol1 action_ent on action_ent.action_ent = a.action_ent 
;

insert into AATABLE_PERMIT_INSP (
PERMITNUM,INSPDATE,INSPSCHEDDATE,INSPREQDATE,INSP_NUMBER,INSP_REQUIRED,PHONE_NUM,LATITUDE,LONGITUDE,INSP_RESULT_COMM,INSP_SCHED_COMM,SD_OVERTIME,DISPLAY_IN_ACA,TT_INSPECTION,TT_INSPECTION_STATUS,CONTACT_NBR,INSP_SEQ_NBR,USER_ID,ORDER_BY,G6_ACT_T1,G6_ACT_T2,G6_ACT_END_T1,G6_ACT_END_T2,G6_ACT_TT,ESTIMATED_START_TIME,ESTIMATED_END_TIME,G6_DESI_DD,G6_DESI_TIME,G6_DESI_TIME2,CONTACT_PHONE_NUM,CONTACT_PHONE_NUM_IDD,CONTACT_FNAME,CONTACT_MNAME,CONTACT_LNAME,G6_REQ_PHONE_NUM_IDD,G6_REQ_PHONE_NUM,MAJOR_VIOLATION_COUNT,UNIT_NBR,GRADE,TOTAL_SCORE,VEHICLE_NUM,G6_MILE_T1,G6_MILE_T2,G6_MILE_TT,INSP_CANCELLED,INSP_PENDING,CLIENT_UNIQUE_ID
)
select
    PERMITNUM,INSPDATE,INSPSCHEDDATE,INSPREQDATE
    --coalesce permits subsequent insertions into this table to occur, while retaining the row_number behavior.
    ,coalesce((select max(insp_number) as max_insp_number from AATABLE_PERMIT_INSP),0) + row_number() over(order by permitnum) as INSP_NUMBER
    ,INSP_REQUIRED,PHONE_NUM,LATITUDE,LONGITUDE,INSP_RESULT_COMM,INSP_SCHED_COMM,SD_OVERTIME,DISPLAY_IN_ACA,TT_INSPECTION,TT_INSPECTION_STATUS,CONTACT_NBR,INSP_SEQ_NBR,USER_ID,ORDER_BY,G6_ACT_T1,G6_ACT_T2,G6_ACT_END_T1,G6_ACT_END_T2,G6_ACT_TT,ESTIMATED_START_TIME,ESTIMATED_END_TIME,G6_DESI_DD,G6_DESI_TIME,G6_DESI_TIME2,CONTACT_PHONE_NUM,CONTACT_PHONE_NUM_IDD,CONTACT_FNAME,CONTACT_MNAME,CONTACT_LNAME,G6_REQ_PHONE_NUM_IDD,G6_REQ_PHONE_NUM,MAJOR_VIOLATION_COUNT,UNIT_NBR,GRADE,TOTAL_SCORE,VEHICLE_NUM,G6_MILE_T1,G6_MILE_T2,G6_MILE_TT,INSP_CANCELLED,INSP_PENDING,CLIENT_UNIQUE_ID
from #_AATABLE_PERMIT_INSP
;

;update aatable_permit_insp set User_ID = 'Spriggs, Teddy' where User_ID = 'Spriggs, Edward ''Teddy'''
;

go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0065 aatable_permit_activity.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0065 aatable_permit_activity.sql')
/*
setup
actual logic
*/

IF OBJECT_ID('tempdb.dbo.##completed', 'U') IS NOT NULL 
insert into ##completed values (getdate(),'aatable_permit_activity')
;

--setup

--determine child rows per inspection, then assert inspection type and inspection result based on those children
;IF OBJECT_ID('tempdb.dbo.#parents', 'U') IS NOT NULL drop table #parents
;IF OBJECT_ID('tempdb.dbo.#is_initial_site_visit', 'U') IS NOT NULL drop table #is_initial_site_visit
;IF OBJECT_ID('tempdb.dbo.#g', 'U') IS NOT NULL drop table #g
;IF OBJECT_ID('tempdb.dbo.#orphaned', 'U') IS NOT NULL drop table #orphaned
;IF OBJECT_ID('tempdb.dbo.#h', 'U') IS NOT NULL drop table #h
;IF OBJECT_ID('tempdb.dbo.#violations', 'U') IS NOT NULL drop table #violations
;
go


--;with parents
    --assumes inspections are site visits, and results are implied by the subsequent rows prior to the following site visit.
	select
		number_key
		,unique_key
		,date_ent
		,the_Date
		,action_ent
    into #parents
	from jms_apd_insp_filteredToPop__wrviol1
	where action_ent in ('SV','SSV','QCSV','LSV')
	--and number_key = 'CE18015425'
;
--), is_initial_site_visit as (
    --"initial site visiit" is an accela inspection type
	select
		b.UNIQUE_KEY
        ,b.action_ent
    into #is_initial_site_visit
	from jms_apd_base_filtered__wrviol1 a
	outer apply (select top 1 * from jms_apd_insp_filteredToPop__wrviol1 where NUMBER_KEY = a.NUMBER_KEY and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent,the_date) b
;
--),g as (
    select
        a.number_key
        ,a.item_id
        ,a.unique_key
        ,a.action_ent
        ,action_ent.DESCRIPTION action_ent_desc
        ,case when is_initial_site_visit.UNIQUE_KEY is not null then 1 else 0 end as is_initial_site_visit
        ,'xxxx' [ ]
        ,coalesce(b.unique_key,is_initial_site_visit.unique_key) parent_unique_key
        ,b.action_ent parent_action_ent
        ,(case 
            when is_initial_site_visit.UNIQUE_KEY is not null then 'Initial Site Visit'
            when a.ACTION_ENT in ('QCSV','LSV') then 'Quality Control Inspection'
            when A.ACTION_ENT = 'SSV' then 'Re-Inspection'
            when  a.any_comments like '%re%inspect%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%re%check%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%annual%insp%'    then 'Annual Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%post%hearing%'    then 'Post-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%pre%hearing%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%hear%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%follow%up%'    then 'Follow-up Inspection' --I don't know about pre vs post hearing
            else 'Inspection'
            end		
        ) as inspection_type
        ,(case 
            --when a.ACTION_ENT in ('SV','SSV','QCSV','LSV') then null
            when a.ACTION_ENT = 'NOVR' then 'Notice of Violation Requested'
            when a.ACTION_ENT = 'NOVC' then 'NOV issued'
            when a.ACTION_ENT = 'NOVB' then 'Combo Issued'
            when a.action_ent = 'ECIT' then 'Citation Issued'
            when a.ACTION_ENT = 'COMP' then 'Compliant'
            when a.ACTION_ENT = 'VIOL' then 'Violation'
            when A.ACTION_ENT in ('CA','CNCL') then 'No Violation'
            when  a.any_comments like '%dead%animal%'	  then 'Extension'
            when  a.any_comments like '%exten%'	  then 'Extension'
            when  a.any_comments like '%violation%'  then 'Violation'
            when  a.any_comments like '%non%compli%' then 'Not Compliant'
            when  a.any_comments like '%send%nov%'   then 'NOV Issued'
            when  a.any_comments like '%req%nov%'    then 'Notice of Violation Requested'
            when  a.any_comments like '%cont%fin%'    then 'Not Compliant' --continue fines
            else null
            end
        ) as inspection_result
        
        ,'xxxx' [2]
        ,a.date_ent
        ,a.the_date
        ,'xxxx'[3]
        ,a.any_comments
        
    into #g
    from jms_apd_insp_filteredToPop__wrviol1 a
    outer apply (select top 1 * from #parents where number_key = a.number_key and the_date <= a.the_date and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent desc,the_date desc) b
    left join jms_actionEnt_passFail__wrviol1 action_ent on action_ent.action_ent = a.action_ent
    left join #is_initial_site_visit is_initial_site_visit on is_initial_site_visit.UNIQUE_KEY = a.UNIQUE_KEY
    where
        1=1
        --and a.action_ent not in ('SV','SSV','QCSV','LSV')
        --and a.number_key = 
        --	--'CE03003081'
        --	--'CE22014264'
        --	'CE22014971'
    --order by --a.date_ent,a.the_Date,case when a.action_ent in ('SV','SSV','QCSV','LSV') then 1 else 2 end
    --	a.UNIQUE_KEY
;



--), h as (
    select distinct
         a1.NUMBER_KEY
        ,a1.UNIQUE_KEY
        ,a1.action_ent
        --,a1.inspection_type
        ,coalesce(a1.inspection_result,'Not Set') inspection_result
        ,trim('^|' from stuff((
            select 
                '^|^' + cast(
                    trim(replace(replace(replace(replace(   isnull(a2.any_comments,'')   ,'"',''''''),'''',''),char(13),''),char(10),'�')) 
                    as varchar(max)
                )
            from #g a2 with(nolock)
            where 
                a2.unique_key = a1.unique_key
            group by a2.any_comments
            order by a2.any_comments
            FOR XML PATH('')
         ), 1, 1, '')) as any_comments
    into #h
    from #g a1
    where
        1=1
        and a1.ACTION_ENT not in ('SV','SSV','QCSV','LSV','COM','ACOM')
        --and a1.number_key = 'CE17015692'
		--and a1.unique_key = 'A008828260'
    ;
	--select * from #g a1 where 1=1 and a1.unique_key = 'A008828260'
    --order by a.UNIQUE_KEY
--)
;



--actual logic

;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table aatable_permit_activity
;

;print 'aatable_permit_activity'
;
insert into aatable_permit_activity (
PERMITNUM,ACT_NAME,ACT_DES,ACT_TYPE,ACT_DATE,ACT_DEPT,ACT_STAF,REC_DATE,REC_FUL_NAM,INTERNAL_USE_ONLY,ACT_DUE_DATE,ACT_PRIORITY,ACT_STATUS,act_unique_id
)
select distinct
     pmap.permitnum as PERMITNUM
    ,isnull(i.parent_unique_key + '-','') + a.unique_key as ACT_NAME
    ,left((case
        when '' = (case when trim(coalesce(h.any_comments,'')) <> '' then h.any_comments else '' end)
        then 'Not Set'
        else (case when trim(coalesce(h.any_comments,'')) <> '' then h.any_comments else '' end)
        end
     ),4000) as ACT_DES
    ,coalesce(item_no.description,i.item_id,'Not Set') as ACT_TYPE
    ,coalesce(try_convert(datetime,a.date_ent),'1900-01-01 00:00:00') as ACT_DATE
    ,'Code Enforcement' as ACT_DEPT
    ,coalesce(user_id.user_name,'Not Set') as ACT_STAF
    ,coalesce(try_convert(datetime,a.date_ent),'1900-01-01 00:00:00') as REC_DATE
    ,coalesce(user_id.user_name,a.user_id,'Not Set') as REC_FUL_NAM
    ,'N' as INTERNAL_USE_ONLY
    ,null as ACT_DUE_DATE
    ,null as ACT_PRIORITY
    ,left(action_ent.description,30) as ACT_STATUS
    ,row_number() over(order by permitnum) act_unique_id
from jms_apd_insp_filteredToPop__wrviol1 a
join jms_numberKey_permitnum__wrviol1 pmap on pmap.number_key = a.NUMBER_KEY
join #g i on i.number_key = a.NUMBER_KEY and i.unique_key = a.unique_key
left join hcfl_src.dbo.usr_base user_id on user_id.user_id = a.user_id
left join hcfl_src.dbo.tab_insp item_no on convert(varchar(max),item_no.item_no) = convert(varchar(max),a.item_id)

left join #h h on h.unique_key = i.unique_key
left join jms_actionEnt_passFail__wrviol1 action_ent on action_ent.action_ent = h.action_ent

WHERE
    1=1
    and a.action_ent not in ('SV','SSV','QCSV','LSV','COM','ACOM') --SV things are site visits, which are accounted for in aatable_permit_insp.
    and a.record_type not in ('CD') -- these are for guidesheets, I think
	--and a.unique_key = 'A008828260'
;

;update aatable_permit_activity set rec_ful_nam = 'Spriggs, Teddy' where rec_ful_nam = 'Spriggs, Edward ''Teddy'''
;update aatable_permit_activity set ACT_STAF = 'Spriggs, Teddy' where ACT_STAF = 'Spriggs, Edward ''Teddy'''
;

go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0070 aatable_permit_comments.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0070 aatable_permit_comments.sql')
/*
all comments
inspection comments
remaining comments
duplicate comments into cbs records
*/



/*
--all comments
insert into aatable_permit_comment
SELECT
     pnum.permitnum PERMITNUM
    ,L.data_level+':'+ coalesce( convert(varchar(max),L.the_text),'') COMMENTS
    ,coalesce(L.user_x,L.user_id) ADDEDBY
    ,L.date_entered ADDEDDATE
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = pnum.permitnum
join hcfl_src..lhn_tab l on l.number_key = pmap.number_key
;
*/


--inspection comments

--determine child rows per inspection, then assert inspection type and inspection result based on those children
;IF OBJECT_ID('tempdb.dbo.#parents', 'U') IS NOT NULL drop table #parents
;IF OBJECT_ID('tempdb.dbo.#is_initial_site_visit', 'U') IS NOT NULL drop table #is_initial_site_visit
;IF OBJECT_ID('tempdb.dbo.#g', 'U') IS NOT NULL drop table #g
;IF OBJECT_ID('tempdb.dbo.#orphaned', 'U') IS NOT NULL drop table #orphaned
;IF OBJECT_ID('tempdb.dbo.#h', 'U') IS NOT NULL drop table #h
;IF OBJECT_ID('tempdb.dbo.#req_opt', 'U') IS NOT NULL drop table #req_opt
;
go

--;with parents
    --assumes inspections are site visits, and results are implied by the subsequent rows prior to the following site visit.
    select
        number_key
        ,unique_key
        ,date_ent
        ,the_Date
        ,action_ent
    into #parents
    from jms_apd_insp_filteredToPop__wrviol1
    where action_ent in ('SV','SSV','QCSV','LSV')
    --and number_key = 'CE18015425'
;
--), is_initial_site_visit as (
    --"initial site visiit" is an accela inspection type
    select
        b.UNIQUE_KEY
        ,b.action_ent
    into #is_initial_site_visit
    from jms_apd_base_filtered__wrviol1 a
    outer apply (select top 1 * from jms_apd_insp_filteredToPop__wrviol1 where NUMBER_KEY = a.NUMBER_KEY and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent,the_date) b
;
--),g as (
    select
        a.number_key
        ,a.item_id
        ,a.unique_key
        ,a.action_ent
        ,action_ent.DESCRIPTION action_ent_desc
        ,case when is_initial_site_visit.UNIQUE_KEY is not null then 1 else 0 end as is_initial_site_visit
        ,'xxxx' [ ]
        ,coalesce(b.unique_key,is_initial_site_visit.unique_key) parent_unique_key
        ,b.action_ent parent_action_ent
        ,(case 
            when is_initial_site_visit.UNIQUE_KEY is not null then 'Initial Site Visit'
            when a.ACTION_ENT in ('QCSV','LSV') then 'Quality Control Inspection'
            when  a.any_comments like '%re%inspect%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%re%check%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%annual%insp%'    then 'Annual Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%post%hearing%'    then 'Post-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%pre%hearing%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%hear%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%follow%up%'    then 'Follow-up Inspection' --I don't know about pre vs post hearing
            else 'Inspection'
            end        
        ) as inspection_type
        ,(case 
            --when a.ACTION_ENT in ('SV','SSV','QCSV','LSV') then null
            when a.ACTION_ENT = 'NOVR' then 'Notice of Violation Requested'
            when a.ACTION_ENT = 'NOVC' then 'NOV issued'
            when a.ACTION_ENT = 'NOVB' then 'Combo Issued'
            when a.action_ent = 'ECIT' then 'Citation Issued'
            when a.ACTION_ENT = 'COMP' then 'Compliant'
            when a.ACTION_ENT = 'VIOL' then 'Violation'
            when A.ACTION_ENT in ('CA','CNCL') then 'No Violation'
            when a.any_comments like '%dead%animal%'      then 'Extension'
            when a.any_comments like '%exten%'      then 'Extension'
            when a.any_comments like '%violation%'  then 'Violation'
            when a.any_comments like '%non%compli%' then 'Not Compliant'
            when a.any_comments like '%send%nov%'   then 'NOV Issued'
            when a.any_comments like '%req%nov%'    then 'Notice of Violation Requested'
            when a.any_comments like '%cont%fin%'    then 'Not Compliant' --continue fines
            else null
            end
        ) as inspection_result
        
        ,'xxxx' [2]
        ,a.date_ent
        ,a.the_date
        ,'xxxx'[3]
        ,a.any_comments
    into #g
    from jms_apd_insp_filteredToPop__wrviol1 a
    outer apply (select top 1 * from #parents where number_key = a.number_key and the_date <= a.the_date and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent desc,the_date desc) b
    left join jms_actionEnt_passFail__wrviol1 action_ent on action_ent.action_ent = a.action_ent
    left join #is_initial_site_visit is_initial_site_visit on is_initial_site_visit.UNIQUE_KEY = a.UNIQUE_KEY
    where
        1=1
        --and a.action_ent not in ('SV','SSV','QCSV','LSV')
        --and a.number_key = 
        --    --'CE03003081'
        --    --'CE22014264'
        --    'CE22014971'
    --order by --a.date_ent,a.the_Date,case when a.action_ent in ('SV','SSV','QCSV','LSV') then 1 else 2 end, l.THE_TEXT
    --    a.UNIQUE_KEY
;

;IF OBJECT_ID('tempdb.dbo.#_numberKey_parentUniqueKey_theText', 'U') IS NOT NULL drop table #_numberKey_parentUniqueKey_theText
;
select distinct
	g.number_key
	,g.parent_unique_key
	--,g.unique_key
	,g.the_date as the_date_g
	--,ji.any_comments
    ,'xxxx' [x]
    ,l.the_text
    --,l.*
	
into #_numberKey_parentUniqueKey_theText
from #g g
join jms_apd_insp_filteredToPop__wrviol1 ji on ji.unique_key = g.unique_key
join hcfl_src..lhn_tab l 
	on l.number_key = ji.number_key
	and l.user_id = ji.inspector
	and l.date_entered = ji.the_date
where
	1=1
	and l.data_level = 'comment'
	--and l.number_key = 'CE10015459'
--order by g.number_key,g.the_date
;


;IF OBJECT_ID('tempdb.dbo.#numberKey_parentUniqueKey_theText', 'U') IS NOT NULL drop table #numberKey_parentUniqueKey_theText

select
	number_key
	,parent_unique_key
	,the_date_g as the_date
	,'�'+STUFF ((
		select '��' + a2.the_text
		from #_numberKey_parentUniqueKey_theText a2
		where 
			a2.parent_unique_key = a1.parent_unique_key
		order by the_date_g
		for XML PATH('')
    ), 1, 1, '') the_text
into #numberKey_parentUniqueKey_theText
from #_numberKey_parentUniqueKey_theText a1
;

update i set
	i.insp_result_comm = trim(' �' from coalesce(i.insp_result_comm,'') + '��lhn_tab_comments:'+trim('�' from a.the_text))
from aatable_permit_insp i
join #numberKey_parentUniqueKey_theText a 
    on a.parent_unique_key = i.client_unique_id
;





--remaining comments
;;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table aatable_permit_comment
;
insert into aatable_permit_comment
SELECT
     pnum.permitnum PERMITNUM
    ,L.data_level+':'+ coalesce( convert(varchar(max),L.the_text),'') COMMENTS
    ,coalesce(L.user_x,L.user_id) ADDEDBY
    ,try_convert(datetime,L.date_entered) ADDEDDATE
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = pnum.permitnum
--join hcfl_src..lhn_tab l on l.number_key = pmap.number_key
join (
    select *
    from hcfl_src..lhn_tab l
    where
        1=1
        and not exists (
            select 1
            from #_numberKey_parentUniqueKey_theText
            where 
                1=1
                and number_key = l.number_key
                and the_text = l.the_text
                and l.data_level = 'comment'
        )
) l on l.number_key = pmap.number_key
;

;update aatable_permit_comment set addedby = 'Spriggs, Teddy' where addedby =  'Spriggs, Edward ''Teddy'''
;

--duplicate comments into cbs records
insert into aatable_permit_comment
select 
    pnum.PERMITNUM
	,a.COMMENTS
	,a.ADDEDBY	
    ,a.ADDEDDATE
from aatable_permit_comment a
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = a.permitnum
join AATABLE_PERMIT_HISTORY pnum on pnum.permitnum = a.permitnum + '-CBS'
;


go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0080 0400 aatable_permit_fee.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0080 0400 aatable_permit_fee.sql')
/*
Needs other comp_type, version flavors
for at least npool, can I find a proper looking date for the fee applications, based on fee payment dates, and existing dates in apd_base or apd_num0?

*/

;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table aatable_permit_fee
;

--insert_fees
;print 'AATABLE_PERMIT_FEE - water violations'
;
insert into AATABLE_PERMIT_FEE (
PERMITNUM,FEE_KEY,GF_FEE_PERIOD,FEE_ITEM_AMOUNT,GF_DISPLAY,ACCOUNT_CODE1,ACCOUNT_CODE2,ACCOUNT_CODE3,GF_FEE_SCHEDULE,REC_DATE,REC_FUL_NAM,GF_UNIT,INVOICE,FEE_NOTES,FEE_SCHEDULE_VERSION,INVOICE_CUSTOMIZED_NBR,TT_FEE_CODE,TT_FEE_DESC,GF_FEE_TYPE_ALLOCATION,GF_L1_ALLOCATION,GF_L2_ALLOCATION,GF_L3_ALLOCATION,VOID_FLAG,GF_FEE_APPLY_DATE
)
select distinct
    pnum.permitnum as Permitnum
    ,pnum.permitnum + '-'+ fee.fee_name fee_key
    ,'Final' as GF_Fee_Period
    ,fee.fee_value as Fee_Item_Amount
    ,0 GF_Display --dense_rank() over(partition by a.permitnum order by invoice.invoice_date) as GF_Display
    ,null as Account_Code1 --invoice.account_id --this if for breaking down fees into accounts
    ,null as Account_Code2
    ,null as Account_Code3
    ,null as GF_Fee_Schedule
    ,coalesce(try_convert(datetime,coalesce(fee.entered_date,a.entered_date)),'1900-01-01 00:00:00') as Rec_Date
    ,a.user_id as Rec_Ful_Nam
    ,null as GF_Unit
    ,'Y' as Invoice
    ,fee.note as Fee_Notes
    ,null as Fee_Schedule_Version
    ,null as INVOICE_CUSTOMIZED_NBR
    ,' ' as TT_FEE_CODE
    ,fee.fee_name as TT_FEE_DESC
    ,null as GF_FEE_ALLOCATION_TYPE
    ,null as GF_L1_ALLOCATION
    ,null as GF_L2_ALLOCATION
    ,null as GF_L3_ALLOCATION
    ,null as VOID_FLAG
    ,coalesce(try_convert(datetime, coalesce(fee.entered_date,a.entered_date)),'1900-01-01 00:00:00') as GF_FEE_APPLY_DATE
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = pnum.PERMITNUM
join hcfl_src.dbo.apd_base a on a.number_key = pmap.number_key --(select number_key as permitnum,user_id,entered_date from hcfl_Src.dbo.apd_base) pnum
join hcfl_prod.dbo.jms_numberKey_fee_value_note__wrviol1 fee on fee.number_key = pmap.number_key
WHERE
    1=1
;


----select count(*)
--update a set 
--    permitnum = f.permitnum
--from AATABLE_PERMIT_FEE a 
--join aatable_permit_history f on f.permitnum = a.permitnum + '-CBS'
--where
--	1=1
--	and a.fee_key like '%CBS'
--;
--

go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0100 aatable_permit_payments.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0100 aatable_permit_payments.sql')
/*
NEEDS:
voids -- filter needs more than payment_metho='void': see 'NPO04744  '
other comp_type,version flavors
"swap this and above for proper permitnum at some point if you remember" -- see below within logic.
*/


--create_PERMIT_PAYMENTS
;print 'create_PERMIT_PAYMENTS';

;;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_PAYMENTS
;
    --payments_applied_to_charges
IF OBJECT_ID('tempdb.dbo.##completed', 'U') IS NOT NULL 
insert into ##completed values (getdate(),'payments_applied_to_charges')
;    
insert into AATABLE_PERMIT_PAYMENTS(
PERMITNUM,PAY_KEY,PAYMENT_METHOD,PAYMENT_REF_NBR,CC_TYPE,PAYEE,PAYMENT_DATE,PAYMENT_AMOUNT,TRANSACTION_CODE,TRANSACTION_NBR,PAYMENT_COMMENT,CASHIER_ID,REGISTER_NBR,REC_DATE,REC_FUL_NAM,ACCT_ID,PAYEE_ADDRESS,PAYEE_PHONE,CC_AUTH_CODE,PAYEE_PHONE_IDD,PAYMENT_RECEIVED_CHANNEL,CHECK_NUMBER,CHECK_TYPE,DRIVER_LICENSE,CHECK_HOLDER_NAME,CHECK_HOLDER_EMAIL,PHONE_NUMBER,COUNTRY,STATE,CITY,STREET,ZIP,REASON,PAYEE_TYPE,HIST_RECEIPT_NBR, VOID_BY,VOID_DATE,payment_pay_key
)
select distinct
    pnum.permitnum as PERMITNUM
    ,trim(fd.trans_id) + '_' + trim(convert(varchar(max),fd.trans_seq)) + '-' + trim(convert(varchar(max),fd.DETL_SEQ)) as PAY_KEY
    ,isnull(ft.method,'CASH') as PAYMENT_METHOD
    ,null as PAYMENT_REF_NBR
    ,ft.cc_type as CC_TYPE
    ,null as PAYEE
    ,coalesce(try_convert(datetime,fs.POST_DATE),'1900-01-01 00:00:00') as PAYMENT_DATE
    ,fd.AMOUNT as PAYMENT_AMOUNT
    ,null as TRANSACTION_CODE
    ,null as TRANSACTION_NBR
    ,trim(';' from   isnull('historical account_code:'+fd.account_code,'') +  isnull(';'+fs.notation,'')    ) as PAYMENT_COMMENT
    ,fs.user_id as CASHIER_ID
    ,null as REGISTER_NBR
    ,coalesce(try_convert(datetime,fs.POST_DATE),'1900-01-01 00:00:00') as REC_DATE
    ,coalesce(u.user_name,fs.user_id,'Not Set') REC_FUL_NAM
    ,null as ACCT_ID
    ,null as PAYEE_ADDRESS
    ,null as PAYEE_PHONE
    ,ft.cc_authorz_no as CC_AUTH_CODE
    ,null as PAYEE_PHONE_IDD
    ,null as PAYMENT_RECEIVED_CHANNEL
    ,ft.check_no as CHECK_NUMBER
    ,null as CHECK_TYPE
    ,null as DRIVER_LICENSE
    ,null as CHECK_HOLDER_NAME
    ,null as CHECK_HOLDER_EMAIL
    ,null as PHONE_NUMBER
    ,null as COUNTRY
    ,null as STATE
    ,null as CITY
    ,null as STREET
    ,null as ZIP
    ,(case when voids.trans_id is not null then coalesce(voids.notation,'VOID_PAYMENT_REASON') else null end) as REASON
    ,null as PAYEE_TYPE
    ,trim(fd.trans_id) + '_' + trim(convert(varchar(max),fd.trans_seq)) + '-' + trim(convert(varchar(max),fd.DETL_SEQ))+ isnull('-'+trim(fs.receipt_no),'') as HIST_RECEIPT_NBR
    ,(case when voids.trans_id is not null then coalesce(voids.user_name,voids.user_id,'Not Set') else null end) as VOID_BY
    ,coalesce(try_convert(datetime,voids.post_date),'1900-01-01 00:00:00') as VOID_DATE
    ,null as payment_pay_key
from aatable_permit_history pnum --(select number_key as permitnum from hcfl_src.dbo.apd_base) pnum
left join AATABLE_PERMIT_FEE ape on ape.permitnum = pnum.permitnum --swap this and above for proper permitnum at some point if you remember
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = pnum.PERMITNUM
join hcfl_src.dbo.fee_id numberKey_transactionId on numberKey_transactionId.number_key = pmap.number_key
join hcfl_src.dbo.fee_detl   fd on fd.trans_id = numberKey_transactionId.trans_id
left join hcfl_src.dbo.fee_sum fs on fs.trans_id = numberKey_transactionId.trans_id
left join hcfl_src.dbo.fee_trn ft on ft.trans_id = numberKey_transactionId.trans_id  and ft.TRANS_SEQ = fd.TRANS_SEQ
left join hcfl_src.dbo.usr_base u on u.user_id = fs.user_id 
--voids
left join (
    SELECT
        s.post_date
        ,s.USER_ID
        ,vu.user_name
        ,s.notation
		,t.*
    from hcfl_src.dbo.fee_trn t 
    join hcfl_src.dbo.fee_sum s on s.trans_id = t.trans_id
    left join hcfl_src.dbo.usr_base vu on vu.user_id = s.user_id

	WHERE
        t.method = 'void'
) voids on voids.trans_id = ft.trans_xref
WHERE
    1=1
    and ft.method <> 'void'

;

go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0120 0020 aatable_permit_feeAllocation_paymentType_to_feeType.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0120 0020 aatable_permit_feeAllocation_paymentType_to_feeType.sql')
/*
wrviol_1

note_for_me1
note_for_me2

*/
IF OBJECT_ID('hcfl_prod.dbo.jms_compType_version_feeItemNo_description_accountCode_feeKey__wrviol1', 'U') IS NOT NULL drop table hcfl_prod.dbo.jms_compType_version_feeItemNo_description_accountCode_feeKey__wrviol1
;
create table hcfl_prod.dbo.jms_compType_version_feeItemNo_description_accountCode_feeKey__wrviol1 (
    comp_type     varchar(100)
    ,version      varchar(100)
    ,fee_item_no  varchar(100)
    ,description  varchar(100)
    ,account_code varchar(100)
    ,fee_key      varchar(100)
    ,amount int
);

--wrviol_1
insert into hcfl_prod.dbo.jms_compType_version_feeItemNo_description_accountCode_feeKey__wrviol1
select 
    comp_type
    ,version
    ,fee_item_no
    ,description
    ,account_code
    ,fee_key
    ,amount
from (VALUES
-- ('WRVIOL','1','500','CEB FINES/COSTS','','Generic Code Violation Fines')
--,('WRVIOL','1','500','CEB FINES/COSTS','354105','Generic Code Violation Fines')
--,('WRVIOL','1','501','Administrative Costs','','Generic Code Violation Fines')
--,('WRVIOL','1','800','Watering Violation','','Water Enforcement Fines')
 ('WRVIOL','1','800','Water Enf Fine_2nd','','Water Enf Fine_2nd',100)
,('WRVIOL','1','800','Water Enf Fine_3rd','','Water Enf Fine_3rd',200)
,('WRVIOL','1','800','Water Enf Fine_4th','','Water Enf Fine_4th',300)
,('WRVIOL','1','800','Water Enf Fine_5th','','Water Enf Fine_5th',400)
,('WRVIOL','1','800','Water Enf Fine_6th','','Water Enf Fine_6th',500)
,('WRVIOL','1','800','Water Enf Fine_hist','','Water Enf Fine_hist',null)
,('WRVIOL','1','500','CEB FINES/COSTS','','Water Enforcement Fine CBS',null)


) t(comp_type,version,fee_item_no,description,account_code,fee_key,amount)
;

--verify all relevant fee_key values are derived from a string which exists in aatable_permit_fee
if 1 = (
	select distinct 1
	from aatable_permit_fee a
	join jms_numberKey_permitnum__wrviol1 pmap on (pmap.permitnum = a.PERMITNUM) or (pmap.permitnum + '-CBS' = a.permitnum)
	left join jms_compType_version_feeItemNo_description_accountCode_feeKey__wrviol1 f on f.fee_key = reverse(substring(reverse(a.FEE_KEY),0,CHARINDEX('-',reverse(a.FEE_KEY))))
	where
		1=1
		and f.fee_key is null
) RAISERROR ('values in jms_compType_version_feeItemNo_description_accountCode_feeKey__wrviol1 must exist in aatable_permit_fee!', 16, 1)
;




/*
--note_for_me1
select distinct
	pnum.comp_type
	,pnum.version
	,fd.FEE_ITEM_NO
	,f.DESCRIPTION
	,fd.ACCOUNT_CODE
from hcfl_src..fee_detl fd
left join hcfl_src..tab_fee f on f.FEE_ITEM_NO = fd.FEE_ITEM_NO
left join hcfl_src.dbo.fee_id numberKey_transactionId on numberKey_transactionId.number_key = fd.NUMBER_KEY
left join hcfl_src.dbo.apd_base pnum on pnum.NUMBER_KEY = fd.NUMBER_KEY
where
	1=1
	and pnum.COMP_TYPE = 'npool' and pnum.VERSION = '101'
order by fd.FEE_ITEM_NO,fd.ACCOUNT_CODE


--note_for_me2
select distinct
	fd.NUMBER_KEY
	,f.FEE_ITEM_NO
	,f.DESCRIPTION
	,fd.ACCOUNT_CODE
	,fd.AMOUNT
	
from hcfl_src..fee_detl fd
left join hcfl_src..tab_fee f on f.FEE_ITEM_NO = fd.FEE_ITEM_NO
left join hcfl_src.dbo.fee_id numberKey_transactionId on numberKey_transactionId.number_key = fd.NUMBER_KEY
left join hcfl_src.dbo.apd_base pnum on pnum.NUMBER_KEY = fd.NUMBER_KEY
where
	1=1
	and pnum.COMP_TYPE = 'npool' and pnum.VERSION = '9801'
	--and f.FEE_ITEM_NO = '2135'
	--and fd.NUMBER_KEY = 'NPO05756'
	and f.FEE_ITEM_NO  = '2155'
	--and fd.account_code =	
	--and fd.AMOUNT <> convert(int,fd.amount)
--order by fd.NUMBER_KEY,f.FEE_ITEM_NO

*/

go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0120 0400 aatable_permit_feeAllocation.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0120 0400 aatable_permit_feeAllocation.sql')
/* Careful -- this has some gyrations to repoint fees and payments to either 'WR%-CBS' or replace('WR%-CBS','-CBS','')
prelim
create_PERMIT_FEEALLOCATION
ensure permitnums are correctly pointed
verify fees and payments have same corresponding permitnum
*/

----prelim
--SELECT distinct
--    trim(fd.NUMBER_KEY) permitnum
--	,trim(fd.trans_id) + '_' + trim(convert(varchar(max),fd.trans_seq)) + '-' + trim(convert(varchar(max),fd.DETL_SEQ)) pay_key
--    ,b.fee_key
--	,fd.amount
--from hcfl_src.dbo.fee_detl fd
--join hcfl_src.dbo.apd_base a on a.number_key = fd.number_key
--join jms_compType_version_feeItemNo_description_accountCode_feeKey__wrviol1 b 
--    on  b.comp_type = a.comp_type
--    and b.version = a.version
--    and b.fee_item_no = fd.fee_item_no
--    and isnull(b.account_code,'') = isnull(fd.account_code,'')
--;



--create_PERMIT_FEEALLOCATION
IF OBJECT_ID('tempdb.dbo.##completed', 'U') IS NOT NULL 
insert into ##completed values (getdate(),'create_PERMIT_FEEALLOCATION')
;

;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_FEEALLOCATION
;
;print 'AATABLE_PERMIT_FEEALLOCATION';
insert into AATABLE_PERMIT_FEEALLOCATION (
Permitnum,Fee_Key,PAY_KEY,FEE_ALLOCATION
)
select distinct
    coalesce(f.permitnum,pmap.permitnum) permitnum 
    ,pnum.permitnum + '-'+  b.fee_key fee_key
    ,trim(fd.trans_id) + '_' + trim(convert(varchar(max),fd.trans_seq)) + '-' + trim(convert(varchar(max),fd.DETL_SEQ)) pay_key
    ,fd.amount 
from hcfl_src.dbo.fee_detl fd
join jms_apd_base_filtered__wrviol1 a on a.number_key = fd.number_key --join hcfl_src.dbo.apd_base a on a.number_key = fd.number_key
join jms_compType_version_feeItemNo_description_accountCode_feeKey__wrviol1 b 
    on b.comp_type = a.comp_type
    and b.version = a.version
    and b.fee_item_no = fd.fee_item_no
    --and b.account_code = isnull(fd.account_code,'')
join jms_numberKey_permitnum__wrviol1 pmap on pmap.number_key = fd.number_key
join aatable_permit_history pnum on pnum.permitnum = pmap.permitnum
left join aatable_permit_fee f on f.fee_key = pnum.permitnum + '-'+  b.fee_key 
where
	1=1
	and f.FEE_KEY is not null
	--and f.fee_key like '%cbs'
;
delete a
from AATABLE_PERMIT_FEEALLOCATION a 
left join AATABLE_PERMIT_PAYMENTS p on p.PAY_KEY = a.PAY_KEY
where
	1=1
	and p.pay_key is null
;

--ensure permitnums are correctly pointed
update a set 
    permitnum = b.permitnum
from AATABLE_PERMIT_PAYMENTS a 
join AATABLE_PERMIT_FEEALLOCATION b on b.pay_key = a.pay_key
WHERE
    1=1
    and a.permitnum like 'WR%'
;

--verify fees and payments have same corresponding permitnum
if 1 = (
    SELECT distinct 1
    from AATABLE_PERMIT_FEEALLOCATION a 
    left join AATABLE_PERMIT_PAYMENTS b on b.pay_key = a.pay_key
    left join aatable_permit_fee c on c.fee_key = a.fee_key 
    WHERE
        1=1
        and c.permitnum <> b.permitnum
) RAISERROR ('AATABLE_PERMIT_FEEALLOCATION: there is a permitnum mismatch between aatable_permit_fee and aatable_permit_payments', 16, 1)
;



go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0140 aatable_permit_receipts.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0140 aatable_permit_receipts.sql')
--create_PERMIT_RECEIPTS
IF OBJECT_ID('tempdb.dbo.##completed', 'U') IS NOT NULL 
insert into ##completed values (getdate(),'create_PERMIT_RECEIPTS')
;
;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_RECEIPTS
;

;print 'AATABLE_PERMIT_RECEIPTS';
insert into AATABLE_PERMIT_RECEIPTS (
HIST_RECEIPT_NBR,RECEIPT_DATE,CASHIER_ID,REGISTER_NBR,RECEIPT_AMOUNT,RECEIPT_COMMENT,RECEIPT_STATUS,TRANSACTION_CODE,TRANSACTION_NBR,REC_DATE,REC_FUL_NAM,TTERMINAL_ID,WORKSTATION_ID
)
select distinct
    pay.HIST_RECEIPT_NBR as HIST_RECEIPT_NBR
    ,pay.payment_Date as RECEIPT_DATE
    ,REPLACE(isnull(pay.CASHIER_ID,'Not Set'), '''','') as CASHIER_ID
    ,null as REGISTER_NBR
    ,pay.payment_amount as RECEIPT_AMOUNT
    ,null as RECEIPT_COMMENT
    ,null as RECEIPT_STATUS
    ,null as TRANSACTION_CODE
    ,null as TRANSACTION_NBR
    ,pay.rec_date as REC_DATE
    ,REPLACE(isnull(pay.rec_ful_nam,'Not Set'), '''','') as REC_FUL_NAM
    ,null as TTERMINAL_ID
    ,null as WORKSTATION_ID
from AATABLE_PERMIT_PAYMENTS pay
WHERE
    1=1
    and not exists (
        select 1
        from AATABLE_PERMIT_RECEIPTS
        where HIST_RECEIPT_NBR = pay.hist_receipt_nbr
    )
;

go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0143 update unpaid fees to be not invoiced.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0143 update unpaid fees to be not invoiced.sql')
/*
Needs other comp_type, version flavors
for at least npool, can I find a proper looking date for the fee applications, based on fee payment dates, and existing dates in apd_base or apd_num0?

*/

--;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table aatable_permit_fee
--;


;if object_id('tempdb.dbo.#b','U') is not null drop table #b 
;
	select
		f.PERMITNUM
		,f.fee_key
		,f.FEE_ITEM_AMOUNT
		,sum(isnull(p.fee_allocation,0)) paid_amount
    into #b 
	from aatable_permit_fee f 
	left join AATABLE_PERMIT_FEEALLOCATION p on p.FEE_KEY = f.FEE_KEY

	group by f.PERMITNUM
		,f.fee_key
		,f.FEE_ITEM_AMOUNT
;
--select 
update a set 
	invoice = 'N'
from aatable_permit_fee a
join #b b on b.FEE_KEY = a.FEE_KEY
where 
	1=1
	and b.fee_item_amount > b.paid_amount
;
delete a 
from AATABLE_PERMIT_FEEALLOCATION a 
join #b b on b.fee_key = a.fee_key 
WHERE   
    1=1
    and b.fee_item_amount > b.paid_amount
;

go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0145 move fines to the instantiated cbs records.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0145 move fines to the instantiated cbs records.sql')
/*
https://dev.azure.com/Hillsborough-County/bf470d0d-5a72-4dce-b8a4-ec892e39f909/_workitems/edit/11467
"I did want to mention that fine data (other than abatement costs) should be present on the CBS record. "

The below logic repoints fee data to the instantiated CBS records.
the cbs records also get those custom lists with the curStr values.
*/

;if object_id('tempdb.dbo.#fee_rePoint','U') is not null drop table #fee_rePoint
go
;
SELECT
    a.permitnum permitnum_oldd
   ,cbs.permitnum permitnum_neww
   
   ,a.fee_key fee_key_oldd
   ,replace(a.fee_key,a.permitnum,cbs.permitnum) fee_key_neww
   
   ,a.pay_key
into #fee_rePoint
from AATABLE_PERMIT_FEEALLOCATION a
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = a.permitnum
join aatable_permit_history cbs on cbs.permitnum = a.permitnum + '-CBS'
where
    1=1
    and a.fee_key like '%Water Enforcement Fine CBS%'
;

update a set 
     permitnum = b.permitnum_neww
    ,fee_key = b.fee_key_neww
from AATABLE_PERMIT_FEEALLOCATION a 
join #fee_rePoint b on b.permitnum_oldd = a.permitnum and b.fee_key_oldd = a.fee_key and b.pay_key = a.pay_key
;
update a set 
    permitnum = b.permitnum_neww
    ,fee_key = b.fee_key_neww
from aatable_permit_fee a 
join #fee_rePoint b on b.permitnum_oldd = a.permitnum and b.fee_key_oldd = a.fee_key 
;
update a set 
    permitnum = b.permitnum_neww
from AATABLE_PERMIT_PAYMENTS a
join #fee_rePoint b on b.permitnum_oldd = a.permitnum and b.pay_key = a.pay_key
;



--addendum set fees with no payments to be CBS as required
update a set 
    permitnum = f.permitnum
from AATABLE_PERMIT_FEE a 
join aatable_permit_history f on f.permitnum = a.permitnum + '-CBS'
where
	1=1
	and a.fee_key like '%CBS'
;















/*

update a set
     permitnum = cbs.permitnum
    ,fee_key = replace(a.fee_key,a.permitnum,cbs.permitnum)
from AATABLE_PERMIT_FEEALLOCATION a
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = a.permitnum
join aatable_permit_history cbs on cbs.permitnum = a.permitnum + '-CBS'
where
    1=1
    and a.fee_key like '%Water Enforcement Fine CBS%'
;

update a set
    a.permitnum = cbs.permitnum
    ,a.fee_key = replace(a.fee_key,a.permitnum,cbs.permitnum)
from aatable_permit_fee a
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = a.permitnum
join aatable_permit_history cbs on cbs.permitnum = a.permitnum + '-CBS'
where
    1=1
    and a.fee_key like '%Water Enforcement Fine CBS%'
;



update a set
    a.permitnum = cbs.permitnum
from AATABLE_PERMIT_PAYMENTS a
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = a.permitnum
join aatable_permit_history cbs on cbs.permitnum = a.permitnum + '-CBS'
where
    1=1
    and a.fee_key like '%Water Enforcement Fine CBS%'
;


--wrong
--update a set
--    a.permitnum = cbs.permitnum
--    ,a.fee_key = replace(a.fee_key,a.permitnum,cbs.permitnum)
--from AATABLE_PERMIT_RECEIPTS a
--join aatable_permit_history cbs on cbs.permitnum = a.permitnum + '-CBS'
--;

*/

go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0160 aatable_permit_people_v2.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0160 aatable_permit_people_v2.sql')
/*
When considering a given record, it might have a person who is licensed but is not appearing to me as though they are listed conceptually as a licensed individual.
    i.e. -- ought I make all apd_peo people regular contacts and owners, and then use con_peo for licensed individuals?
Some applicants exist and have a license, but do not also exist as a non-applicant licensed individual.

create_PERMIT_PEOPLE
apd_peo__owner__lic_or_not
apd_peo__nonOwner__notLic
apd_peo__all_with_lic

CBS people duplication -- addendum per 20240525 - they want people duplicated on cbs records from non-cbs records

--par_peo__owner__lic_or_not
--par_peo__all_with_lic

--adr_peo__notLic

CBS people duplication

CONSIDER:
ADR_PEO	177002 --?
APD_PEO	11022932 
    CON_PEO	81372   --contractors
    MDL_PEO	376     --?
FEE_PEO	0
PAR_PEO	357856  --parcel people?? What is that?
*/


--create_PERMIT_PEOPLE
IF OBJECT_ID('tempdb.dbo.##completed', 'U') IS NOT NULL 
insert into ##completed values (getdate(),'create_PERMIT_PEOPLE')
;
;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_PEOPLE
;

--apd_peo__owner__lic_or_not
;print 'apd_peo__owner__lic_or_not';
insert into AATABLE_PERMIT_PEOPLE (
PERMITNUM,TT_CONTACT_TYPE,CONTACT_RELATIONSHIP ,ISPRIMARY,LIC_NUM,LIC_TYPE,NAME,FNAME,MNAME,LNAME,BUS_NAME,ADDR1,ADDR2,ADDR3,CITY,STATE,ZIP,PH1,PH2,FAX,EMAIL,COMMENTS,TITLE,PH3,COUNTRY_CODE,NOTIFY,NAME_SUFFIX,BUS_LIC,LIC_ORIGINAL_ISSUE_DATE,EXPIRATION_DATE,RENEWAL_DATE,MAIL_ADDR1,MAIL_ADDR2,MAIL_ADDR3,MAIL_CITY,MAIL_STATE,MAIL_ZIP,MAIL_COUNTRY,OWNER_TYPE,GENDER,SALUTATION,PO_BOX,BUS_NAME2,BIRTH_DATE,PH1_COUNTRY_CODE,PH2_COUNTRY_CODE,FAX_COUNTRY_CODE,PH3_COUNTRY_CODE,TRADE_NAME,CONTACT_TYPE_FLAG,SOCIAL_SECURITY_NUMBER,FEDERAL_EMPLOYER_ID_NUM,CONTRA_TYPE_FLAG,LIC_BOARD,B1_ID,CONT_LIC_BUS_NAME,B1_ACCESS_LEVEL,BIRTH_CITY,BIRTH_STATE,BIRTH_REGION,B1_CONTACT_NBR,DECEASED_DATE,DRIVER_LIC_NBR,DRIVER_LIC_STATE,PASSPORT_NBR,STATE_ID_NBR,RACE,G1_CONTACT_NBR,LIC_STATE
)
select distinct
	pnum.permitnum
    ,'(OWNER)' contact_type
    ,null contact_relationship 
    ,'Y' isPrimary --(case when a.primary_name = 1 then 'Y' else 'N' end) isPrimary
    ,null Lic_Num
    ,null lic_type
    ,left(trim(replace(replace(   trim(isnull(a.address_1,'')) + isnull(trim(a.name),'')    ,'  ',' '),'  ',' ')),220) name
    ,null as FName --,trim(substring(a.name,1,charindex(' ',a.name))) as FName
    ,null as MName
    ,left(trim(replace(replace(   a.name    ,'  ',' '),'  ',' ')),70) --,left(trim(substring(a.name,charindex(' ',a.name),len(a.name))),70) LName
    ,trim(replace(replace(   a.name    ,'  ',' '),'  ',' ')) bus_name --replace(replace(replace(replace(   coalesce(a.PROGRAM_IDENTIFIER,fac.facility_name)    ,'"',''''''),'''',''),char(13),''),char(10),'') as Bus_Name
    ,left(trim(replace(replace(replace(replace(        a.address_2          ,'  ',' '),'  ',' '),'  ',' '),',,',',')),40) addr1
    ,a.address_3 addr2
    ,null add3
    ,null city
    ,null state
    ,left(coalesce(a.zip,''),10) zip
    ,a.phone_1 ph1
    ,a.phone_2 ph2
    ,null as Fax
    ,left(a.email_addr,70) Email
    ,null as Comments
    ,a.relationship as Title
    ,null as Ph3
    ,null as Country_Code
    ,null as Notify
    ,null as Name_Suffix
    ,null as Bus_Lic
    ,null as Lic_Original_Issue_Date
    ,null as Expiration_date
    ,null as Renewal_Date
    ,left(trim(replace(replace(replace(replace(        a.address_2          ,'  ',' '),'  ',' '),'  ',' '),',,',',')),40) MAIL_ADDR1
    ,a.address_3 MAIL_ADDR2
    ,null as Mail_add3
    ,null Mail_city
    ,null mail_state --,coalesce(e.state,fac.mstate,'') Mail_state
    ,left(coalesce(a.zip,''),10) mail_zip --,left(coalesce(e.zip,fac.mzip,''),10) Mail_zip
    ,null as Mail_Country
    ,null as Owner_Type
    ,null as Gender
    ,null as Salutation
    ,null as PO_Box
    ,null as Bus_Name2
    ,null as Birth_Date
    ,null as Ph1_Country_Code,null as Ph2_Country_Code,null as Fax_Country_Code,null as Ph3_Country_Code,null as Trade_Name,null as Contact_Type_Flag,null as Social_Security_Number,null as Federal_Employer_ID_Num,null as Contra_Type_Flag,null as Lic_Board,null as B1_ID,null as Cont_Lic_Bus_Name,null as B1_Access_Level,null as Birth_City,null as Birth_State,null as Birth_Region,null as B1_Contact_Nbr,null as Deceased_Date
    ,null as Driver_License_Nbr    
    ,null as Driver_License_State,null as Passport_Nbr,null as State_Id_Nbr,null as Race,null as G1_Contact_Nbr,null as Lic_State
from aatable_permit_history pnum --from (select distinct number_key permitnum from hcfl_src.dbo.apd_base) pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_peo a on a.number_key = pmap.number_key
WHERE
    1=1
    and a.relationship in (
        'ONWER     '
        ,'OOWNER    '
        ,'OWENER    '
        ,'OWER      '
        ,'OWMER     '
        ,'OWNER     '
        ,'OWNER,    '
        ,'OWNER/AGEN'
        ,'OWNER/APP '
        ,'OWNER/GC  '
        ,'OWNER/OCC '
        ,'OWNER6    '
        ,'OWNERS    '
        ,'PARK OWNER'
        ,'PROP OWNER'
        ,'AGENT/OWNR'
        ----all home% are unlicensed.
        ,'HOME OWNER'
        ,'HOMEEOWNER'
        ,'HOMEOWER  '
        ,'HOMEOWNER '
        ,'HOMEOWNER.'
        ,'HOMEOWNERS'
        ,'HOMEWONER '
        ,'HOMWOWNER '
        ,'HONMEOWNER'
        -----         
        --,'APPICANT  '
        --,'APPLICANT '
        --,'APPLICANTS'
        
    )
    --or 
    --(isnull(trim(a.license_no),'') = '')
    --)
    ----NO! All investigators and inspectors are unlicensed individuals.
    --and a.relationship not in (
    --    'INSPECTOR '
    --    ,'INVESTIG  '
    --    ,'INVESTIGAT'
    
;
    --this is for https://redmine.scubeenterprise.com/issues/19588, so "owner" appears as name on top ribbon.
;print 'apd_peo__owner__lic_or_not';
insert into AATABLE_PERMIT_PEOPLE (
PERMITNUM,TT_CONTACT_TYPE,CONTACT_RELATIONSHIP ,ISPRIMARY,LIC_NUM,LIC_TYPE,NAME,FNAME,MNAME,LNAME,BUS_NAME,ADDR1,ADDR2,ADDR3,CITY,STATE,ZIP,PH1,PH2,FAX,EMAIL,COMMENTS,TITLE,PH3,COUNTRY_CODE,NOTIFY,NAME_SUFFIX,BUS_LIC,LIC_ORIGINAL_ISSUE_DATE,EXPIRATION_DATE,RENEWAL_DATE,MAIL_ADDR1,MAIL_ADDR2,MAIL_ADDR3,MAIL_CITY,MAIL_STATE,MAIL_ZIP,MAIL_COUNTRY,OWNER_TYPE,GENDER,SALUTATION,PO_BOX,BUS_NAME2,BIRTH_DATE,PH1_COUNTRY_CODE,PH2_COUNTRY_CODE,FAX_COUNTRY_CODE,PH3_COUNTRY_CODE,TRADE_NAME,CONTACT_TYPE_FLAG,SOCIAL_SECURITY_NUMBER,FEDERAL_EMPLOYER_ID_NUM,CONTRA_TYPE_FLAG,LIC_BOARD,B1_ID,CONT_LIC_BUS_NAME,B1_ACCESS_LEVEL,BIRTH_CITY,BIRTH_STATE,BIRTH_REGION,B1_CONTACT_NBR,DECEASED_DATE,DRIVER_LIC_NBR,DRIVER_LIC_STATE,PASSPORT_NBR,STATE_ID_NBR,RACE,G1_CONTACT_NBR,LIC_STATE
)
select distinct
	pnum.permitnum
    ,'Owner' contact_type
    ,null contact_relationship 
    ,'Y' isPrimary --(case when a.primary_name = 1 then 'Y' else 'N' end) isPrimary
    ,null Lic_Num
    ,null lic_type
    ,left(trim(replace(replace(   trim(isnull(a.address_1,'')) + isnull(trim(a.name),'')    ,'  ',' '),'  ',' ')),220) name
    ,null as FName --,trim(substring(a.name,1,charindex(' ',a.name))) as FName
    ,null as MName
    ,left(trim(replace(replace(   a.name    ,'  ',' '),'  ',' ')),70) --,left(trim(substring(a.name,charindex(' ',a.name),len(a.name))),70) LName
    ,trim(replace(replace(   a.name    ,'  ',' '),'  ',' ')) bus_name --replace(replace(replace(replace(   coalesce(a.PROGRAM_IDENTIFIER,fac.facility_name)    ,'"',''''''),'''',''),char(13),''),char(10),'') as Bus_Name
    ,left(trim(replace(replace(replace(replace(        a.address_2          ,'  ',' '),'  ',' '),'  ',' '),',,',',')),40) addr1
    ,a.address_3 addr2
    ,null add3
    ,null city
    ,null state
    ,left(coalesce(a.zip,''),10) zip
    ,a.phone_1 ph1
    ,a.phone_2 ph2
    ,null as Fax
    ,left(a.email_addr,70) Email
    ,null as Comments
    ,a.relationship as Title
    ,null as Ph3
    ,null as Country_Code
    ,null as Notify
    ,null as Name_Suffix
    ,null as Bus_Lic
    ,null as Lic_Original_Issue_Date
    ,null as Expiration_date
    ,null as Renewal_Date
    ,left(trim(replace(replace(replace(replace(        a.address_2          ,'  ',' '),'  ',' '),'  ',' '),',,',',')),40) addr1
    ,a.address_3 addr2
    ,null as Mail_add3
    ,null Mail_city
    ,null mail_state --,coalesce(e.state,fac.mstate,'') Mail_state
    ,left(coalesce(a.zip,''),10) mail_zip --,left(coalesce(e.zip,fac.mzip,''),10) Mail_zip
    ,null as Mail_Country
    ,null as Owner_Type
    ,null as Gender
    ,null as Salutation
    ,null as PO_Box
    ,null as Bus_Name2
    ,null as Birth_Date
    ,null as Ph1_Country_Code,null as Ph2_Country_Code,null as Fax_Country_Code,null as Ph3_Country_Code,null as Trade_Name,null as Contact_Type_Flag,null as Social_Security_Number,null as Federal_Employer_ID_Num,null as Contra_Type_Flag,null as Lic_Board,null as B1_ID,null as Cont_Lic_Bus_Name,null as B1_Access_Level,null as Birth_City,null as Birth_State,null as Birth_Region,null as B1_Contact_Nbr,null as Deceased_Date
    ,null as Driver_License_Nbr    
    ,null as Driver_License_State,null as Passport_Nbr,null as State_Id_Nbr,null as Race,null as G1_Contact_Nbr,null as Lic_State
from aatable_permit_history pnum --from (select distinct number_key permitnum from hcfl_src.dbo.apd_base) pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_peo a on a.number_key = pmap.number_key
WHERE
    1=1
    and a.relationship in (
        'ONWER     '
        ,'OOWNER    '
        ,'OWENER    '
        ,'OWER      '
        ,'OWMER     '
        ,'OWNER     '
        ,'OWNER,    '
        ,'OWNER/AGEN'
        ,'OWNER/APP '
        ,'OWNER/GC  '
        ,'OWNER/OCC '
        ,'OWNER6    '
        ,'OWNERS    '
        ,'PARK OWNER'
        ,'PROP OWNER'
        ,'AGENT/OWNR'
        ----all home% are unlicensed.
        ,'HOME OWNER'
        ,'HOMEEOWNER'
        ,'HOMEOWER  '
        ,'HOMEOWNER '
        ,'HOMEOWNER.'
        ,'HOMEOWNERS'
        ,'HOMEWONER '
        ,'HOMWOWNER '
        ,'HONMEOWNER'
        -----         
        --,'APPICANT  '
        --,'APPLICANT '
        --,'APPLICANTS'
        
    )
    --or 
    --(isnull(trim(a.license_no),'') = '')
    --)
    ----NO! All investigators and inspectors are unlicensed individuals.
    --and a.relationship not in (
    --    'INSPECTOR '
    --    ,'INVESTIG  '
    --    ,'INVESTIGAT'
;

--apd_peo__nonOwner__notLic
;print 'apd_peo__nonOwner__notLic';
insert into AATABLE_PERMIT_PEOPLE (
PERMITNUM,TT_CONTACT_TYPE,CONTACT_RELATIONSHIP ,ISPRIMARY,LIC_NUM,LIC_TYPE,NAME,FNAME,MNAME,LNAME,BUS_NAME,ADDR1,ADDR2,ADDR3,CITY,STATE,ZIP,PH1,PH2,FAX,EMAIL,COMMENTS,TITLE,PH3,COUNTRY_CODE,NOTIFY,NAME_SUFFIX,BUS_LIC,LIC_ORIGINAL_ISSUE_DATE,EXPIRATION_DATE,RENEWAL_DATE,MAIL_ADDR1,MAIL_ADDR2,MAIL_ADDR3,MAIL_CITY,MAIL_STATE,MAIL_ZIP,MAIL_COUNTRY,OWNER_TYPE,GENDER,SALUTATION,PO_BOX,BUS_NAME2,BIRTH_DATE,PH1_COUNTRY_CODE,PH2_COUNTRY_CODE,FAX_COUNTRY_CODE,PH3_COUNTRY_CODE,TRADE_NAME,CONTACT_TYPE_FLAG,SOCIAL_SECURITY_NUMBER,FEDERAL_EMPLOYER_ID_NUM,CONTRA_TYPE_FLAG,LIC_BOARD,B1_ID,CONT_LIC_BUS_NAME,B1_ACCESS_LEVEL,BIRTH_CITY,BIRTH_STATE,BIRTH_REGION,B1_CONTACT_NBR,DECEASED_DATE,DRIVER_LIC_NBR,DRIVER_LIC_STATE,PASSPORT_NBR,STATE_ID_NBR,RACE,G1_CONTACT_NBR,LIC_STATE
)
select distinct 
	pnum.permitnum
    ,coalesce(case when trim(a.relationship)='' then null else a.relationship end,'Contact') contact_type
    ,null contact_relationship 
    ,(case when a.primary_name = 1 then 'Y' else 'N' end) isPrimary
    ,null Lic_Num
    ,null lic_type
    ,left(trim(replace(replace(   trim(isnull(a.address_1,'')) + isnull(trim(a.name),'')    ,'  ',' '),'  ',' ')),220) name
    ,null as FName --,trim(substring(a.name,1,charindex(' ',a.name))) as FName
    ,null as MName
    ,left(trim(replace(replace(   a.name    ,'  ',' '),'  ',' ')),70) --,left(trim(substring(a.name,charindex(' ',a.name),len(a.name))),70) LName
    ,trim(replace(replace(   a.name    ,'  ',' '),'  ',' ')) bus_name --replace(replace(replace(replace(   coalesce(a.PROGRAM_IDENTIFIER,fac.facility_name)    ,'"',''''''),'''',''),char(13),''),char(10),'') as Bus_Name
    ,left(trim(replace(replace(replace(replace(        a.address_2          ,'  ',' '),'  ',' '),'  ',' '),',,',',')),40) addr1
    ,a.address_3 addr2
    ,null add3
    ,null city
    ,null state
    ,left(coalesce(a.zip,''),10) zip
    ,a.phone_1 ph1
    ,a.phone_2 ph2
    ,null as Fax
    ,left(a.email_addr,70) Email
    ,null as Comments
    ,a.relationship as Title
    ,null as Ph3
    ,null as Country_Code
    ,null as Notify
    ,null as Name_Suffix
    ,null as Bus_Lic
    ,null as Lic_Original_Issue_Date
    ,null as Expiration_date
    ,null as Renewal_Date
    ,left(trim(replace(replace(replace(replace(        a.address_2          ,'  ',' '),'  ',' '),'  ',' '),',,',',')),40) Mail_addr1
    ,a.address_3 as Mail_addr2
    ,null as Mail_add3
    ,null Mail_city
    ,null mail_state --,coalesce(e.state,fac.mstate,'') Mail_state
    ,left(coalesce(a.zip,''),10) mail_zip --,left(coalesce(e.zip,fac.mzip,''),10) Mail_zip
    ,null as Mail_Country
    ,null as Owner_Type
    ,null as Gender
    ,null as Salutation
    ,null as PO_Box
    ,null as Bus_Name2
    ,null as Birth_Date
    ,null as Ph1_Country_Code,null as Ph2_Country_Code,null as Fax_Country_Code,null as Ph3_Country_Code,null as Trade_Name,null as Contact_Type_Flag,null as Social_Security_Number,null as Federal_Employer_ID_Num,null as Contra_Type_Flag,null as Lic_Board,null as B1_ID,null as Cont_Lic_Bus_Name,null as B1_Access_Level,null as Birth_City,null as Birth_State,null as Birth_Region,null as B1_Contact_Nbr,null as Deceased_Date
    ,null as Driver_License_Nbr    
    ,null as Driver_License_State,null as Passport_Nbr,null as State_Id_Nbr,null as Race,null as G1_Contact_Nbr,null as Lic_State
from aatable_permit_history pnum --from (select distinct number_key permitnum from hcfl_src.dbo.apd_base) pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_peo a on a.number_key = pmap.number_key
WHERE
    1=1
    and a.relationship not in (
        'ONWER     '
        ,'OOWNER    '
        ,'OWENER    '
        ,'OWER      '
        ,'OWMER     '
        ,'OWNER     '
        ,'OWNER,    '
        ,'OWNER/AGEN'
        ,'OWNER/APP '
        ,'OWNER/GC  '
        ,'OWNER/OCC '
        ,'OWNER6    '
        ,'OWNERS    '
        ,'PARK OWNER'
        ,'PROP OWNER'
        ,'AGENT/OWNR'
        ----all home% are unlicensed.
        ,'HOME OWNER'
        ,'HOMEEOWNER'
        ,'HOMEOWER  '
        ,'HOMEOWNER '
        ,'HOMEOWNER.'
        ,'HOMEOWNERS'
        ,'HOMEWONER '
        ,'HOMWOWNER '
        ,'HONMEOWNER'
        -----         
        --,'APPICANT  '
        --,'APPLICANT '
        --,'APPLICANTS'
        
    )
    and isnull(trim(a.license_no),'') = ''
;


--apd_peo__all_with_lic
;print 'apd_peo__all_with_lic';
insert into AATABLE_PERMIT_PEOPLE (
PERMITNUM,TT_CONTACT_TYPE,CONTACT_RELATIONSHIP ,ISPRIMARY,LIC_NUM,LIC_TYPE,NAME,FNAME,MNAME,LNAME,BUS_NAME,ADDR1,ADDR2,ADDR3,CITY,STATE,ZIP,PH1,PH2,FAX,EMAIL,COMMENTS,TITLE,PH3,COUNTRY_CODE,NOTIFY,NAME_SUFFIX,BUS_LIC,LIC_ORIGINAL_ISSUE_DATE,EXPIRATION_DATE,RENEWAL_DATE,MAIL_ADDR1,MAIL_ADDR2,MAIL_ADDR3,MAIL_CITY,MAIL_STATE,MAIL_ZIP,MAIL_COUNTRY,OWNER_TYPE,GENDER,SALUTATION,PO_BOX,BUS_NAME2,BIRTH_DATE,PH1_COUNTRY_CODE,PH2_COUNTRY_CODE,FAX_COUNTRY_CODE,PH3_COUNTRY_CODE,TRADE_NAME,CONTACT_TYPE_FLAG,SOCIAL_SECURITY_NUMBER,FEDERAL_EMPLOYER_ID_NUM,CONTRA_TYPE_FLAG,LIC_BOARD,B1_ID,CONT_LIC_BUS_NAME,B1_ACCESS_LEVEL,BIRTH_CITY,BIRTH_STATE,BIRTH_REGION,B1_CONTACT_NBR,DECEASED_DATE,DRIVER_LIC_NBR,DRIVER_LIC_STATE,PASSPORT_NBR,STATE_ID_NBR,RACE,G1_CONTACT_NBR,LIC_STATE
)
select distinct 
    pnum.permitnum
    ,null contact_type
    ,null contact_relationship
    ,(case when isnull(isPrimary.isPrimary,'') = 'Y' then 'N' when a.primary_name = 1 then 'Y' else 'N' end) isPrimary
    ,a.license_no Lic_Num
    ,a.relationship lic_type
    ,left(trim(replace(replace(   trim(isnull(a.address_1,'')) + isnull(trim(a.name),'')    ,'  ',' '),'  ',' ')),220) name
    ,null as FName --,trim(substring(a.name,1,charindex(' ',a.name))) as FName
    ,null as MName
    ,left(trim(replace(replace(   a.name    ,'  ',' '),'  ',' ')),70) --,left(trim(substring(a.name,charindex(' ',a.name),len(a.name))),70) LName
	,a.name as Bus_Name
    ,left(trim(replace(replace(replace(replace(        a.address_2          ,'  ',' '),'  ',' '),'  ',' '),',,',',')),40) addr1
    ,a.address_3 addr2
    ,null add3
    ,null city
    ,null state
    ,left(coalesce(a.zip,''),10) zip
    ,a.phone_1 ph1
    ,a.phone_2 ph2
    ,cp.phone_fax as Fax
    ,left(a.email_addr,70) Email
    ,trim(';' from isnull(';element_key:'+cb.element_key,'')+isnull(';ins_policy:'+cb.ins_policy,'')+isnull(';ins_amt:'+convert(varchar(max),cb.ins_amt),'')+isnull(';ins_carrier:'+cb.ins_carrier,'')) --comments.comment_text as Comments
    ,null as Title
    ,null as Ph3
    ,null as Country_Code
    ,null as Notify
    ,null as Name_Suffix
    ,cb.BUSINESS_LIC as Bus_Lic
    ,cb.entered_date as Lic_Original_Issue_Date
    ,cb.lic_exp_date as Expiration_date
    ,null as renewal_date
    ,left(trim(replace(replace(replace(replace(        a.address_2          ,'  ',' '),'  ',' '),'  ',' '),',,',',')),40) Mail_addr1
    ,a.address_3 as Mail_addr2
    ,null as Mail_add3
    ,null Mail_city
    ,null mail_state --,coalesce(e.state,fac.mstate,'') Mail_state
    ,left(coalesce(a.zip,''),10) mail_zip --,left(coalesce(e.zip,fac.mzip,''),10) Mail_zip
    ,'USA' as Mail_Country
    ,null as Owner_Type,null as Gender,null as Salutation,null as PO_Box,null as Bus_Name2
    ,null as Birth_Date
    ,null as Ph1_Country_Code,null as Ph2_Country_Code,null as Fax_Country_Code,null as Ph3_Country_Code,null as Trade_Name,null as Contact_Type_Flag,null as Social_Security_Number,null as Federal_Employer_ID_Num,null as Contra_Type_Flag,null as Lic_Board,null as B1_ID,null as Cont_Lic_Bus_Name,null as B1_Access_Level,null as Birth_City,null as Birth_State,null as Birth_Region,null as B1_Contact_Nbr,null as Deceased_Date
    ,null as Driver_License_Nbr    
    ,null as Driver_License_State,null as Passport_Nbr,null as State_Id_Nbr,null as Race,null as G1_Contact_Nbr,null as Lic_State
from aatable_permit_history pnum --from (select distinct number_key permitnum from hcfl_src.dbo.apd_base) pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_peo a on a.number_key = pmap.number_key
left join aatable_permit_people isPrimary 
    on isPrimary.permitnum = pnum.permitnum
    and isPrimary.name = trim(replace(replace(   a.name    ,'  ',' '),'  ',' '))
    and isPrimary.addr1 = left(trim(replace(replace(replace(replace(         case when coalesce(trim(a.address_1),'') <> '' then a.address_1 else 'Not Set' end          ,'  ',' '),'  ',' '),'  ',' '),',,',',')),40)
left join hcfl_src.dbo.con_peo cp on cp.LICENSE_NO = a.LICENSE_NO and cp.name = a.name
left join hcfl_src.dbo.CON_BASE cb on cb.ELEMENT_KEY = cp.ELEMENT_KEY
WHERE
    1=1
    and (isnull(trim(a.license_no),'') <> '')
;


--CBS people duplication -- addendum per 20240525 - they want people duplicated on cbs records from non-cbs records
delete a
from AATABLE_PERMIT_PEOPLE a
join AATABLE_PERMIT_HISTORY pnum on pnum.PERMITNUM = a.PERMITNUM
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'-CBS' = pnum.permitnum 
;
go

insert into aatable_permit_people
select
	pnum.PERMITNUM,
	a.TT_CONTACT_TYPE,a.CONTACT_RELATIONSHIP,a.ISPRIMARY,a.LIC_NUM,a.LIC_TYPE,a.NAME,a.FNAME,a.MNAME,a.LNAME,a.BUS_NAME,a.ADDR1,a.ADDR2,a.ADDR3,a.CITY,a.STATE,a.ZIP,a.PH1,a.PH2,a.FAX,a.EMAIL,a.COMMENTS,a.TITLE,a.PH3,a.COUNTRY_CODE,a.NOTIFY,a.NAME_SUFFIX,a.BUS_LIC,a.LIC_ORIGINAL_ISSUE_DATE,a.EXPIRATION_DATE,a.RENEWAL_DATE,a.MAIL_ADDR1,a.MAIL_ADDR2,a.MAIL_ADDR3,a.MAIL_CITY,a.MAIL_STATE,a.MAIL_ZIP,a.MAIL_COUNTRY,a.OWNER_TYPE,a.GENDER,a.SALUTATION,a.PO_BOX,a.BUS_NAME2,a.BIRTH_DATE,a.PH1_COUNTRY_CODE,a.PH2_COUNTRY_CODE,a.FAX_COUNTRY_CODE,a.PH3_COUNTRY_CODE,a.TRADE_NAME,a.CONTACT_TYPE_FLAG,a.SOCIAL_SECURITY_NUMBER,a.FEDERAL_EMPLOYER_ID_NUM,a.CONTRA_TYPE_FLAG,a.LIC_BOARD,a.B1_ID,a.CONT_LIC_BUS_NAME,a.B1_ACCESS_LEVEL,a.BIRTH_CITY,a.BIRTH_STATE,a.BIRTH_REGION,a.B1_CONTACT_NBR,a.DECEASED_DATE,a.DRIVER_LIC_NBR,a.DRIVER_LIC_STATE,a.PASSPORT_NBR,a.STATE_ID_NBR,a.RACE,a.G1_CONTACT_NBR,a.LIC_STATE
from AATABLE_PERMIT_PEOPLE a
join AATABLE_PERMIT_HISTORY pnum on pnum.PERMITNUM = a.PERMITNUM + '-CBS'
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'-CBS' = pnum.permitnum 
where
	1=1	
;






go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0180 aatable_permit_addresses.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0180 aatable_permit_addresses.sql')
/*
create_AATABLE_PERMIT_ADDRESS
locksmith_addresses
apd_adr__addresses
remove_duplicate_numberKey_fullAddress
Address_addendum__parsing
address_assemble_all
remove_str_suffix
CBS address duplication
*/
--create_AATABLE_PERMIT_ADDRESS
IF OBJECT_ID('tempdb.dbo.##completed', 'U') IS NOT NULL 
insert into ##completed values (getdate(),'create_AATABLE_PERMIT_ADDRESS')
;
;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_ADDRESS
;
;IF OBJECT_ID('tempdb.dbo.#AATABLE_PERMIT_ADDRESS', 'U') IS NOT NULL drop table #AATABLE_PERMIT_ADDRESS
--;select top 0 * into #AATABLE_PERMIT_ADDRESS from AATABLE_PERMIT_ADDRESS
;CREATE TABLE #AATABLE_PERMIT_ADDRESS (
	[PERMITNUM] [varchar](30) NOT NULL,
	[ISPRIMARY] [varchar](1) NULL,
	[STR_NUM_START] [numeric](9, 0) NULL,
	[STR_NUM_END] [numeric](9, 0) NULL,
	[STR_FRAC_START] [varchar](20) NULL,
	[STR_FRAC_END] [varchar](20) NULL,
	[STR_DIR] [varchar](20) NULL,
	[STR_NAME] [varchar](100) NULL,
	[STR_SUFFIX] [varchar](30) NULL,
	[STR_SUFFIX_DIR] [varchar](20) NULL,
	[STR_PREFIX] [varchar](20) NULL,
	[STR_UNIT_START] [varchar](10) NULL,
	[STR_UNIT_END] [varchar](10) NULL,
	[STR_UNIT_TYPE] [varchar](20) NULL,
	[SITUS_CITY] [varchar](40) NULL,
	[SITUS_STATE] [varchar](30) NULL,
	[SITUS_ZIP] [varchar](10) NULL,
	[SITUS_COUNTY] [varchar](30) NULL,
	[SITUS_COUNTRY] [varchar](30) NULL,
	[SITUS_COUNTRY_CODE] [varchar](2) NULL,
	[X_COORD] [numeric](20, 8) NULL,
	[Y_COORD] [numeric](20, 8) NULL,
	[ADDR_DESC] [varchar](255) NULL,
	[FULL_ADDRESS] [varchar](600) NOT NULL,
	[ADDRESS1] [varchar](200) NULL,
	[ADDRESS2] [varchar](200) NULL,
	[SITUS_NBRHD] [varchar](30) NULL,
	[EXT_ADDRESS_UID] [varchar](100) NULL,
	[STREET_NAME_START] [varchar](200) NULL,
	[STREET_NAME_END] [varchar](200) NULL,
	[CROSS_STREET_NAME_START] [varchar](200) NULL,
	[CROSS_STREET_NAME_END] [varchar](200) NULL,
	[HSE_NBR_ALPHA_START] [varchar](20) NULL,
	[HSE_NBR_ALPHA_END] [varchar](20) NULL,
	[LEVEL_PREFIX] [varchar](20) NULL,
	[LEVEL_NBR_START] [varchar](20) NULL,
	[LEVEL_NBR_END] [varchar](20) NULL
)
;

--locksmith_addresses
;print 'locksmith_addresses';
    --client (represented this time by shane varnum) explicitly asked for locksmith records to use apd_Base.location
insert into #AATABLE_PERMIT_ADDRESS (
PERMITNUM,ISPRIMARY,STR_NUM_START,STR_NUM_END,STR_FRAC_START,STR_FRAC_END,STR_DIR,STR_NAME,STR_SUFFIX,STR_SUFFIX_DIR,STR_PREFIX,STR_UNIT_START,STR_UNIT_END,STR_UNIT_TYPE,SITUS_CITY,SITUS_STATE,SITUS_ZIP,SITUS_COUNTY,SITUS_COUNTRY,SITUS_COUNTRY_CODE,X_COORD,Y_COORD,ADDR_DESC,FULL_ADDRESS,ADDRESS1,ADDRESS2,SITUS_NBRHD,EXT_ADDRESS_UID,STREET_NAME_START, STREET_NAME_END, CROSS_STREET_NAME_START,CROSS_STREET_NAME_END, HSE_NBR_ALPHA_START,HSE_NBR_ALPHA_END,LEVEL_PREFIX,	LEVEL_NBR_START,LEVEL_NBR_END
)
select distinct
    pnum.PERMITNUM
    ,'Y' --(case when a.primary_addr = 1 then 'Y' else 'N' end) as ISPRIMARY
    ,null --try_convert(int,a.street_no) as STR_NUM_START
    ,null as STR_NUM_END
    ,null --a.addr_fraction as STR_FRAC_START
    ,null as STR_FRAC_END
    ,null --a.street_direction as STR_DIR
    ,null --left( a.street_name ,40) as STR_NAME
    ,null as STR_SUFFIX
    ,null as STR_SUFFIX_DIR
    ,null as STR_PREFIX
    ,null --(case when trim(isnull(a.unit_id,'')) <> '' then a.unit_id else null end) as STR_UNIT_START
    ,null as STR_UNIT_END
    ,null as STR_UNIT_TYPE
    ,null --isnull(left(city_id.city_name,40),left(city_id.city_name,40)) as SITUS_CITY
    ,null --'FL' as SITUS_STATE
    ,null --left(b.zip_code,10) as SITUS_ZIP
    ,null SITUS_COUNTY --,left(district.description,30) as SITUS_COUNTY
    ,'US' as SITUS_COUNTRY
    ,null as SITUS_COUNTRY_CODE
    ,null --b.x_coord as X_COORD
    ,null --b.y_coord as Y_COORD
    ,'Physical Location' as ADDR_DESC
    ,ab.location --coalesce(  CONCAT_WS(' ',a.street_no,a.street_name,a.street_direction,a.addr_fraction,'unit ' + a.unit_id,city_id.city_name,',FL',b.zip_code)  ,'Not Set') as FULL_ADDRESS 
    ,null --coalesce(  CONCAT_WS(' ',a.street_no,a.street_name,a.street_direction,a.addr_fraction,'unit ' + a.unit_id),'Not Set' ) as ADDRESS1
    ,null --coalesce(  CONCAT_WS(' ',city_id.city_name,',FL',b.zip_code),null ) as ADDRESS2
    ,null as SITUS_NBRHD
    ,null as EXT_ADDRESS_UID
    ,null as STREET_NAME_START
    ,null as STREET_NAME_END
    ,null as CROSS_STREET_NAME_START
    ,null as CROSS_STREET_NAME_END
    ,null as HSE_NBR_ALPHA_START
    ,null as HSE_NBR_ALPHA_END
    ,null as LEVEL_PREFIX
    ,null as LEVEL_NBR_START
    ,null as LEVEL_NBR_END
from aatable_permit_history pnum --from (select number_key as permitnum from hcfl_src.dbo.apd_base) pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_base ab on ab.number_key = pmap.number_key
--join hcfl_src.dbo.apd_adr a on a.number_key = pmap.number_key
--left join hcfl_src.dbo.CIT_BASE city_id on city_id.city_id = a.city_id
--left join hcfl_src.dbo.ADR_BASE b on b.ELEMENT_KEY = a.SITE_ELEMENT_KEY
WHERE
    1=1
    and pnum.tt_Record like 'locksmith%'
	and ab.location is not null
;


--apd_adr__addresses
;print 'apd_adr__addresses';
insert into #AATABLE_PERMIT_ADDRESS (
PERMITNUM,ISPRIMARY,STR_NUM_START,STR_NUM_END,STR_FRAC_START,STR_FRAC_END,STR_DIR,STR_NAME,STR_SUFFIX,STR_SUFFIX_DIR,STR_PREFIX,STR_UNIT_START,STR_UNIT_END,STR_UNIT_TYPE,SITUS_CITY,SITUS_STATE,SITUS_ZIP,SITUS_COUNTY,SITUS_COUNTRY,SITUS_COUNTRY_CODE,X_COORD,Y_COORD,ADDR_DESC,FULL_ADDRESS,ADDRESS1,ADDRESS2,SITUS_NBRHD,EXT_ADDRESS_UID,STREET_NAME_START, STREET_NAME_END, CROSS_STREET_NAME_START,CROSS_STREET_NAME_END, HSE_NBR_ALPHA_START,HSE_NBR_ALPHA_END,LEVEL_PREFIX,	LEVEL_NBR_START,LEVEL_NBR_END
)
select distinct
    pnum.PERMITNUM
    ,(case when a.primary_addr = 1 then 'Y' else 'N' end) as ISPRIMARY
    ,try_convert(int,a.street_no) as STR_NUM_START
    ,null as STR_NUM_END
    ,a.addr_fraction as STR_FRAC_START
    ,null as STR_FRAC_END
    ,a.street_direction as STR_DIR
    ,left( a.street_name ,40) as STR_NAME
    ,null as STR_SUFFIX
    ,null as STR_SUFFIX_DIR
    ,null as STR_PREFIX
    ,(case when trim(isnull(a.unit_id,'')) <> '' then a.unit_id else null end) as STR_UNIT_START
    ,null as STR_UNIT_END
    ,null as STR_UNIT_TYPE
    ,isnull(left(city_id.city_name,40),left(city_id.city_name,40)) as SITUS_CITY
    ,'FL' as SITUS_STATE
    ,left(b.zip_code,10) as SITUS_ZIP
    ,null SITUS_COUNTY --,left(district.description,30) as SITUS_COUNTY
    ,'US' as SITUS_COUNTRY
    ,null as SITUS_COUNTRY_CODE
    ,b.x_coord as X_COORD
    ,b.y_coord as Y_COORD
    ,'Physical Location' as ADDR_DESC
    ,replace(replace(replace(replace(replace(replace(coalesce(  CONCAT_WS(' ',a.street_no,a.street_name,a.street_direction,a.addr_fraction,case when trim(isnull(a.unit_id,'')) <> '' then 'unit ' + a.unit_id else null end,city_id.city_name,', FL',b.zip_code)  ,'Not Set'),'  ',' '),'  ',' '),'  ',' '),'  ',' '),'  ',' '),' , ',', ') as FULL_ADDRESS 
    ,coalesce(  CONCAT_WS(' ',a.street_no,a.street_name,a.street_direction,a.addr_fraction,case when trim(isnull(a.unit_id,'')) <> '' then 'unit ' + a.unit_id else null end),'Not Set' ) as ADDRESS1
    ,replace(coalesce(  CONCAT_WS(' ',city_id.city_name,', FL',b.zip_code),null ),' , ',', ') as ADDRESS2
    ,null as SITUS_NBRHD
    ,null as EXT_ADDRESS_UID
    ,null as STREET_NAME_START
    ,null as STREET_NAME_END
    ,null as CROSS_STREET_NAME_START
    ,null as CROSS_STREET_NAME_END
    ,null as HSE_NBR_ALPHA_START
    ,null as HSE_NBR_ALPHA_END
    ,null as LEVEL_PREFIX
    ,null as LEVEL_NBR_START
    ,null as LEVEL_NBR_END
from aatable_permit_history pnum --from (select number_key as permitnum from hcfl_src.dbo.apd_base) pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_adr a on a.number_key = pmap.number_key
left join hcfl_src.dbo.CIT_BASE city_id on city_id.city_id = a.city_id
left join hcfl_src.dbo.ADR_BASE b on b.ELEMENT_KEY = a.SITE_ELEMENT_KEY
;



--remove_duplicate_numberKey_fullAddress
--aatable_permit_Address unique_key on permitnum,fulladdress. Some in source data have same address as both primary and non-primary.
-- Therefore: delete the duplicate keys.
-- note: in source, the two rows have different auto_key values, and different site_element_key values.
-- rem: I think that CE09015735 is the only duplicating row.
;print 'address permitnum,full_Address unique-collision-preventing-deletions'
;WITH cte AS (
  SELECT 
	permitnum
	,full_address
    ,ROW_NUMBER() OVER(PARTITION BY permitnum,full_address ORDER BY isprimary desc) AS Rn
  FROM #aatable_permit_address
)
DELETE cte WHERE Rn > 1



--Address_addendum__parsing
;print 'Address_addendum__parsing';
    --set str_name based on full address
update t set
	STR_NAME = (case 
		when full_address like '%,%' then trim(' ,' from substring(full_address,1,charindex(',',full_address)))
		else full_address 
		end
    )
from #AATABLE_PERMIT_ADDRESS t
where 
	(str_name = 'not set' or str_name is null)
	and 
	(  full_address like '%road%'
	or full_address like '%rd%'
	or full_address like '%lane%'
	or full_address like '%ln%'
	or full_address like '%drive%'
	or full_address like '%dr%'
	or full_address like '%drives%'
	or full_address like '%drs%'
	or full_address like '%street%'
	or full_address like '%st%'
	or full_address like '%boulevard%'
	or full_address like '%blvd%'
	or full_address like '%avenue%'
	or full_address like '%ave%'
	or full_address like '%court%'
	or full_address like '%ct%'
	or full_address like '%circle%'
	or full_address like '%cir%'
	or full_address like '%way%'
	or full_address like '%wy%'
	or full_address like '%run%'
	or full_address like '%trail%'
	or full_address like '%trl%'
	or full_address like '%terrace%'
	or full_address like '%ter%'
	or full_address like '%highway%'
	or full_address like '%hwy%'
	or full_address like '%walk%'
	or full_address like '%path%'
	or full_address like '%place%'
	or full_address like '%pl%'
	or full_address like '%meadow%'
	or full_address like '%mdw%'
	or full_address like '%mdws%'
	)
;

    --remove cardinal direction
update t set
	str_dir = trim(reverse(substring(reverse(str_name),1,charindex(' ',reverse(str_name)))))
	,str_name = trim(replace(str_name,trim(reverse(substring(reverse(str_name),1,charindex(' ',reverse(str_name))))),''))
from #AATABLE_PERMIT_ADDRESS t
where
	str_dir is null
	and
	trim(reverse(substring(reverse(str_name),1,charindex(' ',reverse(str_name))))) in ('north','east','SOUTH','west','n','e','s','w') 
;

    --remove str number
update t set
	str_num_start = convert(int,substring(STR_NAME,1,charindex(' ',str_name))) 
	,STR_NAME = trim(substring(STR_NAME,charindex(' ',str_name),len(str_name)))
from #AATABLE_PERMIT_ADDRESS t
where 
	STR_NUM_START is null
	and 
    try_convert(int,substring(STR_NAME,1,charindex(' ',str_name))) is not null
;

    --remove str suffix
update t set
	str_suffix = reverse(trim(substring(reverse(str_name),1,charindex(' ',reverse(str_name)))))
	,STR_NAME = trim(reverse(substring(
			reverse(str_name)
			,charindex(' ',reverse(str_name))
			,len(reverse(str_name))
		)))
from #AATABLE_PERMIT_ADDRESS t
where 
	str_suffix is null
	and 
	reverse(trim(substring(reverse(str_name),1,charindex(' ',reverse(str_name)))))
	in ('road','rd','lane','ln','drive','dr','drives','drs','street','st','boulevard','blvd','avenue','ave','court','ct','circle','cir','way','wy','run','trail','trl','terrace','ter','highway','hwy','walk','path','place','pl','meadow','mdw','mdws')
;

--    --add county if city matches to existing districts
--update t set
--	situs_county = situs_city
--from #AATABLE_PERMIT_ADDRESS t
--join CD_CORE_DISTRICT_CODE district on district.description = t.situs_city
--WHERE
--    t.situs_county is null
--    or t.situs_county = 'not set'
--;

    --add full address based on primary address data
update t set
	full_address = trim(isnull(
        (  isnull(try_convert(varchar(max),STR_NUM_START),'')
            + isnull(' '+STR_DIR,'')
            + isnull(' '+STR_NAME,'')
            + isnull(' '+STR_SUFFIX,'')
            + isnull(' '+STR_UNIT_START,'')
            + isnull(', '+SITUS_CITY,'')
            + isnull(', '+SITUS_STATE,'')
            + isnull(' '+situs_zip,'')
        ) 
        ,'Not Set'
     ))
from #AATABLE_PERMIT_ADDRESS t
where
	FULL_ADDRESS = 'Not Set'
;
    
    --remove some empty fields
update t set
    str_suffix_dir = case when trim(str_suffix_dir) = '' then null else str_suffix_dir end
    ,str_unit_start = case when trim(str_unit_start) = '' then null else str_unit_start end
    ,str_unit_type = case when trim(str_unit_type) = '' then null else str_unit_type end
from #AATABLE_PERMIT_ADDRESS t
where
    1=1
    and (
        str_suffix_dir is not null
        or str_unit_start is not null
        or str_unit_type  is not null
    )
;





--address_assemble_all
;print 'address_assemble_all';
;;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_ADDRESS
;insert into AATABLE_PERMIT_ADDRESS (
PERMITNUM,ISPRIMARY,STR_NUM_START,STR_NUM_END,STR_FRAC_START,STR_FRAC_END,STR_DIR,STR_NAME,STR_SUFFIX,STR_SUFFIX_DIR,STR_PREFIX,STR_UNIT_START,STR_UNIT_END,STR_UNIT_TYPE,SITUS_CITY,SITUS_STATE,SITUS_ZIP,SITUS_COUNTY,SITUS_COUNTRY,SITUS_COUNTRY_CODE,X_COORD,Y_COORD,ADDR_DESC,FULL_ADDRESS,ADDRESS1,ADDRESS2,SITUS_NBRHD,EXT_ADDRESS_UID,STREET_NAME_START, STREET_NAME_END, CROSS_STREET_NAME_START,CROSS_STREET_NAME_END, HSE_NBR_ALPHA_START,HSE_NBR_ALPHA_END,LEVEL_PREFIX,	LEVEL_NBR_START,LEVEL_NBR_END
)
SELECT
    PERMITNUM,ISPRIMARY,STR_NUM_START,STR_NUM_END,STR_FRAC_START,STR_FRAC_END,STR_DIR
	,left(STR_NAME,40),STR_SUFFIX,STR_SUFFIX_DIR,STR_PREFIX,STR_UNIT_START,STR_UNIT_END,STR_UNIT_TYPE,SITUS_CITY,SITUS_STATE,SITUS_ZIP,SITUS_COUNTY,SITUS_COUNTRY,SITUS_COUNTRY_CODE,X_COORD,Y_COORD,ADDR_DESC,FULL_ADDRESS,ADDRESS1,ADDRESS2,SITUS_NBRHD,EXT_ADDRESS_UID,STREET_NAME_START, STREET_NAME_END, CROSS_STREET_NAME_START,CROSS_STREET_NAME_END, HSE_NBR_ALPHA_START,HSE_NBR_ALPHA_END,LEVEL_PREFIX,	LEVEL_NBR_START,LEVEL_NBR_END
from #AATABLE_PERMIT_ADDRESS
;





    --remove_str_suffix
update t set
	str_suffix = reverse(trim(substring(reverse(str_name),1,charindex(' ',reverse(str_name)))))
	,STR_NAME = trim(reverse(substring(
			reverse(str_name)
			,charindex(' ',reverse(str_name))
			,len(reverse(str_name))
		)))
from AATABLE_PERMIT_ADDRESS t
where 
	str_suffix is null
	and 
	reverse(trim(substring(reverse(str_name),1,charindex(' ',reverse(str_name)))))
	in ('road','rd','lane','ln','drive','dr','drives','drs','street','st','boulevard','blvd','avenue','ave','court','ct','circle','cir','way','wy','run','trail','trl','terrace','ter','highway','hwy','walk','path','place','pl','meadow','mdw','mdws')
;

--CBS address duplication
insert into aatable_permit_Address
SELECT
	pnum.PERMITNUM
	,a.ISPRIMARY,a.STR_NUM_START,a.STR_NUM_END,a.STR_FRAC_START,a.STR_FRAC_END,a.STR_DIR,a.STR_NAME,a.STR_SUFFIX,a.STR_SUFFIX_DIR,a.STR_PREFIX,a.STR_UNIT_START,a.STR_UNIT_END,a.STR_UNIT_TYPE,a.SITUS_CITY,a.SITUS_STATE,a.SITUS_ZIP,a.SITUS_COUNTY,a.SITUS_COUNTRY,a.SITUS_COUNTRY_CODE,a.X_COORD,a.Y_COORD,a.ADDR_DESC,a.FULL_ADDRESS,a.ADDRESS1,a.ADDRESS2,a.SITUS_NBRHD,a.EXT_ADDRESS_UID,a.STREET_NAME_START,a.STREET_NAME_END,a.CROSS_STREET_NAME_START,a.CROSS_STREET_NAME_END,a.HSE_NBR_ALPHA_START,a.HSE_NBR_ALPHA_END,a.LEVEL_PREFIX,a.LEVEL_NBR_START,a.LEVEL_NBR_END
from aatable_permit_address a 
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = a.permitnum
join AATABLE_PERMIT_HISTORY pnum on pnum.permitnum = a.permitnum + '-CBS'
;


go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0200 aatable_permit_parcel.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0100 0200 aatable_permit_parcel.sql')
/*
create_aatable_PERMIT_PARCEL
duplicate the parcel information into the cbs record
*/

--create_aatable_PERMIT_PARCEL
IF OBJECT_ID('tempdb.dbo.##completed', 'U') IS NOT NULL 
insert into ##completed values (getdate(),'create_aatable_PERMIT_PARCEL')
;
;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_PARCEL
;
;print 'AATABLE_PERMIT_PARCEL';
insert into AATABLE_PERMIT_PARCEL (
PERMITNUM,PARCELNUM,BOOK,PAGE,PARCEL,LOT,BLOCK,TRACT,LEGAL_DESC,PARCEL_AREA,PLAN_AREA,CENSUS_TRACT,COUNCIL_DISTRICT,SUPERVISOR_DISTRICT,INSPECTION_DISTRICT,LAND_VALUE,IMPROVED_VALUE,EXEMPT_VALUE,MAP_REFERENCE,MAP_NUMBER,SUBDIVISION,PRIMARY_FLAG,TOWNSHIP,RANGE,SECTION,EXT_PARCEL_UID
)
select distinct
    pnum.permitnum as [PERMITNUM]
	,left(numberKey_parcelNo.PARCEL_NO,24) as [PARCELNUM]
	,null as [BOOK]
	,null as [PAGE]
	,null as [PARCEL]
	,left(a.lot,40) as [LOT]
	,left(a.census_block,15) as [BLOCK]
	,a.tra as [TRACT]
	,left(a.legal_desc,2000) as [LEGAL_DESC]
	,a.acres as [PARCEL_AREA]
	,a.area as [PLAN_AREA]
	,a.census_tract as [CENSUS_TRACT]
	,null as [COUNCIL_DISTRICT]
	,null as [SUPERVISOR_DISTRICT]
	,null as [INSPECTION_DISTRICT]
	,null --a.land_Value as [LAND_VALUE]
	,null --a.imp_value as [IMPROVED_VALUE]
	,null --a.tot_exemp as [EXEMPT_VALUE]
	,null as [MAP_REFERENCE]
	,null as [MAP_NUMBER]
	,a.subdiv as [SUBDIVISION]
	,0 as [PRIMARY_FLAG] --update this value (below)
	,null as [TOWNSHIP]
	,null as [RANGE]
	,null as [SECTION]
	,null as [EXT_PARCEL_UID]
from aatable_permit_history pnum --from (select number_key permitnum from hcfl_src.dbo.apd_base) pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
join hcfl_src.dbo.par_base a on a.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
;


update a set
    a.PRIMARY_FLAG = 1
from AATABLE_PERMIT_PARCEL a
join (
    SELECT
        d.permitnum
        ,a.parcelNum
    from (select distinct parcelNum from AATABLE_PERMIT_PARCEL) a
    outer apply (select top 1 * from AATABLE_PERMIT_PARCEL where parcelNum = a.parcelNum) d
) f on f.permitnum = a.permitnum and f.parcelNum = a.parcelNum
;
go

--duplicate the parcel information into the cbs record
insert into aatable_permit_parcel
select
    pnum.PERMITNUM
    ,a.PARCELNUM,a.BOOK,a.PAGE,a.PARCEL,a.LOT,a.BLOCK,a.TRACT,a.LEGAL_DESC,a.PARCEL_AREA,a.PLAN_AREA,a.CENSUS_TRACT,a.COUNCIL_DISTRICT,a.SUPERVISOR_DISTRICT,a.INSPECTION_DISTRICT,a.LAND_VALUE,a.IMPROVED_VALUE,a.EXEMPT_VALUE,a.MAP_REFERENCE,a.MAP_NUMBER,a.SUBDIVISION,a.PRIMARY_FLAG,a.TOWNSHIP,a.RANGE,a.SECTION,a.EXT_PARCEL_UID
from aatable_permit_parcel a
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = a.permitnum
join aatable_permit_history pnum on pnum.permitnum = a.permitnum + '-CBS'
;


go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0120 0100 workflows.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0120 0100 workflows.sql')
/* 
rem: the apd_insp table: I am conceptualizing it like... a site visit happens, and subsequent actions/results are in subsequent rows.
Therefore: omit SV,SSV,QCSV,LSV rows, and omit COM,ACOM rows.

Citizens_Board_Support_water_enforcement_ENF_CBS_WA
Water_Enforcement__ENF_WATER_2
comment apostrophes
*/

;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_WORKFLOW
;
--Citizens_Board_Support_water_enforcement_ENF_CBS_WA
;IF OBJECT_ID('tempdb.dbo.#dataStatus_task_status_ENF_CBS_WA', 'U') IS NOT NULL drop table #dataStatus_task_status_ENF_CBS_WA
go
select
*
into #dataStatus_task_status_ENF_CBS_WA
from (VALUES
-- ('PREHRNG' ,'CBS Case Review',
--,('PRECEB'  ,'CBS Case Review',
 ('INSP','CBS Case Review','Request to Post At Property')
,('ADJUDIC','Post Hearing','Adjudicated')
,('CMPLFINE','Post-Hearing','Adjudicated')
,('FINERUN' ,'Post-Hearing','Adjudicated')
,('NWOWNFIN','Post-Hearing','Adjudicated')
,('CAONC'   ,'Post-Hearing','Adjudicated')
,('CAOPR'   ,'Post-Hearing','Adjudicated')
,('COMPLIED','Fee Intake','Fees Received')
,('CLOSED'  ,'Fee Intake','Fees Received')
,('CMPLCEB' ,'Fee Intake','Fees Received')
,('CNCL'    ,'Fee Intake','Fees Received')
,('DISMISS' ,'Fee Intake','Fees Received')
) t(data_status,tt_workflow_task,tt_workflow_status)
;
;insert into AATABLE_PERMIT_WORKFLOW (
PERMITNUM,TASKUPDATED,COMMENTS,ASGN_DATE,DUE_DATE,TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS,USER_ID,ID,SD_HOURS_SPENT,SD_BILLABLE,SD_OVERTIME,ESTIMATED_HOURS,ASGN_EMAIL_DISPLAY_FOR_ACA ,RESTRICT_COMMENT_FOR_ACA,RESTRICT_ROLE,TASK_UNIQUE_ID
)
select distinct
    pnum.permitnum as PERMITNUM
    ,COALESCE(try_convert(datetime,pnum.dateopened),'1900-01-01 00:00:00') as TASKUPDATED
    ,null as COMMENTS
    ,null as ASGN_DATE
    ,null as DUE_DATE
    ,f.tt_workflow_task as TT_WORKFLOW_TASK
    ,f.tt_workflow_status as TT_WORKFLOW_STATUS
    ,coalesce(asgn_staff.user_name,created_by.user_name,'Not Set') as USER_ID
    ,null as ID
    ,null as SD_HOURS_SPENT
    ,null as SD_BILLABLE
    ,null as SD_OVERTIME
    ,null as ESTIMATED_HOURS
    ,null as ASGN_EMAIL_DISPLAY_FOR_ACA
    ,null as RESTRICT_COMMENT_FOR_ACA
    ,null as RESTRICT_ROLE
    ,pnum.permitnum +'_initWorkflow' as TASK_UNIQUE_ID
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum +'-CBS' = pnum.permitnum
join jms_apd_base_filtered__wrviol1 a on a.number_key = pmap.number_key
left join jms_userid_username__wrviol1 created_by on created_by.user_id = a.user_id
left join jms_userid_username__wrviol1 asgn_staff on asgn_staff.user_id = a.insp_area
join #dataStatus_task_status_ENF_CBS_WA f on f.data_status = a.data_status
where 
    1=1
    and pnum.tt_record in ('Citizen Board Support Water Enforcement')
;


--Water_Enforcement__ENF_WATER_2

;IF OBJECT_ID('tempdb.dbo.#dataStatus_task_status_ENF_WATER_2', 'U') IS NOT NULL drop table #dataStatus_task_status_ENF_WATER_2
go
select
*
into #dataStatus_task_status_ENF_WATER_2
from (VALUES
-- ('NEW'     ,'Initial Investigation','ACTIVE')
 ('ACTIVE'  ,'Initial Investigation','Corrections Needed') --'Supervisor Approval','ACTIVE')
,('CLNO'    ,'Initial Investigation','No Violation')
,('CLSD'    ,'Admin Send Letter','Warning Sent')
,('COMPLIED','Admin Send Letter','NOV Complete')
,('APPLAPPR','Admin Send Letter','NOV Complete')
,('PRECEB ' ,'Case Affadavit','Case of Affidavit Sent')
,('PREHRNG' ,'Case Affadavit','Case of Affidavit Sent')
,('CAOPR'   ,'Case Affadavit','Case of Affidavit Sent')
,('CLOSED'  ,'Supervisor Approval','Administratively Closed')
,('CMPLCEB' ,'Citizen Board Support','Close')
,('CMPLFINE','Citizen Board Support','Close')
,('CNCL'    ,'Supervisor Approval','Administratively Closed')
,('DISMISS' ,'Citizen Board Support','Case Dismissed')
,('FINERUN' ,'Case Affadavit','Case of Affidavit Sent')
,('VOID'    ,'Supervisor Approval','Administratively Closed')
) t(data_status,tt_workflow_task,tt_workflow_status)
;

insert into AATABLE_PERMIT_WORKFLOW (
PERMITNUM,TASKUPDATED,COMMENTS,ASGN_DATE,DUE_DATE,TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS,USER_ID,ID,SD_HOURS_SPENT,SD_BILLABLE,SD_OVERTIME,ESTIMATED_HOURS,ASGN_EMAIL_DISPLAY_FOR_ACA ,RESTRICT_COMMENT_FOR_ACA,RESTRICT_ROLE,TASK_UNIQUE_ID
)
select distinct
    pnum.permitnum as PERMITNUM
    ,COALESCE(try_convert(datetime,pnum.dateopened),'1900-01-01 00:00:00') as TASKUPDATED
    ,null as COMMENTS
    ,null as ASGN_DATE
    ,null as DUE_DATE
    ,f.tt_workflow_task as TT_WORKFLOW_TASK
    ,f.tt_workflow_status as TT_WORKFLOW_STATUS
    ,coalesce(asgn_staff.user_name,created_by.user_name,'Not Set') as USER_ID
    ,null as ID
    ,null as SD_HOURS_SPENT
    ,null as SD_BILLABLE
    ,null as SD_OVERTIME
    ,null as ESTIMATED_HOURS
    ,null as ASGN_EMAIL_DISPLAY_FOR_ACA
    ,null as RESTRICT_COMMENT_FOR_ACA
    ,null as RESTRICT_ROLE
    ,pnum.permitnum +'_initWorkflow' as TASK_UNIQUE_ID
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered__wrviol1 a on a.number_key = pmap.number_key
left join jms_userid_username__wrviol1 created_by on created_by.user_id = a.user_id
left join jms_userid_username__wrviol1 asgn_staff on asgn_staff.user_id = a.insp_area
join #dataStatus_task_status_ENF_WATER_2 f on f.data_status = a.data_status
where 
    1=1
    and pnum.tt_record in ('Water Enforcement','Water Enforcement - Proactive')
;

--comment apostrophes
update aatable_permit_workflow set
    comments = replace(comments,'''','�')
;
    --and user_id's, apparently...
update aatable_permit_workflow set
    user_id = 'Spriggs, Teddy'
WHERE
    1=1
    and user_id = 'Spriggs, Edward ''Teddy'''
;



go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0140 0100 custom fields.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0140 0100 custom fields.sql')
/* 
water enforcement - ENF_WATER
    --REM this has a hack fix on '0180 0100 0100 custom lists violations.sql'
water enforcement cbs - ENF_CBS_WA


*/

--water enforcement - ENF_WATER
;IF OBJECT_ID('tempdb.dbo.##completed', 'U') is not null insert into ##completed values (getdate(),'0140 0100 custom fields.sql -- water enforcement')
;print 'Water Enforcement - ENF_WATER';

;IF OBJECT_ID('tempdb.dbo.#n0', 'U') IS NOT NULL DROP TABLE #n0
;SELECT
     n0.number_key
    ,n0.Date_053 as [dtLastNotice]
    ,n0.Date_075 as [dtHearingDate]
    ,n0.Num_028 as [numOffenceNumber]
into #n0
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'' = pnum.permitnum
join hcfl_src.dbo.apd_num0 n0 on n0.number_key = pmap.number_key
where 
	pnum.tt_record in ('Water Enforcement','Water Enforcement - Proactive')
	and (coalesce(n0.Date_053,n0.Date_075) is not null or coalesce(n0.Num_028,null) is not null)
;--50sec

;IF OBJECT_ID('tempdb.dbo.#n1', 'U') IS NOT NULL DROP TABLE #n1
;SELECT
     n1.number_key
    ,n1.Date_103 as	dtAppeal          
    ,n1.Date_102 as [dtHearingNotice]
    ,n1.date_103
    ,n1.date_109
    ,n1.date_118
into #n1
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'' = pnum.permitnum
left join hcfl_src.dbo.apd_num1 n1 on n1.number_key = pmap.number_key
--left join hcfl_src.dbo.apd_num0 n0 on n0.number_key = pmap.number_key
where 
	pnum.tt_record in ('Water Enforcement','Water Enforcement - Proactive')
	and coalesce(n1.Date_103,n1.Date_102,n1.date_103,n1.date_109,n1.date_118,null) is not null
;--20sec
;IF OBJECT_ID('tempdb.dbo.#t0', 'U') IS NOT NULL DROP TABLE #t0
;SELECT
     t0.number_key
    ,t0.YN_007   as ynAppealApproved
    ,t0.YN_008   as ynAppealDenied
    ,t0.Text_006 as txt_occupancy
    ,t0.text_000
    ,t0.text_004
    ,t0.text_014
into #t0
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'' = pnum.permitnum
join hcfl_src.dbo.apd_txt0 t0 on t0.number_key = pmap.number_key
where 
	pnum.tt_record in ('Water Enforcement','Water Enforcement - Proactive')
	and coalesce(t0.Text_006,t0.text_000,t0.text_004,t0.text_014,t0.YN_007,t0.YN_008,t0.Text_006) is not null
;--8sec
;IF OBJECT_ID('tempdb.dbo.#dtViolationTime', 'U') IS NOT NULL DROP TABLE #dtViolationTime
;with g as (
	select 
		t1.number_key
        ,try_convert(date,n1.DATE_100) as [dtIncident]
		,t1.Text_053 as [dtViolationTime] 
		,right('0'+replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(t1.Text_053,'.',''),'A',''),'P',''),':',''),' ',''),'hrs',''),'hr',''),'M',''),';',''),'"',''),'`',''),'-',''),4)
			as tttt
	from hcfl_src.dbo.apd_txt1 t1
	left join hcfl_src.dbo.apd_num1 n1 on n1.NUMBER_KEY = t1.NUMBER_KEY
	where 
		1=1
		and t1.NUMBER_KEY like 'wr%' 
		and (t1.text_053 is not null or n1.date_100 is not null)
)
select
	NUMBER_KEY
    ,dtIncident
	,dtViolationTime
	,('1900-01-01 ' +case 
            --WR2303234	1308 PM > 1900-01-01 13:08:00 rather than 25:08:00
			when try_convert(int,left(trim(dtViolationtime),2)) > 12
			then right(  '0'+convert(varchar(2),isnull(try_convert(int,substring(tttt,1,2)),0) + 0)  ,2)

			--12:04 > 1900-01-01 12:04:00 rather than 24:04:00
            when dtViolationTime like '%p%' and trim(dtViolationTime) like '12%' 
			then right(  '0'+convert(varchar(2),isnull(try_convert(int,substring(tttt,1,2)),0) + 0)  ,2)
            
            when dtViolationTime like '%p%' 
            then right(  '0'+convert(varchar(2),isnull(try_convert(int,substring(tttt,1,2)),0) + 12)  ,2)
            
            else left(tttt,2)
            end
        + ':'
        + right(tttt,2)
        + ':00' 
    ) as hhmmss
into #dtViolationTime
from g 
;

;IF OBJECT_ID('tempdb.dbo.#t1', 'U') IS NOT NULL DROP TABLE #t1
;SELECT
     t1.number_key
    ,t1.Text_065 as strAppealReason 
    ,t1.Text_066 as strADX
    ,t1.Text_059 as zoning
    ,t1.Text_076 as str_type
    ,t1.Text_080 as [NOTICE_TYPE]
    ,t1.Text_053 as [dtViolationTime]
    ,t1.text_050 --txt_cert_#_4      
    ,t1.text_060 --txt_phone         
    ,t1.text_067 --txt_Supervisor    
    ,t1.text_069 --txtWELL           
    ,t1.text_072 --
    ,t1.text_077 --txt_zip_code      
into #t1
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'' = pnum.permitnum
join hcfl_src.dbo.apd_txt1 t1 on t1.number_key = pmap.number_key
where 
	pnum.tt_record in ('Water Enforcement','Water Enforcement - Proactive')
	and coalesce(t1.Text_065,t1.Text_066,t1.Text_059,t1.Text_076,t1.Text_080,t1.Text_053,t1.text_050,t1.text_060,t1.text_067,t1.text_069,t1.text_072,t1.text_077,null) is not null
;--3sec
go
;IF OBJECT_ID('tempdb.dbo.#legal_descs', 'U') IS NOT NULL DROP TABLE #legal_descs
;create table #legal_descs ( permitnum varchar(50), legal_desc varchar(max) )
;with cte_many as (
	select 
		pmap.permitnum + '' permitnum
		,count(LEGAL_DESC) ct
	from aatable_permit_history pnum
	join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'' = pnum.permitnum
	join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
	left join hcfl_src.dbo.par_base pb on pb.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
	where
		1=1
		and pnum.tt_record in ('Water Enforcement','Water Enforcement - Proactive')
	group by pmap.permitnum
	having count(LEGAL_DESC) > 1
), g as (
	select distinct
		pmap.permitnum + '' permitnum
		,pb.LEGAL_DESC
	from aatable_permit_history pnum
	join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'' = pnum.permitnum
	join cte_many f on f.permitnum =  pmap.permitnum+''
	join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
	left join hcfl_src.dbo.par_base pb on pb.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
	where
		1=1
		and pnum.tt_record in ('Water Enforcement','Water Enforcement - Proactive')
),h as (
	SELECT
		permitnum
		,trim('^| ' from 
			  STUFF(
				(SELECT ' ^|^ ' + LEGAL_DESC
				 FROM g AS innerTable
				 WHERE innerTable.permitnum = outerTable.permitnum
				 FOR XML PATH(''), TYPE
				).value('.', 'NVARCHAR(MAX)'), 1, 2, '') 
		) AS legal_desc
	FROM g AS outerTable
	where
		1=1
		--and permitnum = 'CE19003259-cbs'
	GROUP BY permitnum
)
insert into #legal_descs
select * from h

union

select 
	pmap.permitnum + '' permitnum
	,trim(pb.LEGAL_DESC) legal_desc
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'' = pnum.permitnum
join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
left join hcfl_src.dbo.par_base pb on pb.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
where
	1=1
	and pnum.tt_record in ('Water Enforcement','Water Enforcement - Proactive')
	and not exists (
		select 1
		from h
		where permitnum =  pmap.permitnum+''
	)
;
go
IF OBJECT_ID('tempdb.dbo.#_wrviol_things', 'U') IS NOT NULL drop table #_wrviol_things
;
select distinct 
	i.number_key
	--,i.ITEM_ID
	,CONVERT(varchar(10), i.THE_DATE,121) the_date
	,i.ITEM_ID
	--i.*
	,tc.notation
into #_wrviol_things
from jms_apd_base_filtered__wrviol1 a 
join hcfl_src..apd_itms i on i.number_key = a.number_key
left join hcfl_src..tab_cond tc on tc.ELEMENT_KEY = i.ITEM_ID
where
	1=1
	and i.RECORD_TYPE = 'CD'
	--and i.number_key = 'WR1900045 '
;

;IF OBJECT_ID('tempdb.dbo.#wrviol_things', 'U') IS NOT NULL drop table #wrviol_things
;select distinct
	number_key
	,trim('^|' from stuff((
			select 
				'^|^' + cast(
					trim(replace(replace(replace(replace(   isnull(a2.the_date,'')   ,'"',''''''),'''',''),char(13),''),char(10),'�')) 
					as varchar(max)
				)
			from #_wrviol_things a2 with(nolock)
			where 
				1=1
				and a2.number_key = a1.number_key
			group by a2.the_date
			--order by a2.the_date,a2.item_id
			FOR XML PATH('')
	), 1, 1, '')) as the_date
	,trim(', ' from stuff((
			select 
				',' + cast(
					trim(replace(replace(replace(replace(   isnull(a2.item_id,'')   ,'"',''''''),'''',''),char(13),''),char(10),'�')) 
					as varchar(max)
				)
			from #_wrviol_things a2 with(nolock)
			where 
				1=1
				and a2.number_key = a1.number_key
			group by a2.item_id
			--order by a2.the_date,a2.item_id
			FOR XML PATH('')
	), 1, 1, '')) as item_id
	,trim(', ' from stuff((
			select 
				',' + cast(
					trim(replace(replace(replace(replace(   isnull(a2.notation,'')   ,'"',''''''),'''',''),char(13),''),char(10),'�')) 
					as varchar(max)
				)
			from #_wrviol_things a2 with(nolock)
			where 
				1=1
				and a2.number_key = a1.number_key
			group by a2.notation
			--order by a2.the_date,a2.item_id
			FOR XML PATH('')
	), 1, 1, '')) as notation
into #wrviol_things
from #_wrviol_things a1
where
	1=1
	--and NUMBER_KEY = 'WR1900045 '
;

;IF OBJECT_ID('tempdb.dbo.#primary_name_wrviol', 'U') IS NOT NULL DROP TABLE #primary_name_wrviol
;WITH RankedResults AS (
    SELECT 
        pmap.number_key --STRINSTRUMENTREL.vdi_key
        ,p.name
        ,ROW_NUMBER() OVER(PARTITION BY  pmap.number_key ORDER BY p.primary_name,p.name ) AS Rank
    from aatable_permit_history pnum
    join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'-CBS' = pnum.permitnum
    join hcfl_src.dbo.apd_peo p on p.number_key = pmap.number_key 
)
SELECT 
    *
into #primary_name_wrviol
FROM RankedResults
WHERE
    1=1
    and Rank = 1
;--22sec

;IF OBJECT_ID('tempdb.dbo.#primary_address_wrviol', 'U') IS NOT NULL DROP TABLE #primary_address_wrviol
;WITH RankedResults AS (
      SELECT 
        permitnum
        ,full_address
        ,ROW_NUMBER() OVER(PARTITION BY permitnum ORDER BY case when isprimary='Y' then 1 else 2 end) AS Rank
      FROM AATABLE_PERMIT_ADDRESS
)
SELECT 
	*
into #primary_address_wrviol
FROM RankedResults
WHERE
	1=1
	and Rank = 1
;




;IF OBJECT_ID('cf_Water_Enforcement', 'U') IS NOT NULL DROP TABLE cf_Water_Enforcement
;
select distinct
    pnum.permitNum
    ,pnum.tt_record
 
    --APPEAL INFORMATION
    ,n1.dtAppeal as [Appeal Hearing Date] --Date 
    ,(case 
        when t0.ynAppealApproved = 'Y' then 'Approved'
        when t0.ynAppealDenied = 'Y' then 'Denied'
        else null 
        end 
    ) as [Appeal Decision]
    ,t1.strAppealReason as [Appeal Comment] --Text 
 
    --DATA FIELDS
    ,t1.strADX as [ADX Number] --Text 
    ,t1.zoning as [Zoning] --Text 
    ,(case 
        when 1=0 then 'Res' 
        when 1=0 then 'Non Res'
        else null 
        end 
    ) as [res or non res] --dropdown
    ,(case t1.str_type
        when 'BLK' then 'Block'
        when 'FR'  then 'Frame'
        when 'MH'  then 'Mobile Home'
        else 'Other'
        end 
    ) as [structure type] --dropdown
 
    ,( case 
         when 1=0 then 'A'
         when 1=0 then 'B'
         when 1=0 then 'C'
         when 1=0 then 'D'
         when 1=0 then 'PRP'
         when 1=0 then 'RR'
        else null
        end
     ) as [Code Inspection Area] --Drop Down 
    ,a.location as [Description of Location] --Text 
    ,( case 
         when 1=0 then 'Back Office'
         when 1=0 then 'BOCC'
         when 1=0 then 'Call Center'
         when 1=0 then 'Proactive'
         when 1=0 then 'Sweep'
        end
     ) as [Type of Submittal] --Drop Down  req 
    ,null as [Repeat Violator] --Yes/No 
    ,t0.txt_occupancy as [occupancy type] --dropwdown
    ,n1.dtHearingNotice as [Notice Date] --Date  --Notice of Hearing Date%%
    ,t1.NOTICE_TYPE as [method of service] --dropdown
    ,n0.dtHearingDate as [Hearing Date] --Date 
 
    --SWEEP INFO
    ,null as [Date of Sweep] --Date 
    ,null as [Location of Sweep Operation] --Text 
 
    --VIOLATION INFO
    ,convert(date,dvt.dtIncident) as [Date of violation] --the hack fix is no longer applicable. Disregard info to the right of here. -- --t1.dtViolationTime as [Date of violation] --Date  ---REM this has a hack fix on '0180 0100 0100 custom lists violations.sql'
    ,dvt.hhmmss as [Time of Violation] -- date
        ,( case 
         when isnull(n0.numOffenceNumber,0) = 0 then null
         when n0.numOffenceNumber = 1 then 'First Offense'
         when n0.numOffenceNumber = 2 then 'Second Offense'
         when n0.numOffenceNumber = 3 then 'Third Offense'
         when n0.numOffenceNumber = 4 then 'Fourth Offense'
         when n0.numOffenceNumber = 5 then 'Fifth Offense'
         when n0.numOffenceNumber >= 6 then 'Sixth + Offense'
         else null
        end
     ) as [Offense Number] --Drop Down 
    ,null as [Lis pendens] --Yes/No 
    ,null as [Is this a Home Owner Associate complaint?] --Yes/No 
    ,null as [If yes, is the letter attached?] --Yes/No 
    ,null as [Create Violator from Owner] --CheckBox 
    ,null as [Court Case Number] --Text 
    
    --HISTORICAL PERMITS PLUS FIELDS
    ,a.ADDL_FEES AS [ADDL_FEES]
    ,NULL AS [ADDRESS_4]
    ,NULL AS [APPROVED]
    ,a.CALC_FEES AS [CALC_FEES]
    ,n1.DATE_103 AS [DATE_103]
    ,n1.DATE_109 AS [DATE_109]
    ,n1.DATE_118 AS [DATE_118]
    ,NULL AS [DATE_L]
    ,a.insp_area AS [INSP_AREA]
    ,pb.LEGAL_DESC AS [LEGAL_DESC]
    ,NULL AS [MON_066]
    ,wt.notation AS [NOTATION]
    ,aa.full_address AS [PRIMARY_ADDR]
    ,ap.name AS [PRIMARY_NAME]
    ,t0.text_000 AS [TEXT_000]
    ,t0.text_004 AS [TEXT_004]
    ,t0.text_014 AS [TEXT_014]
    ,t1.text_050 AS [TEXT_050]
    ,t1.text_060 AS [TEXT_060]
    ,t1.text_067 AS [TEXT_067]
    ,t1.text_069 AS [TEXT_069]
    ,t1.text_072 AS [TEXT_072]
    ,t1.text_077 AS [TEXT_077]
    ,wt.the_date AS [THE_DATE]
    ,coalesce(user_id.user_name,a.user_id) AS [USER_ID]
    ,wt.item_id AS [VIOLATIONS]
    ,a.sub_type [SUB_TYPE]
    ,a.DATE_A [DATE_A]
    ,a.date_k [DATE_K]
into cf_Water_Enforcement
from AATABLE_PERMIT_HISTORY pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered__wrviol1 a on a.NUMBER_KEY = pmap.number_key
left join #n0 n0 on n0.number_key = pmap.number_key
left join #n1 n1 on n1.number_key = pmap.number_key
left join #t0 t0 on t0.number_key = pmap.number_key
left join #t1 t1 on t1.number_key = pmap.number_key
left join #dtViolationTime dvt on dvt.number_key = a.number_key
left join #legal_descs pb on pb.permitnum = pmap.permitnum
left join jms_userid_username__wrviol1 user_id on user_id.user_id = a.user_id
left join #wrviol_things wt on wt.number_key = pmap.number_key
left join #primary_address_wrviol aa on aa.permitnum = pmap.permitnum 
left join #primary_name_wrviol ap on ap.number_key = pmap.number_key
where
    1=1
    and pnum.tt_record in ('Water Enforcement','Water Enforcement - Proactive')
;
 
    --ensure_fields_arent_too_long
declare @table_name varchar(100) = 'cf_Water_Enforcement' 

declare @cutoff int = 50;
DECLARE long_colname_cursor CURSOR for (
	select 
		column_name
	from INFORMATION_SCHEMA.columns 
	where 
		table_name = @table_name
		and len(column_name) > @cutoff
);

declare @column_name_old varchar(200);
declare @modString varchar(200);
declare @newname varchar(200);


OPEN long_colname_cursor
FETCH NEXT FROM long_colname_cursor INTO @column_name_old
    WHILE @@FETCH_STATUS = 0  
		begin
			set @modString = 'dbo.' + @table_name + '.' + @column_name_old;
			set @newname = left(@column_name_old, @cutoff)
			EXEC sp_rename @modString, @newname, 'COLUMN';
			FETCH NEXT FROM long_colname_cursor   INTO @column_name_old
		end
CLOSE long_colname_cursor
DEALLOCATE long_colname_cursor
;
go
;



--water enforcement cbs - ENF_CBS_WA
;IF OBJECT_ID('tempdb.dbo.#m0', 'U') IS NOT NULL DROP TABLE #m0
;SELECT
     m0.number_key
    ,m0.MON_045
    ,m0.MON_046
    ,m0.MON_047
    ,m0.MON_048
into #m0
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'-CBS' = pnum.permitnum
join hcfl_src.dbo.apd_mon0 m0 on m0.number_key = pmap.number_key
where 
	pnum.tt_record = 'Citizen Board Support Water Enforcement'
	and (coalesce(m0.MON_045,m0.MON_046,m0.MON_047,m0.MON_048) is not null)
;--50sec
;IF OBJECT_ID('tempdb.dbo.#n0', 'U') IS NOT NULL DROP TABLE #n0
;SELECT
     n0.number_key
    ,n0.Date_099 dtAffidavit     
	,n0.date_075 dtHearingDate
    ,n0.Date_084
    ,n0.Date_085
    ,n0.Date_099
into #n0
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'-CBS' = pnum.permitnum
join hcfl_src.dbo.apd_num0 n0 on n0.number_key = pmap.number_key
where 
	pnum.tt_record = 'Citizen Board Support Water Enforcement'
	and (coalesce(n0.Date_099,n0.Date_084,n0.Date_085,n0.Date_099,null) is not null)
;--50sec

;IF OBJECT_ID('tempdb.dbo.#n1', 'U') IS NOT NULL DROP TABLE #n1
;SELECT
     n1.number_key
     ,n1.Date_102 dtHearingNotice   
     ,n1.DATE_101
into #n1
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'-CBS' = pnum.permitnum
left join hcfl_src.dbo.apd_num1 n1 on n1.number_key = pmap.number_key
--left join hcfl_src.dbo.apd_num0 n0 on n0.number_key = pmap.number_key
where 
	pnum.tt_record = 'Citizen Board Support Water Enforcement'
	and coalesce(n1.Date_102,n1.DATE_101,null) is not null
;--20sec
;IF OBJECT_ID('tempdb.dbo.#t0', 'U') IS NOT NULL DROP TABLE #t0
;SELECT
     t0.number_key
    ,t0.Text_042 strHearingType    
    ,t0.Text_029 strDefendantHrng  
    ,t0.TEXT_003
    ,t0.TEXT_032
    ,t0.TEXT_040
    ,t0.TEXT_041
    ,t0.YN_007
into #t0
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'-CBS' = pnum.permitnum
join hcfl_src.dbo.apd_txt0 t0 on t0.number_key = pmap.number_key
where 
	pnum.tt_record = 'Citizen Board Support Water Enforcement'
	and coalesce(t0.Text_042,t0.text_029,t0.TEXT_003,t0.TEXT_032,t0.TEXT_040,t0.TEXT_041,t0.YN_007,null) is not null
;--8sec
;IF OBJECT_ID('tempdb.dbo.#dtViolationTime', 'U') IS NOT NULL DROP TABLE #dtViolationTime
;with g as (
	select 
		number_key
		,t1.Text_053 as [dtViolationTime] 
		,right('0'+replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(t1.Text_053,'.',''),'A',''),'P',''),':',''),' ',''),'hrs',''),'hr',''),'M',''),';',''),'"',''),'`',''),'-',''),4)
			as tttt
	from hcfl_src.dbo.apd_txt1 t1 
	where 
		1=1
		and NUMBER_KEY like 'wr%' 
		and t1.text_053 is not null
)
select
	NUMBER_KEY
	,dtViolationTime
	,('1900-01-01 ' +case 
            when dtViolationTime like '%p%' 
            then right(  '0'+convert(varchar(2),isnull(try_convert(int,substring(tttt,1,2)),0) + 12)  ,2)
            else left(tttt,2)
            end
        + ':'
        + right(tttt,2)
        + ':00' 
    ) as hhmmss
into #dtViolationTime
from g 
;

;IF OBJECT_ID('tempdb.dbo.#t1', 'U') IS NOT NULL DROP TABLE #t1
;SELECT
     t1.number_key
    ,t1.Text_065 as strAppealReason 
    ,t1.Text_066 as strADX
    ,t1.Text_059 as zoning
    ,t1.Text_076 as str_type
    ,t1.Text_080 as [NOTICE_TYPE]
    ,t1.Text_053 as [dtViolationTime]
    ,t1.text_050
    ,t1.text_060
    ,t1.text_067
    ,t1.text_069
    ,t1.text_072
    ,t1.text_077
    ,t1.TEXT_098
into #t1
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'-CBS' = pnum.permitnum
join hcfl_src.dbo.apd_txt1 t1 on t1.number_key = pmap.number_key
where 
	pnum.tt_record = 'Citizen Board Support Water Enforcement'
	and coalesce(t1.Text_065,t1.Text_066,t1.Text_059,t1.Text_076,t1.Text_080,t1.Text_053,t1.text_050,t1.text_060,t1.text_067,t1.text_069,t1.text_072,t1.text_077,t1.TEXT_098,null) is not null
;--3sec

;IF OBJECT_ID('tempdb.dbo.#legal_descs', 'U') IS NOT NULL DROP TABLE #legal_descs
;create table #legal_descs ( permitnum varchar(50), legal_desc varchar(max) )
;with cte_many as (
	select 
		pmap.permitnum + '-CBS' permitnum
		,count(LEGAL_DESC) ct
	from aatable_permit_history pnum
	join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'-CBS' = pnum.permitnum
	join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
	left join hcfl_src.dbo.par_base pb on pb.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
	where
		1=1
		and pnum.tt_record in ('Citizen Board Support Water Enforcement')
	group by pmap.permitnum
	having count(LEGAL_DESC) > 1
), g as (
	select distinct
		pmap.permitnum + '-CBS' permitnum
		,pb.LEGAL_DESC
	from aatable_permit_history pnum
	join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'-CBS' = pnum.permitnum
	join cte_many f on f.permitnum =  pmap.permitnum+'-CBS'
	join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
	left join hcfl_src.dbo.par_base pb on pb.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
	where
		1=1
		and pnum.tt_record in ('Citizen Board Support Water Enforcement')
),h as (
	SELECT
		permitnum
		,trim('^| ' from 
			  STUFF(
				(SELECT ' ^|^ ' + LEGAL_DESC
				 FROM g AS innerTable
				 WHERE innerTable.permitnum = outerTable.permitnum
				 FOR XML PATH(''), TYPE
				).value('.', 'NVARCHAR(MAX)'), 1, 2, '') 
		) AS legal_desc
	FROM g AS outerTable
	where
		1=1
		--and permitnum = 'CE19003259-cbs'
	GROUP BY permitnum
)
insert into #legal_descs
select * from h

union

select 
	pmap.permitnum + '-CBS' permitnum
	,trim(pb.LEGAL_DESC) legal_desc
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'-CBS' = pnum.permitnum
join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
left join hcfl_src.dbo.par_base pb on pb.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
where
	1=1
	and pnum.tt_record in ('Citizen Board Support Water Enforcement')
	and not exists (
		select 1
		from h
		where permitnum =  pmap.permitnum+'-CBS'
	)
;
go

;IF OBJECT_ID('cf_Water_Enforcement_cbs', 'U') IS NOT NULL DROP TABLE cf_Water_Enforcement_cbs
;
SELECT
    pnum.permitNum
    ,pnum.tt_record
    
    --DATA FIELDS
    ,n1.dtHearingNotice as [Notice Date]
    ,t1.NOTICE_TYPE as [Method of Service]
    ,n0.dtAffidavit as [Date of Affidavit]
    ,n0.dtHearingDate as [Hearing Date]
    ,null as [Postmark Date]
    ,t0.strHearingType as [Type of Hearing]
    ,n1.dtHearingNotice as [Date received for Hearing]
    ,null as [Date of Board Order]
    ,t0.strDefendantHrng as [Text field for name of person who appeared for hearing]
    ,null as [Cap Value]
    ,null as [Name of the officer giving testimony]
    ,null as [Hearing Location]
    ,null as [Recording Date]
    ,null as [Secondary Recording Date]
    ,null as [Release Date]
    ,null as [Secondary Release Date]
    ,null as [Book Page for Liens]
    ,null as [Instrument Number for Recording Date]
    ,null as [Secondary Instrument Number for Recording Date]
    ,null as [Instrument Number for Release Date]
    ,null as [Secondary Instrument Number for Release Date]
    ,null as [Tracking Number]
    ,null as [Date Posted at Property]
    ,null as [Card Received]
    ,null as [Reason Letter was not received]
    ,null as [Date Notice of Hearing Posted]
    ,null as [Change of Address]
    ,null as [Green Card Received]
    ,null as [Date Posted at Courthouse]
    ,null as [Notice of Hearing Date]
    ,null as [Notice of Hearing Date Verified by Mail Date]
    ,null as [Hearing Time]
    ,null as [Name of person that signed Affidavit]
    ,null as [Extension Order]
    ,null as [Code Record]
    ,null as [Hearing Date Continued]
    ,null as [Offense Number]
    ,null as [Water Enforcement Fine Amount]
    
    --HISTORICAL PERMITS PLUS FIELDS
    ,a.SUB_TYPE as [SUB_TYPE]
    ,a.LOCATION as [LOCATION]
    ,m0.MON_045 as [MON_045]
    ,m0.MON_046 as [MON_046]
    ,m0.MON_047 as [MON_047]
    ,m0.MON_048 as [MON_048]
    ,n0.Date_084 as [DATE_084]
    ,n0.Date_085 as [DATE_085]
    ,n0.Date_099 as [DATE_099]
    ,n1.DATE_101 as [DATE_101]
    ,t0.TEXT_003 as [TEXT_003]
    ,t0.TEXT_032 as [TEXT_032]
    ,t0.TEXT_040 as [TEXT_040]
    ,t0.TEXT_041 as [TEXT_041]
    ,t1.TEXT_098 as [TEXT_098]
    ,t0.yn_007 as [YN_007]
    ,null as [YN_051]
    ,pb.legal_desc as [LEGAL_DESC]
    ,a.calc_fees as [CALC_FEES]
    ,a.addl_fees as [ADDL FEES]
into cf_Water_Enforcement_cbs
from AATABLE_PERMIT_HISTORY pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum +'-CBS' = pnum.permitnum
join jms_apd_base_filtered__wrviol1 a on a.NUMBER_KEY = pmap.number_key
left join #m0 m0 on m0.number_key = pmap.number_key
left join #n0 n0 on n0.number_key = pmap.number_key
left join #n1 n1 on n1.number_key = pmap.number_key
left join #t0 t0 on t0.number_key = pmap.number_key
left join #t1 t1 on t1.number_key = pmap.number_key
left join #dtViolationTime dvt on dvt.number_key = a.number_key
left join #legal_descs pb on pb.permitnum = pmap.permitnum
left join jms_userid_username__wrviol1 user_id on user_id.user_id = a.user_id
--left join #wrviol_things wt on wt.number_key = pmap.number_key
--left join #primary_address_wrviol aa on aa.permitnum = pmap.permitnum 
--left join #primary_name_wrviol ap on ap.number_key = pmap.number_key
where
    1=1
    and pnum.tt_record = 'Citizen Board Support Water Enforcement'
;
 
    --ensure_fields_arent_too_long
declare @table_name varchar(100) = 'cf_Water_Enforcement_cbs' 

declare @cutoff int = 50;
DECLARE long_colname_cursor CURSOR for (
	select 
		column_name
	from INFORMATION_SCHEMA.columns 
	where 
		table_name = @table_name
		and len(column_name) > @cutoff
);

declare @column_name_old varchar(200);
declare @modString varchar(200);
declare @newname varchar(200);


OPEN long_colname_cursor
FETCH NEXT FROM long_colname_cursor INTO @column_name_old
    WHILE @@FETCH_STATUS = 0  
		begin
			set @modString = 'dbo.' + @table_name + '.' + @column_name_old;
			set @newname = left(@column_name_old, @cutoff)
			EXEC sp_rename @modString, @newname, 'COLUMN';
			FETCH NEXT FROM long_colname_cursor   INTO @column_name_old
		end
CLOSE long_colname_cursor
DEALLOCATE long_colname_cursor
;
go
;

go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0180 0100 0050 custom lists feeCalculation.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0180 0100 0050 custom lists feeCalculation.sql')
/*
things
addendum move the orders to CBS record if CBS record exists
*/

--things
;IF OBJECT_ID('tempdb.dbo.#_t', 'U') IS NOT NULL drop table #_t
;IF OBJECT_ID('tempdb.dbo.#t', 'U') IS NOT NULL drop table #t
;
select
	pnum.permitnum
    ,pnum.tt_record
    
	,n0.Date_086
	,m0.Mon_041  
	,t0.Text_019 
	,n0.Date_080 
	,m0.Mon_037  
	,n0.Date_090 

	,n0.Date_087 
	,m0.Mon_042  
	,t0.Text_024 
	,n0.Date_081 
	,m0.Mon_038  
	,n0.Date_091 

	,n0.Date_088
	,m0.Mon_043  
	,t0.Text_025 
	,n0.Date_082 
	,m0.Mon_039  
	,n0.Date_092 

	,n0.Date_089
	,m0.Mon_044 
	,t0.Text_028
	,n0.Date_083
	,m0.Mon_040 
	,n0.Date_093
into #_t
from hcfl_prod..aatable_permit_history pnum 
join hcfl_prod..jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = pnum.permitnum
left join hcfl_src.dbo.apd_num0 n0 on n0.number_key = pmap.number_key
left join hcfl_src.dbo.apd_txt0 t0 on t0.number_key = pmap.number_key
left join hcfl_src.dbo.apd_mon0 m0 on m0.number_key = pmap.number_key
;
SELECT 
*
into #t
from #_t
where 
    1=1
    and (
        coalesce(Mon_041,Mon_037,Mon_042,Mon_038,Mon_043,Mon_039,Mon_044,Mon_040,0) <> 0
        or coalesce(Text_019,Text_024,Text_025,Text_028) is not null
        or coalesce(Date_080,Date_090,Date_087,Date_086,Date_081,Date_091,Date_088,Date_083,Date_082,Date_092,Date_089,Date_093) is not null
    )
;





;IF OBJECT_ID('hcfl_prod.dbo.cl_wrviol_feeCalculation', 'U') IS NOT NULL drop table cl_wrviol_feeCalculation
;
with g as (
    select
         a.permitnum
        ,a.tt_record

        ,a.Date_086 as start_date --a.Date_080 as [dtPart1]
        ,'Part I' as order_part --a.Text_019 as [strOrderPart1]
        ,a.Mon_041 as subtotal_value
        ,a.Text_019 as [order]
        ,a.Date_080 as on_or_before_date
        ,a.Mon_037 as fine_amount
        ,a.Date_090 as end_date
        ,(case when a.Date_090 is null then 'Yes' else 'No' end) as add_fee --(case when dtPart1End is null then 'Yes' else 'No' end) as add_fee
    from #t a
    WHERE
        1=1
        and (
            coalesce(a.Date_086,a.Date_080,a.Date_090) is not NULL
         or coalesce(a.Text_019,convert(varchar(20),a.Mon_037),'0') <> '0'
        )
        

    union

    select
        a.permitnum
        ,a.tt_record

        ,a.Date_087 as start_date --a.Date_080 as [dtPart1]
        ,'Part II' as order_part --a.Text_019 as [strOrderPart2]
        ,a.Mon_042 as subtotal_value
        ,a.Text_024 as [order]
        ,a.Date_081 as on_or_before_date
        ,a.Mon_038 as fine_amount
        ,a.Date_091 as end_date
        ,(case when a.Date_091 is null then 'Yes' else 'No' end) as add_fee --(case when dtPart1End is null then 'Yes' else 'No' end) as add_fee
    from #t a
    WHERE
        1=1
        and (
            coalesce(a.Date_087,a.Date_081,a.Date_091) is not NULL
         or coalesce(a.Text_024,convert(varchar(20),a.Mon_038),'0') <> '0'
        )

    union

    select
        a.permitnum
        ,a.tt_record

        ,a.Date_088 as start_date --a.Date_080 as [dtPart1]
        ,'Part III' as order_part --a.Text_019 as [strOrderPart3]
        ,a.Mon_043 as subtotal_value
        ,a.Text_025 as [order]
        ,a.Date_082 as on_or_before_date
        ,a.Mon_039 as fine_amount
        ,a.Date_092 as end_date
        ,(case when a.Date_092 is null then 'Yes' else 'No' end) as add_fee --(case when dtPart1End is null then 'Yes' else 'No' end) as add_fee
    from #t a
    WHERE
        1=1
        and (
            coalesce(a.Date_088,a.Date_082,a.Date_092) is not NULL
         or coalesce(a.Text_025,convert(varchar(20),a.Mon_039),'0') <> '0'
        )
        
    union

    select
        a.permitnum
        ,a.tt_record

        ,a.Date_089 as start_date --a.Date_080 as [dtPart1]
        ,'Part IV' as order_part --a.Text_019 as [strOrderPart4]
        ,a.Mon_044 as subtotal_value
        ,a.Text_028 as [order]
        ,a.Date_083 as on_or_before_date
        ,a.Mon_040 as fine_amount
        ,a.Date_093 as end_date
        ,(case when a.Date_093 is null then 'Yes' else 'No' end) as add_fee --(case when dtPart1End is null then 'Yes' else 'No' end) as add_fee
    from #t a
    WHERE
        1=1
        and (
            coalesce(a.Date_089,a.Date_083,a.Date_093) is not NULL
         or coalesce(a.Text_028,convert(varchar(20),a.Mon_040),'0') <> '0'
        )

)
select
	*
	,ROW_NUMBER() OVER(PARTITION BY pnum.permitnum order by pnum.permitnum) AS row_num
into cl_wrviol_feeCalculation
from g pnum
where
	1=1
;
    --ensure date is actually a date
--update a set on_or_before_date = convert(varchar(10),on_or_before_date,20) from cl_wrviol_feeCalculation a ;
go
alter table cl_wrviol_feeCalculation alter column on_or_before_date varchar(10)
alter table cl_wrviol_feeCalculation alter column start_date varchar(10)
alter table cl_wrviol_feeCalculation alter column end_date varchar(10)
;
go
;update cl_wrviol_feeCalculation set on_or_before_date= FORMAT(convert(date,on_or_before_date), 'MM/dd/yyyy')
;update cl_wrviol_feeCalculation set start_date= FORMAT(convert(date,start_date), 'MM/dd/yyyy')
;update cl_wrviol_feeCalculation set end_date= FORMAT(convert(date,end_date), 'MM/dd/yyyy')
;
go

--addendum move the orders to CBS record if CBS record exists
update a set 
    permitnum = b.permitnum
from cl_wrviol_feeCalculation a
join aatable_permit_history b on b.permitnum = a.permitnum + '-CBS'

;IF OBJECT_ID('hcfl_prod.dbo.cl_wrviol_feeCalculation_cbs', 'U') IS NOT NULL drop table cl_wrviol_feeCalculation_cbs
GO
select 
*
into cl_wrviol_feeCalculation_cbs
from cl_wrviol_feeCalculation a
where 
    1=1
    and a.permitnum like '%-CBS'
;
update a set 
    tt_record = 'Citizen Board Support Water Enforcement'
from cl_wrviol_feeCalculation_cbs a
;

    --delete from cl_wrviol_feeCalculation those that are cbs. These get mapped to custom lists as ENF_CBS_WA. 
delete a 
from cl_wrviol_feeCalculation a
join cl_wrviol_feeCalculation_cbs b on b.permitnum = a.permitnum
WHERE   
    1=1
;
--    --force into PERMIT_ATTACHEDTABLE. It isnt going because the accela data mapper is grabbing these as ENF_WATER, then tries to join, and misses them into aaxPermit_attachedTable for some reason. I expect the r1_chckbox_code to be 'ENF_CBS_WA'. But it isn't in the mapper. Why?
----truncate table PERMIT_ATTACHEDTABLE
--;insert into PERMIT_ATTACHEDTABLE select A.permitnum,'ENF_CBS_WA','FEECALCULATION','Order Part', a.ROW_NUM,CONVERT(VARCHAR(4000),a."order_part") from "cl_wrviol_feeCalculation_cbs" a INNER JOIN AAXCASE x ON a.PERMITNUM=x.PERMITNUM INNER JOIN TT_R3APPTYP B ON b.R1_PER_GROUP=X.B1_PER_GROUP AND b.R1_PER_TYPE=X.B1_PER_TYPE AND b.R1_PER_SUB_TYPE=X.B1_per_sub_type AND b.r1_per_CATEGORY=X.B1_PER_CATEGORY where b.r1_chckbox_code='ENF_CBS_WA' and a."order_part" is not null
--;insert into PERMIT_ATTACHEDTABLE select A.permitnum,'ENF_CBS_WA','FEECALCULATION','On or Before Date', a.ROW_NUM,CONVERT(VARCHAR(4000),a."on_or_before_date") from "cl_wrviol_feeCalculation_cbs" a INNER JOIN AAXCASE x ON a.PERMITNUM=x.PERMITNUM INNER JOIN TT_R3APPTYP B ON b.R1_PER_GROUP=X.B1_PER_GROUP AND b.R1_PER_TYPE=X.B1_PER_TYPE AND b.R1_PER_SUB_TYPE=X.B1_per_sub_type AND b.r1_per_CATEGORY=X.B1_PER_CATEGORY where b.r1_chckbox_code='ENF_CBS_WA' and a."on_or_before_date" is not null
--;insert into PERMIT_ATTACHEDTABLE select A.permitnum,'ENF_CBS_WA','FEECALCULATION','Fine Amount', a.ROW_NUM,CONVERT(VARCHAR(4000),a."fine_amount") from "cl_wrviol_feeCalculation_cbs" a INNER JOIN AAXCASE x ON a.PERMITNUM=x.PERMITNUM INNER JOIN TT_R3APPTYP B ON b.R1_PER_GROUP=X.B1_PER_GROUP AND b.R1_PER_TYPE=X.B1_PER_TYPE AND b.R1_PER_SUB_TYPE=X.B1_per_sub_type AND b.r1_per_CATEGORY=X.B1_PER_CATEGORY where b.r1_chckbox_code='ENF_CBS_WA' and a."fine_amount" is not null
--;insert into PERMIT_ATTACHEDTABLE select A.permitnum,'ENF_CBS_WA','FEECALCULATION','Order', a.ROW_NUM,CONVERT(VARCHAR(4000),a."order") from "cl_wrviol_feeCalculation_cbs" a INNER JOIN AAXCASE x ON a.PERMITNUM=x.PERMITNUM INNER JOIN TT_R3APPTYP B ON b.R1_PER_GROUP=X.B1_PER_GROUP AND b.R1_PER_TYPE=X.B1_PER_TYPE AND b.R1_PER_SUB_TYPE=X.B1_per_sub_type AND b.r1_per_CATEGORY=X.B1_PER_CATEGORY where b.r1_chckbox_code='ENF_CBS_WA' and a."order" is not null
--;insert into PERMIT_ATTACHEDTABLE select A.permitnum,'ENF_CBS_WA','FEECALCULATION','Start Date', a.ROW_NUM,CONVERT(VARCHAR(4000),a."start_date") from "cl_wrviol_feeCalculation_cbs" a INNER JOIN AAXCASE x ON a.PERMITNUM=x.PERMITNUM INNER JOIN TT_R3APPTYP B ON b.R1_PER_GROUP=X.B1_PER_GROUP AND b.R1_PER_TYPE=X.B1_PER_TYPE AND b.R1_PER_SUB_TYPE=X.B1_per_sub_type AND b.r1_per_CATEGORY=X.B1_PER_CATEGORY where b.r1_chckbox_code='ENF_CBS_WA' and a."start_date" is not null
--;insert into PERMIT_ATTACHEDTABLE select A.permitnum,'ENF_CBS_WA','FEECALCULATION','End Date', a.ROW_NUM,CONVERT(VARCHAR(4000),a."end_date") from "cl_wrviol_feeCalculation_cbs" a INNER JOIN AAXCASE x ON a.PERMITNUM=x.PERMITNUM INNER JOIN TT_R3APPTYP B ON b.R1_PER_GROUP=X.B1_PER_GROUP AND b.R1_PER_TYPE=X.B1_PER_TYPE AND b.R1_PER_SUB_TYPE=X.B1_per_sub_type AND b.r1_per_CATEGORY=X.B1_PER_CATEGORY where b.r1_chckbox_code='ENF_CBS_WA' and a."end_date" is not null
--;insert into PERMIT_ATTACHEDTABLE select A.permitnum,'ENF_CBS_WA','FEECALCULATION','Subtotal Value', a.ROW_NUM,CONVERT(VARCHAR(4000),a."subtotal_value") from "cl_wrviol_feeCalculation_cbs" a INNER JOIN AAXCASE x ON a.PERMITNUM=x.PERMITNUM INNER JOIN TT_R3APPTYP B ON b.R1_PER_GROUP=X.B1_PER_GROUP AND b.R1_PER_TYPE=X.B1_PER_TYPE AND b.R1_PER_SUB_TYPE=X.B1_per_sub_type AND b.r1_per_CATEGORY=X.B1_PER_CATEGORY where b.r1_chckbox_code='ENF_CBS_WA' and a."subtotal_value" is not null
--;insert into PERMIT_ATTACHEDTABLE select A.permitnum,'ENF_CBS_WA','FEECALCULATION','Add Fee', a.ROW_NUM,CONVERT(VARCHAR(4000),a."add_fee") from "cl_wrviol_feeCalculation_cbs" a INNER JOIN AAXCASE x ON a.PERMITNUM=x.PERMITNUM INNER JOIN TT_R3APPTYP B ON b.R1_PER_GROUP=X.B1_PER_GROUP AND b.R1_PER_TYPE=X.B1_PER_TYPE AND b.R1_PER_SUB_TYPE=X.B1_per_sub_type AND b.r1_per_CATEGORY=X.B1_PER_CATEGORY where b.r1_chckbox_code='ENF_CBS_WA' and a."add_fee" is not null
--;
--go


--insert into cl_wrviol_feeCalculation
--select
--    b.permitnum
--    ,a.tt_record,a.start_date,a.order_part,a.subtotal_value,a.order,a.on_or_before_date,a.fine_amount,a.end_date,a.add_fee,a.row_num
--from cl_wrviol_feeCalculation a
--join aatable_permit_history b on b.permitnum = a.permitnum + '-CBS'

/*
;IF OBJECT_ID('hcfl_prod.dbo.cl_wrviol_feeCalculation_cbs', 'U') IS NOT NULL drop table cl_wrviol_feeCalculation_cbs
go
select 
    a.*
into cl_wrviol_feeCalculation_cbs
from cl_wrviol_feeCalculation a
join aatable_permit_history b on b.permitnum = a.permitnum + '-CBS'
where 
    1=1
;
delete a
from cl_wrviol_feeCalculation a
join aatable_permit_history b on b.permitnum = a.permitnum + '-CBS'
;

update a set 
    permitnum = b.permitnum
from cl_wrviol_feeCalculation_cbs a
join aatable_permit_history b on b.permitnum = a.permitnum + '-CBS'
;
*/

go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0180 0100 0100 custom lists violations.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0180 0100 0100 custom lists violations.sql')
--select
--    pnum.permitnum
--	,pnum.tt_record
--	,null as [comment]
--    ,null as [violation]



/* I intended for this to be guidesheets
but conversation yields that most of the violations , based on how accela is configured, are not guidesheet items, rather they seem to belong to comments on an inspection.
Logic copied from elsewhere; calls given site visit a parent inspection, and subsequent rows (comments, other) its children.
For the violations: associates violations with their rows on apd_insp, then to the parent inspection.
Requires post-conversion logic to ensure line breaks occur.

determine child rows per inspection, then assert inspection type and inspection result based on those children
with parents
is_initial_site_visit
create g
create h
create violations
creaet cl_violations__wrviol1
verify counts
hack fix for '0140 0100 custom fields.sql': the date isn't the actual violation date
*/
--determine child rows per inspection, then assert inspection type and inspection result based on those children
;IF OBJECT_ID('tempdb.dbo.#parents', 'U') IS NOT NULL drop table #parents
;IF OBJECT_ID('tempdb.dbo.#is_initial_site_visit', 'U') IS NOT NULL drop table #is_initial_site_visit
;IF OBJECT_ID('tempdb.dbo.#g', 'U') IS NOT NULL drop table #g
;IF OBJECT_ID('tempdb.dbo.#orphaned', 'U') IS NOT NULL drop table #orphaned
;IF OBJECT_ID('tempdb.dbo.#h', 'U') IS NOT NULL drop table #h
;IF OBJECT_ID('tempdb.dbo.#req_opt', 'U') IS NOT NULL drop table #req_opt
;
go

--;with parents
    --assumes inspections are site visits, and results are implied by the subsequent rows prior to the following site visit.
    select
        number_key
        ,unique_key
        ,date_ent
        ,the_Date
        ,action_ent
    into #parents
    from jms_apd_insp_filteredToPop__wrviol1
    where action_ent in ('SV','SSV','QCSV','LSV')
    --and number_key = 'CE18015425'
;
--), is_initial_site_visit as (
    --"initial site visiit" is an accela inspection type
    select
        b.UNIQUE_KEY
        ,b.action_ent
    into #is_initial_site_visit
    from jms_apd_base_filtered__wrviol1 a
    outer apply (select top 1 * from jms_apd_insp_filteredToPop__wrviol1 where NUMBER_KEY = a.NUMBER_KEY and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent,the_date) b
;
--create g
--),g as (
    select
        a.number_key
        ,a.item_id
        ,a.unique_key
        ,a.action_ent
        ,action_ent.DESCRIPTION action_ent_desc
        ,case when is_initial_site_visit.UNIQUE_KEY is not null then 1 else 0 end as is_initial_site_visit
        ,'xxxx' [ ]
        ,coalesce(b.unique_key,is_initial_site_visit.unique_key) parent_unique_key
        ,b.action_ent parent_action_ent
        ,(case 
            when is_initial_site_visit.UNIQUE_KEY is not null then 'Initial Site Visit'
            when a.ACTION_ENT in ('QCSV','LSV') then 'Quality Control Inspection'
            when  a.any_comments like '%re%inspect%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%re%check%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%annual%insp%'    then 'Annual Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%post%hearing%'    then 'Post-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%pre%hearing%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%hear%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%follow%up%'    then 'Follow-up Inspection' --I don't know about pre vs post hearing
            else 'Inspection'
            end		
        ) as inspection_type
        ,(case 
            --when a.ACTION_ENT in ('SV','SSV','QCSV','LSV') then null
            when a.action_ent in ('CERT','DFLT') then 'Issue Citation' --CERT = issue citation
            when a.action_ent in ('CRTY') then 'Issue Warning' --CRTY = warning (courtesy) 
            when a.action_ent in ('CNCL') then 'Cancel'
            --when a.action_ent in ('STLS','STLO') then 'Extension'
            --when a.action_ent in ('ADMN','CREV','NREV') then 'No Violation' --Move this to time accounting? Associate with inspection? I put ADMN here cuz it is not a violation or similar
            --when a.action_ent in ('AP','CMP','COMP') then 'Approved' --maybe "complied"
            --when a.action_ent in ('AFFN','DFLT','ACOM') then 'Disapproved' -- ACOM seemed to all be problems
		
			when a.any_comments like '%created in err%' then 'Cancel' --CNCL
            when a.any_comments like '%CLNO%' then 'No Violation' --yes
            when a.any_comments like '%no viol%' then 'No Violation' --yes 
            when a.any_comments like '%courtesy notice%' then 'Issue Warning'

			--when a.any_comments like '%warn%' then 'Issue Warning'
            --when a.any_comments like '%POST%PROP%' then 'Issue Warning' --post would mean we are getting it ready for a hearing
            --when a.any_comments like '%DOOR%HANG%' then 'Issue Warning' --doesnt necessarily mean a warning is issued; it means we're gonna come back
            --when a.any_comments like '%hand%deliv%' then 'Issue Citation' --could definitely be issue cit
            --when a.any_comments like '%watering days%' then 'Issue Citation' --could be citation or warning
            --when a.any_comments like '%post%' then 'Issue Citation' --sure ok
            --when a.any_comments like '%property was found%' then 'Issue Citation' --not necessarily. Could be a warning.
            --when a.any_comments like '%watering %' then 'Issue Citation' --not necessarily. Could be a warning.
            --when a.any_comments like '%irrigation%restr%' then 'Issue Citation' --not necessarily. Could be a warning
            else 'No Violation'
            end
        ) as inspection_result
        
        ,'xxxx' [2]
        ,a.date_ent
        ,a.the_date
        ,'xxxx'[3]
        ,a.any_comments
    into #g
    from jms_apd_insp_filteredToPop__wrviol1 a
    outer apply (select top 1 * from #parents where number_key = a.number_key and the_date <= a.the_date and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent desc,the_date desc) b
    left join jms_actionEnt_passFail__wrviol1 action_ent on action_ent.action_ent = a.action_ent
    left join #is_initial_site_visit is_initial_site_visit on is_initial_site_visit.UNIQUE_KEY = a.UNIQUE_KEY
    where
        1=1
        --and a.action_ent not in ('SV','SSV','QCSV','LSV')
        --and a.number_key = 
        --    --'CE03003081'
        --    --'CE22014264'
        --    'CE22014971'
    --order by --a.date_ent,a.the_Date,case when a.action_ent in ('SV','SSV','QCSV','LSV') then 1 else 2 end, l.THE_TEXT
    --    a.UNIQUE_KEY
;



--create h
--), h as (
    select distinct
         a1.NUMBER_KEY
        ,a1.UNIQUE_KEY
        ,a1.action_ent
        ,a1.inspection_type
        ,coalesce(b.inspection_result,a1.inspection_result,'Not Set') inspection_result
        ,trim('^|' from stuff((
            select 
                '^|^' + cast(
                    trim(replace(replace(replace(replace(   isnull(a2.any_comments,'')   ,'"',''''''),'''',''),char(13),''),char(10),'�')) 
                    as varchar(max)
                )
            from #g a2 with(nolock)
            where 
                a2.parent_unique_key = a1.parent_unique_key
            group by a2.any_comments
            order by a2.any_comments
            FOR XML PATH('')
         ), 1, 1, '')) as any_comments
    into #h
    from #g a1
    outer apply (
        select top 1 *
        from #g
        where
            parent_unique_key = a1.UNIQUE_KEY
            and inspection_result is not null
        order by case inspection_result when 'Cancel' then 1 when 'Issue Citation' then 2 when 'Issue Warning' then 3 when 'No Violation' then 4 else 5 end
    ) b
    where
        1=1
        and a1.ACTION_ENT in ('SV','SSV','QCSV','LSV')
        --and a1.number_key = 'CE17015692'
    ;

    --order by a.UNIQUE_KEY
--)
;

--create violations
--;with cte_violations as (
;IF OBJECT_ID('tempdb.dbo.#_violations', 'U') IS NOT NULL drop table #_violations
;
;with lesser_dates as (
	select 
		 b.number_key
		,b.sequence
		,b.item_id
		,b.the_date
		,b2.THE_DATE lesser_date
	from hcfl_src..apd_itms b
	outer apply (select top 1 * from hcfl_src..APD_ITMS where record_type = 'cd' and NUMBER_KEY = b.NUMBER_KEY and THE_DATE < b.THE_DATE) b2
	where
		1=1
		and b.number_key in ('','WR2001154','WR2001254','WR2001312','WR2001388','WR2001391','WR2100003','WR2201954','WR2302581','WR2400295'
        )
		and b2.the_Date is not null
)
select distinct
     a.NUMBER_KEY
    ,a.parent_unique_key
    ,a.unique_key --the inspection the violation will be associated with
    ,b.item_id
    ,b.the_date
    ,convert(varchar(max),tc.notation) notation
    ,convert(varchar(max),tc.the_text) the_text
    ,b.approved
into #_violations
from #g a
left join hcfl_src..apd_itms b on b.RECORD_TYPE = 'CD' and b.NUMBER_KEY = a.NUMBER_KEY
left join lesser_dates b2 on b2.number_key = b.number_key and b2.sequence = b.sequence and b2.item_id = b.item_id and b2.the_date = b.the_Date	
left join hcfl_src..tab_cond tc on tc.ELEMENT_KEY = b.ITEM_ID
where
    1=1
    and b.NUMBER_KEY is not null
    --and b.NUMBER_KEY = 'WR2202362 '
    and (
        (year(b.THE_DATE) = year(a.date_ent) and month(b.THE_DATE) = month(a.date_ent) and day(b.THE_DATE) = day(a.date_ent) )
        or (year(b2.lesser_date) = year(a.date_ent) and month(b2.lesser_date) = month(a.date_ent) and day(b2.lesser_date) = day(a.date_ent) )
    )
;

;IF OBJECT_ID('tempdb.dbo.#violations', 'U') IS NOT NULL drop table #violations
;
go
;with lesser_dates as (
	select 
		 b.number_key
		,b.sequence
		,b.item_id
		,b.the_date
		,b2.THE_DATE lesser_date
	from hcfl_src..apd_itms b
	outer apply (select top 1 * from hcfl_src..APD_ITMS where record_type = 'cd' and NUMBER_KEY = b.NUMBER_KEY and THE_DATE < b.THE_DATE) b2
	where
		1=1
		and b.number_key in ('','WR2001154','WR2001254','WR2001312','WR2001388','WR2001391','WR2100003','WR2201954','WR2302581','WR2400295'
        )
		and b2.the_Date is not null
)
select distinct
     a.NUMBER_KEY
    ,a.parent_unique_key
    ,b.item_id
    ,b.the_date
    ,replace(replace(replace(replace(     convert(varchar(max),tc.notation)     ,'"',''''''),'''',''),char(13),''),char(10),'�') notation
    ,replace(replace(replace(replace(     convert(varchar(max),tc.the_text)     ,'"',''''''),'''',''),char(13),''),char(10),'�') the_text
    ,b.approved
into #violations
from #g a
left join hcfl_src..apd_itms b on b.RECORD_TYPE = 'CD' and b.NUMBER_KEY = a.NUMBER_KEY
left join lesser_dates b2 on b2.number_key = b.number_key and b2.sequence = b.sequence and b2.item_id = b.item_id and b2.the_date = b.the_Date	
left join hcfl_src..tab_cond tc on tc.ELEMENT_KEY = b.ITEM_ID
where
    1=1
    and b.NUMBER_KEY is not null
    --and b.NUMBER_KEY = 'WR2202362 '
    and (
        (year(b.THE_DATE) = year(a.date_ent) and month(b.THE_DATE) = month(a.date_ent) and day(b.THE_DATE) = day(a.date_ent) )
        or (year(b2.lesser_date) = year(a.date_ent) and month(b2.lesser_date) = month(a.date_ent) and day(b2.lesser_date) = day(a.date_ent) )
    )
;

delete d
from #violations d 
where
	1=1
	and (
		(number_key = 'WR2001138' and parent_unique_key = 'A008504612')
		or (number_key = 'WR2300607 ' and parent_unique_key = 'A009041780')
	)
;
insert into #violations 
select *
from (VALUES
('WR2100003','A008729399','WRV1','2021-01-11 00:00:00.0000000','WRV RESTRICTED DAY','WATERING ON A RESTRICTED DAY��','N')
,('WR2401601','ORPH-195'  ,'WRV1','2024-06-07 00:00:00.0000000','WRV RESTRICTED DAY','WATERING ON A RESTRICTED DAY��','N')
,('WR2401845','A009213417','WRV1','2021-01-11 00:00:00.0000000','WRV RESTRICTED DAY','WATERING ON A RESTRICTED DAY��','N')
) t(NUMBER_KEY,parent_unique_key,item_id,the_date,notation,the_text,approved)



/*
from here:
notation => guide sheets asi
I think, then: the_text => guide sheet asit ?
I think guidesheet things arent configured?
Is the record type or subtype or something mappable into the guidesheets? 
then the notation to ASI
then the_text to ASIT:inspector_comments?

*/
--creaet cl_violations__wrviol1
;IF OBJECT_ID('hcfl_prod.dbo.cl_violations__wrviol1', 'U') IS NOT NULL drop table cl_violations__wrviol1

;IF OBJECT_ID('hcfl_prod.dbo.cl_violations__wrviol1', 'U') IS NOT NULL drop table cl_violations__wrviol1
;with g as (
    select
        pnum.permitnum
        ,pnum.tt_record
        --,ROW_NUMBER() OVER(PARTITION BY pnum.permitnum order by v.the_date) AS num_row
    
        ,the_date date_added
        ,(case notation
            when 'WRV HOURS'                 then 'Watering During Restricted Hours'
            when 'WRV IRRIGATION AFTER RAIN' then 'IRRIGATION DURING/AFTER SUBSTANTIAL RAINFALL��'
            when 'WRV RESTRICTED DAY'        then 'Watering on Restricted Day'
            when 'WRV WASTE'                 then 'Wasteful/Inefficient Use of Water'
            else null
            end
        ) as violation
    --into cl_violations__wrviol1
    from #violations v
    join jms_numberKey_permitnum__wrviol1 pmap on pmap.number_key = v.NUMBER_KEY
    join aatable_permit_history pnum on pnum.permitnum = pmap.permitnum
)
select
	pnum.permitnum
    ,pnum.tt_record
    
    ,pnum.violation
    ,left(convert(varchar,pnum.date_added,20),11) comment
	,ROW_NUMBER() OVER(PARTITION BY pnum.permitnum order by pnum.date_added) AS row_num
into cl_violations__wrviol1
from g pnum
WHERE
    1=1
    --and g.permitnum = 'WR2202362'
;
go

--verify counts
if 1 = (
	select distinct 1
	from (
        SELECT
            a.permitnum 
            ,a.ct_a
            ,b.ct_b
        from (
            select 
                pmap.permitnum
                ,count(distinct a.item_id) ct_a
                --,a.*
            from hcfl_src..apd_itms a 
            join jms_apd_insp_filteredToPop__wrviol1 f on f.number_key = a.number_key
            join jms_numberKey_permitnum__wrviol1 pmap on pmap.number_key = a.NUMBER_KEY
            WHERE
                1=1
                and a.record_type = 'CD'
                --and a.NUMBER_KEY = 'WR2102935'
            group by pmap.permitnum
        ) a  --violations_per_numberKey
        left join (
            select 
                a.permitnum
                ,max(a.row_num) ct_b
            from cl_violations__wrviol1 a 
            group by a.permitnum
        ) b on b.permitnum = a.permitnum  --captured_violations
        WHERE
            1=1
            and a.ct_a <> b.ct_b
    ) z
) RAISERROR ('cl_violations__wrviol1: there is a violation count mismatch between source and what was captured', 16, 1)
;
go

----hack fix for '0140 0100 custom fields.sql': the date isn't the actual violation date
--ALTER TABLE cf_Water_Enforcement ALTER COLUMN [Date of violation] datetime
--go 
--ALTER TABLE cf_Water_Enforcement ALTER COLUMN [Date of violation] date
--go
--update cf_water_enforcement set 
--	[Time of Violation] = null
--where
--	1=1
--	and try_convert(datetime,[Time of Violation] ) is null
--go
--ALTER TABLE cf_Water_Enforcement ALTER COLUMN [Time of Violation] datetime
--go
--
--update a set 
--     [Date of violation] = coalesce(try_convert(date, b.comment), b.comment, a.[Date of violation])
--    ,[Time of Violation] = coalesce(   try_convert(datetime,b.comment + ' ' + right(convert(varchar,[time of violation]),8))   , [time of violation]   )
--from cf_Water_Enforcement a 
--outer apply (select top 1 * from cl_violations__wrviol1 where permitnum = a.permitnum) b
--;

--meeting on 20240525.txt - Violation not reliably carring over from CE to CE-CBS record
;IF OBJECT_ID('hcfl_prod.dbo.cl_violations__wrviol1_cbs', 'U') IS NOT NULL drop table cl_violations__wrviol1_cbs
;
select
	 b.permitnum
	,'Citizen Board Support Water Enforcement' tt_record
	,a.violation
    ,a.comment
    ,a.row_num
into cl_violations__wrviol1_cbs
from cl_violations__wrviol1 a
join AATABLE_PERMIT_HISTORY b on b.PERMITNUM = a.permitnum + '-CBS'
where 
	1=1
;


go

--filename: C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0180 related_records.sql
insert into ##completed values (getdate(),'C:\Users\JoelStewart\OneDrive - sCube Inc\tasks\accela\hillsborough_county\v11 - locksmith license_locksmith fees\0120 B wrviol1\0180 related_records.sql')
/*

*/


;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_PROJECTS
;
insert into AATABLE_PERMIT_PROJECTS (
PARENTACTIVITYNUM,CHILDACTIVITYNUM,RELATIONSHIP,STATUS
)   
--general_programs
SELECT
     replace(a.permitnum,'-CBS','') as PARENTACTIVITYNUM
    ,a.permitnum as CHILDACTIVITYNUM 
    ,'R' relationship
    ,null status
FROM aatable_permit_history a
WHERE
    1=1
    and right(a.permitnum,4) = '-CBS'
    and a.permitnum like '%-CBS'
	and a.permitnum like 'WR%'
	
;

go

