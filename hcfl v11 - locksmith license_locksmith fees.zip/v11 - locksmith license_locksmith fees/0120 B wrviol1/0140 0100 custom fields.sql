/* 
water enforcement - ENF_WATER
    --REM this has a hack fix on '0180 0100 0100 custom lists violations.sql'
water enforcement cbs - ENF_CBS_WA


*/

--water enforcement - ENF_WATER
;IF OBJECT_ID('tempdb.dbo.##completed', 'U') is not null insert into ##completed values (getdate(),'0140 0100 custom fields.sql -- water enforcement')
;print 'Water Enforcement - ENF_WATER';

;IF OBJECT_ID('tempdb.dbo.#n0', 'U') IS NOT NULL DROP TABLE #n0
;SELECT
     n0.number_key
    ,n0.Date_053 as [dtLastNotice]
    ,n0.Date_075 as [dtHearingDate]
    ,n0.Num_028 as [numOffenceNumber]
into #n0
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'' = pnum.permitnum
join hcfl_src.dbo.apd_num0 n0 on n0.number_key = pmap.number_key
where 
	pnum.tt_record in ('Water Enforcement','Water Enforcement - Proactive')
	and (coalesce(n0.Date_053,n0.Date_075) is not null or coalesce(n0.Num_028,null) is not null)
;--50sec

;IF OBJECT_ID('tempdb.dbo.#n1', 'U') IS NOT NULL DROP TABLE #n1
;SELECT
     n1.number_key
    ,n1.Date_103 as	dtAppeal          
    ,n1.Date_102 as [dtHearingNotice]
    ,n1.date_103
    ,n1.date_109
    ,n1.date_118
into #n1
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'' = pnum.permitnum
left join hcfl_src.dbo.apd_num1 n1 on n1.number_key = pmap.number_key
--left join hcfl_src.dbo.apd_num0 n0 on n0.number_key = pmap.number_key
where 
	pnum.tt_record in ('Water Enforcement','Water Enforcement - Proactive')
	and coalesce(n1.Date_103,n1.Date_102,n1.date_103,n1.date_109,n1.date_118,null) is not null
;--20sec
;IF OBJECT_ID('tempdb.dbo.#t0', 'U') IS NOT NULL DROP TABLE #t0
;SELECT
     t0.number_key
    ,t0.YN_007   as ynAppealApproved
    ,t0.YN_008   as ynAppealDenied
    ,t0.Text_006 as txt_occupancy
    ,t0.text_000
    ,t0.text_004
    ,t0.text_014
into #t0
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'' = pnum.permitnum
join hcfl_src.dbo.apd_txt0 t0 on t0.number_key = pmap.number_key
where 
	pnum.tt_record in ('Water Enforcement','Water Enforcement - Proactive')
	and coalesce(t0.Text_006,t0.text_000,t0.text_004,t0.text_014,t0.YN_007,t0.YN_008,t0.Text_006) is not null
;--8sec
;IF OBJECT_ID('tempdb.dbo.#dtViolationTime', 'U') IS NOT NULL DROP TABLE #dtViolationTime
;with g as (
	select 
		t1.number_key
        ,try_convert(date,n1.DATE_100) as [dtIncident]
		,t1.Text_053 as [dtViolationTime] 
		,right('0'+replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(t1.Text_053,'.',''),'A',''),'P',''),':',''),' ',''),'hrs',''),'hr',''),'M',''),';',''),'"',''),'`',''),'-',''),4)
			as tttt
	from hcfl_src.dbo.apd_txt1 t1
	left join hcfl_src.dbo.apd_num1 n1 on n1.NUMBER_KEY = t1.NUMBER_KEY
	where 
		1=1
		and t1.NUMBER_KEY like 'wr%' 
		and (t1.text_053 is not null or n1.date_100 is not null)
)
select
	NUMBER_KEY
    ,dtIncident
	,dtViolationTime
	,('1900-01-01 ' +case 
            --WR2303234	1308 PM > 1900-01-01 13:08:00 rather than 25:08:00
			when try_convert(int,left(trim(dtViolationtime),2)) > 12
			then right(  '0'+convert(varchar(2),isnull(try_convert(int,substring(tttt,1,2)),0) + 0)  ,2)

			--12:04 > 1900-01-01 12:04:00 rather than 24:04:00
            when dtViolationTime like '%p%' and trim(dtViolationTime) like '12%' 
			then right(  '0'+convert(varchar(2),isnull(try_convert(int,substring(tttt,1,2)),0) + 0)  ,2)
            
            when dtViolationTime like '%p%' 
            then right(  '0'+convert(varchar(2),isnull(try_convert(int,substring(tttt,1,2)),0) + 12)  ,2)
            
            else left(tttt,2)
            end
        + ':'
        + right(tttt,2)
        + ':00' 
    ) as hhmmss
into #dtViolationTime
from g 
;

;IF OBJECT_ID('tempdb.dbo.#t1', 'U') IS NOT NULL DROP TABLE #t1
;SELECT
     t1.number_key
    ,t1.Text_065 as strAppealReason 
    ,t1.Text_066 as strADX
    ,t1.Text_059 as zoning
    ,t1.Text_076 as str_type
    ,t1.Text_080 as [NOTICE_TYPE]
    ,t1.Text_053 as [dtViolationTime]
    ,t1.text_050 --txt_cert_#_4      
    ,t1.text_060 --txt_phone         
    ,t1.text_067 --txt_Supervisor    
    ,t1.text_069 --txtWELL           
    ,t1.text_072 --
    ,t1.text_077 --txt_zip_code      
into #t1
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'' = pnum.permitnum
join hcfl_src.dbo.apd_txt1 t1 on t1.number_key = pmap.number_key
where 
	pnum.tt_record in ('Water Enforcement','Water Enforcement - Proactive')
	and coalesce(t1.Text_065,t1.Text_066,t1.Text_059,t1.Text_076,t1.Text_080,t1.Text_053,t1.text_050,t1.text_060,t1.text_067,t1.text_069,t1.text_072,t1.text_077,null) is not null
;--3sec
go
;IF OBJECT_ID('tempdb.dbo.#legal_descs', 'U') IS NOT NULL DROP TABLE #legal_descs
;create table #legal_descs ( permitnum varchar(50), legal_desc varchar(max) )
;with cte_many as (
	select 
		pmap.permitnum + '' permitnum
		,count(LEGAL_DESC) ct
	from aatable_permit_history pnum
	join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'' = pnum.permitnum
	join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
	left join hcfl_src.dbo.par_base pb on pb.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
	where
		1=1
		and pnum.tt_record in ('Water Enforcement','Water Enforcement - Proactive')
	group by pmap.permitnum
	having count(LEGAL_DESC) > 1
), g as (
	select distinct
		pmap.permitnum + '' permitnum
		,pb.LEGAL_DESC
	from aatable_permit_history pnum
	join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'' = pnum.permitnum
	join cte_many f on f.permitnum =  pmap.permitnum+''
	join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
	left join hcfl_src.dbo.par_base pb on pb.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
	where
		1=1
		and pnum.tt_record in ('Water Enforcement','Water Enforcement - Proactive')
),h as (
	SELECT
		permitnum
		,trim('^| ' from 
			  STUFF(
				(SELECT ' ^|^ ' + LEGAL_DESC
				 FROM g AS innerTable
				 WHERE innerTable.permitnum = outerTable.permitnum
				 FOR XML PATH(''), TYPE
				).value('.', 'NVARCHAR(MAX)'), 1, 2, '') 
		) AS legal_desc
	FROM g AS outerTable
	where
		1=1
		--and permitnum = 'CE19003259-cbs'
	GROUP BY permitnum
)
insert into #legal_descs
select * from h

union

select 
	pmap.permitnum + '' permitnum
	,trim(pb.LEGAL_DESC) legal_desc
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'' = pnum.permitnum
join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
left join hcfl_src.dbo.par_base pb on pb.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
where
	1=1
	and pnum.tt_record in ('Water Enforcement','Water Enforcement - Proactive')
	and not exists (
		select 1
		from h
		where permitnum =  pmap.permitnum+''
	)
;
go
IF OBJECT_ID('tempdb.dbo.#_wrviol_things', 'U') IS NOT NULL drop table #_wrviol_things
;
select distinct 
	i.number_key
	--,i.ITEM_ID
	,CONVERT(varchar(10), i.THE_DATE,121) the_date
	,i.ITEM_ID
	--i.*
	,tc.notation
into #_wrviol_things
from jms_apd_base_filtered__wrviol1 a 
join hcfl_src..apd_itms i on i.number_key = a.number_key
left join hcfl_src..tab_cond tc on tc.ELEMENT_KEY = i.ITEM_ID
where
	1=1
	and i.RECORD_TYPE = 'CD'
	--and i.number_key = 'WR1900045 '
;

;IF OBJECT_ID('tempdb.dbo.#wrviol_things', 'U') IS NOT NULL drop table #wrviol_things
;select distinct
	number_key
	,trim('^|' from stuff((
			select 
				'^|^' + cast(
					trim(replace(replace(replace(replace(   isnull(a2.the_date,'')   ,'"',''''''),'''',''),char(13),''),char(10),'®')) 
					as varchar(max)
				)
			from #_wrviol_things a2 with(nolock)
			where 
				1=1
				and a2.number_key = a1.number_key
			group by a2.the_date
			--order by a2.the_date,a2.item_id
			FOR XML PATH('')
	), 1, 1, '')) as the_date
	,trim(', ' from stuff((
			select 
				',' + cast(
					trim(replace(replace(replace(replace(   isnull(a2.item_id,'')   ,'"',''''''),'''',''),char(13),''),char(10),'®')) 
					as varchar(max)
				)
			from #_wrviol_things a2 with(nolock)
			where 
				1=1
				and a2.number_key = a1.number_key
			group by a2.item_id
			--order by a2.the_date,a2.item_id
			FOR XML PATH('')
	), 1, 1, '')) as item_id
	,trim(', ' from stuff((
			select 
				',' + cast(
					trim(replace(replace(replace(replace(   isnull(a2.notation,'')   ,'"',''''''),'''',''),char(13),''),char(10),'®')) 
					as varchar(max)
				)
			from #_wrviol_things a2 with(nolock)
			where 
				1=1
				and a2.number_key = a1.number_key
			group by a2.notation
			--order by a2.the_date,a2.item_id
			FOR XML PATH('')
	), 1, 1, '')) as notation
into #wrviol_things
from #_wrviol_things a1
where
	1=1
	--and NUMBER_KEY = 'WR1900045 '
;

;IF OBJECT_ID('tempdb.dbo.#primary_name_wrviol', 'U') IS NOT NULL DROP TABLE #primary_name_wrviol
;WITH RankedResults AS (
    SELECT 
        pmap.number_key --STRINSTRUMENTREL.vdi_key
        ,p.name
        ,ROW_NUMBER() OVER(PARTITION BY  pmap.number_key ORDER BY p.primary_name,p.name ) AS Rank
    from aatable_permit_history pnum
    join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'-CBS' = pnum.permitnum
    join hcfl_src.dbo.apd_peo p on p.number_key = pmap.number_key 
)
SELECT 
    *
into #primary_name_wrviol
FROM RankedResults
WHERE
    1=1
    and Rank = 1
;--22sec

;IF OBJECT_ID('tempdb.dbo.#primary_address_wrviol', 'U') IS NOT NULL DROP TABLE #primary_address_wrviol
;WITH RankedResults AS (
      SELECT 
        permitnum
        ,full_address
        ,ROW_NUMBER() OVER(PARTITION BY permitnum ORDER BY case when isprimary='Y' then 1 else 2 end) AS Rank
      FROM AATABLE_PERMIT_ADDRESS
)
SELECT 
	*
into #primary_address_wrviol
FROM RankedResults
WHERE
	1=1
	and Rank = 1
;




;IF OBJECT_ID('cf_Water_Enforcement', 'U') IS NOT NULL DROP TABLE cf_Water_Enforcement
;
select distinct
    pnum.permitNum
    ,pnum.tt_record
 
    --APPEAL INFORMATION
    ,n1.dtAppeal as [Appeal Hearing Date] --Date 
    ,(case 
        when t0.ynAppealApproved = 'Y' then 'Approved'
        when t0.ynAppealDenied = 'Y' then 'Denied'
        else null 
        end 
    ) as [Appeal Decision]
    ,t1.strAppealReason as [Appeal Comment] --Text 
 
    --DATA FIELDS
    ,t1.strADX as [ADX Number] --Text 
    ,t1.zoning as [Zoning] --Text 
    ,(case 
        when 1=0 then 'Res' 
        when 1=0 then 'Non Res'
        else null 
        end 
    ) as [res or non res] --dropdown
    ,(case t1.str_type
        when 'BLK' then 'Block'
        when 'FR'  then 'Frame'
        when 'MH'  then 'Mobile Home'
        else 'Other'
        end 
    ) as [structure type] --dropdown
 
    ,( case 
         when 1=0 then 'A'
         when 1=0 then 'B'
         when 1=0 then 'C'
         when 1=0 then 'D'
         when 1=0 then 'PRP'
         when 1=0 then 'RR'
        else null
        end
     ) as [Code Inspection Area] --Drop Down 
    ,a.location as [Description of Location] --Text 
    ,( case 
         when 1=0 then 'Back Office'
         when 1=0 then 'BOCC'
         when 1=0 then 'Call Center'
         when 1=0 then 'Proactive'
         when 1=0 then 'Sweep'
        end
     ) as [Type of Submittal] --Drop Down  req 
    ,null as [Repeat Violator] --Yes/No 
    ,t0.txt_occupancy as [occupancy type] --dropwdown
    ,n1.dtHearingNotice as [Notice Date] --Date  --Notice of Hearing Date%%
    ,t1.NOTICE_TYPE as [method of service] --dropdown
    ,n0.dtHearingDate as [Hearing Date] --Date 
 
    --SWEEP INFO
    ,null as [Date of Sweep] --Date 
    ,null as [Location of Sweep Operation] --Text 
 
    --VIOLATION INFO
    ,convert(date,dvt.dtIncident) as [Date of violation] --the hack fix is no longer applicable. Disregard info to the right of here. -- --t1.dtViolationTime as [Date of violation] --Date  ---REM this has a hack fix on '0180 0100 0100 custom lists violations.sql'
    ,dvt.hhmmss as [Time of Violation] -- date
        ,( case 
         when isnull(n0.numOffenceNumber,0) = 0 then null
         when n0.numOffenceNumber = 1 then 'First Offense'
         when n0.numOffenceNumber = 2 then 'Second Offense'
         when n0.numOffenceNumber = 3 then 'Third Offense'
         when n0.numOffenceNumber = 4 then 'Fourth Offense'
         when n0.numOffenceNumber = 5 then 'Fifth Offense'
         when n0.numOffenceNumber >= 6 then 'Sixth + Offense'
         else null
        end
     ) as [Offense Number] --Drop Down 
    ,null as [Lis pendens] --Yes/No 
    ,null as [Is this a Home Owner Associate complaint?] --Yes/No 
    ,null as [If yes, is the letter attached?] --Yes/No 
    ,null as [Create Violator from Owner] --CheckBox 
    ,null as [Court Case Number] --Text 
    
    --HISTORICAL PERMITS PLUS FIELDS
    ,a.ADDL_FEES AS [ADDL_FEES]
    ,NULL AS [ADDRESS_4]
    ,NULL AS [APPROVED]
    ,a.CALC_FEES AS [CALC_FEES]
    ,n1.DATE_103 AS [DATE_103]
    ,n1.DATE_109 AS [DATE_109]
    ,n1.DATE_118 AS [DATE_118]
    ,NULL AS [DATE_L]
    ,a.insp_area AS [INSP_AREA]
    ,pb.LEGAL_DESC AS [LEGAL_DESC]
    ,NULL AS [MON_066]
    ,wt.notation AS [NOTATION]
    ,aa.full_address AS [PRIMARY_ADDR]
    ,ap.name AS [PRIMARY_NAME]
    ,t0.text_000 AS [TEXT_000]
    ,t0.text_004 AS [TEXT_004]
    ,t0.text_014 AS [TEXT_014]
    ,t1.text_050 AS [TEXT_050]
    ,t1.text_060 AS [TEXT_060]
    ,t1.text_067 AS [TEXT_067]
    ,t1.text_069 AS [TEXT_069]
    ,t1.text_072 AS [TEXT_072]
    ,t1.text_077 AS [TEXT_077]
    ,wt.the_date AS [THE_DATE]
    ,coalesce(user_id.user_name,a.user_id) AS [USER_ID]
    ,wt.item_id AS [VIOLATIONS]
    ,a.sub_type [SUB_TYPE]
    ,a.DATE_A [DATE_A]
    ,a.date_k [DATE_K]
into cf_Water_Enforcement
from AATABLE_PERMIT_HISTORY pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered__wrviol1 a on a.NUMBER_KEY = pmap.number_key
left join #n0 n0 on n0.number_key = pmap.number_key
left join #n1 n1 on n1.number_key = pmap.number_key
left join #t0 t0 on t0.number_key = pmap.number_key
left join #t1 t1 on t1.number_key = pmap.number_key
left join #dtViolationTime dvt on dvt.number_key = a.number_key
left join #legal_descs pb on pb.permitnum = pmap.permitnum
left join jms_userid_username__wrviol1 user_id on user_id.user_id = a.user_id
left join #wrviol_things wt on wt.number_key = pmap.number_key
left join #primary_address_wrviol aa on aa.permitnum = pmap.permitnum 
left join #primary_name_wrviol ap on ap.number_key = pmap.number_key
where
    1=1
    and pnum.tt_record in ('Water Enforcement','Water Enforcement - Proactive')
;
 
    --ensure_fields_arent_too_long
declare @table_name varchar(100) = 'cf_Water_Enforcement' 

declare @cutoff int = 50;
DECLARE long_colname_cursor CURSOR for (
	select 
		column_name
	from INFORMATION_SCHEMA.columns 
	where 
		table_name = @table_name
		and len(column_name) > @cutoff
);

declare @column_name_old varchar(200);
declare @modString varchar(200);
declare @newname varchar(200);


OPEN long_colname_cursor
FETCH NEXT FROM long_colname_cursor INTO @column_name_old
    WHILE @@FETCH_STATUS = 0  
		begin
			set @modString = 'dbo.' + @table_name + '.' + @column_name_old;
			set @newname = left(@column_name_old, @cutoff)
			EXEC sp_rename @modString, @newname, 'COLUMN';
			FETCH NEXT FROM long_colname_cursor   INTO @column_name_old
		end
CLOSE long_colname_cursor
DEALLOCATE long_colname_cursor
;
go
;



--water enforcement cbs - ENF_CBS_WA
;IF OBJECT_ID('tempdb.dbo.#m0', 'U') IS NOT NULL DROP TABLE #m0
;SELECT
     m0.number_key
    ,m0.MON_045
    ,m0.MON_046
    ,m0.MON_047
    ,m0.MON_048
into #m0
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'-CBS' = pnum.permitnum
join hcfl_src.dbo.apd_mon0 m0 on m0.number_key = pmap.number_key
where 
	pnum.tt_record = 'Citizen Board Support Water Enforcement'
	and (coalesce(m0.MON_045,m0.MON_046,m0.MON_047,m0.MON_048) is not null)
;--50sec
;IF OBJECT_ID('tempdb.dbo.#n0', 'U') IS NOT NULL DROP TABLE #n0
;SELECT
     n0.number_key
    ,n0.Date_099 dtAffidavit     
	,n0.date_075 dtHearingDate
    ,n0.Date_084
    ,n0.Date_085
    ,n0.Date_099
into #n0
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'-CBS' = pnum.permitnum
join hcfl_src.dbo.apd_num0 n0 on n0.number_key = pmap.number_key
where 
	pnum.tt_record = 'Citizen Board Support Water Enforcement'
	and (coalesce(n0.Date_099,n0.Date_084,n0.Date_085,n0.Date_099,null) is not null)
;--50sec

;IF OBJECT_ID('tempdb.dbo.#n1', 'U') IS NOT NULL DROP TABLE #n1
;SELECT
     n1.number_key
     ,n1.Date_102 dtHearingNotice   
     ,n1.DATE_101
into #n1
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'-CBS' = pnum.permitnum
left join hcfl_src.dbo.apd_num1 n1 on n1.number_key = pmap.number_key
--left join hcfl_src.dbo.apd_num0 n0 on n0.number_key = pmap.number_key
where 
	pnum.tt_record = 'Citizen Board Support Water Enforcement'
	and coalesce(n1.Date_102,n1.DATE_101,null) is not null
;--20sec
;IF OBJECT_ID('tempdb.dbo.#t0', 'U') IS NOT NULL DROP TABLE #t0
;SELECT
     t0.number_key
    ,t0.Text_042 strHearingType    
    ,t0.Text_029 strDefendantHrng  
    ,t0.TEXT_003
    ,t0.TEXT_032
    ,t0.TEXT_040
    ,t0.TEXT_041
    ,t0.YN_007
into #t0
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'-CBS' = pnum.permitnum
join hcfl_src.dbo.apd_txt0 t0 on t0.number_key = pmap.number_key
where 
	pnum.tt_record = 'Citizen Board Support Water Enforcement'
	and coalesce(t0.Text_042,t0.text_029,t0.TEXT_003,t0.TEXT_032,t0.TEXT_040,t0.TEXT_041,t0.YN_007,null) is not null
;--8sec
;IF OBJECT_ID('tempdb.dbo.#dtViolationTime', 'U') IS NOT NULL DROP TABLE #dtViolationTime
;with g as (
	select 
		number_key
		,t1.Text_053 as [dtViolationTime] 
		,right('0'+replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(t1.Text_053,'.',''),'A',''),'P',''),':',''),' ',''),'hrs',''),'hr',''),'M',''),';',''),'"',''),'`',''),'-',''),4)
			as tttt
	from hcfl_src.dbo.apd_txt1 t1 
	where 
		1=1
		and NUMBER_KEY like 'wr%' 
		and t1.text_053 is not null
)
select
	NUMBER_KEY
	,dtViolationTime
	,('1900-01-01 ' +case 
            when dtViolationTime like '%p%' 
            then right(  '0'+convert(varchar(2),isnull(try_convert(int,substring(tttt,1,2)),0) + 12)  ,2)
            else left(tttt,2)
            end
        + ':'
        + right(tttt,2)
        + ':00' 
    ) as hhmmss
into #dtViolationTime
from g 
;

;IF OBJECT_ID('tempdb.dbo.#t1', 'U') IS NOT NULL DROP TABLE #t1
;SELECT
     t1.number_key
    ,t1.Text_065 as strAppealReason 
    ,t1.Text_066 as strADX
    ,t1.Text_059 as zoning
    ,t1.Text_076 as str_type
    ,t1.Text_080 as [NOTICE_TYPE]
    ,t1.Text_053 as [dtViolationTime]
    ,t1.text_050
    ,t1.text_060
    ,t1.text_067
    ,t1.text_069
    ,t1.text_072
    ,t1.text_077
    ,t1.TEXT_098
into #t1
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'-CBS' = pnum.permitnum
join hcfl_src.dbo.apd_txt1 t1 on t1.number_key = pmap.number_key
where 
	pnum.tt_record = 'Citizen Board Support Water Enforcement'
	and coalesce(t1.Text_065,t1.Text_066,t1.Text_059,t1.Text_076,t1.Text_080,t1.Text_053,t1.text_050,t1.text_060,t1.text_067,t1.text_069,t1.text_072,t1.text_077,t1.TEXT_098,null) is not null
;--3sec

;IF OBJECT_ID('tempdb.dbo.#legal_descs', 'U') IS NOT NULL DROP TABLE #legal_descs
;create table #legal_descs ( permitnum varchar(50), legal_desc varchar(max) )
;with cte_many as (
	select 
		pmap.permitnum + '-CBS' permitnum
		,count(LEGAL_DESC) ct
	from aatable_permit_history pnum
	join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'-CBS' = pnum.permitnum
	join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
	left join hcfl_src.dbo.par_base pb on pb.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
	where
		1=1
		and pnum.tt_record in ('Citizen Board Support Water Enforcement')
	group by pmap.permitnum
	having count(LEGAL_DESC) > 1
), g as (
	select distinct
		pmap.permitnum + '-CBS' permitnum
		,pb.LEGAL_DESC
	from aatable_permit_history pnum
	join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'-CBS' = pnum.permitnum
	join cte_many f on f.permitnum =  pmap.permitnum+'-CBS'
	join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
	left join hcfl_src.dbo.par_base pb on pb.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
	where
		1=1
		and pnum.tt_record in ('Citizen Board Support Water Enforcement')
),h as (
	SELECT
		permitnum
		,trim('^| ' from 
			  STUFF(
				(SELECT ' ^|^ ' + LEGAL_DESC
				 FROM g AS innerTable
				 WHERE innerTable.permitnum = outerTable.permitnum
				 FOR XML PATH(''), TYPE
				).value('.', 'NVARCHAR(MAX)'), 1, 2, '') 
		) AS legal_desc
	FROM g AS outerTable
	where
		1=1
		--and permitnum = 'CE19003259-cbs'
	GROUP BY permitnum
)
insert into #legal_descs
select * from h

union

select 
	pmap.permitnum + '-CBS' permitnum
	,trim(pb.LEGAL_DESC) legal_desc
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum+'-CBS' = pnum.permitnum
join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
left join hcfl_src.dbo.par_base pb on pb.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
where
	1=1
	and pnum.tt_record in ('Citizen Board Support Water Enforcement')
	and not exists (
		select 1
		from h
		where permitnum =  pmap.permitnum+'-CBS'
	)
;
go

;IF OBJECT_ID('cf_Water_Enforcement_cbs', 'U') IS NOT NULL DROP TABLE cf_Water_Enforcement_cbs
;
SELECT
    pnum.permitNum
    ,pnum.tt_record
    
    --DATA FIELDS
    ,n1.dtHearingNotice as [Notice Date]
    ,t1.NOTICE_TYPE as [Method of Service]
    ,n0.dtAffidavit as [Date of Affidavit]
    ,n0.dtHearingDate as [Hearing Date]
    ,null as [Postmark Date]
    ,t0.strHearingType as [Type of Hearing]
    ,n1.dtHearingNotice as [Date received for Hearing]
    ,null as [Date of Board Order]
    ,t0.strDefendantHrng as [Text field for name of person who appeared for hearing]
    ,null as [Cap Value]
    ,null as [Name of the officer giving testimony]
    ,null as [Hearing Location]
    ,null as [Recording Date]
    ,null as [Secondary Recording Date]
    ,null as [Release Date]
    ,null as [Secondary Release Date]
    ,null as [Book Page for Liens]
    ,null as [Instrument Number for Recording Date]
    ,null as [Secondary Instrument Number for Recording Date]
    ,null as [Instrument Number for Release Date]
    ,null as [Secondary Instrument Number for Release Date]
    ,null as [Tracking Number]
    ,null as [Date Posted at Property]
    ,null as [Card Received]
    ,null as [Reason Letter was not received]
    ,null as [Date Notice of Hearing Posted]
    ,null as [Change of Address]
    ,null as [Green Card Received]
    ,null as [Date Posted at Courthouse]
    ,null as [Notice of Hearing Date]
    ,null as [Notice of Hearing Date Verified by Mail Date]
    ,null as [Hearing Time]
    ,null as [Name of person that signed Affidavit]
    ,null as [Extension Order]
    ,null as [Code Record]
    ,null as [Hearing Date Continued]
    ,null as [Offense Number]
    ,null as [Water Enforcement Fine Amount]
    
    --HISTORICAL PERMITS PLUS FIELDS
    ,a.SUB_TYPE as [SUB_TYPE]
    ,a.LOCATION as [LOCATION]
    ,m0.MON_045 as [MON_045]
    ,m0.MON_046 as [MON_046]
    ,m0.MON_047 as [MON_047]
    ,m0.MON_048 as [MON_048]
    ,n0.Date_084 as [DATE_084]
    ,n0.Date_085 as [DATE_085]
    ,n0.Date_099 as [DATE_099]
    ,n1.DATE_101 as [DATE_101]
    ,t0.TEXT_003 as [TEXT_003]
    ,t0.TEXT_032 as [TEXT_032]
    ,t0.TEXT_040 as [TEXT_040]
    ,t0.TEXT_041 as [TEXT_041]
    ,t1.TEXT_098 as [TEXT_098]
    ,t0.yn_007 as [YN_007]
    ,null as [YN_051]
    ,pb.legal_desc as [LEGAL_DESC]
    ,a.calc_fees as [CALC_FEES]
    ,a.addl_fees as [ADDL FEES]
into cf_Water_Enforcement_cbs
from AATABLE_PERMIT_HISTORY pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum +'-CBS' = pnum.permitnum
join jms_apd_base_filtered__wrviol1 a on a.NUMBER_KEY = pmap.number_key
left join #m0 m0 on m0.number_key = pmap.number_key
left join #n0 n0 on n0.number_key = pmap.number_key
left join #n1 n1 on n1.number_key = pmap.number_key
left join #t0 t0 on t0.number_key = pmap.number_key
left join #t1 t1 on t1.number_key = pmap.number_key
left join #dtViolationTime dvt on dvt.number_key = a.number_key
left join #legal_descs pb on pb.permitnum = pmap.permitnum
left join jms_userid_username__wrviol1 user_id on user_id.user_id = a.user_id
--left join #wrviol_things wt on wt.number_key = pmap.number_key
--left join #primary_address_wrviol aa on aa.permitnum = pmap.permitnum 
--left join #primary_name_wrviol ap on ap.number_key = pmap.number_key
where
    1=1
    and pnum.tt_record = 'Citizen Board Support Water Enforcement'
;
 
    --ensure_fields_arent_too_long
declare @table_name varchar(100) = 'cf_Water_Enforcement_cbs' 

declare @cutoff int = 50;
DECLARE long_colname_cursor CURSOR for (
	select 
		column_name
	from INFORMATION_SCHEMA.columns 
	where 
		table_name = @table_name
		and len(column_name) > @cutoff
);

declare @column_name_old varchar(200);
declare @modString varchar(200);
declare @newname varchar(200);


OPEN long_colname_cursor
FETCH NEXT FROM long_colname_cursor INTO @column_name_old
    WHILE @@FETCH_STATUS = 0  
		begin
			set @modString = 'dbo.' + @table_name + '.' + @column_name_old;
			set @newname = left(@column_name_old, @cutoff)
			EXEC sp_rename @modString, @newname, 'COLUMN';
			FETCH NEXT FROM long_colname_cursor   INTO @column_name_old
		end
CLOSE long_colname_cursor
DEALLOCATE long_colname_cursor
;
go
;