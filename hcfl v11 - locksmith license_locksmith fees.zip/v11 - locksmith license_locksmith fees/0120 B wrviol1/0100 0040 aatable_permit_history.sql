/*
I need to square up the comp_type,version to the specific actual accela record types.
rem: refer to permitHistory_setup
do I need to instantiate records for the citizens board hearing idea? Client expects double records. But do I then double the information, and the charges? Is CBS record effectively a dummy record, related to its parent?

regular history
cbs instantiation
*/



--regular history
;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_HISTORY
;
insert into aatable_permit_history
select distinct
    trim(a.number_key) as permitnum
    ,null as CONTRACTOR_VALUATION
    ,coalesce(a.entered_date,'1900-01-01 00:00:00') as DATEOPENED
    ,null as Expiration_date --,permit_info.date_123 as Expiration_date
    ,null as app_status
    ,coalesce(trim(left(replace(replace(     convert(varchar(max),d.description)    ,char(10),''),char(13),''),4000)),'Not Set') as work_desc --,left(replace(replace( coalesce(  convert(varchar(max),comp_type.description)    ,convert(varchar(max),a.type_title)    ) + isnull(' - '+convert(varchar(max),d.description),'') ,char(10),''),char(13),''),4000)  as work_desc
    ,trim(coalesce(App_Name.name,'Not Set')) as App_Name
    ,a.house_cnt as House_Count
    ,a.bld_cnt as Building_Count
    ,null as Public_Owned
    ,null as Const_Type_Code
    ,null as short_notes --,isnull(a.sub_type,'')+isnull(';'+a.location,'') as short_notes --facname.text_010 as Short_Notes
    ,null as asgn_dept --,a.status_class as Asgn_Dept
    ,null as asgn_staff --,coalesce(asgn_staff.user_name,a.insp_area,'Not Set') as Asgn_Staff
    ,null asgn_date --,a.date_a as Asgn_Date --Populates the first visit date, and store for history
    ,null as Completed_Dept
    ,null as Completed_By
    ,a.date_f as Completed_Date --date_f --The “Closing” date of the record
    ,null as scheduled_date --a.date_k as Scheduled_Date --The “Due” date for the next inspection ----https://redmine.scubeenterprise.com/issues/19564
    ,null as Priority
    ,null as Total_Job_Cost
    ,a.date_f as Closed_Date --date_f --The “Closing” date of the record
    ,null as closed_by --,case when a.date_f is null then null else coalesce(asgn_staff.user_name,a.insp_area,'Not Set') end as Closed_By
    ,null as VR_Tracking_Num
    ,null as created_by --,coalesce(created_by.user_name,a.user_id,'Not Set') as Created_By
    ,null as Reported_Channel
    ,null Created_By_Dept --,'Code Enforcement' as Created_By_Dept
    ,null as first_issued_date --,permit_info.date_122 as First_Issued_Date --an assumption based on HBCODE_DATA.pdf
    ,null as Anonymous_Flag
    ,null as Reference_Type
    ,null as Appearance_Dayofweek
    ,null as Appearance_Date
    ,null as Booking_Flag
    ,null as Defendant_Signature_Flag
    ,null as Enforce_Officer_ID
    ,null as Enforce_Officer_Name
    ,null as Infraction_Flag
    ,null as Inspector_ID
    ,null as Misdemeanor_Flag
    ,null as Offence_Witnessed_Flag
    ,null as Inspector_Name
    ,null as Enforce_Dept
    ,null as Inspector_Dept
    ,null as Valuation_Multiplier
    ,null as Valuation_Extra_Amt
    ,null as Last_Audit_Date
    ,try_convert(datetime,f.entered_date_max) as App_Status_Date
    ,null as Delegate_User_ID
    ,a.data_status as TT_Record_Status
    ,(case when a.SUB_TYPE in ('RTN','SWEEP') then f.tt_record + ' - Proactive' else f.tt_record end) as tt_record
    ,0 as Balance
    ,0 as Total_Fee
    ,0 as Total_Pay
    ,null as Last_Update_By
    ,null as Last_Update_Date
from jms_apd_base_filtered__wrviol1 a --hcfl_src.dbo.apd_base a
join jms_pre_aatablePermitHistory_filter__wrviol1 f on f.NUMBER_KEY = a.NUMBER_KEY
left join jms_permit_info__wrviol1 permit_info on permit_info.number_key = a.number_key 
left join jms_comp_type__wrviol1 comp_type on comp_type.version = a.version and comp_type.comp_type = a.comp_type
left join hcfl_src.dbo.apd_desc d on d.number_key = a.number_key
left join jms_numberKey_primaryOrdering__wrviol1 app_name on app_name.number_key = a.NUMBER_KEY
--left join jms_facname__wrviol1 facname on facname.number_key = a.number_key -- all null
left join jms_userid_username__wrviol1 created_by on created_by.user_id = a.user_id
left join jms_userid_username__wrviol1 asgn_staff on asgn_staff.user_id = a.insp_area
where
    1=1
;

--cbs instantiation
;with cbs_records_cte as (
    select distinct
        a.number_key
    from jms_apd_base_filtered__wrviol1 a 
    join hcfl_src..apd_num0 n0 on n0.number_key = a.number_key
    where 
        1=1
        and n0.Date_075 is not null
)
insert into AATABLE_PERMIT_HISTORY
select distinct
    trim(a.number_key)+'-CBS' as permitnum
    ,null as CONTRACTOR_VALUATION
    ,coalesce(a.date_g,a.entered_date,'1900-01-01 00:00:00') as DATEOPENED --date_g=hearing date
    ,null as Expiration_date --permit_info.date_123 as Expiration_date
    ,null as Expiration_Status
    ,left(replace(replace(     convert(varchar(max),d.description)    ,char(10),''),char(13),''),4000)  as work_desc --,left(replace(replace( coalesce(  convert(varchar(max),comp_type.description)    ,convert(varchar(max),a.type_title)    ) + isnull(' - '+convert(varchar(max),d.description),'') ,char(10),''),char(13),''),4000)  as work_desc
    ,coalesce(App_Name.name,'') as App_Name
    ,a.house_cnt as House_Count
    ,a.bld_cnt as Building_Count
    ,null as Public_Owned
    ,null as Const_Type_Code
    ,null as short_notes --,isnull(a.sub_type,'')+isnull(';'+a.location,'') as short_notes --facname.text_010 as Short_Notes
    ,null as asgn_dept --,a.status_class as Asgn_Dept
    ,coalesce(asgn_staff.user_name,a.insp_area,'Not Set') as Asgn_Staff
    ,a.Date_H as Asgn_Date --date_h=Date of Board order%%
    ,null as Completed_Dept
    ,null as Completed_By
    ,a.date_i as Completed_Date --date_i=Date of affidavit execution**
    ,case when a.date_D > a.date_i then null else a.date_d end as Scheduled_Date --date_d=Hearing date for the specified record%%
    ,null as Priority
    ,null as Total_Job_Cost
    ,a.date_f as Closed_Date --date_f --The “Closing” date of the record
    ,null as closed_by --,case when a.date_f is null then null else coalesce(asgn_staff.user_name,a.insp_area,'Not Set') end as Closed_By
    ,null as VR_Tracking_Num
    ,null as created_By --,coalesce(created_by.user_name,a.user_id,'Not Set') as Created_By
    ,null as Reported_Channel
    ,null as created_by_dept --,'Code Enforcement' as Created_By_Dept
    ,null as First_Issued_Date --,permit_info.date_122 as First_Issued_Date --an assumption based on HBCODE_DATA.pdf
    ,null as Anonymous_Flag
    ,null as Reference_Type
    ,null as Appearance_Dayofweek
    ,null as Appearance_Date
    ,null as Booking_Flag
    ,null as Defendant_Signature_Flag
    ,null as Enforce_Officer_ID
    ,null as Enforce_Officer_Name
    ,null as Infraction_Flag
    ,null as Inspector_ID
    ,null as Misdemeanor_Flag
    ,null as Offence_Witnessed_Flag
    ,null as Inspector_Name
    ,null as Enforce_Dept
    ,null as Inspector_Dept
    ,null as Valuation_Multiplier
    ,null as Valuation_Extra_Amt
    ,null as Last_Audit_Date
    ,try_convert(datetime,f.entered_date_max) as App_Status_Date
    ,null as Delegate_User_ID
    ,a.data_status as TT_Record_Status
    ,'Citizen Board Support Water Enforcement' --f.tt_record
    ,0 as Balance
    ,0 as Total_Fee
    ,0 as Total_Pay
    ,null as Last_Update_By
    ,null as Last_Update_Date
from jms_apd_base_filtered__wrviol1 a --hcfl_src.dbo.apd_base a
join jms_pre_aatablePermitHistory_filter__wrviol1 f on f.NUMBER_KEY = a.NUMBER_KEY
join cbs_records_cte ff on ff.numbeR_key = a.number_key
left join jms_permit_info__wrviol1 permit_info on permit_info.number_key = a.number_key 
left join jms_comp_type__wrviol1 comp_type on comp_type.version = a.version and comp_type.comp_type = a.comp_type
left join hcfl_src.dbo.apd_desc d on d.number_key = a.number_key
left join jms_numberKey_primaryOrdering__wrviol1 app_name on app_name.number_key = a.NUMBER_KEY
--left join jms_facname__wrviol1 facname on facname.number_key = a.number_key -- all null
left join jms_userid_username__wrviol1 created_by on created_by.user_id = a.user_id
left join jms_userid_username__wrviol1 asgn_staff on asgn_staff.user_id = a.insp_area
where
    1=1
;







;update aatable_permit_history set Asgn_Staff = 'Spriggs, Teddy' where Asgn_Staff = 'Spriggs, Edward ''Teddy'''
;


----debug
--delete from aatable_permit_history where permitnum not in (
--    ''
--    --,'WR2301110'
--    --,'WR2301110-CBS'
--    --,'WR1700107'
--    --,'WR1700107-CBS'
--    --,'WR2301331'
--    --,'WR2001217'
--    --,'WR2001217-CBS'
--)
--;
--
