/*
wrviol_1

note_for_me1
note_for_me2

*/
IF OBJECT_ID('accelaconv7.dbo.jms_compType_version_feeItemNo_description_accountCode_feeKey__wrviol1', 'U') IS NOT NULL drop table accelaconv7.dbo.jms_compType_version_feeItemNo_description_accountCode_feeKey__wrviol1
;
create table accelaconv7.dbo.jms_compType_version_feeItemNo_description_accountCode_feeKey__wrviol1 (
    comp_type     varchar(100)
    ,version      varchar(100)
    ,fee_item_no  varchar(100)
    ,description  varchar(100)
    ,account_code varchar(100)
    ,fee_key      varchar(100)
    ,amount int
);

--wrviol_1
insert into accelaconv7.dbo.jms_compType_version_feeItemNo_description_accountCode_feeKey__wrviol1
select 
    comp_type
    ,version
    ,fee_item_no
    ,description
    ,account_code
    ,fee_key
    ,amount
from (VALUES
-- ('WRVIOL','1','500','CEB FINES/COSTS','','Generic Code Violation Fines')
--,('WRVIOL','1','500','CEB FINES/COSTS','354105','Generic Code Violation Fines')
--,('WRVIOL','1','501','Administrative Costs','','Generic Code Violation Fines')
--,('WRVIOL','1','800','Watering Violation','','Water Enforcement Fines')
 ('WRVIOL','1','800','Water Enf Fine_2nd','','Water Enf Fine_2nd',100)
,('WRVIOL','1','800','Water Enf Fine_3rd','','Water Enf Fine_3rd',200)
,('WRVIOL','1','800','Water Enf Fine_4th','','Water Enf Fine_4th',300)
,('WRVIOL','1','800','Water Enf Fine_5th','','Water Enf Fine_5th',400)
,('WRVIOL','1','800','Water Enf Fine_6th','','Water Enf Fine_6th',500)
,('WRVIOL','1','800','Water Enf Fine_hist','','Water Enf Fine_hist',null)
,('WRVIOL','1','500','CEB FINES/COSTS','','Water Enforcement Fine CBS',null)


) t(comp_type,version,fee_item_no,description,account_code,fee_key,amount)
;

--verify all relevant fee_key values are derived from a string which exists in aatable_permit_fee
if 1 = (
	select distinct 1
	from aatable_permit_fee a
	join jms_numberKey_permitnum__wrviol1 pmap on (pmap.permitnum = a.PERMITNUM) or (pmap.permitnum + '-CBS' = a.permitnum)
	left join jms_compType_version_feeItemNo_description_accountCode_feeKey__wrviol1 f on f.fee_key = reverse(substring(reverse(a.FEE_KEY),0,CHARINDEX('-',reverse(a.FEE_KEY))))
	where
		1=1
		and f.fee_key is null
) RAISERROR ('values in jms_compType_version_feeItemNo_description_accountCode_feeKey__wrviol1 must exist in aatable_permit_fee!', 16, 1)
;




/*
--note_for_me1
select distinct
	pnum.comp_type
	,pnum.version
	,fd.FEE_ITEM_NO
	,f.DESCRIPTION
	,fd.ACCOUNT_CODE
from hcfl_src..fee_detl fd
left join hcfl_src..tab_fee f on f.FEE_ITEM_NO = fd.FEE_ITEM_NO
left join hcfl_src.dbo.fee_id numberKey_transactionId on numberKey_transactionId.number_key = fd.NUMBER_KEY
left join hcfl_src.dbo.apd_base pnum on pnum.NUMBER_KEY = fd.NUMBER_KEY
where
	1=1
	and pnum.COMP_TYPE = 'npool' and pnum.VERSION = '101'
order by fd.FEE_ITEM_NO,fd.ACCOUNT_CODE


--note_for_me2
select distinct
	fd.NUMBER_KEY
	,f.FEE_ITEM_NO
	,f.DESCRIPTION
	,fd.ACCOUNT_CODE
	,fd.AMOUNT
	
from hcfl_src..fee_detl fd
left join hcfl_src..tab_fee f on f.FEE_ITEM_NO = fd.FEE_ITEM_NO
left join hcfl_src.dbo.fee_id numberKey_transactionId on numberKey_transactionId.number_key = fd.NUMBER_KEY
left join hcfl_src.dbo.apd_base pnum on pnum.NUMBER_KEY = fd.NUMBER_KEY
where
	1=1
	and pnum.COMP_TYPE = 'npool' and pnum.VERSION = '9801'
	--and f.FEE_ITEM_NO = '2135'
	--and fd.NUMBER_KEY = 'NPO05756'
	and f.FEE_ITEM_NO  = '2155'
	--and fd.account_code =	
	--and fd.AMOUNT <> convert(int,fd.amount)
--order by fd.NUMBER_KEY,f.FEE_ITEM_NO

*/