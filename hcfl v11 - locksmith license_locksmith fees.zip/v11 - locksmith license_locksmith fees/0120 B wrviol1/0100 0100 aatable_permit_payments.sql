/*
NEEDS:
voids -- filter needs more than payment_metho='void': see 'NPO04744  '
other comp_type,version flavors
"swap this and above for proper permitnum at some point if you remember" -- see below within logic.
*/


--create_PERMIT_PAYMENTS
;print 'create_PERMIT_PAYMENTS';

;;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_PAYMENTS
;
    --payments_applied_to_charges
IF OBJECT_ID('tempdb.dbo.##completed', 'U') IS NOT NULL 
insert into ##completed values (getdate(),'payments_applied_to_charges')
;    
insert into AATABLE_PERMIT_PAYMENTS(
PERMITNUM,PAY_KEY,PAYMENT_METHOD,PAYMENT_REF_NBR,CC_TYPE,PAYEE,PAYMENT_DATE,PAYMENT_AMOUNT,TRANSACTION_CODE,TRANSACTION_NBR,PAYMENT_COMMENT,CASHIER_ID,REGISTER_NBR,REC_DATE,REC_FUL_NAM,ACCT_ID,PAYEE_ADDRESS,PAYEE_PHONE,CC_AUTH_CODE,PAYEE_PHONE_IDD,PAYMENT_RECEIVED_CHANNEL,CHECK_NUMBER,CHECK_TYPE,DRIVER_LICENSE,CHECK_HOLDER_NAME,CHECK_HOLDER_EMAIL,PHONE_NUMBER,COUNTRY,STATE,CITY,STREET,ZIP,REASON,PAYEE_TYPE,HIST_RECEIPT_NBR, VOID_BY,VOID_DATE,payment_pay_key
)
select distinct
    pnum.permitnum as PERMITNUM
    ,trim(fd.trans_id) + '_' + trim(convert(varchar(max),fd.trans_seq)) + '-' + trim(convert(varchar(max),fd.DETL_SEQ)) as PAY_KEY
    ,isnull(ft.method,'CASH') as PAYMENT_METHOD
    ,null as PAYMENT_REF_NBR
    ,ft.cc_type as CC_TYPE
    ,null as PAYEE
    ,coalesce(try_convert(datetime,fs.POST_DATE),'1900-01-01 00:00:00') as PAYMENT_DATE
    ,fd.AMOUNT as PAYMENT_AMOUNT
    ,null as TRANSACTION_CODE
    ,null as TRANSACTION_NBR
    ,trim(';' from   isnull('historical account_code:'+fd.account_code,'') +  isnull(';'+fs.notation,'')    ) as PAYMENT_COMMENT
    ,fs.user_id as CASHIER_ID
    ,null as REGISTER_NBR
    ,coalesce(try_convert(datetime,fs.POST_DATE),'1900-01-01 00:00:00') as REC_DATE
    ,coalesce(u.user_name,fs.user_id,'Not Set') REC_FUL_NAM
    ,null as ACCT_ID
    ,null as PAYEE_ADDRESS
    ,null as PAYEE_PHONE
    ,ft.cc_authorz_no as CC_AUTH_CODE
    ,null as PAYEE_PHONE_IDD
    ,null as PAYMENT_RECEIVED_CHANNEL
    ,ft.check_no as CHECK_NUMBER
    ,null as CHECK_TYPE
    ,null as DRIVER_LICENSE
    ,null as CHECK_HOLDER_NAME
    ,null as CHECK_HOLDER_EMAIL
    ,null as PHONE_NUMBER
    ,null as COUNTRY
    ,null as STATE
    ,null as CITY
    ,null as STREET
    ,null as ZIP
    ,(case when voids.trans_id is not null then coalesce(voids.notation,'VOID_PAYMENT_REASON') else null end) as REASON
    ,null as PAYEE_TYPE
    ,trim(fd.trans_id) + '_' + trim(convert(varchar(max),fd.trans_seq)) + '-' + trim(convert(varchar(max),fd.DETL_SEQ))+ isnull('-'+trim(fs.receipt_no),'') as HIST_RECEIPT_NBR
    ,(case when voids.trans_id is not null then coalesce(voids.user_name,voids.user_id,'Not Set') else null end) as VOID_BY
    ,coalesce(try_convert(datetime,voids.post_date),'1900-01-01 00:00:00') as VOID_DATE
    ,null as payment_pay_key
from aatable_permit_history pnum --(select number_key as permitnum from hcfl_src.dbo.apd_base) pnum
left join AATABLE_PERMIT_FEE ape on ape.permitnum = pnum.permitnum --swap this and above for proper permitnum at some point if you remember
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = pnum.PERMITNUM
join hcfl_src.dbo.fee_id numberKey_transactionId on numberKey_transactionId.number_key = pmap.number_key
join hcfl_src.dbo.fee_detl   fd on fd.trans_id = numberKey_transactionId.trans_id
left join hcfl_src.dbo.fee_sum fs on fs.trans_id = numberKey_transactionId.trans_id
left join hcfl_src.dbo.fee_trn ft on ft.trans_id = numberKey_transactionId.trans_id  and ft.TRANS_SEQ = fd.TRANS_SEQ
left join hcfl_src.dbo.usr_base u on u.user_id = fs.user_id 
--voids
left join (
    SELECT
        s.post_date
        ,s.USER_ID
        ,vu.user_name
        ,s.notation
		,t.*
    from hcfl_src.dbo.fee_trn t 
    join hcfl_src.dbo.fee_sum s on s.trans_id = t.trans_id
    left join hcfl_src.dbo.usr_base vu on vu.user_id = s.user_id

	WHERE
        t.method = 'void'
) voids on voids.trans_id = ft.trans_xref
WHERE
    1=1
    and ft.method <> 'void'

;