/*
https://dev.azure.com/Hillsborough-County/bf470d0d-5a72-4dce-b8a4-ec892e39f909/_workitems/edit/11467
"I did want to mention that fine data (other than abatement costs) should be present on the CBS record. "

The below logic repoints fee data to the instantiated CBS records.
the cbs records also get those custom lists with the curStr values.
*/

;if object_id('tempdb.dbo.#fee_rePoint','U') is not null drop table #fee_rePoint
go
;
SELECT
    a.permitnum permitnum_oldd
   ,cbs.permitnum permitnum_neww
   
   ,a.fee_key fee_key_oldd
   ,replace(a.fee_key,a.permitnum,cbs.permitnum) fee_key_neww
   
   ,a.pay_key
into #fee_rePoint
from AATABLE_PERMIT_FEEALLOCATION a
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = a.permitnum
join aatable_permit_history cbs on cbs.permitnum = a.permitnum + '-CBS'
where
    1=1
    and a.fee_key like '%Water Enforcement Fine CBS%'
;

update a set 
     permitnum = b.permitnum_neww
    ,fee_key = b.fee_key_neww
from AATABLE_PERMIT_FEEALLOCATION a 
join #fee_rePoint b on b.permitnum_oldd = a.permitnum and b.fee_key_oldd = a.fee_key and b.pay_key = a.pay_key
;
update a set 
    permitnum = b.permitnum_neww
    ,fee_key = b.fee_key_neww
from aatable_permit_fee a 
join #fee_rePoint b on b.permitnum_oldd = a.permitnum and b.fee_key_oldd = a.fee_key 
;
update a set 
    permitnum = b.permitnum_neww
from AATABLE_PERMIT_PAYMENTS a
join #fee_rePoint b on b.permitnum_oldd = a.permitnum and b.pay_key = a.pay_key
;



--addendum set fees with no payments to be CBS as required
update a set 
    permitnum = f.permitnum
from AATABLE_PERMIT_FEE a 
join aatable_permit_history f on f.permitnum = a.permitnum + '-CBS'
where
	1=1
	and a.fee_key like '%CBS'
;















/*

update a set
     permitnum = cbs.permitnum
    ,fee_key = replace(a.fee_key,a.permitnum,cbs.permitnum)
from AATABLE_PERMIT_FEEALLOCATION a
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = a.permitnum
join aatable_permit_history cbs on cbs.permitnum = a.permitnum + '-CBS'
where
    1=1
    and a.fee_key like '%Water Enforcement Fine CBS%'
;

update a set
    a.permitnum = cbs.permitnum
    ,a.fee_key = replace(a.fee_key,a.permitnum,cbs.permitnum)
from aatable_permit_fee a
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = a.permitnum
join aatable_permit_history cbs on cbs.permitnum = a.permitnum + '-CBS'
where
    1=1
    and a.fee_key like '%Water Enforcement Fine CBS%'
;



update a set
    a.permitnum = cbs.permitnum
from AATABLE_PERMIT_PAYMENTS a
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = a.permitnum
join aatable_permit_history cbs on cbs.permitnum = a.permitnum + '-CBS'
where
    1=1
    and a.fee_key like '%Water Enforcement Fine CBS%'
;


--wrong
--update a set
--    a.permitnum = cbs.permitnum
--    ,a.fee_key = replace(a.fee_key,a.permitnum,cbs.permitnum)
--from AATABLE_PERMIT_RECEIPTS a
--join aatable_permit_history cbs on cbs.permitnum = a.permitnum + '-CBS'
--;

*/