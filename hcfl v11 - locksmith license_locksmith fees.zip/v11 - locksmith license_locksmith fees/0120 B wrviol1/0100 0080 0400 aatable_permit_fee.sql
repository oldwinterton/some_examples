/*
Needs other comp_type, version flavors
for at least npool, can I find a proper looking date for the fee applications, based on fee payment dates, and existing dates in apd_base or apd_num0?

*/

;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table aatable_permit_fee
;

--insert_fees
;print 'AATABLE_PERMIT_FEE - water violations'
;
insert into AATABLE_PERMIT_FEE (
PERMITNUM,FEE_KEY,GF_FEE_PERIOD,FEE_ITEM_AMOUNT,GF_DISPLAY,ACCOUNT_CODE1,ACCOUNT_CODE2,ACCOUNT_CODE3,GF_FEE_SCHEDULE,REC_DATE,REC_FUL_NAM,GF_UNIT,INVOICE,FEE_NOTES,FEE_SCHEDULE_VERSION,INVOICE_CUSTOMIZED_NBR,TT_FEE_CODE,TT_FEE_DESC,GF_FEE_TYPE_ALLOCATION,GF_L1_ALLOCATION,GF_L2_ALLOCATION,GF_L3_ALLOCATION,VOID_FLAG,GF_FEE_APPLY_DATE
)
select distinct
    pnum.permitnum as Permitnum
    ,pnum.permitnum + '-'+ fee.fee_name fee_key
    ,'Final' as GF_Fee_Period
    ,fee.fee_value as Fee_Item_Amount
    ,0 GF_Display --dense_rank() over(partition by a.permitnum order by invoice.invoice_date) as GF_Display
    ,null as Account_Code1 --invoice.account_id --this if for breaking down fees into accounts
    ,null as Account_Code2
    ,null as Account_Code3
    ,null as GF_Fee_Schedule
    ,coalesce(try_convert(datetime,coalesce(fee.entered_date,a.entered_date)),'1900-01-01 00:00:00') as Rec_Date
    ,a.user_id as Rec_Ful_Nam
    ,null as GF_Unit
    ,'Y' as Invoice
    ,fee.note as Fee_Notes
    ,null as Fee_Schedule_Version
    ,null as INVOICE_CUSTOMIZED_NBR
    ,' ' as TT_FEE_CODE
    ,fee.fee_name as TT_FEE_DESC
    ,null as GF_FEE_ALLOCATION_TYPE
    ,null as GF_L1_ALLOCATION
    ,null as GF_L2_ALLOCATION
    ,null as GF_L3_ALLOCATION
    ,null as VOID_FLAG
    ,coalesce(try_convert(datetime, coalesce(fee.entered_date,a.entered_date)),'1900-01-01 00:00:00') as GF_FEE_APPLY_DATE
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = pnum.PERMITNUM
join hcfl_src.dbo.apd_base a on a.number_key = pmap.number_key --(select number_key as permitnum,user_id,entered_date from hcfl_Src.dbo.apd_base) pnum
join accelaconv7.dbo.jms_numberKey_fee_value_note__wrviol1 fee on fee.number_key = pmap.number_key
WHERE
    1=1
;


----select count(*)
--update a set 
--    permitnum = f.permitnum
--from AATABLE_PERMIT_FEE a 
--join aatable_permit_history f on f.permitnum = a.permitnum + '-CBS'
--where
--	1=1
--	and a.fee_key like '%CBS'
--;
--