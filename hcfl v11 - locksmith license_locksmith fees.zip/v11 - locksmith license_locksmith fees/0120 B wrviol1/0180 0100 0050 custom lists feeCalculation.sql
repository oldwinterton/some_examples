/*
things
addendum move the orders to CBS record if CBS record exists
*/

--things
;IF OBJECT_ID('tempdb.dbo.#_t', 'U') IS NOT NULL drop table #_t
;IF OBJECT_ID('tempdb.dbo.#t', 'U') IS NOT NULL drop table #t
;
select
	pnum.permitnum
    ,pnum.tt_record
    
	,n0.Date_086
	,m0.Mon_041  
	,t0.Text_019 
	,n0.Date_080 
	,m0.Mon_037  
	,n0.Date_090 

	,n0.Date_087 
	,m0.Mon_042  
	,t0.Text_024 
	,n0.Date_081 
	,m0.Mon_038  
	,n0.Date_091 

	,n0.Date_088
	,m0.Mon_043  
	,t0.Text_025 
	,n0.Date_082 
	,m0.Mon_039  
	,n0.Date_092 

	,n0.Date_089
	,m0.Mon_044 
	,t0.Text_028
	,n0.Date_083
	,m0.Mon_040 
	,n0.Date_093
into #_t
from accelaconv7..aatable_permit_history pnum 
join accelaconv7..jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = pnum.permitnum
left join hcfl_src.dbo.apd_num0 n0 on n0.number_key = pmap.number_key
left join hcfl_src.dbo.apd_txt0 t0 on t0.number_key = pmap.number_key
left join hcfl_src.dbo.apd_mon0 m0 on m0.number_key = pmap.number_key
;
SELECT 
*
into #t
from #_t
where 
    1=1
    and (
        coalesce(Mon_041,Mon_037,Mon_042,Mon_038,Mon_043,Mon_039,Mon_044,Mon_040,0) <> 0
        or coalesce(Text_019,Text_024,Text_025,Text_028) is not null
        or coalesce(Date_080,Date_090,Date_087,Date_086,Date_081,Date_091,Date_088,Date_083,Date_082,Date_092,Date_089,Date_093) is not null
    )
;





;IF OBJECT_ID('accelaConv7.dbo.cl_wrviol_feeCalculation', 'U') IS NOT NULL drop table cl_wrviol_feeCalculation
;
with g as (
    select
         a.permitnum
        ,a.tt_record

        ,a.Date_086 as start_date --a.Date_080 as [dtPart1]
        ,'Part I' as order_part --a.Text_019 as [strOrderPart1]
        ,a.Mon_041 as subtotal_value
        ,a.Text_019 as [order]
        ,a.Date_080 as on_or_before_date
        ,a.Mon_037 as fine_amount
        ,a.Date_090 as end_date
        ,(case when a.Date_090 is null then 'Yes' else 'No' end) as add_fee --(case when dtPart1End is null then 'Yes' else 'No' end) as add_fee
    from #t a
    WHERE
        1=1
        and (
            coalesce(a.Date_086,a.Date_080,a.Date_090) is not NULL
         or coalesce(a.Text_019,convert(varchar(20),a.Mon_037),'0') <> '0'
        )
        

    union

    select
        a.permitnum
        ,a.tt_record

        ,a.Date_087 as start_date --a.Date_080 as [dtPart1]
        ,'Part II' as order_part --a.Text_019 as [strOrderPart2]
        ,a.Mon_042 as subtotal_value
        ,a.Text_024 as [order]
        ,a.Date_081 as on_or_before_date
        ,a.Mon_038 as fine_amount
        ,a.Date_091 as end_date
        ,(case when a.Date_091 is null then 'Yes' else 'No' end) as add_fee --(case when dtPart1End is null then 'Yes' else 'No' end) as add_fee
    from #t a
    WHERE
        1=1
        and (
            coalesce(a.Date_087,a.Date_081,a.Date_091) is not NULL
         or coalesce(a.Text_024,convert(varchar(20),a.Mon_038),'0') <> '0'
        )

    union

    select
        a.permitnum
        ,a.tt_record

        ,a.Date_088 as start_date --a.Date_080 as [dtPart1]
        ,'Part III' as order_part --a.Text_019 as [strOrderPart3]
        ,a.Mon_043 as subtotal_value
        ,a.Text_025 as [order]
        ,a.Date_082 as on_or_before_date
        ,a.Mon_039 as fine_amount
        ,a.Date_092 as end_date
        ,(case when a.Date_092 is null then 'Yes' else 'No' end) as add_fee --(case when dtPart1End is null then 'Yes' else 'No' end) as add_fee
    from #t a
    WHERE
        1=1
        and (
            coalesce(a.Date_088,a.Date_082,a.Date_092) is not NULL
         or coalesce(a.Text_025,convert(varchar(20),a.Mon_039),'0') <> '0'
        )
        
    union

    select
        a.permitnum
        ,a.tt_record

        ,a.Date_089 as start_date --a.Date_080 as [dtPart1]
        ,'Part IV' as order_part --a.Text_019 as [strOrderPart4]
        ,a.Mon_044 as subtotal_value
        ,a.Text_028 as [order]
        ,a.Date_083 as on_or_before_date
        ,a.Mon_040 as fine_amount
        ,a.Date_093 as end_date
        ,(case when a.Date_093 is null then 'Yes' else 'No' end) as add_fee --(case when dtPart1End is null then 'Yes' else 'No' end) as add_fee
    from #t a
    WHERE
        1=1
        and (
            coalesce(a.Date_089,a.Date_083,a.Date_093) is not NULL
         or coalesce(a.Text_028,convert(varchar(20),a.Mon_040),'0') <> '0'
        )

)
select
	*
	,ROW_NUMBER() OVER(PARTITION BY pnum.permitnum order by pnum.permitnum) AS row_num
into cl_wrviol_feeCalculation
from g pnum
where
	1=1
;
    --ensure date is actually a date
--update a set on_or_before_date = convert(varchar(10),on_or_before_date,20) from cl_wrviol_feeCalculation a ;
go
alter table cl_wrviol_feeCalculation alter column on_or_before_date varchar(10)
alter table cl_wrviol_feeCalculation alter column start_date varchar(10)
alter table cl_wrviol_feeCalculation alter column end_date varchar(10)
;
go
;update cl_wrviol_feeCalculation set on_or_before_date= FORMAT(convert(date,on_or_before_date), 'MM/dd/yyyy')
;update cl_wrviol_feeCalculation set start_date= FORMAT(convert(date,start_date), 'MM/dd/yyyy')
;update cl_wrviol_feeCalculation set end_date= FORMAT(convert(date,end_date), 'MM/dd/yyyy')
;
go

--addendum move the orders to CBS record if CBS record exists
update a set 
    permitnum = b.permitnum
from cl_wrviol_feeCalculation a
join aatable_permit_history b on b.permitnum = a.permitnum + '-CBS'

;IF OBJECT_ID('accelaConv7.dbo.cl_wrviol_feeCalculation_cbs', 'U') IS NOT NULL drop table cl_wrviol_feeCalculation_cbs
GO
select 
*
into cl_wrviol_feeCalculation_cbs
from cl_wrviol_feeCalculation a
where 
    1=1
    and a.permitnum like '%-CBS'
;
update a set 
    tt_record = 'Citizen Board Support Water Enforcement'
from cl_wrviol_feeCalculation_cbs a
;

    --delete from cl_wrviol_feeCalculation those that are cbs. These get mapped to custom lists as ENF_CBS_WA. 
delete a 
from cl_wrviol_feeCalculation a
join cl_wrviol_feeCalculation_cbs b on b.permitnum = a.permitnum
WHERE   
    1=1
;
--    --force into PERMIT_ATTACHEDTABLE. It isnt going because the accela data mapper is grabbing these as ENF_WATER, then tries to join, and misses them into aaxPermit_attachedTable for some reason. I expect the r1_chckbox_code to be 'ENF_CBS_WA'. But it isn't in the mapper. Why?
----truncate table PERMIT_ATTACHEDTABLE
--;insert into PERMIT_ATTACHEDTABLE select A.permitnum,'ENF_CBS_WA','FEECALCULATION','Order Part', a.ROW_NUM,CONVERT(VARCHAR(4000),a."order_part") from "cl_wrviol_feeCalculation_cbs" a INNER JOIN AAXCASE x ON a.PERMITNUM=x.PERMITNUM INNER JOIN TT_R3APPTYP B ON b.R1_PER_GROUP=X.B1_PER_GROUP AND b.R1_PER_TYPE=X.B1_PER_TYPE AND b.R1_PER_SUB_TYPE=X.B1_per_sub_type AND b.r1_per_CATEGORY=X.B1_PER_CATEGORY where b.r1_chckbox_code='ENF_CBS_WA' and a."order_part" is not null
--;insert into PERMIT_ATTACHEDTABLE select A.permitnum,'ENF_CBS_WA','FEECALCULATION','On or Before Date', a.ROW_NUM,CONVERT(VARCHAR(4000),a."on_or_before_date") from "cl_wrviol_feeCalculation_cbs" a INNER JOIN AAXCASE x ON a.PERMITNUM=x.PERMITNUM INNER JOIN TT_R3APPTYP B ON b.R1_PER_GROUP=X.B1_PER_GROUP AND b.R1_PER_TYPE=X.B1_PER_TYPE AND b.R1_PER_SUB_TYPE=X.B1_per_sub_type AND b.r1_per_CATEGORY=X.B1_PER_CATEGORY where b.r1_chckbox_code='ENF_CBS_WA' and a."on_or_before_date" is not null
--;insert into PERMIT_ATTACHEDTABLE select A.permitnum,'ENF_CBS_WA','FEECALCULATION','Fine Amount', a.ROW_NUM,CONVERT(VARCHAR(4000),a."fine_amount") from "cl_wrviol_feeCalculation_cbs" a INNER JOIN AAXCASE x ON a.PERMITNUM=x.PERMITNUM INNER JOIN TT_R3APPTYP B ON b.R1_PER_GROUP=X.B1_PER_GROUP AND b.R1_PER_TYPE=X.B1_PER_TYPE AND b.R1_PER_SUB_TYPE=X.B1_per_sub_type AND b.r1_per_CATEGORY=X.B1_PER_CATEGORY where b.r1_chckbox_code='ENF_CBS_WA' and a."fine_amount" is not null
--;insert into PERMIT_ATTACHEDTABLE select A.permitnum,'ENF_CBS_WA','FEECALCULATION','Order', a.ROW_NUM,CONVERT(VARCHAR(4000),a."order") from "cl_wrviol_feeCalculation_cbs" a INNER JOIN AAXCASE x ON a.PERMITNUM=x.PERMITNUM INNER JOIN TT_R3APPTYP B ON b.R1_PER_GROUP=X.B1_PER_GROUP AND b.R1_PER_TYPE=X.B1_PER_TYPE AND b.R1_PER_SUB_TYPE=X.B1_per_sub_type AND b.r1_per_CATEGORY=X.B1_PER_CATEGORY where b.r1_chckbox_code='ENF_CBS_WA' and a."order" is not null
--;insert into PERMIT_ATTACHEDTABLE select A.permitnum,'ENF_CBS_WA','FEECALCULATION','Start Date', a.ROW_NUM,CONVERT(VARCHAR(4000),a."start_date") from "cl_wrviol_feeCalculation_cbs" a INNER JOIN AAXCASE x ON a.PERMITNUM=x.PERMITNUM INNER JOIN TT_R3APPTYP B ON b.R1_PER_GROUP=X.B1_PER_GROUP AND b.R1_PER_TYPE=X.B1_PER_TYPE AND b.R1_PER_SUB_TYPE=X.B1_per_sub_type AND b.r1_per_CATEGORY=X.B1_PER_CATEGORY where b.r1_chckbox_code='ENF_CBS_WA' and a."start_date" is not null
--;insert into PERMIT_ATTACHEDTABLE select A.permitnum,'ENF_CBS_WA','FEECALCULATION','End Date', a.ROW_NUM,CONVERT(VARCHAR(4000),a."end_date") from "cl_wrviol_feeCalculation_cbs" a INNER JOIN AAXCASE x ON a.PERMITNUM=x.PERMITNUM INNER JOIN TT_R3APPTYP B ON b.R1_PER_GROUP=X.B1_PER_GROUP AND b.R1_PER_TYPE=X.B1_PER_TYPE AND b.R1_PER_SUB_TYPE=X.B1_per_sub_type AND b.r1_per_CATEGORY=X.B1_PER_CATEGORY where b.r1_chckbox_code='ENF_CBS_WA' and a."end_date" is not null
--;insert into PERMIT_ATTACHEDTABLE select A.permitnum,'ENF_CBS_WA','FEECALCULATION','Subtotal Value', a.ROW_NUM,CONVERT(VARCHAR(4000),a."subtotal_value") from "cl_wrviol_feeCalculation_cbs" a INNER JOIN AAXCASE x ON a.PERMITNUM=x.PERMITNUM INNER JOIN TT_R3APPTYP B ON b.R1_PER_GROUP=X.B1_PER_GROUP AND b.R1_PER_TYPE=X.B1_PER_TYPE AND b.R1_PER_SUB_TYPE=X.B1_per_sub_type AND b.r1_per_CATEGORY=X.B1_PER_CATEGORY where b.r1_chckbox_code='ENF_CBS_WA' and a."subtotal_value" is not null
--;insert into PERMIT_ATTACHEDTABLE select A.permitnum,'ENF_CBS_WA','FEECALCULATION','Add Fee', a.ROW_NUM,CONVERT(VARCHAR(4000),a."add_fee") from "cl_wrviol_feeCalculation_cbs" a INNER JOIN AAXCASE x ON a.PERMITNUM=x.PERMITNUM INNER JOIN TT_R3APPTYP B ON b.R1_PER_GROUP=X.B1_PER_GROUP AND b.R1_PER_TYPE=X.B1_PER_TYPE AND b.R1_PER_SUB_TYPE=X.B1_per_sub_type AND b.r1_per_CATEGORY=X.B1_PER_CATEGORY where b.r1_chckbox_code='ENF_CBS_WA' and a."add_fee" is not null
--;
--go


--insert into cl_wrviol_feeCalculation
--select
--    b.permitnum
--    ,a.tt_record,a.start_date,a.order_part,a.subtotal_value,a.order,a.on_or_before_date,a.fine_amount,a.end_date,a.add_fee,a.row_num
--from cl_wrviol_feeCalculation a
--join aatable_permit_history b on b.permitnum = a.permitnum + '-CBS'

/*
;IF OBJECT_ID('accelaConv7.dbo.cl_wrviol_feeCalculation_cbs', 'U') IS NOT NULL drop table cl_wrviol_feeCalculation_cbs
go
select 
    a.*
into cl_wrviol_feeCalculation_cbs
from cl_wrviol_feeCalculation a
join aatable_permit_history b on b.permitnum = a.permitnum + '-CBS'
where 
    1=1
;
delete a
from cl_wrviol_feeCalculation a
join aatable_permit_history b on b.permitnum = a.permitnum + '-CBS'
;

update a set 
    permitnum = b.permitnum
from cl_wrviol_feeCalculation_cbs a
join aatable_permit_history b on b.permitnum = a.permitnum + '-CBS'
;
*/