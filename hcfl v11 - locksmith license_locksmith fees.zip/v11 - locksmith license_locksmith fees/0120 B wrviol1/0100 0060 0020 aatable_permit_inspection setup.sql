/*
setup to get any orphaned rows (rows without some kind of site visit preceding them)
    setup parents
    setup is_initial_site_visit
    setup g
    which number_key values have orphaned inspection rows?
    setup orphan parents
NOW REDO ABOVE LOGIC AND USE REMAINING LOGIC
    (determine child rows per inspection, then assert inspection type and inspection result based on those children)
    create parents
    create is_initial_site_visit
    create g
    create h
    create violations
    VERIFY the above
ensure no duplicates
*/


--setup to get any orphaned rows (rows without some kind of site visit preceding them)
/* SET UP:
I found 511 unique_key values in apd_insp that dont have a preceding site visit. 
So I run the logic, identify those without the preceding SV et al, then add them to my apd_insp.
*/


;delete from jms_apd_insp_filteredToPop__wrviol1 where unique_key like 'ORPH-%'

--determine child rows per inspection, then assert inspection type and inspection result based on those children
;IF OBJECT_ID('tempdb.dbo.#parents', 'U') IS NOT NULL drop table #parents
;IF OBJECT_ID('tempdb.dbo.#is_initial_site_visit', 'U') IS NOT NULL drop table #is_initial_site_visit
;IF OBJECT_ID('tempdb.dbo.#g', 'U') IS NOT NULL drop table #g
;IF OBJECT_ID('tempdb.dbo.#orphaned', 'U') IS NOT NULL drop table #orphaned
;IF OBJECT_ID('tempdb.dbo.#h', 'U') IS NOT NULL drop table #h
;IF OBJECT_ID('tempdb.dbo.#violations', 'U') IS NOT NULL drop table #violations
;
go

--setup parents
--;with parents
    --assumes inspections are site visits, and results are implied by the subsequent rows prior to the following site visit.
	select
		number_key
		,unique_key
		,date_ent
		,the_Date
		,action_ent
    into #parents
	from jms_apd_insp_filteredToPop__wrviol1
	where action_ent in ('SV','SSV','QCSV','LSV')
	--and number_key = 'CE18015425'
;
--setup is_initial_site_visit
--), is_initial_site_visit as (
    --"initial site visiit" is an accela inspection type
	select
		b.UNIQUE_KEY
        ,b.action_ent
    into #is_initial_site_visit
	from jms_apd_base_filtered__wrviol1 a
	outer apply (select top 1 * from jms_apd_insp_filteredToPop__wrviol1 where NUMBER_KEY = a.NUMBER_KEY and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent,the_date) b
;
--setup g
--),g as (
    select
        a.number_key
        ,a.item_id
        ,a.unique_key
        ,a.action_ent
        ,action_ent.DESCRIPTION action_ent_desc
        ,case when is_initial_site_visit.UNIQUE_KEY is not null then 1 else 0 end as is_initial_site_visit
        ,'xxxx' [ ]
        ,coalesce(b.unique_key,is_initial_site_visit.unique_key) parent_unique_key
        ,b.action_ent parent_action_ent
        ,(case 
            when is_initial_site_visit.UNIQUE_KEY is not null then 'Initial Site Visit'
            when a.ACTION_ENT in ('QCSV','LSV') then 'Quality Control Inspection'
            when  a.any_comments like '%re%inspect%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%re%check%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%annual%insp%'    then 'Annual Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%post%hearing%'    then 'Post-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%pre%hearing%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%hear%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%follow%up%'    then 'Follow-up Inspection' --I don't know about pre vs post hearing
            else 'Inspection'
            end		
        ) as inspection_type
        ,(case 
            --when a.ACTION_ENT in ('SV','SSV','QCSV','LSV') then null
            when a.action_ent in ('CERT','DFLT') then 'Issue Citation' --CERT = issue citation
            when a.action_ent in ('CRTY') then 'Issue Warning' --CRTY = warning (courtesy) 
            when a.action_ent in ('CNCL') then 'Cancel'
            --when a.action_ent in ('STLS','STLO') then 'Extension'
            --when a.action_ent in ('ADMN','CREV','NREV') then 'No Violation' --Move this to time accounting? Associate with inspection? I put ADMN here cuz it is not a violation or similar
            --when a.action_ent in ('AP','CMP','COMP') then 'Approved' --maybe "complied"
            --when a.action_ent in ('AFFN','DFLT','ACOM') then 'Disapproved' -- ACOM seemed to all be problems
		
			when a.any_comments like '%created in err%' then 'Cancel' --CNCL
            when a.any_comments like '%CLNO%' then 'No Violation' --yes
            when a.any_comments like '%no viol%' then 'No Violation' --yes 
            when a.any_comments like '%courtesy notice%' then 'Issue Warning'

			--when a.any_comments like '%warn%' then 'Issue Warning'
            --when a.any_comments like '%POST%PROP%' then 'Issue Warning' --post would mean we are getting it ready for a hearing
            --when a.any_comments like '%DOOR%HANG%' then 'Issue Warning' --doesnt necessarily mean a warning is issued; it means we're gonna come back
            --when a.any_comments like '%hand%deliv%' then 'Issue Citation' --could definitely be issue cit
            --when a.any_comments like '%watering days%' then 'Issue Citation' --could be citation or warning
            --when a.any_comments like '%post%' then 'Issue Citation' --sure ok
            --when a.any_comments like '%property was found%' then 'Issue Citation' --not necessarily. Could be a warning.
            --when a.any_comments like '%watering %' then 'Issue Citation' --not necessarily. Could be a warning.
            --when a.any_comments like '%irrigation%restr%' then 'Issue Citation' --not necessarily. Could be a warning
            else 'No Violation'
            end
        ) as inspection_result
        
        ,'xxxx' [2]
        ,a.date_ent
        ,a.the_date
        ,'xxxx'[3]
        ,a.any_comments
    into #g
    from jms_apd_insp_filteredToPop__wrviol1 a
    outer apply (select top 1 * from #parents where number_key = a.number_key and the_date <= a.the_date and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent desc,the_date desc) b
    left join jms_actionEnt_passFail__wrviol1 action_ent on action_ent.action_ent = a.action_ent
    left join #is_initial_site_visit is_initial_site_visit on is_initial_site_visit.UNIQUE_KEY = a.UNIQUE_KEY
    where
        1=1
        --and a.action_ent not in ('SV','SSV','QCSV','LSV')
        --and a.number_key = 
        --	--'CE03003081'
        --	--'CE22014264'
        --	'CE22014971'
    --order by --a.date_ent,a.the_Date,case when a.action_ent in ('SV','SSV','QCSV','LSV') then 1 else 2 end, l.THE_TEXT
    --	a.UNIQUE_KEY
;

----which number_key values have orphaned inspection rows?
--select 
--	a.NUMBER_KEY
--	,a.parent_unique_key
--	,count(b.number_key) ct
--    
--into #orphaned
--from #g a
--left join hcfl_src..apd_itms b 
--	on b.RECORD_TYPE = 'CD'
--	and b.NUMBER_KEY = a.NUMBER_KEY
--	and year(b.THE_DATE) = year(a.the_date) and month(b.THE_DATE) = month(a.the_date) and day(b.THE_DATE) = day(a.THE_DATE)
--	and b.ITEM_ID = a.ITEM_ID
--where
--	b.NUMBER_KEY is not null
--    and a.parent_unique_key is null
--group by a.numbeR_key,a.parent_unique_key
--;
select 
	a.NUMBER_KEY
	,a.UNIQUE_KEY
    
into #orphaned
from #g a
where
	a.parent_unique_key is null
;

--setup orphan parents
--;delete from jms_apd_insp_filteredToPop__wrviol1 where unique_key like 'ORPH-%' --moved up top. Otherwise, can on alternating conversions yield nothing, while deleting the relevant records.
;
insert into jms_apd_insp_filteredToPop__wrviol1
SELECT distinct
     f.NUMBER_KEY
    ,'A' DATA_LEVEL
    ,'IN' RECORD_TYPE
    ,'14320' ITEM_ID
    ,'ORPH-' + convert(varchar(max),row_number() over(order by f.number_key) ) unique_key 
    ,null INSPECTOR
    ,null USER_ID
    ,'KE' ENTRY_METHOD
    ,null REMOTE_USER_ID
    ,min(a.date_ent) DATE_ENT
    ,'SV' ACTION_ENT
    ,'N' APPROVAL
    ,min(a.THE_DATE) the_date
    ,null BEG_TIME
    ,null END_TIME
    ,null TOTAL_TIME
    ,0 VIOLATIONS
    ,null MILAGE
    ,convert(varchar(max),a.ANY_COMMENTS) any_comments
    ,'14320' ITEM_NO
    ,null REQUEST_ID
    ,null BEG_MILEAGE
    ,null END_MILEAGE
    ,null VEHICLE_ID
    ,null SUBMIT_TIME
    ,null SUBMIT_DATE
from #orphaned f --on f.number_key = a.number_key
outer apply (select top 1 * from jms_apd_insp_filteredToPop__wrviol1 where number_key = f.number_key order by the_date,date_ent) a
WHERE
    1=1
group by f.NUMBER_KEY,convert(varchar(max),a.ANY_COMMENTS)
;

-----------------------
--NOW REDO ABOVE LOGIC AND USE REMAINING LOGIC
-----------------------

--determine child rows per inspection, then assert inspection type and inspection result based on those children
;IF OBJECT_ID('tempdb.dbo.#parents', 'U') IS NOT NULL drop table #parents
;IF OBJECT_ID('tempdb.dbo.#is_initial_site_visit', 'U') IS NOT NULL drop table #is_initial_site_visit
;IF OBJECT_ID('tempdb.dbo.#g', 'U') IS NOT NULL drop table #g
;IF OBJECT_ID('tempdb.dbo.#orphaned', 'U') IS NOT NULL drop table #orphaned
;IF OBJECT_ID('tempdb.dbo.#h', 'U') IS NOT NULL drop table #h
;IF OBJECT_ID('tempdb.dbo.#violations', 'U') IS NOT NULL drop table #violations
;IF OBJECT_ID('tempdb.dbo.#req_opt', 'U') IS NOT NULL drop table #req_opt
;
go

--create parents
--;with parents
    --assumes inspections are site visits, and results are implied by the subsequent rows prior to the following site visit.
	select
		number_key
		,unique_key
		,date_ent
		,the_Date
		,action_ent
    into #parents
	from jms_apd_insp_filteredToPop__wrviol1
	where action_ent in ('SV','SSV','QCSV','LSV')
	--and number_key = 'CE18015425'
;
--create is_initial_site_visit
--), is_initial_site_visit as (
    --"initial site visiit" is an accela inspection type
	select
		b.UNIQUE_KEY
        ,b.action_ent
    into #is_initial_site_visit
	from jms_apd_base_filtered__wrviol1 a
	outer apply (select top 1 * from jms_apd_insp_filteredToPop__wrviol1 where NUMBER_KEY = a.NUMBER_KEY and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent,the_date) b
;
--create g
--),g as (
    select
        a.number_key
        ,a.item_id
        ,a.unique_key
        ,a.action_ent
        ,action_ent.DESCRIPTION action_ent_desc
        ,case when is_initial_site_visit.UNIQUE_KEY is not null then 1 else 0 end as is_initial_site_visit
        ,'xxxx' [ ]
        ,coalesce(b.unique_key,is_initial_site_visit.unique_key) parent_unique_key
        ,b.action_ent parent_action_ent
        ,(case 
            when is_initial_site_visit.UNIQUE_KEY is not null then 'Initial Site Visit'
            when a.ACTION_ENT in ('QCSV','LSV') then 'Quality Control Inspection'
            when  a.any_comments like '%re%inspect%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%re%check%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%annual%insp%'    then 'Annual Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%post%hearing%'    then 'Post-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%pre%hearing%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%hear%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%follow%up%'    then 'Follow-up Inspection' --I don't know about pre vs post hearing
            else 'Inspection'
            end		
        ) as inspection_type
        ,(case 
            --when a.ACTION_ENT in ('SV','SSV','QCSV','LSV') then null
            when a.action_ent in ('CERT','DFLT') then 'Issue Citation' --CERT = issue citation
            when a.action_ent in ('CRTY') then 'Issue Warning' --CRTY = warning (courtesy) 
            when a.action_ent in ('CNCL') then 'Cancel'
            --when a.action_ent in ('STLS','STLO') then 'Extension'
            --when a.action_ent in ('ADMN','CREV','NREV') then 'No Violation' --Move this to time accounting? Associate with inspection? I put ADMN here cuz it is not a violation or similar
            --when a.action_ent in ('AP','CMP','COMP') then 'Approved' --maybe "complied"
            --when a.action_ent in ('AFFN','DFLT','ACOM') then 'Disapproved' -- ACOM seemed to all be problems
		
			when a.any_comments like '%created in err%' then 'Cancel' --CNCL
            when a.any_comments like '%CLNO%' then 'No Violation' --yes
            when a.any_comments like '%no viol%' then 'No Violation' --yes 
            when a.any_comments like '%courtesy notice%' then 'Issue Warning'

			--when a.any_comments like '%warn%' then 'Issue Warning'
            --when a.any_comments like '%POST%PROP%' then 'Issue Warning' --post would mean we are getting it ready for a hearing
            --when a.any_comments like '%DOOR%HANG%' then 'Issue Warning' --doesnt necessarily mean a warning is issued; it means we're gonna come back
            --when a.any_comments like '%hand%deliv%' then 'Issue Citation' --could definitely be issue cit
            --when a.any_comments like '%watering days%' then 'Issue Citation' --could be citation or warning
            --when a.any_comments like '%post%' then 'Issue Citation' --sure ok
            --when a.any_comments like '%property was found%' then 'Issue Citation' --not necessarily. Could be a warning.
            --when a.any_comments like '%watering %' then 'Issue Citation' --not necessarily. Could be a warning.
            --when a.any_comments like '%irrigation%restr%' then 'Issue Citation' --not necessarily. Could be a warning
            else 'No Violation'
            end
        ) as inspection_result
        ,'xxxx' [2]
        ,a.date_ent
        ,a.the_date
        ,'xxxx'[3]
        ,a.any_comments
    into #g
    from jms_apd_insp_filteredToPop__wrviol1 a
    outer apply (select top 1 * from #parents where number_key = a.number_key and the_date <= a.the_date and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent desc,the_date desc) b
    left join jms_actionEnt_passFail__wrviol1 action_ent on action_ent.action_ent = a.action_ent
    left join #is_initial_site_visit is_initial_site_visit on is_initial_site_visit.UNIQUE_KEY = a.UNIQUE_KEY
    where
        1=1
        --and a.action_ent not in ('SV','SSV','QCSV','LSV')
        --and a.number_key = 
        --	--'CE03003081'
        --	--'CE22014264'
        --	'CE22014971'
    --order by --a.date_ent,a.the_Date,case when a.action_ent in ('SV','SSV','QCSV','LSV') then 1 else 2 end, l.THE_TEXT
    --	a.UNIQUE_KEY
;



















--create h
--), h as (
    select distinct
         a1.NUMBER_KEY
        ,a1.UNIQUE_KEY
        ,a1.action_ent
        ,a1.inspection_type
        ,coalesce(b.inspection_result,a1.inspection_result,'Not Set') inspection_result
        ,trim('^|' from stuff((
            select 
                '^|^' + cast(
                    trim(replace(replace(replace(replace(   isnull(a2.any_comments,'')   ,'"',''''''),'''',''),char(13),''),char(10),'®')) 
                    as varchar(max)
                )
            from #g a2 with(nolock)
            where 
                a2.parent_unique_key = a1.parent_unique_key
            group by a2.any_comments
            order by a2.any_comments
            FOR XML PATH('')
         ), 1, 1, '')) as any_comments
    into #h
    from #g a1
    outer apply (
        select top 1 *
        from #g
        where
            parent_unique_key = a1.UNIQUE_KEY
            and inspection_result is not null
        order by case inspection_result when 'Cancel' then 1 when 'Issue Citation' then 2 when 'Issue Warning' then 3 when 'No Violation' then 4 else 5 end
    ) b
    where
        1=1
        and a1.ACTION_ENT in ('SV','SSV','QCSV','LSV')
        --and a1.number_key = 'CE17015692'
    ;

    --order by a.UNIQUE_KEY
--)
;
--create violations
--;with cte_violations as (
;with lesser_dates as (
	select 
		 b.number_key
		,b.sequence
		,b.item_id
		,b.the_date
		,b2.THE_DATE lesser_date
	from hcfl_src..apd_itms b
	outer apply (select top 1 * from hcfl_src..APD_ITMS where record_type = 'cd' and NUMBER_KEY = b.NUMBER_KEY and THE_DATE < b.THE_DATE) b2
	where
		1=1
		and b.number_key in ('','WR2001154','WR2001254','WR2001312','WR2001388','WR2001391','WR2100003','WR2201954','WR2302581','WR2400295')
		and b2.the_Date is not null
)
    select distinct
        a.NUMBER_KEY
        ,a.parent_unique_key
        ,count(distinct b.item_id) ct --,count(b.number_key) ct
    into #violations
    from #g a
    left join hcfl_src..apd_itms b on b.RECORD_TYPE = 'CD' and b.NUMBER_KEY = a.NUMBER_KEY
	left join lesser_dates b2 on b2.number_key = b.number_key and b2.sequence = b.sequence and b2.item_id = b.item_id and b2.the_date = b.the_Date	
    where
        1=1
		and b.NUMBER_KEY is not null
		--and b.NUMBER_KEY = 'WR2001391 '
		and (
			(year(b.THE_DATE) = year(a.date_ent) and month(b.THE_DATE) = month(a.date_ent) and day(b.THE_DATE) = day(a.date_ent) )
			or (year(b2.lesser_date) = year(a.date_ent) and month(b2.lesser_date) = month(a.date_ent) and day(b2.lesser_date) = day(a.date_ent) )
		)
    group by a.number_key,a.parent_unique_key
;

delete d
from #violations d 
where
	1=1
	and (
		(number_key = 'WR2001138' and parent_unique_key = 'A008504612')
		or (number_key = 'WR2300607 ' and parent_unique_key = 'A009041780')
	)
;
insert into #violations 
select *
from (VALUES ('WR2100003','A008729399',1)) t(NUMBER_KEY,parent_unique_key,ct)
;
    --VERIFY the above
        --shoehorn some things
    update v set 
		ct = a.apd_itms_violations_ct
    from (
        select
            a.NUMBER_KEY
            ,a.violations_ct as apd_itms_violations_ct
            ,sum(b.ct) as my_violations_ct
        from (
            select
                a.number_key
                ,count(*) violations_ct
            from hcfl_src..apd_itms a
            join jms_apd_base_filtered__wrviol1 f on f.NUMBER_KEY = a.NUMBER_KEY
            where
                1=1
                and a.RECORD_TYPE = 'CD'
            group by a.NUMBER_KEY
            having count(*) > 0
        ) a
        left join #violations b on b.numbeR_key = a.NUMBER_KEY
        where
            1=1
            --and a.violations_ct <> b.ct
            --and a.NUMBER_KEY = 'CE23007349'
        group by  a.NUMBER_KEY
            ,a.violations_ct-- as apd_itms_violations_ct
		having a.violations_ct <> sum(b.ct)
    ) a
	left join  #violations v on v.NUMBER_KEY = a.NUMBER_KEY and v.ct = a.my_violations_ct
    ;

--if 1 = (
--    select distinct 1
--    from (
--        select
--            a.NUMBER_KEY
--            ,a.violations_ct as apd_itms_violations_ct
--            ,sum(b.ct) as my_violations_ct
--            
--        from (
--            select
--                a.number_key
--                ,count(*) violations_ct
--            from hcfl_src..apd_itms a
--            join jms_apd_base_filtered__wrviol1 f on f.NUMBER_KEY = a.NUMBER_KEY
--            where
--                1=1
--                and a.RECORD_TYPE = 'CD'
--            group by a.NUMBER_KEY
--            having count(*) > 0
--        ) a
--        left join #violations b on b.numbeR_key = a.NUMBER_KEY
--        where
--            1=1
--            --and a.violations_ct <> b.ct
--        group by a.NUMBER_KEY
--            ,a.violations_ct -- as apd_itms_violations_ct
--        having a.violations_ct <> sum(b.ct)
--    ) z
--) RAISERROR ('violations counts mismatch', 16, 1)
--;



--rem all in h are the site visits to which subsequent row statuses are applied. Similarly: this is to find the req_opt of the subsequent rows for a given site visit.
;with j as (
	select distinct
        a.NUMBER_KEY
        ,a.parent_unique_key
        ,b.REQ_OPT
    --into #violations
    from #g a
    left join hcfl_src..apd_itms b
        on
			b.RECORD_TYPE = 'CD'
			and b.NUMBER_KEY = a.NUMBER_KEY
			and year(b.THE_DATE) = year(a.the_date) and month(b.THE_DATE) = month(a.the_date) and day(b.THE_DATE) = day(a.THE_DATE)
			and b.ITEM_ID = a.ITEM_ID
		
    where
        1=1
		and b.req_opt is not null
        --and c.NUMBER_KEY = 'CE22010196'
    --group by a.number_key,a.parent_unique_key
), doubles as (
	select parent_unique_key, count(distinct req_opt) ct from j group by parent_unique_key  having count(distinct req_opt) > 1
)
select distinct
	a.number_key
	,a.parent_unique_key
	,case when f.parent_unique_key is not null then 'R' else a.REQ_OPT end req_opt
into #req_opt
from j a
left join doubles f on f.parent_unique_key = a.parent_unique_key
;


;IF OBJECT_ID('accelaconv7.dbo.jms_inspections_compliantOrNot__wrviol1', 'U') IS NOT NULL drop table accelaconv7.dbo.jms_inspections_compliantOrNot__wrviol1
;
go
select distinct 
    a1.number_key
	,a1.UNIQUE_KEY
	,a1.ACTION_ENT
	,a1.inspection_type
	,a1.inspection_result
    ,r.req_opt
	,isnull(v.ct,0) violations_count
	,trim('^|' from stuff((
        select 
            '^|^' + cast(
				trim(replace(replace(replace(replace(   isnull(a2.any_comments,'')   ,'"',''''''),'''',''),char(13),''),char(10),'®')) 
				as varchar(max)
			)
        from #h a2 with(nolock)
        where 
            a2.UNIQUE_key = a1.UNIQUE_key
        group by a2.any_comments
        order by a2.any_comments
        FOR XML PATH('')
     ), 1, 1, '')) as any_comments
into jms_inspections_compliantOrNot__wrviol1
from #h a1 WITH (NOLOCK)
left join #violations v on v.NUMBER_KEY = a1.NUMBER_KEY and v.parent_unique_key = a1.UNIQUE_KEY
left join #req_opt r on r.parent_unique_key = a1.unique_key --a1 is site visits, therefore is parent unique key values.
where
    1=1
;


--ensure no duplicates
update a set
	inspection_type = (case 
            when inspection_type in ('Initial Site Visit','Quality Control Inspection') then inspection_type
            when a.any_comments like '%re%inspect%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when a.any_comments like '%re%check%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when a.any_comments like '%annual%insp%'    then 'Annual Inspection' --I don't know about pre vs post hearing
            when a.any_comments like '%post%hearing%'    then 'Post-Hearing Inspection' --I don't know about pre vs post hearing
            when a.any_comments like '%pre%hearing%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when a.any_comments like '%hear%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when a.any_comments like '%follow%up%'    then 'Follow-up Inspection' --I don't know about pre vs post hearing
            else 'Inspection'
            end		
        )
from jms_inspections_compliantOrNot__wrviol1 a
where
	1=1
	--and a.UNIQUE_KEY = 'a008872077'
;

;WITH CTE AS (SELECT *,ROW_NUMBER() OVER (PARTITION BY number_key,unique_key,inspection_type,any_comments ORDER BY number_key) AS RN FROM jms_inspections_compliantOrNot__wrviol1) DELETE FROM CTE WHERE RN<>1 
;

