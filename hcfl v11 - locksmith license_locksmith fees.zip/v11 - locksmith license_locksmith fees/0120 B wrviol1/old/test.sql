declare @number_key varchar(50) = 
--'WR2201925' --no calc_fee, no addl_fee; but has curPart1 fee.
--'WR2300005' --1 calc fee, no addl_fee
--'WR2300938  '
--'WR2202191       '
'WR1600012 '

;select top 10 * from FEE_DETL fd where number_key = @number_key
;select top 10 * from fee_adl where NUMBER_KEY = @number_key
;select top 10 * from FEE_TRN where number_key = @number_key
;
select 
	 a.number_key,a.CALC_FEES,a.ADDL_FEES,a.TOT_FEE,a.TOT_PAY,a.BALANCE
	,'||||' [ ] ,m.Mon_008 as fee_fine_st_              
    ,n.Date_080 as dtPart1
    ,m.Mon_037 as curPart1 
    ,n.Date_086 as dtPart1Start 
    ,n.Date_090 as dtPart1End  
    ,m.Mon_041 as curPart1Sub   
    ,(datediff(day,n.Date_086 , coalesce(n.Date_090,getdate()) )  ) * m.mon_037 curPart1Sub_calc
	,m.Mon_046 as curAddCosts 
    ,m.Mon_048 as curReduction 
    ,m.Mon_050 as curPenaltyFine
	,'xxxx' [x] ,t.Text_019 as strOrderPart1     
from hcfl_src.dbo.apd_base a
join hcfl_src.dbo.apd_mon0 m on m.number_key = a.number_key
left join hcfl_src.dbo.apd_num0 n on n.NUMBER_KEY = a.NUMBER_KEY
left join hcfl_src.dbo.apd_txt0 t on t.number_key = a.number_key
where 
	1=1
	and a.number_key = @number_key
;

--------




;if object_id('tempdb.dbo.#g') is not null drop table #g
;
select
	'' [ ]
	,case when adl.NUMBER_KEY is not null then 1 else 0 end as is_addl_fee
	,'fee_detl' [fee_detl]
	,a.NUMBER_KEY
	,fd.TRANS_ID
	,fd.TRANS_TYPE
	,fd.TRANS_SEQ
	,fd.fee_item_no
	,fd.ACCOUNT_CODE
	,isnull(fd.amount,0) amount
	--,fd.*
	,'fee_adl' [fee_adl]
	--,adl.fee_item_no
	,adl.USER_ID
	,convert(varchar(max),adl.NOTATION) notation
	--,adl.*
	,'fee_item_no' [fee_item_no break]
	,tf.description
	--,tf.ACCOUNT_CODE [account_code 2]
	--,tf.*
	,a.tot_fee
into #g
from apd_base a 
left join FEE_DETL fd on fd.NUMBER_KEY = a.NUMBER_KEY
full join FEE_ADL adl 
	on adl.NUMBER_KEY = a.number_key --fd.NUMBER_KEY 
	and adl.FEE_ITEM_NO = fd.FEE_ITEM_NO
	and adl.TRANS_SEQ = fd.DETL_SEQ
left join TAB_FEE tf on tf.FEE_ITEM_NO = fd.FEE_ITEM_NO
where
	1=1
	and a.COMP_TYPE = 'WRVIOL' and VERSION=1
	--and fd.NUMBER_KEY = @number_key
	--and a.NUMBER_KEY = 'WR2201925' --'WR2202191       '
--order by a.NUMBER_KEY
;
;if object_id('tempdb.dbo.#default_totals') is not null drop table #default_totals
;
--), default_totals as (
	select
		a.number_key
		,a.TOT_FEE
	into #default_totals
	from apd_base a 
	where
		1=1
		and a.COMP_TYPE = 'WRVIOL' and VERSION=1
;
;if object_id('tempdb.dbo.#my_totals') is not null drop table #my_totals
;
--), mytotals as (
	select
		number_key
		,sum(amount) amount
	into #my_totals
	from #g
	group by NUMBER_KEY
--)



;if object_id('tempdb.dbo.#exists') is not null drop table #exists
;
select distinct
	'' [ ]
	,sum(g.amount) amount
	,g.number_key
	,g.FEE_ITEM_NO
	--,g.notation
	,g.DESCRIPTION
	--,g.is_addl_fee
into #exists
from #g g 
where 
	1=1
	and exists (
		select 1
		from #my_totals m 
		join #default_totals f on f.NUMBER_KEY = m.NUMBER_KEY and f.TOT_FEE = m.amount
		where
			1=1
			and m.NUMBER_KEY = g.NUMBER_KEY
			
	)
	and g.amount > 0
group by
	g.number_key
	,g.FEE_ITEM_NO
	,g.DESCRIPTION
	--,g.is_addl_fee
;

;if object_id('tempdb.dbo.#not_exists') is not null drop table #not_exists
;
select distinct
	'' [ ]
	,sum(g.amount) amount
	,g.number_key
	,g.FEE_ITEM_NO
	--,g.notation
	,g.DESCRIPTION
	--,g.is_addl_fee
	,g.tot_fee
into #not_exists
from #g g 
where 
	1=1
	and not exists (
		select 1
		from #my_totals m 
		join #default_totals f on f.NUMBER_KEY = m.NUMBER_KEY and f.TOT_FEE = m.amount
		where
			1=1
			and m.NUMBER_KEY = g.NUMBER_KEY
			
	)
	--and g.amount > 0
group by
	g.number_key
	,g.FEE_ITEM_NO
	,g.DESCRIPTION
	,g.tot_fee
	--,g.is_addl_fee
;
select * from #not_exists


---------



select
	'' [ ]
	,case when adl.NUMBER_KEY is not null then 1 else 0 end as is_addl_fee
	,'fee_detl' [fee_detl]
	,fd.*
	,'fee_adl' [fee_adl]
	,adl.*
	,'fee_item_no' [fee_item_no]
	,tf.*
from FEE_DETL fd
full join FEE_ADL adl 
	on adl.NUMBER_KEY = fd.NUMBER_KEY 
	and adl.FEE_ITEM_NO = fd.FEE_ITEM_NO
	and adl.TRANS_SEQ = fd.DETL_SEQ
left join TAB_FEE tf on tf.FEE_ITEM_NO = fd.FEE_ITEM_NO
where
	1=1
	and fd.NUMBER_KEY = @number_key
;




----------
/*
get totals as declared 
get the two fee values based on grouped fee_detl. Full join so everything has one general fee (CEB FINES/COSTS)
Update the general fee to force my total to match declared tot_fee.
*/

;if object_id('tempdb.dbo.#g') is not null drop table #g
;create table #g (
	number_key varchar(20)
	,tot_fee money
	,fee_water_violation money
	,fee_generic		 money
)
;
insert into #g
select
    a.number_key
    ,a.TOT_FEE
    ,0 as fee_water_violation
    ,0 as fee_generic
from apd_base a 
where
    1=1
    and a.COMP_TYPE = 'WRVIOL' and VERSION=1
;


;if object_id('tempdb.dbo.#fee_parts') is not null drop table #fee_parts
;
select distinct
	'' [ ]
	,case when adl.NUMBER_KEY is not null then 1 else 0 end as is_addl_fee
	,a.NUMBER_KEY
	,isnull(fd.fee_item_no,500) fee_item_no
	,isnull(fd.amount,0) amount
	--,convert(varchar(max),adl.NOTATION) notation
	,isnull(tf.description,'CEB FINES/COSTS') description
into #fee_parts
from apd_base a 
left join FEE_DETL fd on fd.NUMBER_KEY = a.NUMBER_KEY
full join FEE_ADL adl 
	on adl.NUMBER_KEY = a.number_key --fd.NUMBER_KEY 
	and adl.FEE_ITEM_NO = fd.FEE_ITEM_NO
	and adl.TRANS_SEQ = fd.DETL_SEQ
left join TAB_FEE tf on tf.FEE_ITEM_NO = fd.FEE_ITEM_NO
where
	1=1
	and a.COMP_TYPE = 'WRVIOL' and VERSION=1
	--and fd.NUMBER_KEY = @number_key
	--and a.NUMBER_KEY = 'WR2201925' --'WR2202191       '
--order by a.NUMBER_KEY
;

--total up water violation fee
;with b as (
    select
        a.number_key
        ,sum(b.amount) amount
    from #g a 
    join #fee_parts b on b.number_key = a.number_key
    where 
        1=1
        and b.fee_item_no = 800
        --and a.number_key = 'WR2201899'
    group by a.number_key
)
update a set 
	fee_water_violation = b.amount
from #g a
join b on b.number_key = a.number_key
where
	1=1
;
--total up generic fee
;with b as (
    select
        a.number_key
        ,sum(b.amount) amount
    from #g a 
    join #fee_parts b on b.number_key = a.number_key
    where 
        1=1
        and b.fee_item_no <> 800
        --and a.number_key = 'WR2201899'
    group by a.number_key
)
update a set 
	fee_generic = b.amount
from #g a
join b on b.number_key = a.number_key
where
	1=1
;
--force generic fee to result in tot_fee matching
update a set 
	fee_generic = tot_fee - fee_water_violation
from #g a
where
	1=1
    and tot_fee <> fee_water_violation + fee_generic
;

select * from #g where tot_fee <> fee_water_violation + fee_generic
;