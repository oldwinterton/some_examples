;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_FEEALLOCATION
;
;print 'AATABLE_PERMIT_FEEALLOCATION';
insert into AATABLE_PERMIT_FEEALLOCATION (
Permitnum,Fee_Key,PAY_KEY,FEE_ALLOCATION
)
select distinct
    pmap.permitnum permitnum 
    ,pnum.permitnum + '-'+  b.fee_key fee_key
    ,trim(fd.trans_id) + '_' + trim(convert(varchar(max),fd.trans_seq)) + '-' + trim(convert(varchar(max),fd.DETL_SEQ)) pay_key
    ,fd.amount 
from hcfl_src.dbo.fee_detl fd
join jms_apd_base_filtered__wrviol1 a on a.number_key = fd.number_key --join hcfl_src.dbo.apd_base a on a.number_key = fd.number_key
join jms_compType_version_feeItemNo_description_accountCode_feeKey__wrviol1 b 
    on b.comp_type = a.comp_type
    and b.version = a.version
    and b.fee_item_no = fd.fee_item_no
    --and b.account_code = isnull(fd.account_code,'')
join jms_numberKey_permitnum__wrviol1 pmap on pmap.number_key = fd.number_key
join aatable_permit_history pnum on pnum.permitnum = pmap.permitnum
left join aatable_permit_fee f on f.fee_key = pnum.permitnum + '-'+  b.fee_key 
where
	1=1
	and f.FEE_KEY is not null
	--and f.fee_key like '%cbs'
;
select * from AATABLE_PERMIT_FEEALLOCATION

select pay_key, count(*) from AATABLE_PERMIT_FEEALLOCATION group by PAY_KEY having count(*) > 1
select FEE_KEY, count(*) from AATABLE_PERMIT_FEEALLOCATION group by FEE_KEY having count(*) > 1
select fee_key from AATABLE_PERMIT_FEEALLOCATION except select fee_key from aatable_permit_fee
select pay_key from AATABLE_PERMIT_FEEALLOCATION except select pay_key from AATABLE_PERMIT_PAYMENTS

with m as (
	select pay_key from AATABLE_PERMIT_FEEALLOCATION except select pay_key from AATABLE_PERMIT_PAYMENTS
)
select 
	a.* 
from AATABLE_PERMIT_FEEALLOCATION a
join m on m.pay_key = a.PAY_KEY
where 
	1=1