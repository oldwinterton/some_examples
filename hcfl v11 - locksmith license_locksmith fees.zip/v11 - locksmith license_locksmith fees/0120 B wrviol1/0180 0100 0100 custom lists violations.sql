--select
--    pnum.permitnum
--	,pnum.tt_record
--	,null as [comment]
--    ,null as [violation]



/* I intended for this to be guidesheets
but conversation yields that most of the violations , based on how accela is configured, are not guidesheet items, rather they seem to belong to comments on an inspection.
Logic copied from elsewhere; calls given site visit a parent inspection, and subsequent rows (comments, other) its children.
For the violations: associates violations with their rows on apd_insp, then to the parent inspection.
Requires post-conversion logic to ensure line breaks occur.

determine child rows per inspection, then assert inspection type and inspection result based on those children
with parents
is_initial_site_visit
create g
create h
create violations
creaet cl_violations__wrviol1
verify counts
hack fix for '0140 0100 custom fields.sql': the date isn't the actual violation date
*/
--determine child rows per inspection, then assert inspection type and inspection result based on those children
;IF OBJECT_ID('tempdb.dbo.#parents', 'U') IS NOT NULL drop table #parents
;IF OBJECT_ID('tempdb.dbo.#is_initial_site_visit', 'U') IS NOT NULL drop table #is_initial_site_visit
;IF OBJECT_ID('tempdb.dbo.#g', 'U') IS NOT NULL drop table #g
;IF OBJECT_ID('tempdb.dbo.#orphaned', 'U') IS NOT NULL drop table #orphaned
;IF OBJECT_ID('tempdb.dbo.#h', 'U') IS NOT NULL drop table #h
;IF OBJECT_ID('tempdb.dbo.#req_opt', 'U') IS NOT NULL drop table #req_opt
;
go

--;with parents
    --assumes inspections are site visits, and results are implied by the subsequent rows prior to the following site visit.
    select
        number_key
        ,unique_key
        ,date_ent
        ,the_Date
        ,action_ent
    into #parents
    from jms_apd_insp_filteredToPop__wrviol1
    where action_ent in ('SV','SSV','QCSV','LSV')
    --and number_key = 'CE18015425'
;
--), is_initial_site_visit as (
    --"initial site visiit" is an accela inspection type
    select
        b.UNIQUE_KEY
        ,b.action_ent
    into #is_initial_site_visit
    from jms_apd_base_filtered__wrviol1 a
    outer apply (select top 1 * from jms_apd_insp_filteredToPop__wrviol1 where NUMBER_KEY = a.NUMBER_KEY and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent,the_date) b
;
--create g
--),g as (
    select
        a.number_key
        ,a.item_id
        ,a.unique_key
        ,a.action_ent
        ,action_ent.DESCRIPTION action_ent_desc
        ,case when is_initial_site_visit.UNIQUE_KEY is not null then 1 else 0 end as is_initial_site_visit
        ,'xxxx' [ ]
        ,coalesce(b.unique_key,is_initial_site_visit.unique_key) parent_unique_key
        ,b.action_ent parent_action_ent
        ,(case 
            when is_initial_site_visit.UNIQUE_KEY is not null then 'Initial Site Visit'
            when a.ACTION_ENT in ('QCSV','LSV') then 'Quality Control Inspection'
            when  a.any_comments like '%re%inspect%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%re%check%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%annual%insp%'    then 'Annual Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%post%hearing%'    then 'Post-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%pre%hearing%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%hear%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%follow%up%'    then 'Follow-up Inspection' --I don't know about pre vs post hearing
            else 'Inspection'
            end		
        ) as inspection_type
        ,(case 
            --when a.ACTION_ENT in ('SV','SSV','QCSV','LSV') then null
            when a.action_ent in ('CERT','DFLT') then 'Issue Citation' --CERT = issue citation
            when a.action_ent in ('CRTY') then 'Issue Warning' --CRTY = warning (courtesy) 
            when a.action_ent in ('CNCL') then 'Cancel'
            --when a.action_ent in ('STLS','STLO') then 'Extension'
            --when a.action_ent in ('ADMN','CREV','NREV') then 'No Violation' --Move this to time accounting? Associate with inspection? I put ADMN here cuz it is not a violation or similar
            --when a.action_ent in ('AP','CMP','COMP') then 'Approved' --maybe "complied"
            --when a.action_ent in ('AFFN','DFLT','ACOM') then 'Disapproved' -- ACOM seemed to all be problems
		
			when a.any_comments like '%created in err%' then 'Cancel' --CNCL
            when a.any_comments like '%CLNO%' then 'No Violation' --yes
            when a.any_comments like '%no viol%' then 'No Violation' --yes 
            when a.any_comments like '%courtesy notice%' then 'Issue Warning'

			--when a.any_comments like '%warn%' then 'Issue Warning'
            --when a.any_comments like '%POST%PROP%' then 'Issue Warning' --post would mean we are getting it ready for a hearing
            --when a.any_comments like '%DOOR%HANG%' then 'Issue Warning' --doesnt necessarily mean a warning is issued; it means we're gonna come back
            --when a.any_comments like '%hand%deliv%' then 'Issue Citation' --could definitely be issue cit
            --when a.any_comments like '%watering days%' then 'Issue Citation' --could be citation or warning
            --when a.any_comments like '%post%' then 'Issue Citation' --sure ok
            --when a.any_comments like '%property was found%' then 'Issue Citation' --not necessarily. Could be a warning.
            --when a.any_comments like '%watering %' then 'Issue Citation' --not necessarily. Could be a warning.
            --when a.any_comments like '%irrigation%restr%' then 'Issue Citation' --not necessarily. Could be a warning
            else 'No Violation'
            end
        ) as inspection_result
        
        ,'xxxx' [2]
        ,a.date_ent
        ,a.the_date
        ,'xxxx'[3]
        ,a.any_comments
    into #g
    from jms_apd_insp_filteredToPop__wrviol1 a
    outer apply (select top 1 * from #parents where number_key = a.number_key and the_date <= a.the_date and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent desc,the_date desc) b
    left join jms_actionEnt_passFail__wrviol1 action_ent on action_ent.action_ent = a.action_ent
    left join #is_initial_site_visit is_initial_site_visit on is_initial_site_visit.UNIQUE_KEY = a.UNIQUE_KEY
    where
        1=1
        --and a.action_ent not in ('SV','SSV','QCSV','LSV')
        --and a.number_key = 
        --    --'CE03003081'
        --    --'CE22014264'
        --    'CE22014971'
    --order by --a.date_ent,a.the_Date,case when a.action_ent in ('SV','SSV','QCSV','LSV') then 1 else 2 end, l.THE_TEXT
    --    a.UNIQUE_KEY
;



--create h
--), h as (
    select distinct
         a1.NUMBER_KEY
        ,a1.UNIQUE_KEY
        ,a1.action_ent
        ,a1.inspection_type
        ,coalesce(b.inspection_result,a1.inspection_result,'Not Set') inspection_result
        ,trim('^|' from stuff((
            select 
                '^|^' + cast(
                    trim(replace(replace(replace(replace(   isnull(a2.any_comments,'')   ,'"',''''''),'''',''),char(13),''),char(10),'®')) 
                    as varchar(max)
                )
            from #g a2 with(nolock)
            where 
                a2.parent_unique_key = a1.parent_unique_key
            group by a2.any_comments
            order by a2.any_comments
            FOR XML PATH('')
         ), 1, 1, '')) as any_comments
    into #h
    from #g a1
    outer apply (
        select top 1 *
        from #g
        where
            parent_unique_key = a1.UNIQUE_KEY
            and inspection_result is not null
        order by case inspection_result when 'Cancel' then 1 when 'Issue Citation' then 2 when 'Issue Warning' then 3 when 'No Violation' then 4 else 5 end
    ) b
    where
        1=1
        and a1.ACTION_ENT in ('SV','SSV','QCSV','LSV')
        --and a1.number_key = 'CE17015692'
    ;

    --order by a.UNIQUE_KEY
--)
;

--create violations
--;with cte_violations as (
;IF OBJECT_ID('tempdb.dbo.#_violations', 'U') IS NOT NULL drop table #_violations
;
;with lesser_dates as (
	select 
		 b.number_key
		,b.sequence
		,b.item_id
		,b.the_date
		,b2.THE_DATE lesser_date
	from hcfl_src..apd_itms b
	outer apply (select top 1 * from hcfl_src..APD_ITMS where record_type = 'cd' and NUMBER_KEY = b.NUMBER_KEY and THE_DATE < b.THE_DATE) b2
	where
		1=1
		and b.number_key in ('','WR2001154','WR2001254','WR2001312','WR2001388','WR2001391','WR2100003','WR2201954','WR2302581','WR2400295'
        )
		and b2.the_Date is not null
)
select distinct
     a.NUMBER_KEY
    ,a.parent_unique_key
    ,a.unique_key --the inspection the violation will be associated with
    ,b.item_id
    ,b.the_date
    ,convert(varchar(max),tc.notation) notation
    ,convert(varchar(max),tc.the_text) the_text
    ,b.approved
into #_violations
from #g a
left join hcfl_src..apd_itms b on b.RECORD_TYPE = 'CD' and b.NUMBER_KEY = a.NUMBER_KEY
left join lesser_dates b2 on b2.number_key = b.number_key and b2.sequence = b.sequence and b2.item_id = b.item_id and b2.the_date = b.the_Date	
left join hcfl_src..tab_cond tc on tc.ELEMENT_KEY = b.ITEM_ID
where
    1=1
    and b.NUMBER_KEY is not null
    --and b.NUMBER_KEY = 'WR2202362 '
    and (
        (year(b.THE_DATE) = year(a.date_ent) and month(b.THE_DATE) = month(a.date_ent) and day(b.THE_DATE) = day(a.date_ent) )
        or (year(b2.lesser_date) = year(a.date_ent) and month(b2.lesser_date) = month(a.date_ent) and day(b2.lesser_date) = day(a.date_ent) )
    )
;

;IF OBJECT_ID('tempdb.dbo.#violations', 'U') IS NOT NULL drop table #violations
;
go
;with lesser_dates as (
	select 
		 b.number_key
		,b.sequence
		,b.item_id
		,b.the_date
		,b2.THE_DATE lesser_date
	from hcfl_src..apd_itms b
	outer apply (select top 1 * from hcfl_src..APD_ITMS where record_type = 'cd' and NUMBER_KEY = b.NUMBER_KEY and THE_DATE < b.THE_DATE) b2
	where
		1=1
		and b.number_key in ('','WR2001154','WR2001254','WR2001312','WR2001388','WR2001391','WR2100003','WR2201954','WR2302581','WR2400295'
        )
		and b2.the_Date is not null
)
select distinct
     a.NUMBER_KEY
    ,a.parent_unique_key
    ,b.item_id
    ,b.the_date
    ,replace(replace(replace(replace(     convert(varchar(max),tc.notation)     ,'"',''''''),'''',''),char(13),''),char(10),'®') notation
    ,replace(replace(replace(replace(     convert(varchar(max),tc.the_text)     ,'"',''''''),'''',''),char(13),''),char(10),'®') the_text
    ,b.approved
into #violations
from #g a
left join hcfl_src..apd_itms b on b.RECORD_TYPE = 'CD' and b.NUMBER_KEY = a.NUMBER_KEY
left join lesser_dates b2 on b2.number_key = b.number_key and b2.sequence = b.sequence and b2.item_id = b.item_id and b2.the_date = b.the_Date	
left join hcfl_src..tab_cond tc on tc.ELEMENT_KEY = b.ITEM_ID
where
    1=1
    and b.NUMBER_KEY is not null
    --and b.NUMBER_KEY = 'WR2202362 '
    and (
        (year(b.THE_DATE) = year(a.date_ent) and month(b.THE_DATE) = month(a.date_ent) and day(b.THE_DATE) = day(a.date_ent) )
        or (year(b2.lesser_date) = year(a.date_ent) and month(b2.lesser_date) = month(a.date_ent) and day(b2.lesser_date) = day(a.date_ent) )
    )
;

delete d
from #violations d 
where
	1=1
	and (
		(number_key = 'WR2001138' and parent_unique_key = 'A008504612')
		or (number_key = 'WR2300607 ' and parent_unique_key = 'A009041780')
	)
;
insert into #violations 
select *
from (VALUES
('WR2100003','A008729399','WRV1','2021-01-11 00:00:00.0000000','WRV RESTRICTED DAY','WATERING ON A RESTRICTED DAY®®','N')
,('WR2401601','ORPH-195'  ,'WRV1','2024-06-07 00:00:00.0000000','WRV RESTRICTED DAY','WATERING ON A RESTRICTED DAY®®','N')
,('WR2401845','A009213417','WRV1','2021-01-11 00:00:00.0000000','WRV RESTRICTED DAY','WATERING ON A RESTRICTED DAY®®','N')
) t(NUMBER_KEY,parent_unique_key,item_id,the_date,notation,the_text,approved)



/*
from here:
notation => guide sheets asi
I think, then: the_text => guide sheet asit ?
I think guidesheet things arent configured?
Is the record type or subtype or something mappable into the guidesheets? 
then the notation to ASI
then the_text to ASIT:inspector_comments?

*/
--creaet cl_violations__wrviol1
;IF OBJECT_ID('hcfl_prod.dbo.cl_violations__wrviol1', 'U') IS NOT NULL drop table cl_violations__wrviol1

;IF OBJECT_ID('hcfl_prod.dbo.cl_violations__wrviol1', 'U') IS NOT NULL drop table cl_violations__wrviol1
;with g as (
    select
        pnum.permitnum
        ,pnum.tt_record
        --,ROW_NUMBER() OVER(PARTITION BY pnum.permitnum order by v.the_date) AS num_row
    
        ,the_date date_added
        ,(case notation
            when 'WRV HOURS'                 then 'Watering During Restricted Hours'
            when 'WRV IRRIGATION AFTER RAIN' then 'IRRIGATION DURING/AFTER SUBSTANTIAL RAINFALL®®'
            when 'WRV RESTRICTED DAY'        then 'Watering on Restricted Day'
            when 'WRV WASTE'                 then 'Wasteful/Inefficient Use of Water'
            else null
            end
        ) as violation
    --into cl_violations__wrviol1
    from #violations v
    join jms_numberKey_permitnum__wrviol1 pmap on pmap.number_key = v.NUMBER_KEY
    join aatable_permit_history pnum on pnum.permitnum = pmap.permitnum
)
select
	pnum.permitnum
    ,pnum.tt_record
    
    ,pnum.violation
    ,left(convert(varchar,pnum.date_added,20),11) comment
	,ROW_NUMBER() OVER(PARTITION BY pnum.permitnum order by pnum.date_added) AS row_num
into cl_violations__wrviol1
from g pnum
WHERE
    1=1
    --and g.permitnum = 'WR2202362'
;
go

--verify counts
if 1 = (
	select distinct 1
	from (
        SELECT
            a.permitnum 
            ,a.ct_a
            ,b.ct_b
        from (
            select 
                pmap.permitnum
                ,count(distinct a.item_id) ct_a
                --,a.*
            from hcfl_src..apd_itms a 
            join jms_apd_insp_filteredToPop__wrviol1 f on f.number_key = a.number_key
            join jms_numberKey_permitnum__wrviol1 pmap on pmap.number_key = a.NUMBER_KEY
            WHERE
                1=1
                and a.record_type = 'CD'
                --and a.NUMBER_KEY = 'WR2102935'
            group by pmap.permitnum
        ) a  --violations_per_numberKey
        left join (
            select 
                a.permitnum
                ,max(a.row_num) ct_b
            from cl_violations__wrviol1 a 
            group by a.permitnum
        ) b on b.permitnum = a.permitnum  --captured_violations
        WHERE
            1=1
            and a.ct_a <> b.ct_b
    ) z
) RAISERROR ('cl_violations__wrviol1: there is a violation count mismatch between source and what was captured', 16, 1)
;
go

----hack fix for '0140 0100 custom fields.sql': the date isn't the actual violation date
--ALTER TABLE cf_Water_Enforcement ALTER COLUMN [Date of violation] datetime
--go 
--ALTER TABLE cf_Water_Enforcement ALTER COLUMN [Date of violation] date
--go
--update cf_water_enforcement set 
--	[Time of Violation] = null
--where
--	1=1
--	and try_convert(datetime,[Time of Violation] ) is null
--go
--ALTER TABLE cf_Water_Enforcement ALTER COLUMN [Time of Violation] datetime
--go
--
--update a set 
--     [Date of violation] = coalesce(try_convert(date, b.comment), b.comment, a.[Date of violation])
--    ,[Time of Violation] = coalesce(   try_convert(datetime,b.comment + ' ' + right(convert(varchar,[time of violation]),8))   , [time of violation]   )
--from cf_Water_Enforcement a 
--outer apply (select top 1 * from cl_violations__wrviol1 where permitnum = a.permitnum) b
--;

--meeting on 20240525.txt - Violation not reliably carring over from CE to CE-CBS record
;IF OBJECT_ID('hcfl_prod.dbo.cl_violations__wrviol1_cbs', 'U') IS NOT NULL drop table cl_violations__wrviol1_cbs
;
select
	 b.permitnum
	,'Citizen Board Support Water Enforcement' tt_record
	,a.violation
    ,a.comment
    ,a.row_num
into cl_violations__wrviol1_cbs
from cl_violations__wrviol1 a
join AATABLE_PERMIT_HISTORY b on b.PERMITNUM = a.permitnum + '-CBS'
where 
	1=1
;
