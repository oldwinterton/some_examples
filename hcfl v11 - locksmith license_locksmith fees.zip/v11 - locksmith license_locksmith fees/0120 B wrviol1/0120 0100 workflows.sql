/* 
rem: the apd_insp table: I am conceptualizing it like... a site visit happens, and subsequent actions/results are in subsequent rows.
Therefore: omit SV,SSV,QCSV,LSV rows, and omit COM,ACOM rows.

Citizens_Board_Support_water_enforcement_ENF_CBS_WA
Water_Enforcement__ENF_WATER_2
comment apostrophes
*/

;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_WORKFLOW
;
--Citizens_Board_Support_water_enforcement_ENF_CBS_WA
;IF OBJECT_ID('tempdb.dbo.#dataStatus_task_status_ENF_CBS_WA', 'U') IS NOT NULL drop table #dataStatus_task_status_ENF_CBS_WA
go
select
*
into #dataStatus_task_status_ENF_CBS_WA
from (VALUES
-- ('PREHRNG' ,'CBS Case Review',
--,('PRECEB'  ,'CBS Case Review',
 ('INSP','CBS Case Review','Request to Post At Property')
,('ADJUDIC','Post Hearing','Adjudicated')
,('CMPLFINE','Post-Hearing','Adjudicated')
,('FINERUN' ,'Post-Hearing','Adjudicated')
,('NWOWNFIN','Post-Hearing','Adjudicated')
,('CAONC'   ,'Post-Hearing','Adjudicated')
,('CAOPR'   ,'Post-Hearing','Adjudicated')
,('COMPLIED','Fee Intake','Fees Received')
,('CLOSED'  ,'Fee Intake','Fees Received')
,('CMPLCEB' ,'Fee Intake','Fees Received')
,('CNCL'    ,'Fee Intake','Fees Received')
,('DISMISS' ,'Fee Intake','Fees Received')
) t(data_status,tt_workflow_task,tt_workflow_status)
;
;insert into AATABLE_PERMIT_WORKFLOW (
PERMITNUM,TASKUPDATED,COMMENTS,ASGN_DATE,DUE_DATE,TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS,USER_ID,ID,SD_HOURS_SPENT,SD_BILLABLE,SD_OVERTIME,ESTIMATED_HOURS,ASGN_EMAIL_DISPLAY_FOR_ACA ,RESTRICT_COMMENT_FOR_ACA,RESTRICT_ROLE,TASK_UNIQUE_ID
)
select distinct
    pnum.permitnum as PERMITNUM
    ,COALESCE(try_convert(datetime,pnum.dateopened),'1900-01-01 00:00:00') as TASKUPDATED
    ,null as COMMENTS
    ,null as ASGN_DATE
    ,null as DUE_DATE
    ,f.tt_workflow_task as TT_WORKFLOW_TASK
    ,f.tt_workflow_status as TT_WORKFLOW_STATUS
    ,coalesce(asgn_staff.user_name,created_by.user_name,'Not Set') as USER_ID
    ,null as ID
    ,null as SD_HOURS_SPENT
    ,null as SD_BILLABLE
    ,null as SD_OVERTIME
    ,null as ESTIMATED_HOURS
    ,null as ASGN_EMAIL_DISPLAY_FOR_ACA
    ,null as RESTRICT_COMMENT_FOR_ACA
    ,null as RESTRICT_ROLE
    ,pnum.permitnum +'_initWorkflow' as TASK_UNIQUE_ID
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum +'-CBS' = pnum.permitnum
join jms_apd_base_filtered__wrviol1 a on a.number_key = pmap.number_key
left join jms_userid_username__wrviol1 created_by on created_by.user_id = a.user_id
left join jms_userid_username__wrviol1 asgn_staff on asgn_staff.user_id = a.insp_area
join #dataStatus_task_status_ENF_CBS_WA f on f.data_status = a.data_status
where 
    1=1
    and pnum.tt_record in ('Citizen Board Support Water Enforcement')
;


--Water_Enforcement__ENF_WATER_2

;IF OBJECT_ID('tempdb.dbo.#dataStatus_task_status_ENF_WATER_2', 'U') IS NOT NULL drop table #dataStatus_task_status_ENF_WATER_2
go
select
*
into #dataStatus_task_status_ENF_WATER_2
from (VALUES
-- ('NEW'     ,'Initial Investigation','ACTIVE')
 ('ACTIVE'  ,'Initial Investigation','Corrections Needed') --'Supervisor Approval','ACTIVE')
,('CLNO'    ,'Initial Investigation','No Violation')
,('CLSD'    ,'Admin Send Letter','Warning Sent')
,('COMPLIED','Admin Send Letter','NOV Complete')
,('APPLAPPR','Admin Send Letter','NOV Complete')
,('PRECEB ' ,'Case Affadavit','Case of Affidavit Sent')
,('PREHRNG' ,'Case Affadavit','Case of Affidavit Sent')
,('CAOPR'   ,'Case Affadavit','Case of Affidavit Sent')
,('CLOSED'  ,'Supervisor Approval','Administratively Closed')
,('CMPLCEB' ,'Citizen Board Support','Close')
,('CMPLFINE','Citizen Board Support','Close')
,('CNCL'    ,'Supervisor Approval','Administratively Closed')
,('DISMISS' ,'Citizen Board Support','Case Dismissed')
,('FINERUN' ,'Case Affadavit','Case of Affidavit Sent')
,('VOID'    ,'Supervisor Approval','Administratively Closed')
) t(data_status,tt_workflow_task,tt_workflow_status)
;

insert into AATABLE_PERMIT_WORKFLOW (
PERMITNUM,TASKUPDATED,COMMENTS,ASGN_DATE,DUE_DATE,TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS,USER_ID,ID,SD_HOURS_SPENT,SD_BILLABLE,SD_OVERTIME,ESTIMATED_HOURS,ASGN_EMAIL_DISPLAY_FOR_ACA ,RESTRICT_COMMENT_FOR_ACA,RESTRICT_ROLE,TASK_UNIQUE_ID
)
select distinct
    pnum.permitnum as PERMITNUM
    ,COALESCE(try_convert(datetime,pnum.dateopened),'1900-01-01 00:00:00') as TASKUPDATED
    ,null as COMMENTS
    ,null as ASGN_DATE
    ,null as DUE_DATE
    ,f.tt_workflow_task as TT_WORKFLOW_TASK
    ,f.tt_workflow_status as TT_WORKFLOW_STATUS
    ,coalesce(asgn_staff.user_name,created_by.user_name,'Not Set') as USER_ID
    ,null as ID
    ,null as SD_HOURS_SPENT
    ,null as SD_BILLABLE
    ,null as SD_OVERTIME
    ,null as ESTIMATED_HOURS
    ,null as ASGN_EMAIL_DISPLAY_FOR_ACA
    ,null as RESTRICT_COMMENT_FOR_ACA
    ,null as RESTRICT_ROLE
    ,pnum.permitnum +'_initWorkflow' as TASK_UNIQUE_ID
from aatable_permit_history pnum
join jms_numberKey_permitnum__wrviol1 pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered__wrviol1 a on a.number_key = pmap.number_key
left join jms_userid_username__wrviol1 created_by on created_by.user_id = a.user_id
left join jms_userid_username__wrviol1 asgn_staff on asgn_staff.user_id = a.insp_area
join #dataStatus_task_status_ENF_WATER_2 f on f.data_status = a.data_status
where 
    1=1
    and pnum.tt_record in ('Water Enforcement','Water Enforcement - Proactive')
;

--comment apostrophes
update aatable_permit_workflow set
    comments = replace(comments,'''','Å')
;
    --and user_id's, apparently...
update aatable_permit_workflow set
    user_id = 'Spriggs, Teddy'
WHERE
    1=1
    and user_id = 'Spriggs, Edward ''Teddy'''
;

