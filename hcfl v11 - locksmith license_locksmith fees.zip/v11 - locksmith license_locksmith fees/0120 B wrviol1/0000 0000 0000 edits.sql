--apostraphe--officer's comments
;update R2CHCKBOX set R1_CHECKBOX_DESC = 'Officer®s Comments' where R1_CHECKBOX_DESC = 'Officer''s Comments'
;
