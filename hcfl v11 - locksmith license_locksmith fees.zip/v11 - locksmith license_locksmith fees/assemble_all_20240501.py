""" I probably need to still make it so nothing is a carte blanche join to aatable_permit_history, now.
Make sure to set the DB_NAME and FOLDERS_TO_INCLUDE.

get filenames to concat 
prefix the file with the truncate-stopper, and with progress-tracking-table
concat files
"""

import os

DB_NAME = 'accelaConv7'

FOLDERS_TO_INCLUDE = {
''
,'0100 hbcode4_rcdapp1'
,'0120 B wrviol1'

}

##----------------------------------
SETUP_FOLDER = '0000'
SETUP_FILES = { ##These should only get used once! But I keep them within each child folder, so I can run each child folder individually.
'0000 0020 HistoryStagingTables-MSSQL.sql'
,'0000 0040 mssql_01_create_tables.sql'
,'0000 0060 mssql_02_create_views.sql'
}

##get filenames to concat 
thisDir = os.path.dirname(os.path.abspath(__file__))
folders = [os.path.join(thisDir,folder) for folder in os.listdir(thisDir) if os.path.isdir(os.path.join(thisDir,folder)) and folder in FOLDERS_TO_INCLUDE]
filenames = (
    sorted([os.path.join(thisDir,SETUP_FOLDER,filename) for filename in os.listdir(os.path.join(thisDir,SETUP_FOLDER))])
    + sorted([os.path.join(thisDir,filename) for filename in os.listdir(thisDir) if not os.path.isdir(os.path.join(thisDir,filename))])
)
filenames += sorted([os.path.join(thisDir,filename) for filename in os.listdir(thisDir) if not os.path.isdir(os.path.join(thisDir,filename))])

for folder in folders:
    _filenames = [
        i for i in 
        sorted([os.path.join(folder,filename) for filename in os.listdir(folder) if not os.path.isdir(os.path.join(folder,filename))])
        if i.rsplit(os.sep,1)[-1] not in SETUP_FILES
    ]
    filenames += _filenames


##prefix the file with the truncate-stopper, and with progress-tracking-table
with open('all.sql','w') as f:
    f.write(f'''
use {DB_NAME};
go

IF OBJECT_ID('tempdb.dbo.##completed', 'U') IS NOT NULL
DROP TABLE ##completed
;
create table ##completed (dt datetime, val varchar(1000))
;

--## this lets me have a folder for each record type, include truncates in those folders for work within that record type, and allows me to ignore those truncates and combine any record types together for a single conversion.
IF OBJECT_ID('tempdb.dbo.#includeTruncates', 'U') IS NOT NULL
DROP TABLE #includeTruncates
;
select 1 includeTruncates into #includeTruncates
;

go

''')
    ##concat files
    for filename in filenames:
        #print(filename.rsplit(os.sep,1)[-1])
        if filename.rsplit(os.sep,1)[-1] in ('all.sql',) or not filename.lower().endswith('sql'):
            continue
        print(filename)
        with open(filename,'rb') as sqlSegment:
            f.write(f'--filename: {filename}\n')
            if not filename.startswith('0000'):
                f.write(f"insert into ##completed values (getdate(),'{filename}')\n")
            _fc = sqlSegment.read()
            fc = _fc.decode().replace('\r\n','\n')
            f.write(fc+'\n\ngo\n\n')
            #f.write(sqlSegment.read()+'\n\n;\n\n')
