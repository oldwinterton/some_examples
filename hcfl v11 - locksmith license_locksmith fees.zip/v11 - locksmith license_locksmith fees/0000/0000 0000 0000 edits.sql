--apostraphe--officer's comments
;update R2CHCKBOX set R1_CHECKBOX_DESC = 'Officer®s Comments' where R1_CHECKBOX_DESC = 'Officer''s Comments'
;
--fieldname length
;update R2CHCKBOX set R1_CHECKBOX_DESC = 'who appeared for hearing' where R1_CHECKBOX_DESC = 'Text field for name of person who appeared for hearing'
;
