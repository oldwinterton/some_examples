-- Be sure to review and update the @spc accordingly
-- the @SPC is hte agency id for your client.
-- Are you logged into the correct database ?



DECLARE @SPC VARCHAR(15)
BEGIN
SET @SPC = 'HCFL'
 
delete from F4FEEITEM_AUDIT_TRAIL where serv_prov_code = @spc and b1_per_id1='20XXX' and b1_per_id2='00000' and b1_per_id3='00000'
delete from F4FEEITEM where serv_prov_code = @spc and b1_per_id1='20XXX' and b1_per_id2='00000' and b1_per_id3='00000'
delete from accounting_audit_trail where serv_prov_code = @spc and b1_per_id1='20XXX' and b1_per_id2='00000' and b1_per_id3='00000'
delete from status_history where serv_prov_code = @spc and b1_per_id1='20XXX' and b1_per_id2='00000' and b1_per_id3='00000'
delete from GACTIVITY where serv_prov_code = @spc and b1_per_id1='20XXX' and b1_per_id2='00000' and b1_per_id3='00000'
delete from F4PAYMENT where serv_prov_code = @spc and b1_per_id1='20XXX' and b1_per_id2='00000' and b1_per_id3='00000'
delete from GWORK_ORDER_COSTING where serv_prov_code = @spc and b1_per_id1='20XXX' and b1_per_id2='00000' and b1_per_id3='00000'
delete from B3CONTACT where serv_prov_code = @spc and b1_per_id1='20XXX' and b1_per_id2='00000' and b1_per_id3='00000'
delete from XRECORD_CONTACT_ENTITY where serv_prov_code = @spc and b1_per_id1='20XXX' and b1_per_id2='00000' and b1_per_id3='00000'
delete from G6ACTION where serv_prov_code = @spc and b1_per_id1='20XXX' and b1_per_id2='00000' and b1_per_id3='00000'
delete d from GGUIDESHEET g join GGUIDESHEET_ITEM f on g.GUIDESHEET_SEQ_NBR =f.GUIDESHEET_SEQ_NBR join rguidesheet_item d on d.guide_item_Seq_nbr = f.guide_item_Seq_nbr  where 1=1 and g.b1_per_id1 = '20XXX'
delete d from GGUIDESHEET g join GGUIDESHEET_ITEM d on g.GUIDESHEET_SEQ_NBR = d.GUIDESHEET_SEQ_NBR where 1=1 and g.b1_per_id1 = '20XXX'
delete from GGUIDESHEET where serv_prov_code = @spc and b1_per_id1='20XXX' and b1_per_id2='00000' and b1_per_id3='00000'
delete from BINFO_TABLE_VALUE where serv_prov_code = @spc and b1_per_id1='20XXX' and b1_per_id2='00000' and b1_per_id3='00000'
delete from BINFO_TABLE where serv_prov_code = @spc and b1_per_id1='20XXX' and b1_per_id2='00000' and b1_per_id3='00000'
delete from B3ADDRES where serv_prov_code = @spc and b1_per_id1='20XXX' and b1_per_id2='00000' and b1_per_id3='00000'
delete from B3OWNERS where serv_prov_code = @spc and b1_per_id1='20XXX' and b1_per_id2='00000' and b1_per_id3='00000'
delete from B6CONDIT_DETAIL where serv_prov_code = @spc and b1_per_id1='20XXX' and b1_per_id2='00000' and b1_per_id3='00000'
delete from B6CONDIT where serv_prov_code = @spc and b1_per_id1='20XXX' and b1_per_id2='00000' and b1_per_id3='00000'
delete from BPERMIT_COMMENT where serv_prov_code = @spc and b1_per_id1='20XXX' and b1_per_id2='00000' and b1_per_id3='00000'
delete from GPROCESS_NOTE where serv_prov_code = @spc and b1_per_id1='20XXX' and b1_per_id2='00000' and b1_per_id3='00000'
delete from GPROCESS_HISTORY where serv_prov_code = @spc and b1_per_id1='20XXX' and b1_per_id2='00000' and b1_per_id3='00000'
delete from b1permit where serv_prov_code = @spc and b1_per_id1='20XXX' and b1_per_id2='00000' and b1_per_id3='00000'
delete from g3contact where serv_prov_code = @spc and rec_ful_nam = 'AASEQ'
delete from L1CONDIT where serv_prov_code = @spc and rec_ful_nam = 'AASEQ'
delete from l3common_condit where serv_prov_code = @spc and rec_ful_nam = 'AASEQ'
delete from XREFCONTACT_ENTITY where serv_prov_code = @spc and rec_ful_nam = 'AASEQ'
delete from G7CONTACT_ADDRESS where serv_prov_code = @spc and rec_ful_nam = 'AASEQ'
delete from f4receipt where cashier_id = 'AASEQ' and rec_ful_nam = 'AASEQ'
delete from t1_time_log where serv_prov_code = @spc and b1_per_id1='20XXX' and b1_per_id2='00000' and b1_per_id3='00000'                                                                                                              
END
go