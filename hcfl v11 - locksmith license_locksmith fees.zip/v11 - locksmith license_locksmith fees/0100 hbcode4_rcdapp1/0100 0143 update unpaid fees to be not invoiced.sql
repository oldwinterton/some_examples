/*
Needs other comp_type, version flavors
for at least npool, can I find a proper looking date for the fee applications, based on fee payment dates, and existing dates in apd_base or apd_num0?

*/

--;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table aatable_permit_fee
--;


;if object_id('tempdb.dbo.#b','U') is not null drop table #b 
;
	select
		f.PERMITNUM
		,f.fee_key
		,f.FEE_ITEM_AMOUNT
		,sum(isnull(p.fee_allocation,0)) paid_amount
    into #b 
	from aatable_permit_fee f 
	left join AATABLE_PERMIT_FEEALLOCATION p on p.FEE_KEY = f.FEE_KEY

	group by f.PERMITNUM
		,f.fee_key
		,f.FEE_ITEM_AMOUNT
;
--select 
update a set 
	invoice = 'N'
from aatable_permit_fee a
join #b b on b.FEE_KEY = a.FEE_KEY
where 
	1=1
	and b.fee_item_amount > b.paid_amount
;
delete a 
from AATABLE_PERMIT_FEEALLOCATION a 
join #b b on b.fee_key = a.fee_key 
WHERE   
    1=1
    and b.fee_item_amount > b.paid_amount
;