/*
https://dev.azure.com/Hillsborough-County/bf470d0d-5a72-4dce-b8a4-ec892e39f909/_workitems/edit/11467
"I did want to mention that fine data (other than abatement costs) should be present on the CBS record. "

The below logic repoints fee data to the instantated CBS records.
the cbs records also get those custom lists with the curStr values.
*/
update a set
    a.permitnum = cbs.permitnum
    ,a.fee_key = replace(a.fee_key,a.permitnum,cbs.permitnum)
from aatable_permit_fee a
join jms_numberKey_permitnum pmap on pmap.permitnum = a.permitnum
join aatable_permit_history cbs on cbs.permitnum = a.permitnum + '-CBS'
;

update a set
    a.permitnum = cbs.permitnum
from AATABLE_PERMIT_PAYMENTS a
join jms_numberKey_permitnum pmap on pmap.permitnum = a.permitnum
join aatable_permit_history cbs on cbs.permitnum = a.permitnum + '-CBS'
;

update a set
    a.permitnum = cbs.permitnum
    ,a.fee_key = replace(a.fee_key,a.permitnum,cbs.permitnum)
from AATABLE_PERMIT_FEEALLOCATION a
join jms_numberKey_permitnum pmap on pmap.permitnum = a.permitnum
join aatable_permit_history cbs on cbs.permitnum = a.permitnum + '-CBS'
;

--wrong
--update a set
--    a.permitnum = cbs.permitnum
--    ,a.fee_key = replace(a.fee_key,a.permitnum,cbs.permitnum)
--from AATABLE_PERMIT_RECEIPTS a
--join aatable_permit_history cbs on cbs.permitnum = a.permitnum + '-CBS'
--;
