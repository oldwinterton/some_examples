/*
prelim
create_PERMIT_FEEALLOCATION
*/

----prelim
--SELECT distinct
--    trim(fd.NUMBER_KEY) permitnum
--	,trim(fd.trans_id) + '_' + trim(convert(varchar(max),fd.trans_seq)) + '-' + trim(convert(varchar(max),fd.DETL_SEQ)) pay_key
--    ,b.fee_key
--	,fd.amount
--from hcfl_src.dbo.fee_detl fd
--join hcfl_src.dbo.apd_base a on a.number_key = fd.number_key
--join jms_compType_version_feeItemNo_description_accountCode_feeKey b 
--    on  b.comp_type = a.comp_type
--    and b.version = a.version
--    and b.fee_item_no = fd.fee_item_no
--    and isnull(b.account_code,'') = isnull(fd.account_code,'')
--;



--create_PERMIT_FEEALLOCATION
IF OBJECT_ID('tempdb.dbo.##completed', 'U') IS NOT NULL 
insert into ##completed values (getdate(),'create_PERMIT_FEEALLOCATION')
;

;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_FEEALLOCATION
;
;print 'AATABLE_PERMIT_FEEALLOCATION';
insert into AATABLE_PERMIT_FEEALLOCATION (
Permitnum,Fee_Key,PAY_KEY,FEE_ALLOCATION
)
select distinct
    pmap.permitnum permitnum 
    ,pnum.permitnum + '-'+  b.fee_key 
    ,trim(fd.trans_id) + '_' + trim(convert(varchar(max),fd.trans_seq)) + '-' + trim(convert(varchar(max),fd.DETL_SEQ)) pay_key
    ,fd.amount 
from hcfl_src.dbo.fee_detl fd
join hcfl_src.dbo.apd_base a on a.number_key = fd.number_key
join jms_compType_version_feeItemNo_description_accountCode_feeKey b 
    on b.comp_type = a.comp_type
    and b.version = a.version
    and b.fee_item_no = fd.fee_item_no
    and b.account_code = isnull(fd.account_code,'')
join jms_numberKey_permitnum pmap on pmap.number_key = fd.number_key
join aatable_permit_history pnum on pnum.permitnum = pmap.permitnum

;
    --ensure no payments are allocated which havent been put in the payment table
delete a
from AATABLE_PERMIT_FEEALLOCATION a 
left join AATABLE_PERMIT_PAYMENTS p on p.PAY_KEY = a.PAY_KEY
where
	1=1
	and p.pay_key is null
;

--ensure permitnums are correctly pointed
update a set 
    permitnum = b.permitnum
from AATABLE_PERMIT_PAYMENTS a 
join AATABLE_PERMIT_FEEALLOCATION b on b.pay_key = a.pay_key
WHERE
    1=1
    and a.permitnum like 'CE%'
;


--verify fees and payments have same corresponding permitnum
if 1 = (
    SELECT distinct 1
    from AATABLE_PERMIT_FEEALLOCATION a 
    left join AATABLE_PERMIT_PAYMENTS b on b.pay_key = a.pay_key
    left join aatable_permit_fee c on c.fee_key = a.fee_key 
    WHERE
        1=1
        and c.permitnum like 'CE%'
        and b.permitnum like 'CE%'
        and c.permitnum <> b.permitnum
) RAISERROR ('AATABLE_PERMIT_FEEALLOCATION: there is a permitnum mismatch between aatable_permit_fee and aatable_permit_payments', 16, 1)
;