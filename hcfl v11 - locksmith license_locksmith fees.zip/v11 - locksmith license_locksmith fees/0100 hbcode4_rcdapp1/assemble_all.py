import os
    
with open('all.sql','w') as f:
    f.write('''
use accelaConv7;
go

IF OBJECT_ID('tempdb.dbo.##completed', 'U') IS NOT NULL
DROP TABLE ##completed
;
create table ##completed (dt datetime, val varchar(1000))
;
go

''')
    for filename in sorted(os.listdir()):
        print(filename)
        if filename in ('all.sql',) or not filename.lower().endswith('sql'):
            continue
        with open(filename,'rb') as sqlSegment:
            f.write(f'--filename: {filename}\n')
            if not filename.startswith('0000'):
                f.write(f"insert into ##completed values (getdate(),'{filename}')\n")
            _fc = sqlSegment.read()
            fc = _fc.decode().replace('\r\n','\n')
            f.write(fc+'\n\ngo\n\n')
            #f.write(sqlSegment.read()+'\n\n;\n\n')
