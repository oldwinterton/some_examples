/*

*/


;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_PROJECTS
;
insert into AATABLE_PERMIT_PROJECTS (
PARENTACTIVITYNUM,CHILDACTIVITYNUM,RELATIONSHIP,STATUS
)   
--general_programs
SELECT
     replace(a.permitnum,'-CBS','') as PARENTACTIVITYNUM
    ,a.permitnum as CHILDACTIVITYNUM 
    ,'R' relationship
    ,null status
FROM aatable_permit_history a
WHERE
    1=1
    and right(a.permitnum,4) = '-CBS'
    and a.permitnum like '%-CBS'
;
