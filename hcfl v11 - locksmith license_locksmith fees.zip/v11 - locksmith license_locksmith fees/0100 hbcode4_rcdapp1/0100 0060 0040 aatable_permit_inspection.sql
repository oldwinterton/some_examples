
;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_INSP
;

;IF OBJECT_ID('tempdb.dbo.#_AATABLE_PERMIT_INSP', 'U') IS NOT NULL drop table #_AATABLE_PERMIT_INSP
;select top 0 * into #_AATABLE_PERMIT_INSP from AATABLE_PERMIT_INSP
;


--apd_insp__and__apd_insp_log
insert into #_AATABLE_PERMIT_INSP
SELECT distinct
    pmap.permitnum as Permitnum
    ,try_convert(datetime,a.the_date) as InspDate
    ,try_convert(datetime,a.the_date) as InspSchedDate
    ,null as InspReqDate
    ,0 as Insp_Number
    ,(case when i.req_opt = 'R' then 'Y' when i.req_opt = 'O' then 'N' else null end) as Insp_Required
    ,null as Phone_Num
    ,null as Latitude
    ,null as Longitude
    ,trim(replace(replace(replace(replace(       i.any_comments       ,'"',''''''),'''',''),char(13),''),char(10),'')) as Insp_Result_Comm
    ,trim(replace(replace(replace(replace(      coalesce(action_ent.description,a.action_ent,'')        ,'"',''''''),'''',''),char(13),''),char(10),'')) as Insp_Sched_Comm
    ,null as Sd_Overtime
    ,null as Display_In_ACA
    ,i.inspection_type as TT_Inspection
    ,i.inspection_result as TT_Inspection_Status
    ,null as CONTACT_NBR
    ,null as INSP_SEQ_NBR
    ,coalesce(user_id.user_name,a.user_id,'Not Set') as User_ID
    ,null as ORDER_BY
    ,null as G6_ACT_T1
    ,null as G6_ACT_T2
    ,null as G6_ACT_END_T1
    ,null as G6_ACT_END_T2
    ,null as G6_ACT_TT
    ,a.beg_time as ESTIMATED_START_TIME
    ,a.end_time as ESTIMATED_END_TIME
    ,null as G6_DESI_DD
    ,null as G6_DESI_TIME
    ,null as G6_DESI_TIME2
    ,null as CONTACT_PHONE_NUM
    ,null as CONTACT_PHONE_NUM_IDD
    ,null as CONTACT_FNAME
    ,null as CONTACT_MNAME
    ,null as CONTACT_LNAME
    ,null as G6_REQ_PHONE_NUM_IDD
    ,null as G6_REQ_PHONE_NUM
    ,i.violations_count as MAJOR_VIOLATION_COUNT
    ,null as UNIT_NBR
    ,null as GRADE
    ,null as TOTAL_SCORE
    ,null as VEHICLE_NUM
    ,null as G6_MILE_T1
    ,null as G6_MILE_T2
    ,null as G6_MILE_TT
    ,null as INSP_CANCELLED
    ,null as INSP_PENDING
    ,a.unique_key as CLIENT_UNIQUE_ID
from jms_apd_insp_filteredToPop a 
join jms_numberKey_permitnum pmap on pmap.number_key = a.NUMBER_KEY
join jms_inspections_compliantOrNot i on i.number_key = a.NUMBER_KEY and i.unique_key = a.unique_key
left join hcfl_src.dbo.usr_base user_id on user_id.user_id = a.user_id
left join jms_actionEnt_passFail action_ent on action_ent.action_ent = a.action_ent 
left join aatable_permit_history pnum on pnum.permitnum = pmap.permitnum
;

insert into AATABLE_PERMIT_INSP (
PERMITNUM,INSPDATE,INSPSCHEDDATE,INSPREQDATE,INSP_NUMBER,INSP_REQUIRED,PHONE_NUM,LATITUDE,LONGITUDE,INSP_RESULT_COMM,INSP_SCHED_COMM,SD_OVERTIME,DISPLAY_IN_ACA,TT_INSPECTION,TT_INSPECTION_STATUS,CONTACT_NBR,INSP_SEQ_NBR,USER_ID,ORDER_BY,G6_ACT_T1,G6_ACT_T2,G6_ACT_END_T1,G6_ACT_END_T2,G6_ACT_TT,ESTIMATED_START_TIME,ESTIMATED_END_TIME,G6_DESI_DD,G6_DESI_TIME,G6_DESI_TIME2,CONTACT_PHONE_NUM,CONTACT_PHONE_NUM_IDD,CONTACT_FNAME,CONTACT_MNAME,CONTACT_LNAME,G6_REQ_PHONE_NUM_IDD,G6_REQ_PHONE_NUM,MAJOR_VIOLATION_COUNT,UNIT_NBR,GRADE,TOTAL_SCORE,VEHICLE_NUM,G6_MILE_T1,G6_MILE_T2,G6_MILE_TT,INSP_CANCELLED,INSP_PENDING,CLIENT_UNIQUE_ID
)
select
    PERMITNUM,INSPDATE,INSPSCHEDDATE,INSPREQDATE
    --coalesce permits subsequent insertions into this table to occur, while retaining the row_number behavior.
    ,coalesce((select max(insp_number) as max_insp_number from AATABLE_PERMIT_INSP),0) + row_number() over(order by permitnum) as INSP_NUMBER
    ,INSP_REQUIRED,PHONE_NUM,LATITUDE,LONGITUDE,INSP_RESULT_COMM,INSP_SCHED_COMM,SD_OVERTIME,DISPLAY_IN_ACA,TT_INSPECTION,TT_INSPECTION_STATUS,CONTACT_NBR,INSP_SEQ_NBR,USER_ID,ORDER_BY,G6_ACT_T1,G6_ACT_T2,G6_ACT_END_T1,G6_ACT_END_T2,G6_ACT_TT,ESTIMATED_START_TIME,ESTIMATED_END_TIME,G6_DESI_DD,G6_DESI_TIME,G6_DESI_TIME2,CONTACT_PHONE_NUM,CONTACT_PHONE_NUM_IDD,CONTACT_FNAME,CONTACT_MNAME,CONTACT_LNAME,G6_REQ_PHONE_NUM_IDD,G6_REQ_PHONE_NUM,MAJOR_VIOLATION_COUNT,UNIT_NBR,GRADE,TOTAL_SCORE,VEHICLE_NUM,G6_MILE_T1,G6_MILE_T2,G6_MILE_TT,INSP_CANCELLED,INSP_PENDING,CLIENT_UNIQUE_ID
from #_AATABLE_PERMIT_INSP
;

;update aatable_permit_insp set User_ID = 'Spriggs, Teddy' where User_ID = 'Spriggs, Edward ''Teddy'''
;