/*
all comments
inspection comments
remaining comments
duplicate comments into cbs records
*/



/*
--all comments
insert into aatable_permit_comment
SELECT
     pnum.permitnum PERMITNUM
    ,L.data_level+':'+ coalesce( convert(varchar(max),L.the_text),'') COMMENTS
    ,coalesce(L.user_x,L.user_id) ADDEDBY
    ,L.date_entered ADDEDDATE
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src..lhn_tab l on l.number_key = pmap.number_key
;
*/


--inspection comments

--determine child rows per inspection, then assert inspection type and inspection result based on those children
;IF OBJECT_ID('tempdb.dbo.#parents', 'U') IS NOT NULL drop table #parents
;IF OBJECT_ID('tempdb.dbo.#is_initial_site_visit', 'U') IS NOT NULL drop table #is_initial_site_visit
;IF OBJECT_ID('tempdb.dbo.#g', 'U') IS NOT NULL drop table #g
;IF OBJECT_ID('tempdb.dbo.#orphaned', 'U') IS NOT NULL drop table #orphaned
;IF OBJECT_ID('tempdb.dbo.#h', 'U') IS NOT NULL drop table #h
;IF OBJECT_ID('tempdb.dbo.#req_opt', 'U') IS NOT NULL drop table #req_opt
;
go

--;with parents
    --assumes inspections are site visits, and results are implied by the subsequent rows prior to the following site visit.
    select
        number_key
        ,unique_key
        ,date_ent
        ,the_Date
        ,action_ent
    into #parents
    from jms_apd_insp_filteredToPop
    where action_ent in ('SV','SSV','QCSV','LSV')
    --and number_key = 'CE18015425'
;
--), is_initial_site_visit as (
    --"initial site visiit" is an accela inspection type
    select
        b.UNIQUE_KEY
        ,b.action_ent
    into #is_initial_site_visit
    from jms_apd_base_filtered a
    outer apply (select top 1 * from jms_apd_insp_filteredToPop where NUMBER_KEY = a.NUMBER_KEY and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent,the_date) b
;
--),g as (
    select
        a.number_key
        ,a.item_id
        ,a.unique_key
        ,a.action_ent
        ,action_ent.DESCRIPTION action_ent_desc
        ,case when is_initial_site_visit.UNIQUE_KEY is not null then 1 else 0 end as is_initial_site_visit
        ,'xxxx' [ ]
        ,coalesce(b.unique_key,is_initial_site_visit.unique_key) parent_unique_key
        ,b.action_ent parent_action_ent
        ,(case 
            when is_initial_site_visit.UNIQUE_KEY is not null then 'Initial Site Visit'
            when a.ACTION_ENT in ('QCSV','LSV') then 'Quality Control Inspection'
            when  a.any_comments like '%re%inspect%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%re%check%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%annual%insp%'    then 'Annual Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%post%hearing%'    then 'Post-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%pre%hearing%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%hear%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%follow%up%'    then 'Follow-up Inspection' --I don't know about pre vs post hearing
            else 'Inspection'
            end        
        ) as inspection_type
        ,(case 
            --when a.ACTION_ENT in ('SV','SSV','QCSV','LSV') then null
            when a.ACTION_ENT = 'NOVR' then 'Notice of Violation Requested'
            when a.ACTION_ENT = 'NOVC' then 'NOV issued'
            when a.ACTION_ENT = 'NOVB' then 'Combo Issued'
            when a.action_ent = 'ECIT' then 'Citation Issued'
            when a.ACTION_ENT = 'COMP' then 'Compliant'
            when a.ACTION_ENT = 'VIOL' then 'Violation'
            when A.ACTION_ENT in ('CA','CNCL') then 'No Violation'
            when a.any_comments like '%dead%animal%'      then 'Extension'
            when a.any_comments like '%exten%'      then 'Extension'
            when a.any_comments like '%violation%'  then 'Violation'
            when a.any_comments like '%non%compli%' then 'Not Compliant'
            when a.any_comments like '%send%nov%'   then 'NOV Issued'
            when a.any_comments like '%req%nov%'    then 'Notice of Violation Requested'
            when a.any_comments like '%cont%fin%'    then 'Not Compliant' --continue fines
            else null
            end
        ) as inspection_result
        
        ,'xxxx' [2]
        ,a.date_ent
        ,a.the_date
        ,'xxxx'[3]
        ,a.any_comments
    into #g
    from jms_apd_insp_filteredToPop a
    outer apply (select top 1 * from #parents where number_key = a.number_key and the_date <= a.the_date and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent desc,the_date desc) b
    left join jms_actionEnt_passFail action_ent on action_ent.action_ent = a.action_ent
    left join #is_initial_site_visit is_initial_site_visit on is_initial_site_visit.UNIQUE_KEY = a.UNIQUE_KEY
    where
        1=1
        --and a.action_ent not in ('SV','SSV','QCSV','LSV')
        --and a.number_key = 
        --    --'CE03003081'
        --    --'CE22014264'
        --    'CE22014971'
    --order by --a.date_ent,a.the_Date,case when a.action_ent in ('SV','SSV','QCSV','LSV') then 1 else 2 end, l.THE_TEXT
    --    a.UNIQUE_KEY
;

;IF OBJECT_ID('tempdb.dbo.#_numberKey_parentUniqueKey_theText', 'U') IS NOT NULL drop table #_numberKey_parentUniqueKey_theText
;
select distinct
	g.number_key
	,g.parent_unique_key
	--,g.unique_key
	,g.the_date as the_date_g
	--,ji.any_comments
    ,'xxxx' [x]
    ,l.the_text
    --,l.*
	
into #_numberKey_parentUniqueKey_theText
from #g g
join jms_apd_insp_filteredToPop ji on ji.unique_key = g.unique_key
join hcfl_src..lhn_tab l 
	on l.number_key = ji.number_key
	and l.user_id = ji.inspector
	and l.date_entered = ji.the_date
where
	1=1
	and l.data_level = 'comment'
	--and l.number_key = 'CE10015459'
--order by g.number_key,g.the_date
;


;IF OBJECT_ID('tempdb.dbo.#numberKey_parentUniqueKey_theText', 'U') IS NOT NULL drop table #numberKey_parentUniqueKey_theText

select
	number_key
	,parent_unique_key
	,the_date_g as the_date
	,'®'+STUFF ((
		select '®®' + a2.the_text
		from #_numberKey_parentUniqueKey_theText a2
		where 
			a2.parent_unique_key = a1.parent_unique_key
		order by the_date_g
		for XML PATH('')
    ), 1, 1, '') the_text
into #numberKey_parentUniqueKey_theText
from #_numberKey_parentUniqueKey_theText a1
;

update i set
	i.insp_result_comm = trim(' ®' from coalesce(i.insp_result_comm,'') + '®®lhn_tab_comments:'+trim('®' from a.the_text))
from aatable_permit_insp i
join #numberKey_parentUniqueKey_theText a 
    on a.parent_unique_key = i.client_unique_id
;





--remaining comments
;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table aatable_permit_comment
;
insert into aatable_permit_comment
SELECT
     pnum.permitnum PERMITNUM
    ,L.data_level+':'+ coalesce( convert(varchar(max),L.the_text),'') COMMENTS
    ,coalesce(L.user_x,L.user_id) ADDEDBY
    ,try_convert(datetime,L.date_entered) ADDEDDATE
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
--join hcfl_src..lhn_tab l on l.number_key = pmap.number_key
join (
    select *
    from hcfl_src..lhn_tab l
    where
        1=1
        and not exists (
            select 1
            from #_numberKey_parentUniqueKey_theText
            where 
                1=1
                and number_key = l.number_key
                and the_text = l.the_text
                and l.data_level = 'comment'
        )
) l on l.number_key = pmap.number_key
;

;update aatable_permit_comment set addedby = 'Spriggs, Teddy' where addedby =  'Spriggs, Edward ''Teddy'''
;

--duplicate comments into cbs records
insert into aatable_permit_comment
select 
    pnum.PERMITNUM
	,a.COMMENTS
	,a.ADDEDBY	
    ,a.ADDEDDATE
from aatable_permit_comment a
join jms_numberKey_permitnum pmap on pmap.permitnum = a.permitnum
join AATABLE_PERMIT_HISTORY pnum on pnum.permitnum = a.permitnum + '-CBS'
;
