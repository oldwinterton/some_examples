--cbs
;IF OBJECT_ID('tempdb.dbo.#hbcode4_aatablePermitFeeSetup', 'U') IS NOT NULL drop table #hbcode4_aatablePermitFeeSetup
;
select distinct
	 pnum.permitnum
    ,pnum.tt_record
    
	,'xx' [1]
	,n0.Date_080 as dtPart1           
	,m0.Mon_037 as curPart1          
	,n0.Date_086 as dtPart1Start      
	,n0.Date_090 as dtPart1End        
	,t0.Text_019 as strOrderPart1     
	,m0.Mon_041 as curPart1Sub     
	,(datediff(day,n0.Date_086 , coalesce(n0.Date_090,getdate()) )  ) * m0.mon_037 curPart1Sub_calc
	
	,'xx' [2]
	,n0.Date_081 as dtPart2           
	,m0.Mon_038 as curPart2          
	,n0.Date_087 as dtPart2Start      
	,n0.Date_091 as dtPart2End        
	,t0.Text_024 as strOrderPart2     
	,m0.Mon_042 as curPart2Sub       
	,(datediff(day,n0.Date_087 , coalesce(n0.Date_091,getdate()) )  ) * m0.Mon_038 curPart2Sub_calc
	
	,'xx' [3]
	,n0.Date_082 as dtPart3           
	,m0.Mon_039 as curPart3          
	,n0.Date_088 as dtPart3Start          
	,n0.Date_092 as dtPart3End     
	,t0.Text_025 as strOrderPart3     
	,m0.Mon_043 as curPart3Sub       
	,(datediff(day,n0.Date_088 , coalesce(n0.Date_092,getdate()) )  ) * m0.Mon_039 curPart3Sub_calc
	
	,'xx' [4]
	,n0.Date_083 as dtPart4           
	,m0.Mon_040 as curPart4     
	,n0.Date_089 as dtPart4Start   
	,n0.Date_093 as dtPart4End      
	,t0.Text_028 as strOrderPart4     
	,m0.Mon_044 as curPart4Sub       
	,(datediff(day,n0.Date_089 , coalesce(n0.Date_093,getdate()) )  ) * m0.Mon_040 curPart4Sub_calc
	   
into #hbcode4_aatablePermitFeeSetup
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum+'-cbs' = pnum.PERMITNUM
join jms_apd_base_filtered a on a.NUMBER_KEY = pmap.number_key
join hcfl_src.dbo.apd_mon0 m0 on m0.NUMBER_KEY = a.NUMBER_KEY
left join hcfl_src.dbo.apd_num0 n0 on n0.number_key = a.number_key
left join hcfl_src.dbo.apd_txt0 t0 on t0.number_key = a.number_key
where
	1=1
	and pnum.permitnum like'%-cbs'
    --and pmap.number_key = 'CE11005977'
;

;IF OBJECT_ID('accelaConv7.dbo.cl_cbs_feeCalculation', 'U') IS NOT NULL drop table cl_cbs_feeCalculation
;
with g as (
    select distinct
        pnum.permitnum
        ,pnum.tt_record
        
        ,'Part I' as order_part 
        ,dtPart1 onOrBeforeDate
        ,curPart1 fineAmount
        ,strOrderPart1 orderText
        ,dtPart1Start startDate
        ,dtPart1End endDate
        --,curPart1Sub subtotal
        ,curPart1Sub_calc subtotal
        ,(case when dtPart1End is null then 'Yes' else 'No' end) addFee
    from #hbcode4_aatablePermitFeeSetup pnum
    WHERE
        1=1
        and dtpart1 is not null

    UNION

    select distinct
        pnum.permitnum
        ,pnum.tt_record
        
        ,'Part II' as order_part 
        ,dtPart2 onOrBeforeDate
        ,curPart2 fineAmount
        ,strOrderPart2 orderText
        ,dtPart2Start startDate
        ,dtPart2End endDate
        --,curPart2Sub subtotal 
        ,curPart2Sub_calc subtotal
        ,(case when dtPart2End is null then 'Yes' else 'No' end) addFee
    from #hbcode4_aatablePermitFeeSetup pnum
    WHERE
        2=2
        and dtpart2 is not null

    UNION

    select distinct
        pnum.permitnum
        ,pnum.tt_record
        
        ,'Part III' as order_part 
        ,dtPart3 onOrBeforeDate
        ,curPart3 fineAmount
        ,strOrderPart3 orderText
        ,dtPart3Start startDate
        ,dtPart3End endDate
        --,curPart3Sub subtotal
        ,curPart3Sub_calc subtotal
        ,(case when dtPart3End is null then 'Yes' else 'No' end) addFee
    from #hbcode4_aatablePermitFeeSetup pnum
    WHERE
        3=3
        and dtpart3 is not null

    UNION

    select distinct
        pnum.permitnum
        ,pnum.tt_record
        
        ,'Part IV' as order_part 
        ,dtPart4 onOrBeforeDate
        ,curPart4 fineAmount
        ,strOrderPart4 orderText
        ,dtPart4Start startDate
        ,dtPart4End endDate
        --,curPart4Sub subtotal 
        ,curPart4Sub_calc subtotal
        ,(case when dtPart4End is null then 'Yes' else 'No' end) addFee
    from #hbcode4_aatablePermitFeeSetup pnum
    WHERE
        4=4
        and dtpart4 is not null

)
select
	 pnum.permitnum
    ,pnum.tt_record
    
    ,pnum.order_part
    ,convert(varchar(10),pnum.onOrBeforeDate,101) onOrBeforeDate
    ,pnum.fineAmount
    ,pnum.orderText
    ,convert(varchar(10),pnum.startDate,101) startDate
    ,convert(varchar(10),pnum.endDate,101) endDate
    ,pnum.subtotal
    ,pnum.addFee
	,ROW_NUMBER() OVER(PARTITION BY pnum.permitnum order by pnum.permitnum) AS row_num
into cl_cbs_feeCalculation
from g pnum
where
	1=1
    --and permitnum = 'CE11005977-CBS'
;