-- rem `print` has a 4000 char limit.
set NOCOUNT on
;
go
;

IF OBJECT_ID('tempdb.dbo.#ttRecord_cfGroup_cfSubgroup_cfFieldname_isReq_len_dtype_ddsql ', 'U') IS NOT NULL DROP TABLE #ttRecord_cfGroup_cfSubgroup_cfFieldname_isReq_len_dtype_ddsql
;

;with _unclosedCustomFieldDdVals as (
	select 
		dv.BIZDOMAIN
		,dv.sort_order
		,x.SERV_PROV_CODE
		,x.level1 as customfield_groupName --R1_CHCKBOX_CODE
		,x.level2 as customField_subGroup --r1_checkbox_type 
		--,x.level3 as [??] --APPLICATION, FEEATTACHEDTABLE
		,x.level4 as customField_fieldName
		,dv.BIZDOMAIN_VALUE
	from XBIZDOMAIN_DDLIST x
	join RBIZDOMAIN_VALUE dv on (dv.BIZDOMAIN = x.BIZDOMAIN) and (dv.serv_prov_code = x.SERV_PROV_CODE)
	where
		1=1
        --and dv.REC_STATUS <> 'I'
		--and x.LEVEL1 = 'EH_ARTIF_PMT'
), unclosedCustomFieldDdVals as ( 
    select distinct
        a1.SERV_PROV_CODE
        ,a1.bizdomain
        ,a1.customfield_groupName
        ,a1.customField_subGroup
        ,a1.customField_fieldName
        ,'( case ' +char(10) + stuff(
            (select distinct
                '        ' + ' when 1=0 then ''' + cast(a2.bizdomain_value as varchar(max)) + '''' + char(10)
            from _unclosedCustomFieldDdVals a2 with(nolock)
            where 
                a2.bizdomain = a1.bizdomain
            --order by a2.sort_order
            FOR XML PATH('')
            )
            , 1, 1, ''
        ) as _ddSql --+ '    else null end' + char(10) + ')' as liDesc

    from _unclosedCustomFieldDdVals a1
)--, ttRecord_cfGroup_cfSubgroup_cfFieldname_isReq_len_dtype_ddsql as (
SELECT
	app.R1_APP_TYPE_ALIAS tt_record
	,app.R1_CHCKBOX_CODE customfield_groupName
	,cf.r1_checkbox_type customField_subGroup
	,cf.r1_checkbox_desc customField_fieldName
	,cf.R1_ATTRIBUTE_VALUE_REQ_FLAG isRequired
	,cf.MAX_LENGTH 
	,( case
        when r1_checkbox_ind = 1 then 'Text'
        when r1_checkbox_ind = 2 then 'Date'
        when r1_checkbox_ind = 3 then 'Yes/No'
        when r1_checkbox_ind = 4 then 'Number'
        when r1_checkbox_ind = 5 then 'Drop Down'
        when r1_checkbox_ind = 6 then 'Text Area'
        when r1_checkbox_ind = 7 then ''
        when r1_checkbox_ind = 8 then ''
        when r1_checkbox_ind = 9 then 'CheckBox'
        else null
        end
    ) as DATA_TYPE
	,(case 
		when cf.R1_ATTRIBUTE_VALUE_REQ_FLAG = 'Y' then replace(ddvals._ddSql + '        end'+char(10)+'     )','when 1=0 then','when 1=1 then')
		else ddvals._ddSql + '        else null' + char(10) + '        end' + char(10) + '     )'
		end
	) as ddsql
	,cf.R1_DISPLAY_ORDER as sort_order
into #ttRecord_cfGroup_cfSubgroup_cfFieldname_isReq_len_dtype_ddsql 
from R2CHCKBOX cf
join r3apptyp app on app.R1_CHCKBOX_CODE = cf.r1_checkbox_code and app.SERV_PROV_CODE = cf.SERV_PROV_CODE
join AA_MASK_DEF mask on mask.mask_name = app.CAP_MASK_NAME and mask.SERV_PROV_CODE = app.SERV_PROV_CODE
join (select distinct tt_record from AATABLE_PERMIT_HISTORY) pnum on pnum.TT_RECORD = app.R1_APP_TYPE_ALIAS
left join unclosedCustomFieldDdVals ddVals 
	on ddvals.serv_prov_code = cf.SERV_PROV_CODE
	and ddvals.customfield_groupName = app.R1_CHCKBOX_CODE
	and ddvals.customField_subGroup = cf.r1_checkbox_type
	and ddvals.customField_fieldName = cf.r1_checkbox_desc
where
	1=1
    --and cf.rec_status <> 'I' --i inactive, a active
    and app.r1_app_type_alias in (
        --irrelevant; but permits filtering of tt_record for debugging. And I don't want to have to remember or look up "app.r1_app...".
        select distinct tt_record from AATABLE_PERMIT_HISTORY
    )
    and cf.r1_checkbox_group not in ('FEEATTACHEDTABLE')
order by 
	app.R1_APP_TYPE_ALIAS --  tt_record
	,app.R1_CHCKBOX_CODE  -- customfield_groupName
	,cf.r1_checkbox_type  -- customField_subGroup
	,cf.R1_DISPLAY_ORDER  -- sort_order
;
--select * from #ttRecord_cfGroup_cfSubgroup_cfFieldname_isReq_len_dtype_ddsql

;declare @tableOfContents varchar(4000) = '/*'+char(10)
;declare @tableToCreate varchar(1000)

;declare @distinct_ttRecord     varchar(255)
;declare @distinct_group        varchar(255)
;declare @distinct_subgroup    varchar(255)

;declare @cf_sql                varchar(4000)
;DECLARE @tt_record             varchar(255)
;DECLARE @customfield_groupName varchar(255)
;DECLARE @customField_subGroup  varchar(255)
;DECLARE @customField_fieldName varchar(255)
;DECLARE @isRequired            varchar(1)
;DECLARE @MAX_LENGTH            int
;DECLARE @DATA_TYPE             varchar(50)
;DECLARE @ddsql                 varchar(500)
;DECLARE @sort_order            int
;


-- expected output:
----<distinct tt_record>
----<distinct tt_record> - <distinct group>
--select distinct
--    pnum.tt_record
--    --<distinct subgroup>
--    ,<null or value> as [field1]
--    ,<null or value> as [field2]
--    ,...
--from AATABLE_PERMIT_HISTORY pnum
--where
--	1=1

;DECLARE distinct_ttRecords_cursor CURSOR FOR select distinct tt_record from #ttRecord_cfGroup_cfSubgroup_cfFieldname_isReq_len_dtype_ddsql order by 1
;
open distinct_ttRecords_cursor;
fetch next from distinct_ttRecords_cursor into @distinct_ttRecord;
while @@FETCH_STATUS = 0 
BEGIN
	set @tableOfContents = @tableOfContents + @distinct_ttRecord + char(10);
	set @tableToCreate = 'cf_' + replace(replace(replace(@distinct_ttRecord,' ','_'),'-','_'),'/','_')

    declare distinct_groupName_cursor cursor for 
        SELECT distinct
            customfield_groupName
        from #ttRecord_cfGroup_cfSubgroup_cfFieldname_isReq_len_dtype_ddsql
        where 
            tt_record = @distinct_ttRecord
    ;
    open distinct_groupName_cursor;
    fetch next from distinct_groupName_cursor into @distinct_group;
    while @@FETCH_STATUS = 0
    BEGIN
        print '--' + @distinct_ttRecord + ' - ' + @distinct_group;
        print 'print ''' + @distinct_ttRecord + ' - ' + @distinct_group + ''';'
        print 'IF OBJECT_ID('''+@tableToCreate+''', ''U'') IS NOT NULL DROP TABLE '+@tableToCreate+char(10)+';'
        print 'select distinct'
        print '    pnum.permitNum'
        print '    ,pnum.tt_record'
        
        declare distinct_subgroup_cursor cursor for
            select distinct
                customField_subGroup
            from #ttRecord_cfGroup_cfSubgroup_cfFieldname_isReq_len_dtype_ddsql
            WHERE
                tt_record = @distinct_ttRecord
                and customfield_groupName = @distinct_group
        ;
        open distinct_subgroup_cursor;
        fetch next from distinct_subgroup_cursor into @distinct_subgroup;
        while @@FETCH_STATUS = 0
        BEGIN
            print ''
            print '    --' + @distinct_subgroup;
            
            declare cf_sql_cursor CURSOR FOR
                select 
                    (case 
                        when isRequired = 'N' then case
                            when data_type = 'Drop Down' then ddsql
                            else 'null' 
                            end                            
                        else case data_type
                            when 'Text' then ''''''
                            when 'Date' then '''1900-01-01'''
                            when 'Yes/No' then '''Yes'''
                            when 'Number' then '0'
                            when 'Drop Down' then ddsql
                            when 'Text Area' then ''''''
                            --when ''
                            --when ''
                            when 'CheckBox' then '1'
                            end
                        end
                    ) + ' as ' + '[' + customField_fieldName + ']' + ' --'+data_type + ' ' + (case when isRequired='Y' then ' req ' else '' end) + (case when max_length > 0 then convert(varchar,max_length) else '' end)
                from #ttRecord_cfGroup_cfSubgroup_cfFieldname_isReq_len_dtype_ddsql
                where
                    tt_record = @distinct_ttRecord
                    and customfield_groupName = @distinct_group
                    and customField_subGroup = @distinct_subgroup
                order by
                    sort_order
            ;
            open cf_sql_cursor;
            fetch next from cf_sql_cursor into @cf_sql;
            while @@FETCH_STATUS = 0
            BEGIN
                
                print '    ,' + @cf_sql;
                fetch next from cf_sql_cursor into @cf_sql;
            END
            CLOSE cf_sql_cursor;
            DEALLOCATE cf_sql_cursor;
            fetch next from distinct_subgroup_cursor into @distinct_subgroup
        END
        CLOSE distinct_subgroup_cursor;
        DEALLOCATE distinct_subgroup_cursor;
    
        fetch next from distinct_groupName_cursor into @distinct_group;
    END
    CLOSE distinct_groupName_cursor;
    DEALLOCATE distinct_groupName_cursor;
    
	print 'into ' + @tableToCreate
	print 'from AATABLE_PERMIT_HISTORY pnum'
	print 'where'
	print '    1=1'
	print ';'
	print ''
    print (
        '    --ensure_fields_arent_too_long'
        +char(10)+'declare @table_name varchar(100) = '''+@tableToCreate+''' '
        +char(10)+''
        +char(10)+'declare @cutoff int = 50;'
        +char(10)+'DECLARE long_colname_cursor CURSOR for ('
        +char(10)+'	select '
        +char(10)+'		column_name'
        +char(10)+'	from INFORMATION_SCHEMA.columns '
        +char(10)+'	where '
        +char(10)+'		table_name = @table_name'
        +char(10)+'		and len(column_name) > @cutoff'
        +char(10)+');'
        +char(10)+''
        +char(10)+'declare @column_name_old varchar(200);'
        +char(10)+'declare @modString varchar(200);'
        +char(10)+'declare @newname varchar(200);'
        +char(10)+''
        +char(10)+''
        +char(10)+'OPEN long_colname_cursor'
        +char(10)+'FETCH NEXT FROM long_colname_cursor INTO @column_name_old'
        +char(10)+'    WHILE @@FETCH_STATUS = 0  '
        +char(10)+'		begin'
        +char(10)+'			set @modString = ''dbo.'' + @table_name + ''.'' + @column_name_old;'
        +char(10)+'			set @newname = left(@column_name_old, @cutoff)'
        +char(10)+'			EXEC sp_rename @modString, @newname, ''COLUMN'';'
        +char(10)+'			FETCH NEXT FROM long_colname_cursor   INTO @column_name_old'
        +char(10)+'		end'
        +char(10)+'CLOSE long_colname_cursor'
        +char(10)+'DEALLOCATE long_colname_cursor'
        +char(10)+';'
        +char(10)+'go'
        +char(10)+';'
    )
    FETCH NEXT FROM distinct_ttRecords_cursor into @distinct_ttRecord
	
END
CLOSE distinct_ttRecords_cursor;
DEALLOCATE distinct_ttRecords_cursor;

set @tableOfContents = @tableOfContents + '*/' + char(10) + char(10)
print @tableOfContents
;
go
;
set NOCOUNT off;
go