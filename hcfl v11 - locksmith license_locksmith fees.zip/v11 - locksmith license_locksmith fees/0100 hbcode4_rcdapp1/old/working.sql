Locksmith Initial Application, Locksmith Renewal > inspection group:LOC_INSP > site visit > checklistGroup:LOC_INSP 
    > ENF_LK_CK=_A > INSPECTION FORM
        Name of Locksmith Services Business
        Date of Inspection
        Time of Inspection
        Telephone Number
        Physical Address
        City
        Zip
        Business Owner Name
        License #
        Inspection Remarks
    > ENF_LK_CK=_B > REMARKS
        Inspection Remarks

Neither is guidesheet material!
Therefore: shove all violations into corresponding inspection result comments field
