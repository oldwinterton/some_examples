/*
initial table
logical output
*/

--initial table 
drop table ##_hbcode4_aatablePermitFeeSetup
go

select distinct
	 a.number_key
	,a.CALC_FEES
	,a.ADDL_FEES
	,a.TOT_FEE
	,a.TOT_PAY
	,a.BALANCE
	,'||||' [|]
    
	,'xx' [1]
	,n.Date_080 as dtPart1           
	,m.Mon_037 as curPart1          
	,n.Date_086 as dtPart1Start      
	,n.Date_090 as dtPart1End        
	,m.Mon_041 as curPart1Sub     
	,datediff(day,n.Date_086 , coalesce(n.Date_090,getdate()) ) datedifff
	,coalesce(		(datediff(day,n.Date_086 , coalesce(n.Date_090,getdate()) )  ) * m.mon_037		,0) curPart1Sub_calc
	
	,'xx' [2]
	,n.Date_081 as dtPart2           
	,m.Mon_038 as curPart2          
	,n.Date_087 as dtPart2Start      
	,n.Date_091 as dtPart2End        
	,m.Mon_042 as curPart2Sub       
	,datediff(day,n.Date_087 , coalesce(n.Date_091,getdate()) ) datedifff2
	,coalesce(		(datediff(day,n.Date_087 , coalesce(n.Date_091,getdate()) )  ) * m.Mon_038		,0) curPart2Sub_calc
	
	,'xx' [3]
	,n.Date_082 as dtPart3           
	,m.Mon_039 as curPart3          
	,n.Date_088 as dtPart3Start          
	,n.Date_092 as dtPart3End     
	,m.Mon_043 as curPart3Sub       
	,coalesce(		(datediff(day,n.Date_088 , coalesce(n.Date_092,getdate()) )  ) * m.Mon_039		,0) curPart3Sub_calc
	
	,'xx' [4]
	,n.Date_083 as dtPart4           
	,m.Mon_040 as curPart4     
	,n.Date_089 as dtPart4Start   
	,n.Date_093 as dtPart4End        
	,m.Mon_044 as curPart4Sub       
	,coalesce(		(datediff(day,n.Date_089 , coalesce(n.Date_093,getdate()) )  ) * m.Mon_040		,0) curPart4Sub_calc
	
	,'xx' [other]
	,m.Mon_045 as curFineTotal      
	,m.Mon_046 as curAddCosts       
	,m.Mon_047 as curOtherFees      
	,coalesce(m.Mon_048,0) as curReduction     
	,m.Mon_049 as curDynamic        
	,m.Mon_050 as curDumpFee        
	,m.Mon_051 as curOGFee          
	,m.Mon_052 as curAbate1         
	,m.Mon_053 as curAbate2         
	,m.Mon_054 as curAbate3         
	,m.Mon_055 as curAbate4         
	,m.Mon_056 as curAbate5         
	,m.Mon_057 as curAbate6         
	,m.Mon_058 as curAbate7         
	,m.Mon_059 as curAbate8         
	,m.Mon_060 as curAbate9         
	,m.Mon_061 as curAbate10        
	,m.Mon_062 as curSEUrecording   
	,m.Mon_063 as curSEUdumpster    
	,m.Mon_064 as curDebrisDisp     
	,m.Mon_065 as curTireDisp       
	,m.Mon_066 as curAbateInterest  
	,m.Mon_067 as curAbateSub       
	,m.Mon_068 as curAbateMail      
	,coalesce(m.Mon_069,0) as curNpi
	,m.Mon_080 as curFineCap        
	,'||||' [||]
	,convert(money, (case 
		when m.Mon_080 is not null 
		and m.Mon_080 > 0
		and m.Mon_080 < (	
			coalesce(		(datediff(day,n.Date_086 , coalesce(n.Date_090,getdate()) )  ) * m.mon_037		,0)
			+coalesce(		(datediff(day,n.Date_087 , coalesce(n.Date_091,getdate()) )  ) * m.Mon_038		,0)
			+coalesce(		(datediff(day,n.Date_088 , coalesce(n.Date_092,getdate()) )  ) * m.Mon_039		,0)
			+coalesce(		(datediff(day,n.Date_089 , coalesce(n.Date_093,getdate()) )  ) * m.Mon_040		,0)
			- coalesce(m.Mon_048,0)
		)
		then m.Mon_080
		else 
		(	
			coalesce(		(datediff(day,n.Date_086 , coalesce(n.Date_090,getdate()) )  ) * m.mon_037		,0)
			+coalesce(		(datediff(day,n.Date_087 , coalesce(n.Date_091,getdate()) )  ) * m.Mon_038		,0)
			+coalesce(		(datediff(day,n.Date_088 , coalesce(n.Date_092,getdate()) )  ) * m.Mon_039		,0)
			+coalesce(		(datediff(day,n.Date_089 , coalesce(n.Date_093,getdate()) )  ) * m.Mon_040		,0)
		)
		end - coalesce(m.Mon_048,0)
	)) [CBS records: lesser_of_subCalcsLessCurReduction_or_curFineCap aka "General Code Violation Fines"]
	,convert(money, coalesce(m.Mon_069,0)) as [CE records: abatement_fee aka "fees associated with abatements"]
	,convert(money, (case when a.tot_pay > 0 and m.mon_069 > 0 then a.tot_pay - m.mon_069 else 0 end)) as [CE records: abatement_interest aka "fees associated with interest calculations on abatements"]
into ##_hbcode4_aatablePermitFeeSetup
from (select distinct * from hcfl_src.dbo.apd_base where 1=1 and comp_type = 'HBCODE' and version = '4') a
join hcfl_src.dbo.apd_mon0 m on m.NUMBER_KEY = a.NUMBER_KEY
left join hcfl_src.dbo.apd_num0 n on n.number_key = a.number_key
left join hcfl_src.dbo.apd_txt0 t on t.number_key = a.number_key
where
	1=1
	--and a.number_key = 'CE18011040'
;


--logical output

select
    [number_key]
    ,[CALC_FEES]
    ,[ADDL_FEES]
    ,[TOT_FEE]
    ,[TOT_PAY]
    ,[BALANCE]
	,'xxxx' [x]
    ,[curReduction]
    ,[curFineCap]
    ,[curDynamic]
    
	,[other]
    ,[curFineTotal]
    ,[curAddCosts]
    ,[curOtherFees]
    --,[curDumpFee]
    --,[curOGFee]
    --,[curAbate1]
    --,[curAbate2]
    --,[curAbate3]
    --,[curAbate4]
    --,[curAbate5]
    --,[curAbate6]
    --,[curAbate7]
    --,[curAbate8]
    --,[curAbate9]
    --,[curAbate10]
    --,[curSEUrecording]
    --,[curSEUdumpster]
    --,[curDebrisDisp]
    --,[curTireDisp]
    --,[curAbateInterest]
    ,[curAbateSub]
    --,[curAbateMail]
    ,[curNpi]
    ,'||||' [||]
    ,[CBS records: lesser_of_subCalcsLessCurReduction_or_curFineCap aka "General Code Violation Fines"] as [cbs:lesser fee]
    ,[CE records: abatement_fee aka "fees associated with abatements"] as [abatement_fee]
    ,[CE records: abatement_interest aka "fees associated with interest calculations on abatements"] as [interest]
    ,[curAddCosts]
	,'zzzz'[z]
	,case when curDynamic is not null and curDynamic <> 0 then curDynamic + addl_Fees
	else ([CBS records: lesser_of_subCalcsLessCurReduction_or_curFineCap aka "General Code Violation Fines"]
	+ [CE records: abatement_fee aka "fees associated with abatements"]
	+ [CE records: abatement_interest aka "fees associated with interest calculations on abatements"]
	+ curAddCosts
	+ addl_fees
	) end as my_calcd_fee
	
	,case when (case when curDynamic is not null and curDynamic <> 0 then curDynamic + addl_Fees
	else ([CBS records: lesser_of_subCalcsLessCurReduction_or_curFineCap aka "General Code Violation Fines"]
	+ [CE records: abatement_fee aka "fees associated with abatements"]
	+ [CE records: abatement_interest aka "fees associated with interest calculations on abatements"]
	+ curAddCosts
	+ addl_fees
	) end ) = tot_fee then 1 else 0 end as myCalc_matches_totFee
	,tot_fee
from ##_hbcode4_aatablePermitFeeSetup
where
	1=1
	and (
		   isnull([CBS records: lesser_of_subCalcsLessCurReduction_or_curFineCap aka "General Code Violation Fines"],0) > 0
		or isnull([CE records: abatement_fee aka "fees associated with abatements"],0) > 0
		or isnull([CE records: abatement_interest aka "fees associated with interest calculations on abatements"],0) > 0
	)

	and convert(money, 
		case when curDynamic is not null and curDynamic <> 0 then curDynamic + addl_Fees
	else ([CBS records: lesser_of_subCalcsLessCurReduction_or_curFineCap aka "General Code Violation Fines"]
	+ [CE records: abatement_fee aka "fees associated with abatements"]
	+ [CE records: abatement_interest aka "fees associated with interest calculations on abatements"]
	+ curAddCosts
	+ addl_fees
	) end 
	) <> converT(money,tot_fee)
	--and tot_pay > 0
	and curDynamic <> 0
;