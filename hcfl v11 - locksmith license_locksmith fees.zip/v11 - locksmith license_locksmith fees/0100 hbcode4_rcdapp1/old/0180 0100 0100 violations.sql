/* I intended for this to be guidesheets
but conversation yields that most of the violations , based on how accela is configured, are not guidesheet items, rather they seem to belong to comments on an inspection.
Logic copied from elsewhere; calls given site visit a parent inspection, and subsequent rows (comments, other) its children.
For the violations: associates violations with their rows on apd_insp, then to the parent inspection.
Requires post-conversion logic to ensure line breaks occur.
*/
--determine child rows per inspection, then assert inspection type and inspection result based on those children
;IF OBJECT_ID('tempdb.dbo.#parents', 'U') IS NOT NULL drop table #parents
;IF OBJECT_ID('tempdb.dbo.#is_initial_site_visit', 'U') IS NOT NULL drop table #is_initial_site_visit
;IF OBJECT_ID('tempdb.dbo.#g', 'U') IS NOT NULL drop table #g
;IF OBJECT_ID('tempdb.dbo.#orphaned', 'U') IS NOT NULL drop table #orphaned
;IF OBJECT_ID('tempdb.dbo.#h', 'U') IS NOT NULL drop table #h
;IF OBJECT_ID('tempdb.dbo.#req_opt', 'U') IS NOT NULL drop table #req_opt
;
go

--;with parents
    --assumes inspections are site visits, and results are implied by the subsequent rows prior to the following site visit.
	select
		number_key
		,unique_key
		,date_ent
		,the_Date
		,action_ent
    into #parents
	from jms_apd_insp_filteredToPop
	where action_ent in ('SV','SSV','QCSV','LSV')
	--and number_key = 'CE18015425'
;
--), is_initial_site_visit as (
    --"initial site visiit" is an accela inspection type
	select
		b.UNIQUE_KEY
        ,b.action_ent
    into #is_initial_site_visit
	from jms_apd_base_filtered a
	outer apply (select top 1 * from jms_apd_insp_filteredToPop where NUMBER_KEY = a.NUMBER_KEY and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent,the_date) b
;
--),g as (
    select
        a.number_key
        ,a.item_id
        ,a.unique_key
        ,a.action_ent
        ,action_ent.DESCRIPTION action_ent_desc
        ,case when is_initial_site_visit.UNIQUE_KEY is not null then 1 else 0 end as is_initial_site_visit
        ,'xxxx' [ ]
        ,coalesce(b.unique_key,is_initial_site_visit.unique_key) parent_unique_key
        ,b.action_ent parent_action_ent
        ,(case 
            when is_initial_site_visit.UNIQUE_KEY is not null then 'Initial Site Visit'
            when a.ACTION_ENT in ('QCSV','LSV') then 'Quality Control Inspection'
            when  a.any_comments like '%re%inspect%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%re%check%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%annual%insp%'    then 'Annual Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%post%hearing%'    then 'Post-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%pre%hearing%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%hear%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%follow%up%'    then 'Follow-up Inspection' --I don't know about pre vs post hearing
            else 'Inspection'
            end		
        ) as inspection_type
        ,(case 
            --when a.ACTION_ENT in ('SV','SSV','QCSV','LSV') then null
            when a.ACTION_ENT = 'NOVR' then 'Notice of Violation Requested'
            when a.ACTION_ENT = 'NOVC' then 'NOV issued'
            when a.ACTION_ENT = 'NOVB' then 'Combo Issued'
            when a.action_ent = 'ECIT' then 'Citation Issued'
            when a.ACTION_ENT = 'COMP' then 'Compliant'
            when a.ACTION_ENT = 'VIOL' then 'Violation'
            when A.ACTION_ENT in ('CA','CNCL') then 'No Violation'
            when a.any_comments like '%dead%animal%'	  then 'Extension'
            when a.any_comments like '%exten%'	  then 'Extension'
            when a.any_comments like '%violation%'  then 'Violation'
            when a.any_comments like '%non%compli%' then 'Not Compliant'
            when a.any_comments like '%send%nov%'   then 'NOV Issued'
            when a.any_comments like '%req%nov%'    then 'Notice of Violation Requested'
            when a.any_comments like '%cont%fin%'    then 'Not Compliant' --continue fines
            else null
            end
        ) as inspection_result
        
        ,'xxxx' [2]
        ,a.date_ent
        ,a.the_date
        ,'xxxx'[3]
        ,a.any_comments
    into #g
    from jms_apd_insp_filteredToPop a
    outer apply (select top 1 * from #parents where number_key = a.number_key and the_date <= a.the_date and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent desc,the_date desc) b
    left join jms_actionEnt_passFail action_ent on action_ent.action_ent = a.action_ent
    left join #is_initial_site_visit is_initial_site_visit on is_initial_site_visit.UNIQUE_KEY = a.UNIQUE_KEY
    where
        1=1
        --and a.action_ent not in ('SV','SSV','QCSV','LSV')
        --and a.number_key = 
        --	--'CE03003081'
        --	--'CE22014264'
        --	'CE22014971'
    --order by --a.date_ent,a.the_Date,case when a.action_ent in ('SV','SSV','QCSV','LSV') then 1 else 2 end, l.THE_TEXT
    --	a.UNIQUE_KEY
;




--), h as (
    select distinct
         a1.NUMBER_KEY
        ,a1.UNIQUE_KEY
        ,a1.action_ent
        ,a1.inspection_type
        ,coalesce(b.inspection_result,a1.inspection_result,'Not Set') inspection_result
        ,trim('^|' from stuff((
            select 
                '^|^' + cast(
                    trim(replace(replace(replace(replace(   isnull(a2.any_comments,'')   ,'"',''''''),'''',''),char(13),''),char(10),'®')) 
                    as varchar(max)
                )
            from #g a2 with(nolock)
            where 
                a2.parent_unique_key = a1.parent_unique_key
            group by a2.any_comments
            order by a2.any_comments
            FOR XML PATH('')
         ), 1, 1, '')) as any_comments
    into #h
    from #g a1
    outer apply (
        select top 1 *
        from #g
        where
            parent_unique_key = a1.UNIQUE_KEY
            and inspection_result is not null
    ) b
    where
        1=1
        and a1.ACTION_ENT in ('SV','SSV','QCSV','LSV')
        --and a1.number_key = 'CE17015692'
    ;

    --order by a.UNIQUE_KEY
--)
;

--;with cte_violations as (
;IF OBJECT_ID('tempdb.dbo.#_violations', 'U') IS NOT NULL drop table #_violations
;
select distinct
	g.NUMBER_KEY
    ,g.parent_unique_key
    ,g.unique_key --the inspection the violation will be associated with
	,g.item_id
	,i.the_date
	,convert(varchar(max),tc.notation) notation
	,convert(varchar(max),tc.the_text) the_text
	,i.approved
into #_violations
from #g g
join hcfl_src..apd_itms i
    on  i.RECORD_TYPE = 'CD'
    and i.NUMBER_KEY = g.NUMBER_KEY
    and year(i.THE_DATE) = year(g.the_date) and month(i.THE_DATE) = month(g.the_date) and day(i.THE_DATE) = day(g.THE_DATE)
    and i.ITEM_ID = g.ITEM_ID
left join hcfl_src..tab_cond tc on tc.ELEMENT_KEY = i.ITEM_ID
where
	1=1
    and i.NUMBER_KEY is not null
;
;IF OBJECT_ID('tempdb.dbo.#violations', 'U') IS NOT NULL drop table #violations
;
select distinct
	g.NUMBER_KEY
    ,g.parent_unique_key
    ,g.item_id
	,i.the_date
	,replace(replace(replace(replace(     convert(varchar(max),tc.notation)     ,'"',''''''),'''',''),char(13),''),char(10),'®') notation
	,replace(replace(replace(replace(     convert(varchar(max),tc.the_text)     ,'"',''''''),'''',''),char(13),''),char(10),'®') the_text
	,i.approved
into #violations
from #g g
join hcfl_src..apd_itms i
    on  i.RECORD_TYPE = 'CD'
    and i.NUMBER_KEY = g.NUMBER_KEY
    and year(i.THE_DATE) = year(g.the_date) and month(i.THE_DATE) = month(g.the_date) and day(i.THE_DATE) = day(g.THE_DATE)
    and i.ITEM_ID = g.ITEM_ID
left join hcfl_src..tab_cond tc on tc.ELEMENT_KEY = i.ITEM_ID
where
	1=1
    and i.NUMBER_KEY is not null
;
/*
from here:
notation => guide sheets asi
I think, then: the_text => guide sheet asit ?
I think guidesheet things arent configured?
Is the record type or subtype or something mappable into the guidesheets? 
then the notation to ASI
then the_text to ASIT:inspector_comments?

*/

;IF OBJECT_ID('tempdb.dbo.#violations_stuffd', 'U') IS NOT NULL drop table #violations_stuffd
--;with g as (
SELECT
    number_key
    ,parent_unique_key
    ,replace(replace(replace(replace(   
        convert(varchar(2000),trim('®®' from STUFF ((
            select '®®' + isnull(g2.item_id + '®','') + isnull(g2.notation + '®','') + isnull(g2.the_text,'')
            from #violations g2
            where 
                1=1
                and g2.parent_unique_key = g1.parent_unique_key

            for XML PATH('')
        ), 1, 1, '')))
    ,'"',''''''),'''',''),char(13),''),char(10),'') as COMMENTS
into #violations_stuffd
from #violations g1
where
	1=1
	--and number_key = 'CE17002421'
----this commented out logic must be used post-conversion
--)
--select 
--	number_key
--	,parent_unique_key
--	,comments
--	,replace(replace(replace(comments,'®',char(10)),'&#x0D;&#x0D;',char(10)),'&#x0D;','') c
--into #violations_stuffd
--from g 
;


--select top 1000 i.INSP_NUMBER,isnull(i.insp_result_comm,'') + '®®®' + a.COMMENTS
update i set i.insp_result_comm = i.insp_result_comm + '®®®' + a.comments
from #violations_stuffd a --43003
join aatable_permit_insp i on i.CLIENT_UNIQUE_ID = a.parent_unique_key --43003
where 
    1=1
    --and i.insp_number = 25
;

/* --for post conversion
update a set
    <field> = replace(replace(replace( <field> ,'®',char(10)),'&#x0D;&#x0D;',char(10)),'&#x0D;','')
from <table>
;
*/