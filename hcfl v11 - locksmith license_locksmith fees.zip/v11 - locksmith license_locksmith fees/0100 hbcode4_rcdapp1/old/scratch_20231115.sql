/*;IF OBJECT_ID('hcfl_src.dbo.jms_whichAddressEndsFirstAddress', 'U') IS NOT NULL drop table jms_whichAddressEndsFirstAddress
;IF OBJECT_ID('hcfl_src.dbo.jms_whichAddressEndsFirstAddress2', 'U') IS NOT NULL drop table jms_whichAddressEndsFirstAddress2

;
select distinct
	ADDRESS_1 
	,ADDRESS_2
	,ADDRESS_3
	,ADDRESS_4

	,(case 
		--when trim(reverse(substring(reverse(trim(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(address_1,'0',''),'1',''),'2',''),'3',''),'4',''),'5',''),'6',''),'7',''),'8',''),'9',''))),1,3))) in ('AL','AK','AS','AZ','AR','CA','CO','CT','DE','DC','FL','GA','GU','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','MP','OH','OK','OR','PA','PR','RI','SC','SD','TN','TX','UT','VT','VA','VI','WA','WV','WI','WY')
		--then ADDRESS_1
		when trim(reverse(substring(reverse(trim(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(address_2,'0',''),'1',''),'2',''),'3',''),'4',''),'5',''),'6',''),'7',''),'8',''),'9',''))),1,3))) in ('AL','AK','AS','AZ','AR','CA','CO','CT','DE','DC','FL','GA','GU','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','MP','OH','OK','OR','PA','PR','RI','SC','SD','TN','TX','UT','VT','VA','VI','WA','WV','WI','WY')
		then 2
		when trim(reverse(substring(reverse(trim(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(address_3,'0',''),'1',''),'2',''),'3',''),'4',''),'5',''),'6',''),'7',''),'8',''),'9',''))),1,3))) in ('AL','AK','AS','AZ','AR','CA','CO','CT','DE','DC','FL','GA','GU','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','MP','OH','OK','OR','PA','PR','RI','SC','SD','TN','TX','UT','VT','VA','VI','WA','WV','WI','WY')
		then 3
		when trim(reverse(substring(reverse(trim(replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(address_4,'0',''),'1',''),'2',''),'3',''),'4',''),'5',''),'6',''),'7',''),'8',''),'9',''))),1,3))) in ('AL','AK','AS','AZ','AR','CA','CO','CT','DE','DC','FL','GA','GU','HI','ID','IL','IN','IA','KS','KY','LA','ME','MD','MA','MI','MN','MS','MO','MT','NE','NV','NH','NJ','NM','NY','NC','ND','MP','OH','OK','OR','PA','PR','RI','SC','SD','TN','TX','UT','VT','VA','VI','WA','WV','WI','WY')
		then 4
		else -1
		end
	) as which_address_ends_first_address
into hcfl_src.dbo.jms_whichAddressEndsFirstAddress 
from hcfl_src.dbo.apd_peo a
where 
	1=1	
;


select ADDRESS_1 ,ADDRESS_2,ADDRESS_3,ADDRESS_4,1 which_address_is_it,trim(isnull(replace(address_1,'\',''),'')+' '+isnull(replacE(address_2,'\',''),'') ) full_address
--'
into hcfl_src.dbo.jms_whichAddressEndsFirstAddress2
from hcfl_src.dbo.jms_whichAddressEndsFirstAddress 
where
	which_Address_ends_first_address = 2

union

select ADDRESS_1 ,ADDRESS_2,ADDRESS_3,ADDRESS_4,1 ,trim(isnull(replace(address_1,'\',''),'')+' '+isnull(replace(address_2,'\',''),'')+' '+isnull(replace(address_3,'\',''),''))
--'
from jms_whichAddressEndsFirstAddress 
where
	which_Address_ends_first_address = 3

union

select ADDRESS_1 ,ADDRESS_2,ADDRESS_3,ADDRESS_4,1,trim(isnull(replace(address_1,'\',''),'')+' '+isnull(replace(address_2,'\',''),'')+' '+isnull(replace(address_3,'\',''),'')+' '+isnull(replace(address_4,'\',''),''))
--'
from jms_whichAddressEndsFirstAddress 
where
	which_Address_ends_first_address = 4

union

select ADDRESS_1 ,ADDRESS_2,ADDRESS_3,ADDRESS_4,2,trim(isnull(replace(address_3,'\',''),'')+isnull(replacE(address_4,'\',''),'') )
--'
from jms_whichAddressEndsFirstAddress 
where
	which_Address_ends_first_address = 2
	and '' <> trim(isnull(replace(address_3,'\',''),'')+' '+isnull(replacE(address_4,'\',''),'') )
--'

union

select ADDRESS_1 ,ADDRESS_2,ADDRESS_3,ADDRESS_4,2,trim(isnull(replacE(address_4,'\',''),'') )
--'
from jms_whichAddressEndsFirstAddress 
where
	which_Address_ends_first_address = 3
	and '' <> trim(isnull(replacE(address_4,'\',''),''))
;



select * from jms_whichAddressEndsFirstAddress2 order by 1,2

use accelaconv7
*/
select top 20
	a.number_key
	,a.name
	,a.RELATIONSHIP
	,a.address_1
	,a.address_2
	,a.address_3
	,a.address_4
	,a.zip
	,'xxxx'[x]

	,af.full_address
	,'xxxx'[s]
	,a.phone_1
	,a.phone_2
	,a.EMAIL_ADDR
	,a.notation
	,'zzzz' [z]
	,left((case 
		when a.address_1 not like '%[0-9]%' and len(   trim(replace(replace(replace(replace(   a.address_1   ,'"',''''''),'''',''),char(13),''),char(10),''))    ) > 1
		then trim(replace(replace(replace(replace(   a.address_1   ,'"',''''''),'''',''),char(13),''),char(10),'')) 

		else trim(replace(replace(   a.name    ,'  ',' '),'  ',' ')) 
			
		end
	),255)
from aatable_permit_history pnum --from (select distinct number_key permitnum from hcfl_src.dbo.apd_base) pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_peo a on a.number_key = pmap.number_key
left join hcfl_src.dbo.jms_whichAddressEndsFirstAddress2 af 
	on isnull(af.ADDRESS_1,'') = isnull(a.ADDRESS_1,'')
	and isnull(af.ADDRESS_2,'') = isnull(a.ADDRESS_2,'')
	and isnull(af.ADDRESS_3,'') = isnull(a.ADDRESS_3,'')
	and isnull(af.ADDRESS_4,'') = isnull(a.ADDRESS_4,'')
	and af.which_address_is_it = 1
where
	af.which_address_is_it = 1
;
