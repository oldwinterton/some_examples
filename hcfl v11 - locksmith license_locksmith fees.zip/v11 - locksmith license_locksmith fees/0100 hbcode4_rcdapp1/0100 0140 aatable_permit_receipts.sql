--create_PERMIT_RECEIPTS
IF OBJECT_ID('tempdb.dbo.##completed', 'U') IS NOT NULL 
insert into ##completed values (getdate(),'create_PERMIT_RECEIPTS')
;
;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_RECEIPTS
;

;print 'AATABLE_PERMIT_RECEIPTS';
insert into AATABLE_PERMIT_RECEIPTS (
HIST_RECEIPT_NBR,RECEIPT_DATE,CASHIER_ID,REGISTER_NBR,RECEIPT_AMOUNT,RECEIPT_COMMENT,RECEIPT_STATUS,TRANSACTION_CODE,TRANSACTION_NBR,REC_DATE,REC_FUL_NAM,TTERMINAL_ID,WORKSTATION_ID
)
select distinct
    pay.HIST_RECEIPT_NBR as HIST_RECEIPT_NBR
    ,pay.payment_Date as RECEIPT_DATE
    ,REPLACE(isnull(pay.CASHIER_ID,'Not Set'), '''','') as CASHIER_ID
    ,null as REGISTER_NBR
    ,pay.payment_amount as RECEIPT_AMOUNT
    ,null as RECEIPT_COMMENT
    ,null as RECEIPT_STATUS
    ,null as TRANSACTION_CODE
    ,null as TRANSACTION_NBR
    ,pay.rec_date as REC_DATE
    ,REPLACE(isnull(pay.rec_ful_nam,'Not Set'), '''','') as REC_FUL_NAM
    ,null as TTERMINAL_ID
    ,null as WORKSTATION_ID
from AATABLE_PERMIT_PAYMENTS pay
WHERE
    1=1
    and not exists (
        select 1
        from AATABLE_PERMIT_RECEIPTS
        where HIST_RECEIPT_NBR = pay.hist_receipt_nbr
    )
;