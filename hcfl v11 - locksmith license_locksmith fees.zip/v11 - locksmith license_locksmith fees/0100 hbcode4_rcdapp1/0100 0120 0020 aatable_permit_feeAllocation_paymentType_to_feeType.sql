/*
hbcode_4__codeEnforcement_LOCKSMTH
--hbcode_5 -- irrelevant cuz one record, no tot_fee or tot_pay or balance
--hbcode_6 -- irrelevant cuz one record, no tot_fee or tot_pay or balance
--HBREHAB_1 -- irrelevant cuz one record, no tot_fee or tot_pay or balance
HBNSG_1__codeEnforcement
HBSNIPE_1__codeEnforcement
HBTEMP_1__codeEnforcement
npool__101_19801
    npool_101
    npool_9801
RCDAPP_1__LCKSMITH
RCDVIOL_1__LCKSMITH
wrviol_1

note_for_me1
note_for_me2

----TO DO:
AGE     	2012
ASBUILT 	9901
ATF     	201
ATF     	2008
ATF     	2019
ATF     	2020
AUTOPBAK	202
AUTOPROJ	201
AUTOPROJ	2007
AUTOPROJ	2011
AUTOPROJ	2016
AUTOPROJ	2018
AUTOPROJ	8901
BFL     	2012
CBSFA   	1
CBSNR   	1
CHG     	2015
CODECOMP	101
CODECOMP	2018
CODECOMP	2019
CODECOMP	8901
CODECOMP	9901
COMREV  	8901
CONSTSUB	8901
CONSUMER	1
CPOOL   	201
CPOOL   	2007
CPOOL   	2011
DAT     	202
DEMO    	8901
DEV     	1
DRIVE   	201
DRIVE   	9601
DRIVE   	9701
EMER    	8901
EXAM    	9801
FCGB    	201
FCGB    	202
FCGB    	2007
FCGB    	2011
FCGB    	2016
FCGB    	2018
FCGB    	2019
FCOM    	1
FCOM    	101
FCOM    	201
FCOM    	202
FCOM    	2007
FCOM    	2011
FCOM    	2016
FCOM    	2018
FCOM    	8901
FCOM    	9706
FCOM    	9707
FCOM    	9801
FCOM    	9901
FCONDO  	202
FCONDO  	203
FCONDO  	2007
FCONDO  	2011
FCONDO  	2018
FDUP    	201
FDUP    	203
FDUP    	2007
FDUP    	2011
FDUP    	2018
FEMAPRO 	201
FENCE   	201
FENCE   	8901
FENCE   	9701
FENCE   	9801
FENCE   	9901
FGB     	101
FGB     	8901
FGB     	9706
FGB     	9707
FGB     	9801
FGB     	9901
FHM     	201
FHM     	2007
FHM     	2011
FHM     	9801
FHM     	9901
FINSITE 	9801
FINSITE 	9901
FINSUB  	8901
FIREALRM	202
FIREALRM	9901
FIREINV 	202
FIRESPKL	202
FIREUSER	202
FIRMREV 	8901
FIRMREV 	9702
FIRMREVP	8901
FMF     	1
FMF     	101
FMF     	202
FMF     	2007
FMF     	2011
FMF     	2016
FMF     	2018
FMF     	2021
FMF     	8901
FMF     	9707
FMF     	9801
FMF     	9901
FMH     	201
FMH     	202
FMH     	2007
FMH     	2011
FMH     	8901
FMH     	9706
FMH     	9801
FMH     	9901
FOUND   	8901
FPOF    	9902
FR      	9901
FRGB    	201
FRGB    	202
FRGB    	2007
FRGB    	2011
FRGB    	2016
FRGB    	2018
FSFR    	1
FSFR    	101
FSFR    	201
FSFR    	202
FSFR    	2007
FSFR    	8901
FSFR    	9706
FSFR    	9707
FSFR    	9801
FSFT    	101
FSFT    	202
FSFT    	2007
FSFT    	2011
FSFT    	2016
FSFT    	2018
FSHELL  	101
FSHELL  	201
FSHELL  	202
FSHELL  	203
FSHELL  	2007
FSHELL  	2011
FSHELL  	2016
FSHELL  	2018
FSHELL  	8901
FSHELL  	9801
FSHELL  	9901
FTF     	201
FTF     	2008
GAS     	8901
GLASS   	202
GLASS   	2007
GLASS   	2011
GLASS   	2019
HBCBRD  	1
HBCBRD  	3
HBCBS   	1
HBCNDM  	1
HBCODE  	1
HBOUTRCH	1
INTFIN  	101
INTFIN  	201
INTFIN  	202
INTFIN  	2007
INTFIN  	2011
INTFIN  	2016
INTFIN  	2018
INTFIN  	2019
INTFIN  	2020
INTFIN  	2021
INTFIN  	8901
INTFIN  	9706
INTFIN  	9707
INTFIN  	9801
INTFIN  	9901
INTREM  	101
INTREM  	201
INTREM  	202
INTREM  	2007
INTREM  	2011
INTREM  	2016
INTREM  	2018
INTREM  	2019
INTREM  	2020
INTREM  	8901
INTREM  	9706
INTREM  	9707
INTREM  	9801
INTREM  	9901
LAL     	8901
MF      	8901
MFST    	2011
MFST    	2012
MFST    	2016
MFST    	2018
MHPARK  	201
MHPARK  	8901
MHPARK  	9801
MHPARKA 	8901
MHPK    	9612
MISC    	201
MISC    	202
MISCNEW 	202
MISCNEW 	203
MSFR    	2011
MSFR    	2012
MSFR    	2016
MSFR    	2018
MSFR    	2021
MSFRBU  	2012
MSFT    	2011
MSFT    	2012
MSFT    	2016
MSFT    	2018
NCGB    	20
NCGB    	201
NCGB    	202
NCGB    	2007
NCGB    	2011
NCGB    	2016
NCGB    	2018
NCGB    	2019
NCGB    	2020
NCOM    	1
NCOM    	101
NCOM    	201
NCOM    	202
NCOM    	2007
NCOM    	2011
NCOM    	2016
NCOM    	2018
NCOM    	2019
NCOM    	2020
NCOM    	2021
NCOM    	8901
NCOM    	9701
NCOM    	9707
NCOM    	9801
NCOM    	9901
NCONDO  	202
NCONDO  	203
NCONDO  	2007
NCONDO  	2011
NCONDO  	2016
NCONDO  	2018
NDEM    	2007
NDEM    	2011
NDEM    	8901
NDEM    	9701
NDEM    	9801
NDUP    	201
NDUP    	202
NDUP    	203
NDUP    	2007
NDUP    	2011
NDUP    	2016
NDUP    	2018
NEL     	101
NEL     	201
NEL     	2007
NEL     	2011
NEL     	8901
NEL     	9701
NEL     	9801
NGAS    	201
NGAS    	2007
NGAS    	2011
NGAS    	9607
NGAS    	9801
NGAS    	9901
NGB     	101
NGB     	8901
NGB     	9701
NGB     	9707
NGB     	9801
NGB     	9901
NGFR    	2007
NGFR    	2011
NHM     	101
NHM     	201
NHM     	2007
NHM     	2011
NHM     	8901
NHM     	9706
NHM     	9801
NME     	101
NME     	201
NME     	2007
NME     	2011
NME     	8901
NME     	9701
NME     	9801
NMF     	1
NMF     	101
NMF     	201
NMF     	202
NMF     	2007
NMF     	2011
NMF     	2016
NMF     	2018
NMF     	2021
NMF     	8901
NMF     	9701
NMF     	9707
NMF     	9801
NMF     	9901
NMFBAK  	2007
NMH     	201
NMH     	202
NMH     	2007
NMH     	2011
NMH     	2019
NMH     	2020
NMH     	2021
NMH     	8901
NMH     	9701
NMH     	9801
NMH     	9901
NOSP    	201
NOSP    	2007
NOSP    	2011
NOSP    	8901
NOSP    	9701
NOSP    	9801
NPENC   	101
NPENC   	201
NPENC   	2007
NPENC   	2011
NPL     	201
NPL     	2007
NPL     	2011
NPL     	8901
NPL     	9701
NPL     	9801
NPOOL   	201
NPOOL   	2007
NPOOL   	2011
NPOOL   	8901
NPOOL   	9701
NPREMH  	202
NRGB    	201
NRGB    	202
NRGB    	2007
NRGB    	2011
NRGB    	2016
NRGB    	2018
NRGB    	2019
NRGB    	2020
NRGB    	2021
NSFR    	1
NSFR    	101
NSFR    	201
NSFR    	202
NSFR    	2007
NSFR    	2008
NSFR    	2011
NSFR    	2016
NSFR    	2018
NSFR    	2019
NSFR    	2020
NSFR    	2021
NSFR    	8901
NSFR    	9701
NSFR    	9801
NSFR10  	2008
NSFT    	101
NSFT    	201
NSFT    	202
NSFT    	2007
NSFT    	2011
NSFT    	2016
NSFT    	2018
NSFT    	2019
NSFT    	2021
NSG     	101
NSG     	201
NSG     	2007
NSG     	2011
NSG     	2019
NSG     	8901
NSG     	9701
NSG     	9801
NSVA    	2012
NSVA    	2016
NSVA    	2018
NSVA    	2021
NWP     	201
NWP     	2007
NWP     	2011
PLANFILE	2007
PLANFILE	9607
PREPLAN 	201
PRESITE 	9801
PRESITE 	9901
PRESUB  	8901
PROCREV 	201
PROCREV 	202
PROCREV 	2011
PROCREV 	2012
PROCREV 	2018
PROCREV 	2020
PROJ    	1
PUMP    	101
PUMP    	201
PUMP    	2007
PUMP    	2011
PUMP    	9701
PUMP    	9801
PVS     	2010
PVS     	2011
RENEWAL 	201
RENEWAL 	8901
RENEWAL 	9607
RENEWAL 	9801
ROOF    	101
ROOF    	201
ROOF    	2007
ROOF    	2011
ROOF    	8901
ROOF    	9701
ROOF    	9801
ROW     	201
ROW     	8901
ROW     	9701
ROWD    	8901
ROWD    	9701
ROWNEW  	202
ROW-PGM 	201
RPOOL   	201
RPOOL   	2007
RPOOL   	2011
RWD     	2010
RWD     	2011
RWP     	2011
SCREEN  	101
SCREEN  	201
SCREEN  	2007
SCREEN  	2011
SCREEN  	8901
SCREEN  	9701
SCREEN  	9801
SHELL   	101
SHELL   	201
SHELL   	202
SHELL   	203
SHELL   	2007
SHELL   	2011
SHELL   	2016
SHELL   	2018
SHELL   	2019
SHELL   	2020
SHELL   	2021
SHELL   	8901
SHELL   	9801
SHELL   	9901
SIGN    	8901
SITESUB 	9801
SITESUB 	9901
SPP     	2010
SPP     	2011
SUB     	2003
SUBREV  	8901
TENT    	8901
TENT    	9701
TST-EMER	9607
TTC     	201
WWCS    	101
WWCS    	9001
WWCS    	9701
WWCS    	9801
ZONING  	3
ZONING  	2019
ZONING  	2020
*/
IF OBJECT_ID('accelaconv7.dbo.jms_compType_version_feeItemNo_description_accountCode_feeKey', 'U') IS NOT NULL drop table accelaconv7.dbo.jms_compType_version_feeItemNo_description_accountCode_feeKey
;
create table accelaconv7.dbo.jms_compType_version_feeItemNo_description_accountCode_feeKey (
    comp_type     varchar(100)
    ,version      varchar(100)
    ,fee_item_no  varchar(100)
    ,description  varchar(100)
    ,account_code varchar(100)
    ,fee_key      varchar(100)
);





--hbcode_4__codeEnforcement_LOCKSMTH
--some records have curPart1/2/3/4 and maybe addl_fees/other_fees and nothing else
-- some records have curPart1/2/3/4 and the other fees, but only the curPart1/2/3/4 is considered
-- some records have curPart1/2/3/4 and other fees, and I think the other fees sometimes matter.
-- some records have no curPart1 but do have curPart2.
-- Some records have no curPart1/2/3/4 and do have other fee data.
-- some records have no explicit fee data, but have addl_fees and a tot_fee, or only a tot_fee
-- How the fees are considered seems to be determinable only based on how the payments are made.
-- THEREFORE: I shoehorn everything into TOT_FEE; I use calculated curPart1/2/3/4 to get a calculated total based on the logic they informed me of regarding start/endDates.
insert into accelaconv7.dbo.jms_compType_version_feeItemNo_description_accountCode_feeKey
SELECT
    comp_type
    ,version
    ,fee_item_no
    ,description
    ,account_code
    ,fee_key
from (VALUES
-- ('HBCODE  ','4','500','CEB FINES/COSTS','','TOT_FEE'),('HBCODE  ','4','500','CEB FINES/COSTS','354105','TOT_FEE'),('HBCODE  ','4','540','Additional CEB Charges','','TOT_FEE'),('HBCODE  ','4','510','Demo Principle Remaining','','Addl_Fees'),('HBCODE  ','4','520','Condemnation Interest','','Addl_Fees'),('HBCODE  ','4','601','OVERGROWTH ABATEMENT','PPO','curOGFee'),('HBCODE  ','4','602','ACCUMULATION DISPOSAL','PPO','curDumpFee'),('HBCODE  ','4','603','DEBRIS DISPOSAL','PPO','curDebrisDisp'),('HBCODE  ','4','604','TIRE DISPOSAL','PPO','curTireDisp'),('HBCODE  ','4','700','CARRIAGE BOLTS','PPO','curAbate2'),('HBCODE  ','4','702','FENCING','PPO','curAbate3'),('HBCODE  ','4','703','FENCE POSTS','PPO','curAbate4'),('HBCODE  ','4','704','GARBAGE BAGS','PPO','curAbate5'),('HBCODE  ','4','706','PLYWOOD','PPO','curAbate7'),('HBCODE  ','4','706','PLYWOOD','PPO','curAbate1'),('HBCODE  ','4','707','SCREWS','PPO','curAbate8'),('HBCODE  ','4','708','TWO BY FOURS','PPO','curAbate9'),('HBCODE  ','4','709','ZIP TIES','PPO','curAbate10'),('HBCODE  ','4','710','PIP RECORDING COSTS','PPO','curSEUrecording'),('HBCODE  ','4','711','DUMPSTER DELIVERY','PPO','curSeuDumpster'),('HBCODE  ','4','712','INTEREST ON ABATEMENT','PPO','curAbateInterest'),('HBCODE  ','4','713','CERTIFIED MAIL','PPO','curAbateMail'),('HBCODE  ','4','714','NON PRICED ITEM','PPO','curNpi'),('HBCODE  ','4','715','Locksmith Registration','','Addl_Fees')
 ('HBCODE  ','4','500','CEB FINES/COSTS','','TOT_FEE')
,('HBCODE  ','4','500','CEB FINES/COSTS','354105','TOT_FEE')
,('HBCODE  ','4','540','Additional CEB Charges','','TOT_FEE')
,('HBCODE  ','4','510','Demo Principle Remaining','','TOT_FEE')
,('HBCODE  ','4','520','Condemnation Interest','','TOT_FEE')
,('HBCODE  ','4','601','OVERGROWTH ABATEMENT','PPO','TOT_FEE')
,('HBCODE  ','4','602','ACCUMULATION DISPOSAL','PPO','TOT_FEE')
,('HBCODE  ','4','603','DEBRIS DISPOSAL','PPO','TOT_FEE')
,('HBCODE  ','4','604','TIRE DISPOSAL','PPO','TOT_FEE')
,('HBCODE  ','4','700','CARRIAGE BOLTS','PPO','TOT_FEE')
,('HBCODE  ','4','702','FENCING','PPO','TOT_FEE')
,('HBCODE  ','4','703','FENCE POSTS','PPO','TOT_FEE')
,('HBCODE  ','4','704','GARBAGE BAGS','PPO','TOT_FEE')
,('HBCODE  ','4','706','PLYWOOD','PPO','TOT_FEE')
,('HBCODE  ','4','706','PLYWOOD','PPO','TOT_FEE')
,('HBCODE  ','4','707','SCREWS','PPO','TOT_FEE')
,('HBCODE  ','4','708','TWO BY FOURS','PPO','TOT_FEE')
,('HBCODE  ','4','709','ZIP TIES','PPO','TOT_FEE')
,('HBCODE  ','4','710','PIP RECORDING COSTS','PPO','TOT_FEE')
,('HBCODE  ','4','711','DUMPSTER DELIVERY','PPO','TOT_FEE')
,('HBCODE  ','4','712','INTEREST ON ABATEMENT','PPO','TOT_FEE')
,('HBCODE  ','4','713','CERTIFIED MAIL','PPO','TOT_FEE')
,('HBCODE  ','4','714','NON PRICED ITEM','PPO','TOT_FEE')
,('HBCODE  ','4','715','Locksmith Registration','','TOT_FEE')
) t(comp_type,version,fee_item_no,description,account_code,fee_key)
;


--HBNSG_1__codeEnforcement
insert into accelaconv7.dbo.jms_compType_version_feeItemNo_description_accountCode_feeKey
SELECT
    comp_type
    ,version
    ,fee_item_no
    ,description
    ,account_code
    ,fee_key
from (VALUES
--This can't be correct. But what else do I direct the payments for the two number_key values to? (number_key values 111 and 154)
('HBNSG   ','1','2054','Trust Account Code Hist','TRUST ACCOUNT DEPOSIT GLNUM','fee_temp_sign') 
) t(comp_type,version,fee_item_no,description,account_code,fee_key)
;

--HBSNIPE_1__codeEnforcement
--No fees exist. No payments exist.


--HBTEMP_1__codeEnforcement
insert into accelaconv7.dbo.jms_compType_version_feeItemNo_description_accountCode_feeKey
SELECT
    comp_type
    ,version
    ,fee_item_no
    ,description
    ,account_code
    ,fee_key
from (VALUES
('HBTEMP  ','1','500','CEB FINES/COSTS','','TOT_FEE')
,('HBTEMP  ','1','530','CEB/HCCE Costs','','TOT_FEE' )
) t(comp_type,version,fee_item_no,description,account_code,fee_key)
;

--npool__101_19801
    --npool_101
insert into accelaconv7.dbo.jms_compType_version_feeItemNo_description_accountCode_feeKey
SELECT
    comp_type
    ,version
    ,fee_item_no
    ,description
    ,account_code
    ,fee_key
from (VALUES
 ('NPOOL','101','2001','NOC Fees','BLDG','FEE_NOTICE')
,('NPOOL','101','2001','NOC Fees','PGR00215    0186','FEE_NOTICE')
,('NPOOL','101','2080','Pool-Permits','BLDG','TOTAL_POOL')
,('NPOOL','101','2080','Pool-Permits','CUR00208    0034','TOTAL_POOL')
,('NPOOL','101','2080','Pool-Permits','PGR00208    0034','TOTAL_POOL')
,('NPOOL','101','2085','Pool-Misc Fees','CUR00208    0034','FEE_MISC')
,('NPOOL','101','2085','Pool-Misc Fees','PGR00208    0034','FEE_MISC')
,('NPOOL','101','2085','Pool-Misc Fees','POOL','FEE_MISC')
,('NPOOL','101','2130','Plumbing-Permit','PGR00210    0034','FEE_PLUMB')
,('NPOOL','101','2130','Plumbing-Permit','PLUMB','FEE_PLUMB')
,('NPOOL','101','2135','Plumbing-Reinspection','CUR00214    0034','FEE_REINSP')
,('NPOOL','101','2135','Plumbing-Reinspection','PGR00214    0034','FEE_REINSP')
,('NPOOL','101','2135','Plumbing-Reinspection','PRG00214    0034','FEE_REINSP')
,('NPOOL','101','2135','Plumbing-Reinspection','REINSPCT','FEE_REINSP')
,('NPOOL','101','2150','Electrical-Permit','CUR00204    0034','FEE_GENELE')
,('NPOOL','101','2150','Electrical-Permit','ELEC','FEE_ELEC')
,('NPOOL','101','2150','Electrical-Permit','PGR00204    0034','FEE_ELEC')
,('NPOOL','101','2155','Electrical-Reinspection','CUR00214    0034','FEE_ELREIN')
,('NPOOL','101','2155','Electrical-Reinspection','PGR00214    0034','FEE_ELREIN')
,('NPOOL','101','2155','Electrical-Reinspection','REINSPCT','FEE_ELREIN')
) t(comp_type,version,fee_item_no,description,account_code,fee_key)
;

    --npool_9801
insert into accelaconv7.dbo.jms_compType_version_feeItemNo_description_accountCode_feeKey
SELECT
    comp_type
    ,version
    ,fee_item_no
    ,description
    ,account_code
    ,fee_key
from (VALUES
('NPOOL','9801','2040','Bldg Reinspection','REINSPCT','FEE_REINSP')
,('NPOOL','9801','2040','Bldg Reinspection','CUR00214    0034','ADDL_FEES')
,('NPOOL','9801','2080','Pool-Permits','PGR00208    0034','FEE_POOL')
,('NPOOL','9801','2080','Pool-Permits','CUR00208    0034','FEE_GENL')
,('NPOOL','9801','2080','Pool-Permits','BLDG','FEE_POOL')
,('NPOOL','9801','2085','Pool-Misc Fees','CUR00208    0034','FEE_MISC')
,('NPOOL','9801','2085','Pool-Misc Fees','PGR00208    0034','FEE_MISC')
,('NPOOL','9801','2085','Pool-Misc Fees','POOL','FEE_MISC')
,('NPOOL','9801','2130','Plumbing-Permit','PLUMB','FEE_PLUMB')
,('NPOOL','9801','2130','Plumbing-Permit','PGR00210    0034','FEE_PLUMB')
,('NPOOL','9801','2130','Plumbing-Permit','CUR00210    0034','FEE_PLUMB')
,('NPOOL','9801','2135','Plumbing-Reinspection','REINSPCT','FEE_REINSP')
,('NPOOL','9801','2135','Plumbing-Reinspection','CUR00214    0034','FEE_REINSP')
,('NPOOL','9801','2135','Plumbing-Reinspection','PGR00214    0034','FEE_REINSP')
,('NPOOL','9801','2135','Plumbing-Reinspection','PRG00214    0034','FEE_REINSP')
,('NPOOL','9801','2150','Electrical-Permit','CUR00204    0034','FEE_GENELE')
,('NPOOL','9801','2150','Electrical-Permit','PGR00204    0034','FEE_GENELE')
,('NPOOL','9801','2150','Electrical-Permit','ELEC','FEE_ELEC')
,('NPOOL','9801','2155','Electrical-Reinspection','PGR00214    0034','FEE_ELREIN')
,('NPOOL','9801','2155','Electrical-Reinspection','REINSPCT','FEE_ELREIN')
,('NPOOL','9801','2155','Electrical-Reinspection','CUR00214    0034','FEE_ELREIN')
,('NPOOL','9801','9000','ADJUSTMENTS','','')
) t(comp_type,version,fee_item_no,description,account_code,fee_key)
;


--RCDAPP_1__LCKSMITH
--trick question. This has no payments in the source data.


--RCDVIOL_1__LCKSMITH
insert into accelaconv7.dbo.jms_compType_version_feeItemNo_description_accountCode_feeKey
select 
    comp_type
    ,version
    ,fee_item_no
    ,description
    ,account_code
    ,fee_key
from (VALUES
 ('RCDVIOL ','1','100','RCDCitations','','TOT_FEE')
,('RCDVIOL ','1','500','CEB FINES/COSTS','354105','TOT_FEE')
,('RCDVIOL ','1','501','Administrative Costs','','TOT_FEE')
,('RCDVIOL ','1','900','VEHHIRE - TPASS TOW FINE','','TOT_FEE')
) t(comp_type,version,fee_item_no,description,account_code,fee_key)
;

--wrviol_1
insert into accelaconv7.dbo.jms_compType_version_feeItemNo_description_accountCode_feeKey
select 
    comp_type
    ,version
    ,fee_item_no
    ,description
    ,account_code
    ,fee_key
from (VALUES
('WRVIOL','1','500','CEB FINES/COSTS','','TOT_FEE')
,('WRVIOL','1','500','CEB FINES/COSTS','354105','TOT_FEE')
,('WRVIOL','1','501','Administrative Costs','','TOT_FEE')
,('WRVIOL','1','800','Watering Violation','','TOT_FEE')
) t(comp_type,version,fee_item_no,description,account_code,fee_key)
;

--verify all relevant fee_key values are derived from a string which exists in aatable_permit_fee
if 1 = (
	select distinct
		a.fee_key
	from aatable_permit_fee a
	join jms_numberKey_permitnum pmap on (pmap.permitnum = a.PERMITNUM) or (pmap.permitnum + '-CBS' = a.permitnum)
	left join jms_compType_version_feeItemNo_description_accountCode_feeKey f on f.fee_key = reverse(substring(reverse(a.FEE_KEY),0,CHARINDEX('-',reverse(a.FEE_KEY))))
	join jms_apd_base_filtered b on b.NUMBER_KEY = pmap.number_key
	where
		1=1
		and f.fee_key is null
		and not (b.COMP_TYPE = 'RCDAPP' and b.version = 1) --this one has no payments, so it doesnt need to match anything (due to no aatable_permit_feeAllocation rows)
) RAISERROR ('values in jms_compType_version_feeItemNo_description_accountCode_feeKey must exist in aatable_permit_fee!', 16, 1)
;




/*
--note_for_me1
select distinct
	pnum.comp_type
	,pnum.version
	,fd.FEE_ITEM_NO
	,f.DESCRIPTION
	,fd.ACCOUNT_CODE
from hcfl_src..fee_detl fd
left join hcfl_src..tab_fee f on f.FEE_ITEM_NO = fd.FEE_ITEM_NO
left join hcfl_src.dbo.fee_id numberKey_transactionId on numberKey_transactionId.number_key = fd.NUMBER_KEY
left join hcfl_src.dbo.apd_base pnum on pnum.NUMBER_KEY = fd.NUMBER_KEY
where
	1=1
	and pnum.COMP_TYPE = 'npool' and pnum.VERSION = '101'
order by fd.FEE_ITEM_NO,fd.ACCOUNT_CODE


--note_for_me2
select distinct
	fd.NUMBER_KEY
	,f.FEE_ITEM_NO
	,f.DESCRIPTION
	,fd.ACCOUNT_CODE
	,fd.AMOUNT
	
from hcfl_src..fee_detl fd
left join hcfl_src..tab_fee f on f.FEE_ITEM_NO = fd.FEE_ITEM_NO
left join hcfl_src.dbo.fee_id numberKey_transactionId on numberKey_transactionId.number_key = fd.NUMBER_KEY
left join hcfl_src.dbo.apd_base pnum on pnum.NUMBER_KEY = fd.NUMBER_KEY
where
	1=1
	and pnum.COMP_TYPE = 'npool' and pnum.VERSION = '9801'
	--and f.FEE_ITEM_NO = '2135'
	--and fd.NUMBER_KEY = 'NPO05756'
	and f.FEE_ITEM_NO  = '2155'
	--and fd.account_code =	
	--and fd.AMOUNT <> convert(int,fd.amount)
--order by fd.NUMBER_KEY,f.FEE_ITEM_NO

*/