/*
setup to get any orphaned rows (rows without some kind of site visit preceding them)
    setup parents
    setup is_initial_site_visit
    setup g
    which number_key values have orphaned inspection rows?
    setup orphan parents
NOW REDO ABOVE LOGIC AND USE REMAINING LOGIC
    (determine child rows per inspection, then assert inspection type and inspection result based on those children)
    create parents
    create is_initial_site_visit
    create g
    create h
    create violations
    VERIFY the above
ensure no duplicates
*/


--setup to get any orphaned rows (rows without some kind of site visit preceding them)
/* SET UP:
I found 511 unique_key values in apd_insp that dont have a preceding site visit. 
So I run the logic, identify those without the preceding SV et al, then add them to my apd_insp.
*/


;delete from jms_apd_insp_filteredToPop where unique_key like 'ORPH-%'

--determine child rows per inspection, then assert inspection type and inspection result based on those children
;IF OBJECT_ID('tempdb.dbo.#parents', 'U') IS NOT NULL drop table #parents
;IF OBJECT_ID('tempdb.dbo.#is_initial_site_visit', 'U') IS NOT NULL drop table #is_initial_site_visit
;IF OBJECT_ID('tempdb.dbo.#g', 'U') IS NOT NULL drop table #g
;IF OBJECT_ID('tempdb.dbo.#orphaned', 'U') IS NOT NULL drop table #orphaned
;IF OBJECT_ID('tempdb.dbo.#h', 'U') IS NOT NULL drop table #h
;IF OBJECT_ID('tempdb.dbo.#violations', 'U') IS NOT NULL drop table #violations
;
go


--setup parents           
--;with parents
    --assumes inspections are site visits, and results are implied by the subsequent rows prior to the following site visit.
	select
		number_key
		,unique_key
		,date_ent
		,the_Date
		,action_ent
    into #parents
	from jms_apd_insp_filteredToPop
	where action_ent in ('SV','SSV','QCSV','LSV')
	--and number_key = 'CE18015425'
;
--setup is_initial_site_visit                        
--), is_initial_site_visit as (
    --"initial site visiit" is an accela inspection type
	select
		b.UNIQUE_KEY
        ,b.action_ent
    into #is_initial_site_visit
	from jms_apd_base_filtered a
	outer apply (select top 1 * from jms_apd_insp_filteredToPop where NUMBER_KEY = a.NUMBER_KEY and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent,the_date) b
;
--setup g  
--),g as (
    select
        a.number_key
        ,a.item_id
        ,a.unique_key
        ,a.action_ent
        ,action_ent.DESCRIPTION action_ent_desc
        ,case when is_initial_site_visit.UNIQUE_KEY is not null then 1 else 0 end as is_initial_site_visit
        ,'xxxx' [ ]
        ,coalesce(b.unique_key,is_initial_site_visit.unique_key) parent_unique_key
        ,b.action_ent parent_action_ent
        ,(case 
            when is_initial_site_visit.UNIQUE_KEY is not null then 'Initial Site Visit'
            when a.ACTION_ENT in ('QCSV','LSV') then 'Quality Control Inspection'
            when  a.any_comments like '%re%inspect%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%re%check%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%annual%insp%'    then 'Annual Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%post%hearing%'    then 'Post-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%pre%hearing%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%hear%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%follow%up%'    then 'Follow-up Inspection' --I don't know about pre vs post hearing
            else 'Inspection'
            end		
        ) as inspection_type
        ,(case 
            --when a.ACTION_ENT in ('SV','SSV','QCSV','LSV') then null
            when a.ACTION_ENT = 'NOVR' then 'Notice of Violation Requested'
            when a.ACTION_ENT = 'NOVC' then 'NOV issued'
            when a.ACTION_ENT = 'NOVB' then 'Combo Issued'
            when a.action_ent = 'ECIT' then 'Citation Issued'
            when a.ACTION_ENT = 'COMP' then 'Compliant'
            when a.ACTION_ENT = 'VIOL' then 'Violation'
            when A.ACTION_ENT in ('CA','CNCL') then 'No Violation'
            when a.any_comments like '%dead%animal%'	  then 'Extension'
            when a.any_comments like '%exten%'	  then 'Extension'
            when a.any_comments like '%violation%'  then 'Violation'
            when a.any_comments like '%non%compli%' then 'Not Compliant'
            when a.any_comments like '%send%nov%'   then 'NOV Issued'
            when a.any_comments like '%req%nov%'    then 'Notice of Violation Requested'
            when a.any_comments like '%cont%fin%'    then 'Not Compliant' --continue fines
            else null
            end
        ) as inspection_result
        
        ,'xxxx' [2]
        ,a.date_ent
        ,a.the_date
        ,'xxxx'[3]
        ,a.any_comments
    into #g
    from jms_apd_insp_filteredToPop a
    outer apply (select top 1 * from #parents where number_key = a.number_key and the_date <= a.the_date and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent desc,the_date desc) b
    left join jms_actionEnt_passFail action_ent on action_ent.action_ent = a.action_ent
    left join #is_initial_site_visit is_initial_site_visit on is_initial_site_visit.UNIQUE_KEY = a.UNIQUE_KEY
    where
        1=1
        --and a.action_ent not in ('SV','SSV','QCSV','LSV')
        --and a.number_key = 
        --	--'CE03003081'
        --	--'CE22014264'
        --	'CE22014971'
    --order by --a.date_ent,a.the_Date,case when a.action_ent in ('SV','SSV','QCSV','LSV') then 1 else 2 end, l.THE_TEXT
    --	a.UNIQUE_KEY
;

----which number_key values have orphaned inspection rows?
--select 
--	a.NUMBER_KEY
--	,a.parent_unique_key
--	,count(b.number_key) ct
--    
--into #orphaned
--from #g a
--left join hcfl_src..apd_itms b 
--	on b.RECORD_TYPE = 'CD'
--	and b.NUMBER_KEY = a.NUMBER_KEY
--	and year(b.THE_DATE) = year(a.the_date) and month(b.THE_DATE) = month(a.the_date) and day(b.THE_DATE) = day(a.THE_DATE)
--	and b.ITEM_ID = a.ITEM_ID
--where
--	b.NUMBER_KEY is not null
--    and a.parent_unique_key is null
--group by a.numbeR_key,a.parent_unique_key
--;
select 
	a.NUMBER_KEY
	,a.UNIQUE_KEY
    
into #orphaned
from #g a
where
	a.parent_unique_key is null
;


--setup orphan parents             
--;delete from jms_apd_insp_filteredToPop where unique_key like 'ORPH-%' --moved up top. Otherwise, can on alternating conversions yield nothing, while deleting the relevant records.
;
insert into jms_apd_insp_filteredToPop
SELECT distinct
     f.NUMBER_KEY
    ,'A' DATA_LEVEL
    ,'IN' RECORD_TYPE
    ,'14320' ITEM_ID
    ,'ORPH-' + convert(varchar(max),row_number() over(order by f.number_key) ) unique_key 
    ,null INSPECTOR
    ,null USER_ID
    ,'KE' ENTRY_METHOD
    ,null REMOTE_USER_ID
    ,min(a.date_ent) DATE_ENT
    ,'SV' ACTION_ENT
    ,'N' APPROVAL
    ,min(a.THE_DATE) the_date
    ,null BEG_TIME
    ,null END_TIME
    ,null TOTAL_TIME
    ,0 VIOLATIONS
    ,null MILAGE
    ,convert(varchar(max),a.ANY_COMMENTS) any_comments
    ,'14320' ITEM_NO
    ,null REQUEST_ID
    ,null BEG_MILEAGE
    ,null END_MILEAGE
    ,null VEHICLE_ID
    ,null SUBMIT_TIME
    ,null SUBMIT_DATE
from #orphaned f --on f.number_key = a.number_key
outer apply (select top 1 * from jms_apd_insp_filteredToPop where number_key = f.number_key order by the_date,date_ent) a
WHERE
    1=1
group by f.NUMBER_KEY,convert(varchar(max),a.ANY_COMMENTS)
;

-----------------------
--NOW REDO ABOVE LOGIC AND USE REMAINING LOGIC
-----------------------

--determine child rows per inspection, then assert inspection type and inspection result based on those children
;IF OBJECT_ID('tempdb.dbo.#parents', 'U') IS NOT NULL drop table #parents
;IF OBJECT_ID('tempdb.dbo.#is_initial_site_visit', 'U') IS NOT NULL drop table #is_initial_site_visit
;IF OBJECT_ID('tempdb.dbo.#g', 'U') IS NOT NULL drop table #g
;IF OBJECT_ID('tempdb.dbo.#orphaned', 'U') IS NOT NULL drop table #orphaned
;IF OBJECT_ID('tempdb.dbo.#h', 'U') IS NOT NULL drop table #h
;IF OBJECT_ID('tempdb.dbo.#violations', 'U') IS NOT NULL drop table #violations
;IF OBJECT_ID('tempdb.dbo.#req_opt', 'U') IS NOT NULL drop table #req_opt
;
go

--create parents              
--;with parents
    --assumes inspections are site visits, and results are implied by the subsequent rows prior to the following site visit.
	select
		number_key
		,unique_key
		,date_ent
		,the_Date
		,action_ent
    into #parents
	from jms_apd_insp_filteredToPop
	where action_ent in ('SV','SSV','QCSV','LSV')
	--and number_key = 'CE18015425'
;
--create is_initial_site_visit
--), is_initial_site_visit as (
    --"initial site visiit" is an accela inspection type
	select
		b.UNIQUE_KEY
        ,b.action_ent
    into #is_initial_site_visit
	from jms_apd_base_filtered a
	outer apply (select top 1 * from jms_apd_insp_filteredToPop where NUMBER_KEY = a.NUMBER_KEY and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent,the_date) b
;
--create g  
--),g as (
    select
        a.number_key
        ,a.item_id
        ,a.unique_key
        ,a.action_ent
        ,action_ent.DESCRIPTION action_ent_desc
        ,case when is_initial_site_visit.UNIQUE_KEY is not null then 1 else 0 end as is_initial_site_visit
        ,'xxxx' [ ]
        ,coalesce(b.unique_key,is_initial_site_visit.unique_key) parent_unique_key
        ,b.action_ent parent_action_ent
        ,(case 
            when is_initial_site_visit.UNIQUE_KEY is not null then 'Initial Site Visit'
            when a.ACTION_ENT in ('QCSV','LSV') then 'Quality Control Inspection'
            when  a.any_comments like '%re%inspect%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%re%check%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%annual%insp%'    then 'Annual Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%post%hearing%'    then 'Post-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%pre%hearing%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%hear%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%follow%up%'    then 'Follow-up Inspection' --I don't know about pre vs post hearing
            else 'Inspection'
            end		
        ) as inspection_type
        ,(case 
            --when a.ACTION_ENT in ('SV','SSV','QCSV','LSV') then null
            when a.ACTION_ENT = 'NOVR' then 'Notice of Violation Requested'
            when a.ACTION_ENT = 'NOVC' then 'NOV issued'
            when a.ACTION_ENT = 'NOVB' then 'Combo Issued'
            when a.action_ent = 'ECIT' then 'Citation Issued'
            when a.ACTION_ENT = 'COMP' then 'Compliant'
            when a.ACTION_ENT = 'VIOL' then 'Violation'
            when A.ACTION_ENT in ('CA','CNCL') then 'No Violation'
            when a.any_comments like '%dead%animal%'	  then 'Extension'
            when a.any_comments like '%exten%'	  then 'Extension'
            when a.any_comments like '%violation%'  then 'Violation'
            when a.any_comments like '%non%compli%' then 'Not Compliant'
            when a.any_comments like '%send%nov%'   then 'NOV Issued'
            when a.any_comments like '%req%nov%'    then 'Notice of Violation Requested'
            when a.any_comments like '%cont%fin%'    then 'Not Compliant' --continue fines
            else 'No Violation'
            end
        ) as inspection_result
        
        ,'xxxx' [2]
        ,a.date_ent
        ,a.the_date
        ,'xxxx'[3]
        ,a.any_comments
    into #g
    from jms_apd_insp_filteredToPop a
    outer apply (select top 1 * from #parents where number_key = a.number_key and the_date <= a.the_date and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent desc,the_date desc) b
    left join jms_actionEnt_passFail action_ent on action_ent.action_ent = a.action_ent
    left join #is_initial_site_visit is_initial_site_visit on is_initial_site_visit.UNIQUE_KEY = a.UNIQUE_KEY
    where
        1=1
        --and a.action_ent not in ('SV','SSV','QCSV','LSV')
        --and a.number_key = 
        --	--'CE03003081'
        --	--'CE22014264'
        --	'CE22014971'
    --order by --a.date_ent,a.the_Date,case when a.action_ent in ('SV','SSV','QCSV','LSV') then 1 else 2 end, l.THE_TEXT
    --	a.UNIQUE_KEY
;



















--create h
--), h as (
    select distinct
         a1.NUMBER_KEY
        ,a1.UNIQUE_KEY
        ,a1.action_ent
        ,a1.inspection_type
        ,coalesce(b.inspection_result,a1.inspection_result,'Not Set') inspection_result
        ,trim('^|' from stuff((
            select 
                '^|^' + cast(
                    trim(replace(replace(replace(replace(   isnull(a2.any_comments,'')   ,'"',''''''),'''',''),char(13),''),char(10),'®')) 
                    as varchar(max)
                )
            from #g a2 with(nolock)
            where 
                a2.parent_unique_key = a1.parent_unique_key
            group by a2.any_comments
            order by a2.any_comments
            FOR XML PATH('')
         ), 1, 1, '')) as any_comments
    into #h
    from #g a1
    outer apply (
        select top 1 *
        from #g
        where
            parent_unique_key = a1.UNIQUE_KEY
            and inspection_result is not null
        order by case inspection_result 
            when 'violation'		then 1
            when 'combo issued'		then 2
            when 'NOV issued'		then 3
            when 'not compliant'	then 4
            when 'Notice of Violation Requested' then 5
            when 'Extension' then 6
            when 'Compliant' then 7
            when 'No Violation' then 8
            else 999
            end                                                                                                                                                        
    ) b
    where
        1=1
        and a1.ACTION_ENT in ('SV','SSV','QCSV','LSV')
        --and a1.number_key = 'CE17015692'
    ;

    --order by a.UNIQUE_KEY
--)
;
--create violations
--;with cte_violations as (
;IF OBJECT_ID('tempdb.dbo.#_violations', 'U') IS NOT NULL drop table #_violations
;
select distinct
    a.NUMBER_KEY
    ,a.parent_unique_key
    ,b.item_id --count(distinct b.item_id) ct --,count(b.number_key) ct
into #_violations
from #g a
left join hcfl_src..apd_itms b on b.RECORD_TYPE = 'CD' and b.NUMBER_KEY = a.NUMBER_KEY
--left join greater_dates b2 on b2.number_key = b.number_key and b2.sequence = b.sequence and b2.item_id = b.item_id and b2.the_date = b.the_Date	
where
    1=1
	and b.NUMBER_KEY is not null
	--and b.NUMBER_KEY = @number_key
	and (
		(year(b.THE_DATE) = year(a.THE_DATE) and month(b.THE_DATE) = month(a.THE_DATE) and day(b.THE_DATE) = day(a.THE_DATE) )
		--or (year(b2.greater_date) = year(a.date_ent) and month(b2.greater_date) = month(a.date_ent) and day(b2.greater_date) = day(a.date_ent) )
		--or a.item_id = b.ITEM_ID
	)
	--and a.parent_unique_key not like 'ORPH-%'
	and a.item_id = b.ITEM_ID
	--and b.NUMBER_KEY = 'CE20005395'
--group by a.number_key,a.parent_unique_key
;
insert into #_violations
select distinct
    a.NUMBER_KEY
    ,a.parent_unique_key
    ,b.item_id --count(distinct b.item_id) ct --,count(b.number_key) ct
--into #violations
from #g a
left join hcfl_src..apd_itms b on b.RECORD_TYPE = 'CD' and b.NUMBER_KEY = a.NUMBER_KEY
--left join greater_dates b2 on b2.number_key = b.number_key and b2.sequence = b.sequence and b2.item_id = b.item_id and b2.the_date = b.the_Date	
left join #_violations f on f.number_key = b.number_key and f.parent_unique_key = a.parent_unique_key and f.item_id = b.item_id
where
    1=1
	and b.NUMBER_KEY is not null
    and b.number_key in (
        'CE19003559','CE23009136','CE19009756','CE20002548','CE21004204','CE19003581','CE20012598','CE19012011','CE23005979','CE19015277','CE21016309','CE19011421','CE19012401','CE22014685','CE18005494','CE23010215','CE19012411','CE20009721','CE22013741','CE19014671','CE21011018','CE22014110','CE20007800','CE20005402','CE20009114','CE19002911','CE20018403','CE23011330','CE22015121','CE23007240','CE23013057','CE19010651','CE19018933','CE20014046','CE21009047','CE21007959','CE23004103','CE22001176','CE23006298','CE23010669','CE24000898','CE24000231','CE20004070','CE23009308','CE23010811','CE23010751','CE21014360','CE22012777','CE19009560','CE19012398','CE19008217','CE21000155','CE19010306','CE19006856','CE19005561','CE19008165','CE20003010','CE23013515','CE19019242','CE18019800','CE14014593','CE21004712','CE20002119','CE20011293','CE19012874','CE20007286','CE19010901','CE21016777','CE21015105','CE20017070','CE23011743','CE19006692','CE22014556','CE21002721','CE22012195','CE23014129','CE16008878','CE23014777','CE21014002','CE22002145','CE21014975','CE19000216','CE22012498','CE16010830','CE19007826','CE20017491','CE24001587','CE22014672','CE20004106','CE21013194','CE19011203','CE19005242','CE19008010','CE20005850','CE23014313','CE19009809','CE22007611','CE22014657','CE19002688','CE19004742','CE19019742','CE16012518','CE19005138','CE24002345','CE21002886','CE19005576','CE21010907','CE23000913','CE19015279','CE24000171','CE23013386','CE19004841','CE20003005','CE23013302','CE21010027','CE21003160','CE23011649','CE20002551','CE21012168','CE20001647','CE19015282','CE19010593','CE22005509','CE22002774','CE19000583','CE22009951','CE19012963','CE21013802','CE19006869','CE19007787','CE22010728','CE21014537','CE19015962','CE19002555','CE19009892','CE15004960','CE23007140','CE20012475','CE19011046','CE23013565','CE20002543','CE22010175','CE21007517','CE22012138','CE24002684','CE20015397','CE20014604','CE18008839','CE23012423','CE19001765','CE19014362','CE22013524','CE19012586','CE23002470','CE23014099','CE20012835','CE07006722','CE19015151','CE19000528','CE19014919','CE19011732','CE22005218','CE12012059','CE19013938','CE23003461','CE21010022','CE22008356','CE19005972','CE20000742','CE21003266','CE23002791','CE20004250','CE23006823','CE23006205','CE20006255','CE23005529','CE19015687','CE17020849','CE16011159','CE23008481','CE21010743','CE21000977','CE19012735','CE19013243','CE23009435','CE14002241','CE19019208','CE19003241','CE19010951','CE19007064','CE05008956','CE23000156','CE20011005','CE19015960','CE23006198','CE23000896','CE23009330','CE23003520','CE23013768','CE23013242','CE21012600','CE23006418','CE19019872','CE19009080','CE20017647','CE21008460','CE20003079','CE21004247','CE19016865','CE22014691','CE20000309','CE23009317','CE16009497','CE20012757','CE22013184','CE22012525','CE23002424','CE19011120','CE20004011','CE20018362','CE11001952','CE19008549','CE19002850','CE23003766','CE23011872','CE20016297','CE21012795','CE21010756','CE19014909','CE23004666','CE19011322','CE21006583','CE21003395','CE22002320','CE19001103','CE23010757','CE20002145','CE21010369','CE24001675','CE24001194','CE19019970','CE21008117','CE04002961','CE24000282','CE23000226','CE19011049','CE22002273','CE23010810','CE12009147','CE20013788','CE23001776','CE22012221','CE22008197','CE20006453','CE20007168','CE19014933','CE20017446','CE21002204','CE19013740','CE22008400','CE19006253','CE19015187','CE21013889','CE22012226','CE19006592','CE21008765','CE20009474','CE21000352','CE22011604','CE23011454','CE12004910','CE20005069','CE22012974','CE23007078','CE21011822','CE22002278','CE23014558','CE19006177','CE22014960','CE20014073','CE21010304','CE23012408','CE20006029','CE19005819','CE23009508','CE19009231','CE22003059','CE21012398','CE24001576','CE20002603','CE23013958','CE20004452','CE23004337','CE23007397','CE22009674','CE19010319','CE19020349','CE20004379','CE22011606','CE20001696','CE23001612','CE23013064','CE12003323','CE19018598','CE20003134','CE20008234','CE13011361','CE21014323','CE23010838','CE21005870','CE20002550','CE21014995','CE23010548','CE21012765','CE23001406','CE23002206','CE23009679','CE23001283','CE23012306','CE13013683','CE21005650','CE12001135','CE21011659','CE21016565','CE22004816','CE23005030','CE21009405','CE22012975','CE22010001','CE22011513','CE23013896','CE23002363','CE19005407','CE19008000','CE19009810','CE22007403','CE19007948','CE23009295','CE20001120','CE19014351','CE20000610','CE23002831','CE20014638','CE23013343','CE23014165','CE21016896','CE20003292','CE22015143','CE24001125','CE23002421','CE19009336','CE23002074','CE20002546','CE24001901','CE19001606','CE22009736','CE19010548','CE19008853','CE22010991','CE23014102','CE20016689','CE19004262','CE23009562','CE22009001','CE19019345','CE22006714','CE22011587','CE21008384','CE23001747','CE20011292','CE20001622','CE19016871','CE21006173','CE19011196','CE21003999','CE22014860','CE23002436','CE20006243','CE19013762','CE19014356','CE20008245','CE22012248','CE20012913','CE12010833','CE15004070','CE23000058','CE21012761','CE19002976','CE19009561','CE12003209','CE20003150','CE19001475','CE23005154','CE23010438','CE20018499','CE19014365','CE22012717','CE21015934','CE20013132','CE21011969','CE21006590','CE20010968','CE23003853','CE19006731','CE20012661','CE19014495','CE23004358','CE19008554','CE12003481','CE21010313','CE19005606','CE24002068','CE19012746','CE22006893','CE20000497','CE19004484','CE19019300','CE20007394','CE19004709','CE22009437','CE19003007','CE20003512','CE20008813','CE19006620','CE22013816','CE23012610','CE23000787','CE20008316','CE19018571','CE23008403','CE20008130','CE20013020','CE20014591','CE19002826','CE23003059','CE21012920','CE23010317','CE19001686','CE19001411','CE21012638','CE22001793','CE20002331','CE22003873','CE21008521','CE22006128','CE19009748','CE24002782','CE22011816','CE20017803','CE20006246','CE19010718','CE19005680','CE23000343','CE23007720','CE21010763','CE19015601','CE23011648','CE23011763','CE19018118','CE19007967','CE22012227','CE19013394','CE19016400','CE22004361','CE19002524','CE23010807','CE20003397','CE21011776','CE20004736','CE23005362','CE22014454','CE19005224','CE22011538','CE23010784','CE21003639','CE22008060','CE22014307','CE19006949','CE23014035','CE23000733','CE19007174','CE23009656','CE19011783','CE23002446','CE20012172','CE20018297','CE22015243','CE22012244','CE22005890','CE14010124','CE13011483','CE14001851','CE19001083','CE19007005','CE23013870','CE23013902','CE20012565','CE23008547','CE21012485','CE21014466','CE21009616','CE21015281','CE22010385','CE20004993','CE14005007','CE23008919','CE24002844','CE22007390','CE23010656','CE21004311','CE22001149','CE21013884','CE19014358','CE19015146','CE21008386','CE24002767','CE15000614','CE20014082','CE22014182','CE19009841','CE21015914','CE20006690','CE21012900','CE21008633','CE20017129','CE19018457','CE19016224','CE20007033','CE17020054','CE21006656','CE19007624','CE19007856','CE24000155','CE21003053','CE20017241','CE21011881','CE20008418','CE20010455','CE20004732','CE19014570','CE20006292','CE21015375','CE19011447','CE19000792','CE21016389','CE19014360','CE22014462','CE21006869','CE18016947','CE21000243','CE19005193','CE19015620','CE19009660','CE23009887','CE19009394','CE20010371','CE19016747','CE20012261','CE20016621','CE21005706','CE19015803','CE23001600','CE21009603','CE21001824','CE23008181','CE19002202','CE20013524','CE19000089','CE22004210','CE19005975','CE19011418','CE15005695','CE21015426','CE15014606','CE24001159','CE23000199','CE21005536','CE09010970','CE19008023','CE23011791','CE21009067','CE14011996','CE19010936','CE19016716','CE21011355','CE23003583','CE19011802','CE19010955','CE19016203','CE21010910','CE24002426','CE21016673','CE23012219','CE22013786','CE19009668','CE22011836','CE19009143','CE23000542','CE20008814','CE21004395','CE21004115','CE21002610','CE19012769','CE21010936','CE19009287','CE23001979','CE19012909','CE21011878','CE23002066','CE22001087','CE23006657','CE23006359','CE20016242','CE23004804','CE22003318','CE20004878','CE19008390','CE20012528','CE21008611','CE20011023','CE20011864','CE19014999','CE21011633','CE19006885','CE21005417','CE19003467','CE23002849','CE19012235','CE23014299','CE19014787','CE22012563','CE23000697','CE23011871','CE20000772','CE24001088','CE19011733','CE23014637','CE19001888','CE21015526','CE20003493','CE20014445','CE21006950','CE21004695','CE23011954','CE20006572','CE22008689','CE23009513','CE20003050','CE21012426','CE19009735','CE11005977','CE19014998','CE19010223','CE20007557','CE19018638','CE20015660','CE23011387','CE22007121','CE22000047','CE20004381','CE23009659','CE23008130','CE19019823','CE20007412','CE19008934','CE20004016','CE19013230','CE22005119','CE21001337','CE21000775','CE19016372','CE20001956','CE20013301','CE22013147','CE21003099','CE20014278','CE19013135','CE23002208','CE07001296','CE19019109','CE21015908','CE20001749','CE20015687','CE19018345','CE22002182','CE20018105','CE21011445','CE23008789','CE20014627','CE23004210','CE19009927','CE19011446','CE19011601','CE23005483','CE23000499','CE19000107','CE15001935','CE19020066','CE23009555','CE24003156','CE22008683','CE21015760','CE20011836','CE21010788','CE21015292','CE22005681','CE20014528','CE23011254','CE24000868','CE21012407','CE19018960','CE21009065','CE19014789','CE23011930','CE19015375','CE19013427','CE13015163','CE21003071','CE24000638','CE21012732','CE23005375','CE21007358','CE20007758','CE19011415','CE19008372','CE21013741','CE19006738','CE23002691','CE21010804','CE21010404','CE19004732','CE21003873','CE18009943','CE24003192','CE21002922','CE24002441','CE21011960','CE19011951','CE19015807','CE22004245','CE23013466','CE23005114','CE19019042','CE23004448','CE13001146','CE15003234','CE19000075','CE22014720','CE23005270','CE20007832','CE21011578','CE23011187','CE22001295','CE19016119','CE21015152','CE22014515','CE23013660','CE21003858','CE21005508','CE20013249','CE19000309','CE19015441','CE23013201','CE21008769','CE20008086','CE23001657','CE22000405','CE22006223','CE20003009','CE23006589','CE23011376','CE19013429','CE19014786','CE23014462','CE23005238','CE20005395','CE23004420','CE23003257','CE21002906','CE23006630','CE19005858','CE22012514','CE23012617','CE19009646','CE19013927','CE19011782','CE23012694','CE23005147','CE19007844','CE22012490','CE19020275','CE20002228','CE21011362','CE23011087','CE19009909','CE23003399','CE19014363','CE24000786','CE21005468','CE20008282','CE21001701','CE22001252','CE21010091','CE19016202','CE21011856','CE23010066','CE22001653','CE24002049','CE19011432','CE19014641','CE19015002','CE19006459','CE19018760','CE23002026','CE23001005','CE21007737','CE20004731','CE22012004','CE21010824','CE23002216','CE23001411','CE22005981','CE19002751','CE20005115','CE20012329','CE09013743','CE19010748'
    )
	--and b.NUMBER_KEY = @number_key
	and (
		(year(b.THE_DATE) = year(a.THE_DATE) and month(b.THE_DATE) = month(a.THE_DATE) and day(b.THE_DATE) = day(a.THE_DATE) )
		--or (year(b2.greater_date) = year(a.date_ent) and month(b2.greater_date) = month(a.date_ent) and day(b2.greater_date) = day(a.date_ent) )
		--or a.item_id = b.ITEM_ID
	)
	--and a.parent_unique_key not like 'ORPH-%'
	and a.item_id <> b.ITEM_ID
	--and b.NUMBER_KEY = 'CE04002961'
	and f.number_key is null	
;
insert into #_violations
select distinct
    a.NUMBER_KEY
    ,a.parent_unique_key
    ,b.item_id --count(distinct b.item_id) ct --,count(b.number_key) ct
--into #violations
from #g a
left join hcfl_src..apd_itms b on b.RECORD_TYPE = 'CD' and b.NUMBER_KEY = a.NUMBER_KEY
--left join greater_dates b2 on b2.number_key = b.number_key and b2.sequence = b.sequence and b2.item_id = b.item_id and b2.the_date = b.the_Date	
left join #_violations f on f.number_key = b.number_key and f.parent_unique_key = a.parent_unique_key and f.item_id = b.item_id
where
    1=1
	and b.NUMBER_KEY is not null
    and b.number_key in ('CE20008234' --'CE21005536','CE19019042','CE21009603','CE19011049','CE23013343','CE23012694','CE21009067','CE23011187','CE19010223','CE19005193','CE23005114','CE22012975','CE22014860','CE22008356','CE22013786','CE23003461','CE23014129','CE22014110','CE19011418','CE21005870','CE20006572','CE23001411','CE19011783','CE23004666','CE23000058','CE19004709','CE20001956','CE21000243','CE19012398','CE20008234','CE21014360','CE22009736','CE22014685','CE22014657','CE19009809','CE24002441','CE22006893','CE19014786','CE23000913','CE19011421','CE21010824','CE23009508','CE21011969','CE20009721','CE19007826','CE21014995','CE21003873','CE19012874','CE21007737','CE22013816','CE23009435','CE19005819','CE21016777','CE19007948','CE23014165','CE22012717','CE23000896','CE21011018','CE23002208','CE23001747','CE21004311','CE20001120','CE20004452','CE21015105','CE21009065','CE16010830','CE21000775','CE23003399','CE19011196','CE22003059','CE23009136','CE21013889','CE21002906','CE20000742','CE19015601','CE22010175','CE23013302','CE22012248','CE20002119','CE23000199','CE07006722','CE23011454','CE24002068','CE19011951','CE21012765','CE22001252','CE20014591','CE22003873','CE20011292','CE19011732','CE19011432','CE19005606','CE21010756','CE23003520','CE22002774','CE19001103','CE20003079','CE20007412','CE21004115'
)
	--and b.NUMBER_KEY = @number_key
	and (
		(year(b.THE_DATE) = year(a.date_ent) and month(b.THE_DATE) = month(a.date_ent) and day(b.THE_DATE) = day(a.date_ent) )
		--or (year(b2.greater_date) = year(a.date_ent) and month(b2.greater_date) = month(a.date_ent) and day(b2.greater_date) = day(a.date_ent) )
		--or a.item_id = b.ITEM_ID
	)
	and a.item_id <> b.ITEM_ID
	and f.number_key is null	
;


;with greater_dates as (
	select 
		 b.number_key
		,b.sequence
		,b.item_id
		,b.the_date
		,b2.THE_DATE greater_date
	from hcfl_src..apd_itms b
	outer apply (select top 1 * from hcfl_src..APD_ITMS where record_type = 'cd' and NUMBER_KEY = b.NUMBER_KEY and THE_DATE <> b.THE_DATE) b2
	where
		1=1
		and b.number_key in (--'CE19011421'
			'CE19014786','CE23000913','CE19011421','CE21010824','CE23009508','CE21011969','CE20009721','CE19007826','CE21014995','CE22014110','CE19011418','CE21005870','CE20006572','CE23001411','CE19011783','CE23004666','CE23009435','CE19005819','CE21016777','CE19007948','CE23014165','CE22012717','CE23000896','CE19011432','CE19005606','CE21010756','CE23003520','CE22002774','CE19001103','CE20003079','CE20007412','CE21004115','CE21000775','CE23003399','CE19011196','CE22003059','CE23009136','CE21013889','CE21002906','CE20000742','CE19015601','CE22010175','CE23013302','CE22012248','CE20002119','CE23000199','CE07006722','CE23011454','CE24002068','CE19011951','CE21012765','CE22001252','CE20014591','CE22003873','CE20011292','CE19011732','CE19012398','CE20008234','CE21014360','CE22009736','CE22014685','CE22014657','CE19009809','CE24002441','CE22006893','CE21005536','CE19019042','CE21009603','CE19011049','CE23013343','CE23012694','CE21009067','CE23011187','CE19010223','CE19005193','CE23005114','CE22012975','CE22014860','CE22008356','CE22013786','CE23003461','CE23014129','CE21003873','CE19012874','CE21007737','CE22013816','CE23000058','CE19004709','CE20001956','CE21000243','CE21011018','CE23002208','CE23001747','CE21004311','CE20001120','CE20004452','CE21015105','CE21009065','CE16010830'
            ,'CE24002698','CE24002677','CE24000095','CE24002940','CE24002516','CE24001571','CE24000841','CE24000276','CE21014437','CE24000153','CE24003572','CE24001826','CE24002465','CE24000537','CE24002759','CE24002219','CE24003484','CE23009330','CE24002813','CE24000171','CE24000155','CE24003615','CE23013361','CE19011049','CE21014435','CE24003382','CE24002844','CE24002618','CE24001446','CE24002499','CE23014427','CE24002629','CE24000956','CE24000307','CE23014095','CE24000177','CE23014301','CE24003053','CE23013872','CE23012257','CE24001949','CE24001585','CE24003139'
            ,'CE24007466','CE24004807','CE20017588','CE24000095','CE24003833','CE24004913','CE24007447','CE24005250','CE24007204','CE24007484','CE24004245','CE24004796','CE24004219','CE24003859','CE24007235','CE24006348','CE24005928','CE24007812','CE23014475','CE23009075','CE24004710','CE24005717','CE24006132','CE24006594','CE24000177','CE24006287','CE24004515','CE24004388','CE24004119','CE24006719'
		)
		and b2.the_Date is not null
		and b.RECORD_TYPE = 'cd'
		and not exists (select 1 from #_violations where number_key = b.NUMBER_KEY and item_id = b.ITEM_ID)
)
insert into #_violations
select distinct
	a.NUMBER_KEY
    ,a.parent_unique_key
    ,b.ITEM_ID   	
from #g a
left join hcfl_src..apd_itms b on b.RECORD_TYPE = 'CD' and b.NUMBER_KEY = a.NUMBER_KEY
left join greater_dates b2 on b2.number_key = b.number_key and b2.sequence = b.sequence and b2.item_id = b.item_id and b2.the_date = b.the_Date	
--left join #_violations f on f.parent_unique_key = a.parent_unique_key and f.item_id = a.item_id
where
    1=1
	and b.NUMBER_KEY is not null
	--and b.NUMBER_KEY = 'CE20008234 '
	and (
		--(year(b.THE_DATE) = year(a.date_ent) and month(b.THE_DATE) = month(a.date_ent) and day(b.THE_DATE) = day(a.date_ent) )
		(year(b2.greater_date) = year(a.date_ent) and month(b2.greater_date) = month(a.date_ent) and day(b2.greater_date) = day(a.date_ent) )
	)
	and a.item_id <> b.ITEM_ID
	--and f.number_key is null
;

insert into #_violations
select *
from (VALUES 
('CE19011049','A007910186','S13.2.1.11')
,('CE19011049','A007910186','S13.2.1.5')
,('CE19011049','A007910186','NR10.5.2')
,('CE24000095','A009153805','PM12.3A   ') --arbitrary association to capture them, and it's late
,('CE24000095','A009153805','R11.11.2  ') --arbitrary association to capture them, and it's late
,('CE24000095','A009153805','R11.7.5   ') --arbitrary association to capture them, and it's late
,('CE24000095','A009153805','R11.7.2   ') --arbitrary association to capture them, and it's late
,('CE24000095','A009153805','R11.6.4   ') --arbitrary association to capture them, and it's late
,('CE24000095','A009153805','PM12.4    ') --arbitrary association to capture them, and it's late
,('CE24000177','A009133092','NR10.1    ') --arbitrary association to capture them, and it's late
,('CE24000177','A009133092','PM12.3A   ') --arbitrary association to capture them, and it's late
,('CE24000177','A009133092','R11.5.5   ') --arbitrary association to capture them, and it's late
,('CE24000177','A009133092','R11.7.9   ') --arbitrary association to capture them, and it's late
,('CE24000177','A009133092','PM12.3B   ') --arbitrary association to capture them, and it's late

) t(number_key,parent_unique_key,item_id)
;
delete a
from #_violations a 
join (VALUES 
 ('CE20014591','A008555900','R11.7.4   ')
,('CE19011049','A007962881','S13.2.1.11')
,('CE19011049','A007962881','S13.2.1.5 ')
) d(number_key,parent_unique_key,item_id)
	on d.number_key = a.number_key
	and d.parent_unique_key = a.parent_unique_key 
	and d.item_id = a.item_id
where
	1=1
;


;IF OBJECT_ID('tempdb.dbo.#violations', 'U') IS NOT NULL drop table #violations
select
	number_key 
	,parent_unique_key 
	,count(item_id) ct 
into #violations
from #_violations
group by number_key,parent_unique_key
;
go

    --VERIFY the above
        --shoehorn some things
    update v set 
		ct = a.apd_itms_violations_ct
    from (
        select
            a.NUMBER_KEY
            ,a.violations_ct as apd_itms_violations_ct
            ,sum(b.ct) as my_violations_ct
        from (
            select
                a.number_key
                ,count(*) violations_ct
            from hcfl_src..apd_itms a
            join jms_apd_base_filtered f on f.NUMBER_KEY = a.NUMBER_KEY
            where
                1=1
                and a.RECORD_TYPE = 'CD'
            group by a.NUMBER_KEY
            having count(*) > 0
        ) a
        left join #violations b on b.numbeR_key = a.NUMBER_KEY
        where
            1=1
            --and a.violations_ct <> b.ct
            --and a.NUMBER_KEY = 'CE23007349'
        group by  a.NUMBER_KEY
            ,a.violations_ct-- as apd_itms_violations_ct
		having a.violations_ct <> sum(b.ct)
    ) a
	left join  #violations v on v.NUMBER_KEY = a.NUMBER_KEY and v.ct = a.my_violations_ct
    ;
--if 1 = (
--    select distinct 1 
--    from (
--        select
--            a.NUMBER_KEY
--            ,a.violations_ct as apd_itms_violations_ct
--            ,sum(b.ct) as my_violations_ct
--        from (
--            select
--                a.number_key
--                ,count(*) violations_ct
--            from hcfl_src..apd_itms a
--            join jms_apd_base_filtered f on f.NUMBER_KEY = a.NUMBER_KEY
--            where
--                1=1
--                and a.RECORD_TYPE = 'CD'
--            group by a.NUMBER_KEY
--            having count(*) > 0
--        ) a
--        left join #violations b on b.numbeR_key = a.NUMBER_KEY
--        where
--            1=1
--            --and a.violations_ct <> b.ct
--            --and a.NUMBER_KEY = 'CE23007349'
--        group by  a.NUMBER_KEY
--            ,a.violations_ct-- as apd_itms_violations_ct
--		having a.violations_ct <> sum(b.ct)
--    ) a
--    
--) RAISERROR ('violations counts mismatch', 16, 1)
--;          
go

--rem all in h are the site visits to which subsequent row statuses are applied. Similarly: this is to find the req_opt of the subsequent rows for a given site visit.
;with j as (
	select distinct
        a.NUMBER_KEY
        ,a.parent_unique_key
        ,b.REQ_OPT
    --into #violations
    from #g a
    left join hcfl_src..apd_itms b
        on
			b.RECORD_TYPE = 'CD'
			and b.NUMBER_KEY = a.NUMBER_KEY
			and year(b.THE_DATE) = year(a.the_date) and month(b.THE_DATE) = month(a.the_date) and day(b.THE_DATE) = day(a.THE_DATE)
			and b.ITEM_ID = a.ITEM_ID
		
    where
        1=1
		and b.req_opt is not null
        --and c.NUMBER_KEY = 'CE22010196'
    --group by a.number_key,a.parent_unique_key
), doubles as (
	select parent_unique_key, count(distinct req_opt) ct from j group by parent_unique_key  having count(distinct req_opt) > 1
)
select distinct
	a.number_key
	,a.parent_unique_key
	,case when f.parent_unique_key is not null then 'R' else a.REQ_OPT end req_opt
into #req_opt
from j a
left join doubles f on f.parent_unique_key = a.parent_unique_key
;


;IF OBJECT_ID('accelaconv7.dbo.jms_inspections_compliantOrNot', 'U') IS NOT NULL drop table accelaconv7.dbo.jms_inspections_compliantOrNot
;
select distinct 
    a1.number_key
	,a1.UNIQUE_KEY
	,a1.ACTION_ENT
	,a1.inspection_type
	,a1.inspection_result
    ,r.req_opt
	,isnull(v.ct,0) violations_count
	,trim('^|' from stuff((
        select 
            '^|^' + cast(
				trim(replace(replace(replace(replace(   isnull(a2.any_comments,'')   ,'"',''''''),'''',''),char(13),''),char(10),'®')) 
				as varchar(max)
			)
        from #h a2 with(nolock)
        where 
            a2.UNIQUE_key = a1.UNIQUE_key
        group by a2.any_comments
        order by a2.any_comments
        FOR XML PATH('')
     ), 1, 1, '')) as any_comments
into jms_inspections_compliantOrNot
from #h a1 WITH (NOLOCK)
left join #violations v on v.NUMBER_KEY = a1.NUMBER_KEY and v.parent_unique_key = a1.UNIQUE_KEY
left join #req_opt r on r.parent_unique_key = a1.unique_key --a1 is site visits, therefore is parent unique key values.
where
    1=1
;


--ensure no duplicates
update a set
	inspection_type = (case 
            when inspection_type in ('Initial Site Visit','Quality Control Inspection') then inspection_type
            when a.any_comments like '%re%inspect%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when a.any_comments like '%re%check%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when a.any_comments like '%annual%insp%'    then 'Annual Inspection' --I don't know about pre vs post hearing
            when a.any_comments like '%post%hearing%'    then 'Post-Hearing Inspection' --I don't know about pre vs post hearing
            when a.any_comments like '%pre%hearing%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when a.any_comments like '%hear%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when a.any_comments like '%follow%up%'    then 'Follow-up Inspection' --I don't know about pre vs post hearing
            else 'Inspection'
            end		
        )
from jms_inspections_compliantOrNot a
where
	1=1
	--and a.UNIQUE_KEY = 'a008872077'
;

;WITH CTE AS (SELECT *,ROW_NUMBER() OVER (PARTITION BY number_key,unique_key,inspection_type,any_comments ORDER BY number_key) AS RN FROM jms_inspections_compliantOrNot) DELETE FROM CTE WHERE RN<>1 
;
