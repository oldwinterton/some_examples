/*
When considering a given record, it might have a person who is licensed but is not appearing to me as though they are listed conceptually as a licensed individual.
    i.e. -- ought I make all apd_peo people regular contacts and owners, and then use con_peo for licensed individuals?
Some applicants exist and have a license, but do not also exist as a non-applicant licensed individual.

create_PERMIT_PEOPLE
apd_peo__owner__lic_or_not
apd_peo__nonOwner__notLic
apd_peo__all_with_lic

CBS people duplication -- addendum per 20240525 - they want people duplicated on cbs records from non-cbs records

--par_peo__owner__lic_or_not
--par_peo__all_with_lic

--adr_peo__notLic



CONSIDER:
ADR_PEO	177002 --?
APD_PEO	11022932 
    CON_PEO	81372   --contractors
    MDL_PEO	376     --?
FEE_PEO	0
PAR_PEO	357856  --parcel people?? What is that?
*/


--create_PERMIT_PEOPLE
IF OBJECT_ID('tempdb.dbo.##completed', 'U') IS NOT NULL 
insert into ##completed values (getdate(),'create_PERMIT_PEOPLE')
;
;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_PEOPLE
;

--apd_peo__owner__lic_or_not
;print 'apd_peo__owner__lic_or_not';
insert into AATABLE_PERMIT_PEOPLE (
PERMITNUM,TT_CONTACT_TYPE,CONTACT_RELATIONSHIP ,ISPRIMARY,LIC_NUM,LIC_TYPE,NAME,FNAME,MNAME,LNAME,BUS_NAME,ADDR1,ADDR2,ADDR3,CITY,STATE,ZIP,PH1,PH2,FAX,EMAIL,COMMENTS,TITLE,PH3,COUNTRY_CODE,NOTIFY,NAME_SUFFIX,BUS_LIC,LIC_ORIGINAL_ISSUE_DATE,EXPIRATION_DATE,RENEWAL_DATE,MAIL_ADDR1,MAIL_ADDR2,MAIL_ADDR3,MAIL_CITY,MAIL_STATE,MAIL_ZIP,MAIL_COUNTRY,OWNER_TYPE,GENDER,SALUTATION,PO_BOX,BUS_NAME2,BIRTH_DATE,PH1_COUNTRY_CODE,PH2_COUNTRY_CODE,FAX_COUNTRY_CODE,PH3_COUNTRY_CODE,TRADE_NAME,CONTACT_TYPE_FLAG,SOCIAL_SECURITY_NUMBER,FEDERAL_EMPLOYER_ID_NUM,CONTRA_TYPE_FLAG,LIC_BOARD,B1_ID,CONT_LIC_BUS_NAME,B1_ACCESS_LEVEL,BIRTH_CITY,BIRTH_STATE,BIRTH_REGION,B1_CONTACT_NBR,DECEASED_DATE,DRIVER_LIC_NBR,DRIVER_LIC_STATE,PASSPORT_NBR,STATE_ID_NBR,RACE,G1_CONTACT_NBR,LIC_STATE
)
select distinct
	pnum.permitnum
    ,'(OWNER)' contact_type
    ,null contact_relationship 
    ,'Y' isPrimary --(case when a.primary_name = 1 then 'Y' else 'N' end) isPrimary
    ,null Lic_Num
    ,null lic_type
    ,left(trim(replace(replace(   trim(isnull(a.address_1,'')) + isnull(trim(a.name),'')    ,'  ',' '),'  ',' ')),220) name
    ,null as FName --,trim(substring(a.name,1,charindex(' ',a.name))) as FName
    ,null as MName
    ,left(trim(replace(replace(   a.name    ,'  ',' '),'  ',' ')),70) --,left(trim(substring(a.name,charindex(' ',a.name),len(a.name))),70) LName
    ,trim(replace(replace(   a.name    ,'  ',' '),'  ',' ')) bus_name --replace(replace(replace(replace(   coalesce(a.PROGRAM_IDENTIFIER,fac.facility_name)    ,'"',''''''),'''',''),char(13),''),char(10),'') as Bus_Name
    ,left(trim(replace(replace(replace(replace(        a.address_2          ,'  ',' '),'  ',' '),'  ',' '),',,',',')),40) addr1
    ,a.address_3 addr2
    ,null add3
    ,null city
    ,null state
    ,left(coalesce(a.zip,''),10) zip
    ,a.phone_1 ph1
    ,a.phone_2 ph2
    ,null as Fax
    ,left(a.email_addr,70) Email
    ,null as Comments
    ,a.relationship as Title
    ,null as Ph3
    ,null as Country_Code
    ,null as Notify
    ,null as Name_Suffix
    ,null as Bus_Lic
    ,null as Lic_Original_Issue_Date
    ,null as Expiration_date
    ,null as Renewal_Date
    ,left(trim(replace(replace(replace(replace(        a.address_2          ,'  ',' '),'  ',' '),'  ',' '),',,',',')),40) MAIL_ADDR1
    ,a.address_3 MAIL_ADDR2
    ,null as Mail_add3
    ,null Mail_city
    ,null mail_state --,coalesce(e.state,fac.mstate,'') Mail_state
    ,left(coalesce(a.zip,''),10) mail_zip --,left(coalesce(e.zip,fac.mzip,''),10) Mail_zip
    ,null as Mail_Country
    ,null as Owner_Type
    ,null as Gender
    ,null as Salutation
    ,null as PO_Box
    ,null as Bus_Name2
    ,null as Birth_Date
    ,null as Ph1_Country_Code,null as Ph2_Country_Code,null as Fax_Country_Code,null as Ph3_Country_Code,null as Trade_Name,null as Contact_Type_Flag,null as Social_Security_Number,null as Federal_Employer_ID_Num,null as Contra_Type_Flag,null as Lic_Board,null as B1_ID,null as Cont_Lic_Bus_Name,null as B1_Access_Level,null as Birth_City,null as Birth_State,null as Birth_Region,null as B1_Contact_Nbr,null as Deceased_Date
    ,null as Driver_License_Nbr    
    ,null as Driver_License_State,null as Passport_Nbr,null as State_Id_Nbr,null as Race,null as G1_Contact_Nbr,null as Lic_State
from aatable_permit_history pnum --from (select distinct number_key permitnum from hcfl_src.dbo.apd_base) pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_peo a on a.number_key = pmap.number_key
WHERE
    1=1
    and a.relationship in (
        'ONWER     '
        ,'OOWNER    '
        ,'OWENER    '
        ,'OWER      '
        ,'OWMER     '
        ,'OWNER     '
        ,'OWNER,    '
        ,'OWNER/AGEN'
        ,'OWNER/APP '
        ,'OWNER/GC  '
        ,'OWNER/OCC '
        ,'OWNER6    '
        ,'OWNERS    '
        ,'PARK OWNER'
        ,'PROP OWNER'
        ,'AGENT/OWNR'
        ----all home% are unlicensed.
        ,'HOME OWNER'
        ,'HOMEEOWNER'
        ,'HOMEOWER  '
        ,'HOMEOWNER '
        ,'HOMEOWNER.'
        ,'HOMEOWNERS'
        ,'HOMEWONER '
        ,'HOMWOWNER '
        ,'HONMEOWNER'
        -----         
        --,'APPICANT  '
        --,'APPLICANT '
        --,'APPLICANTS'
        
    )
    --or 
    --(isnull(trim(a.license_no),'') = '')
    --)
    ----NO! All investigators and inspectors are unlicensed individuals.
    --and a.relationship not in (
    --    'INSPECTOR '
    --    ,'INVESTIG  '
    --    ,'INVESTIGAT'
    
;
    --this is for https://redmine.scubeenterprise.com/issues/19588, so "owner" appears as name on top ribbon.
;print 'apd_peo__owner__lic_or_not part2';
insert into AATABLE_PERMIT_PEOPLE (
PERMITNUM,TT_CONTACT_TYPE,CONTACT_RELATIONSHIP ,ISPRIMARY,LIC_NUM,LIC_TYPE,NAME,FNAME,MNAME,LNAME,BUS_NAME,ADDR1,ADDR2,ADDR3,CITY,STATE,ZIP,PH1,PH2,FAX,EMAIL,COMMENTS,TITLE,PH3,COUNTRY_CODE,NOTIFY,NAME_SUFFIX,BUS_LIC,LIC_ORIGINAL_ISSUE_DATE,EXPIRATION_DATE,RENEWAL_DATE,MAIL_ADDR1,MAIL_ADDR2,MAIL_ADDR3,MAIL_CITY,MAIL_STATE,MAIL_ZIP,MAIL_COUNTRY,OWNER_TYPE,GENDER,SALUTATION,PO_BOX,BUS_NAME2,BIRTH_DATE,PH1_COUNTRY_CODE,PH2_COUNTRY_CODE,FAX_COUNTRY_CODE,PH3_COUNTRY_CODE,TRADE_NAME,CONTACT_TYPE_FLAG,SOCIAL_SECURITY_NUMBER,FEDERAL_EMPLOYER_ID_NUM,CONTRA_TYPE_FLAG,LIC_BOARD,B1_ID,CONT_LIC_BUS_NAME,B1_ACCESS_LEVEL,BIRTH_CITY,BIRTH_STATE,BIRTH_REGION,B1_CONTACT_NBR,DECEASED_DATE,DRIVER_LIC_NBR,DRIVER_LIC_STATE,PASSPORT_NBR,STATE_ID_NBR,RACE,G1_CONTACT_NBR,LIC_STATE
)
select distinct
	pnum.permitnum
    ,'Owner' contact_type
    ,null contact_relationship 
    ,'Y' isPrimary
    ,null Lic_Num
    ,null lic_type
    ,left(trim(replace(replace(   trim(isnull(a.address_1,'')) + isnull(trim(a.name),'')    ,'  ',' '),'  ',' ')),220) name
    ,null as FName --,trim(substring(a.name,1,charindex(' ',a.name))) as FName
    ,null as MName
    ,left(trim(replace(replace(   a.name    ,'  ',' '),'  ',' ')),70) --,left(trim(substring(a.name,charindex(' ',a.name),len(a.name))),70) LName
    ,trim(replace(replace(   a.name    ,'  ',' '),'  ',' ')) bus_name --replace(replace(replace(replace(   coalesce(a.PROGRAM_IDENTIFIER,fac.facility_name)    ,'"',''''''),'''',''),char(13),''),char(10),'') as Bus_Name
    ,left(trim(replace(replace(replace(replace(        a.address_2          ,'  ',' '),'  ',' '),'  ',' '),',,',',')),40) addr1
    ,a.address_3 addr2
    ,null add3
    ,null city
    ,null state
    ,left(coalesce(a.zip,''),10) zip
    ,a.phone_1 ph1
    ,a.phone_2 ph2
    ,null as Fax
    ,left(a.email_addr,70) Email
    ,null as Comments
    ,a.relationship as Title
    ,null as Ph3
    ,null as Country_Code
    ,null as Notify
    ,null as Name_Suffix
    ,null as Bus_Lic
    ,null as Lic_Original_Issue_Date
    ,null as Expiration_date
    ,null as Renewal_Date
    ,left(trim(replace(replace(replace(replace(        a.address_2          ,'  ',' '),'  ',' '),'  ',' '),',,',',')),40) addr1
    ,a.address_3 addr2
    ,null as Mail_add3
    ,null Mail_city
    ,null mail_state --,coalesce(e.state,fac.mstate,'') Mail_state
    ,left(coalesce(a.zip,''),10) mail_zip --,left(coalesce(e.zip,fac.mzip,''),10) Mail_zip
    ,null as Mail_Country
    ,null as Owner_Type
    ,null as Gender
    ,null as Salutation
    ,null as PO_Box
    ,null as Bus_Name2
    ,null as Birth_Date
    ,null as Ph1_Country_Code,null as Ph2_Country_Code,null as Fax_Country_Code,null as Ph3_Country_Code,null as Trade_Name,null as Contact_Type_Flag,null as Social_Security_Number,null as Federal_Employer_ID_Num,null as Contra_Type_Flag,null as Lic_Board,null as B1_ID,null as Cont_Lic_Bus_Name,null as B1_Access_Level,null as Birth_City,null as Birth_State,null as Birth_Region,null as B1_Contact_Nbr,null as Deceased_Date
    ,null as Driver_License_Nbr    
    ,null as Driver_License_State,null as Passport_Nbr,null as State_Id_Nbr,null as Race,null as G1_Contact_Nbr,null as Lic_State
from aatable_permit_history pnum --from (select distinct number_key permitnum from hcfl_src.dbo.apd_base) pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_peo a on a.number_key = pmap.number_key
WHERE
    1=1
    and a.relationship in (
        'ONWER     '
        ,'OOWNER    '
        ,'OWENER    '
        ,'OWER      '
        ,'OWMER     '
        ,'OWNER     '
        ,'OWNER,    '
        ,'OWNER/AGEN'
        ,'OWNER/APP '
        ,'OWNER/GC  '
        ,'OWNER/OCC '
        ,'OWNER6    '
        ,'OWNERS    '
        ,'PARK OWNER'
        ,'PROP OWNER'
        ,'AGENT/OWNR'
        ----all home% are unlicensed.
        ,'HOME OWNER'
        ,'HOMEEOWNER'
        ,'HOMEOWER  '
        ,'HOMEOWNER '
        ,'HOMEOWNER.'
        ,'HOMEOWNERS'
        ,'HOMEWONER '
        ,'HOMWOWNER '
        ,'HONMEOWNER'
        -----         
        --,'APPICANT  '
        --,'APPLICANT '
        --,'APPLICANTS'
        
    )
    --or 
    --(isnull(trim(a.license_no),'') = '')
    --)
    ----NO! All investigators and inspectors are unlicensed individuals.
    --and a.relationship not in (
    --    'INSPECTOR '
    --    ,'INVESTIG  '
    --    ,'INVESTIGAT'
    
;
--apd_peo__nonOwner__notLic
;print 'apd_peo__nonOwner__notLic';
insert into AATABLE_PERMIT_PEOPLE (
PERMITNUM,TT_CONTACT_TYPE,CONTACT_RELATIONSHIP ,ISPRIMARY,LIC_NUM,LIC_TYPE,NAME,FNAME,MNAME,LNAME,BUS_NAME,ADDR1,ADDR2,ADDR3,CITY,STATE,ZIP,PH1,PH2,FAX,EMAIL,COMMENTS,TITLE,PH3,COUNTRY_CODE,NOTIFY,NAME_SUFFIX,BUS_LIC,LIC_ORIGINAL_ISSUE_DATE,EXPIRATION_DATE,RENEWAL_DATE,MAIL_ADDR1,MAIL_ADDR2,MAIL_ADDR3,MAIL_CITY,MAIL_STATE,MAIL_ZIP,MAIL_COUNTRY,OWNER_TYPE,GENDER,SALUTATION,PO_BOX,BUS_NAME2,BIRTH_DATE,PH1_COUNTRY_CODE,PH2_COUNTRY_CODE,FAX_COUNTRY_CODE,PH3_COUNTRY_CODE,TRADE_NAME,CONTACT_TYPE_FLAG,SOCIAL_SECURITY_NUMBER,FEDERAL_EMPLOYER_ID_NUM,CONTRA_TYPE_FLAG,LIC_BOARD,B1_ID,CONT_LIC_BUS_NAME,B1_ACCESS_LEVEL,BIRTH_CITY,BIRTH_STATE,BIRTH_REGION,B1_CONTACT_NBR,DECEASED_DATE,DRIVER_LIC_NBR,DRIVER_LIC_STATE,PASSPORT_NBR,STATE_ID_NBR,RACE,G1_CONTACT_NBR,LIC_STATE
)
select distinct 
	pnum.permitnum
    ,coalesce(case when trim(a.relationship)='' then null else a.relationship end,'Contact') contact_type
    ,null contact_relationship 
    ,(case when a.primary_name = 1 then 'Y' else 'N' end) isPrimary
    ,null Lic_Num
    ,null lic_type
    ,left(trim(replace(replace(   trim(isnull(a.address_1,'')) + isnull(trim(a.name),'')    ,'  ',' '),'  ',' ')),220) name
    ,null as FName --,trim(substring(a.name,1,charindex(' ',a.name))) as FName
    ,null as MName
    ,left(trim(replace(replace(   a.name    ,'  ',' '),'  ',' ')),70) --,left(trim(substring(a.name,charindex(' ',a.name),len(a.name))),70) LName
    ,trim(replace(replace(   a.name    ,'  ',' '),'  ',' ')) bus_name --replace(replace(replace(replace(   coalesce(a.PROGRAM_IDENTIFIER,fac.facility_name)    ,'"',''''''),'''',''),char(13),''),char(10),'') as Bus_Name
    ,left(trim(replace(replace(replace(replace(        a.address_2          ,'  ',' '),'  ',' '),'  ',' '),',,',',')),40) addr1
    ,a.address_3 addr2
    ,null add3
    ,null city
    ,null state
    ,left(coalesce(a.zip,''),10) zip
    ,a.phone_1 ph1
    ,a.phone_2 ph2
    ,null as Fax
    ,left(a.email_addr,70) Email
    ,null as Comments
    ,a.relationship as Title
    ,null as Ph3
    ,null as Country_Code
    ,null as Notify
    ,null as Name_Suffix
    ,null as Bus_Lic
    ,null as Lic_Original_Issue_Date
    ,null as Expiration_date
    ,null as Renewal_Date
    ,left(trim(replace(replace(replace(replace(        a.address_2          ,'  ',' '),'  ',' '),'  ',' '),',,',',')),40) Mail_addr1
    ,a.address_3 as Mail_addr2
    ,null as Mail_add3
    ,null Mail_city
    ,null mail_state --,coalesce(e.state,fac.mstate,'') Mail_state
    ,left(coalesce(a.zip,''),10) mail_zip --,left(coalesce(e.zip,fac.mzip,''),10) Mail_zip
    ,null as Mail_Country
    ,null as Owner_Type
    ,null as Gender
    ,null as Salutation
    ,null as PO_Box
    ,null as Bus_Name2
    ,null as Birth_Date
    ,null as Ph1_Country_Code,null as Ph2_Country_Code,null as Fax_Country_Code,null as Ph3_Country_Code,null as Trade_Name,null as Contact_Type_Flag,null as Social_Security_Number,null as Federal_Employer_ID_Num,null as Contra_Type_Flag,null as Lic_Board,null as B1_ID,null as Cont_Lic_Bus_Name,null as B1_Access_Level,null as Birth_City,null as Birth_State,null as Birth_Region,null as B1_Contact_Nbr,null as Deceased_Date
    ,null as Driver_License_Nbr    
    ,null as Driver_License_State,null as Passport_Nbr,null as State_Id_Nbr,null as Race,null as G1_Contact_Nbr,null as Lic_State
from aatable_permit_history pnum --from (select distinct number_key permitnum from hcfl_src.dbo.apd_base) pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_peo a on a.number_key = pmap.number_key
WHERE
    1=1
    and a.relationship not in (
        'ONWER     '
        ,'OOWNER    '
        ,'OWENER    '
        ,'OWER      '
        ,'OWMER     '
        ,'OWNER     '
        ,'OWNER,    '
        ,'OWNER/AGEN'
        ,'OWNER/APP '
        ,'OWNER/GC  '
        ,'OWNER/OCC '
        ,'OWNER6    '
        ,'OWNERS    '
        ,'PARK OWNER'
        ,'PROP OWNER'
        ,'AGENT/OWNR'
        ----all home% are unlicensed.
        ,'HOME OWNER'
        ,'HOMEEOWNER'
        ,'HOMEOWER  '
        ,'HOMEOWNER '
        ,'HOMEOWNER.'
        ,'HOMEOWNERS'
        ,'HOMEWONER '
        ,'HOMWOWNER '
        ,'HONMEOWNER'
        -----         
        --,'APPICANT  '
        --,'APPLICANT '
        --,'APPLICANTS'
        
    )
    and isnull(trim(a.license_no),'') = ''
;


--apd_peo__all_with_lic
;print 'apd_peo__all_with_lic';
insert into AATABLE_PERMIT_PEOPLE (
PERMITNUM,TT_CONTACT_TYPE,CONTACT_RELATIONSHIP ,ISPRIMARY,LIC_NUM,LIC_TYPE,NAME,FNAME,MNAME,LNAME,BUS_NAME,ADDR1,ADDR2,ADDR3,CITY,STATE,ZIP,PH1,PH2,FAX,EMAIL,COMMENTS,TITLE,PH3,COUNTRY_CODE,NOTIFY,NAME_SUFFIX,BUS_LIC,LIC_ORIGINAL_ISSUE_DATE,EXPIRATION_DATE,RENEWAL_DATE,MAIL_ADDR1,MAIL_ADDR2,MAIL_ADDR3,MAIL_CITY,MAIL_STATE,MAIL_ZIP,MAIL_COUNTRY,OWNER_TYPE,GENDER,SALUTATION,PO_BOX,BUS_NAME2,BIRTH_DATE,PH1_COUNTRY_CODE,PH2_COUNTRY_CODE,FAX_COUNTRY_CODE,PH3_COUNTRY_CODE,TRADE_NAME,CONTACT_TYPE_FLAG,SOCIAL_SECURITY_NUMBER,FEDERAL_EMPLOYER_ID_NUM,CONTRA_TYPE_FLAG,LIC_BOARD,B1_ID,CONT_LIC_BUS_NAME,B1_ACCESS_LEVEL,BIRTH_CITY,BIRTH_STATE,BIRTH_REGION,B1_CONTACT_NBR,DECEASED_DATE,DRIVER_LIC_NBR,DRIVER_LIC_STATE,PASSPORT_NBR,STATE_ID_NBR,RACE,G1_CONTACT_NBR,LIC_STATE
)
select distinct 
    pnum.permitnum
    ,null contact_type
    ,null contact_relationship
    ,(case when isnull(isPrimary.isPrimary,'') = 'Y' then 'N' when a.primary_name = 1 then 'Y' else 'N' end) isPrimary
    ,a.license_no Lic_Num
    ,a.relationship lic_type
    ,left(trim(replace(replace(   trim(isnull(a.address_1,'')) + isnull(trim(a.name),'')    ,'  ',' '),'  ',' ')),220) name
    ,null as FName --,trim(substring(a.name,1,charindex(' ',a.name))) as FName
    ,null as MName
    ,left(trim(replace(replace(   a.name    ,'  ',' '),'  ',' ')),70) --,left(trim(substring(a.name,charindex(' ',a.name),len(a.name))),70) LName
	,a.name as Bus_Name
    ,left(trim(replace(replace(replace(replace(        a.address_2          ,'  ',' '),'  ',' '),'  ',' '),',,',',')),40) addr1
    ,a.address_3 addr2
    ,null add3
    ,null city
    ,null state
    ,left(coalesce(a.zip,''),10) zip
    ,a.phone_1 ph1
    ,a.phone_2 ph2
    ,cp.phone_fax as Fax
    ,left(a.email_addr,70) Email
    ,trim(';' from isnull(';element_key:'+cb.element_key,'')+isnull(';ins_policy:'+cb.ins_policy,'')+isnull(';ins_amt:'+convert(varchar(max),cb.ins_amt),'')+isnull(';ins_carrier:'+cb.ins_carrier,'')) --comments.comment_text as Comments
    ,null as Title
    ,null as Ph3
    ,null as Country_Code
    ,null as Notify
    ,null as Name_Suffix
    ,cb.BUSINESS_LIC as Bus_Lic
    ,cb.entered_date as Lic_Original_Issue_Date
    ,cb.lic_exp_date as Expiration_date
    ,null as renewal_date
    ,left(trim(replace(replace(replace(replace(        a.address_2          ,'  ',' '),'  ',' '),'  ',' '),',,',',')),40) Mail_addr1
    ,a.address_3 as Mail_addr2
    ,null as Mail_add3
    ,null Mail_city
    ,null mail_state --,coalesce(e.state,fac.mstate,'') Mail_state
    ,left(coalesce(a.zip,''),10) mail_zip --,left(coalesce(e.zip,fac.mzip,''),10) Mail_zip
    ,'USA' as Mail_Country
    ,null as Owner_Type,null as Gender,null as Salutation,null as PO_Box,null as Bus_Name2
    ,null as Birth_Date
    ,null as Ph1_Country_Code,null as Ph2_Country_Code,null as Fax_Country_Code,null as Ph3_Country_Code,null as Trade_Name,null as Contact_Type_Flag,null as Social_Security_Number,null as Federal_Employer_ID_Num,null as Contra_Type_Flag,null as Lic_Board,null as B1_ID,null as Cont_Lic_Bus_Name,null as B1_Access_Level,null as Birth_City,null as Birth_State,null as Birth_Region,null as B1_Contact_Nbr,null as Deceased_Date
    ,null as Driver_License_Nbr    
    ,null as Driver_License_State,null as Passport_Nbr,null as State_Id_Nbr,null as Race,null as G1_Contact_Nbr,null as Lic_State
from aatable_permit_history pnum --from (select distinct number_key permitnum from hcfl_src.dbo.apd_base) pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_peo a on a.number_key = pmap.number_key
left join aatable_permit_people isPrimary 
    on isPrimary.permitnum = pnum.permitnum
    and isPrimary.name = trim(replace(replace(   a.name    ,'  ',' '),'  ',' '))
    and isPrimary.addr1 = left(trim(replace(replace(replace(replace(         case when coalesce(trim(a.address_1),'') <> '' then a.address_1 else 'Not Set' end          ,'  ',' '),'  ',' '),'  ',' '),',,',',')),40)
left join hcfl_src.dbo.con_peo cp on cp.LICENSE_NO = a.LICENSE_NO and cp.name = a.name
left join hcfl_src.dbo.CON_BASE cb on cb.ELEMENT_KEY = cp.ELEMENT_KEY
WHERE
    1=1
    and (isnull(trim(a.license_no),'') <> '')
;


--CBS people duplication -- addendum per 20240525 - they want people duplicated on cbs records from non-cbs records
delete a
from AATABLE_PERMIT_PEOPLE a
join AATABLE_PERMIT_HISTORY pnum on pnum.PERMITNUM = a.PERMITNUM
join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum 
;
go

insert into aatable_permit_people
select
	pnum.PERMITNUM,
	a.TT_CONTACT_TYPE,a.CONTACT_RELATIONSHIP,a.ISPRIMARY,a.LIC_NUM,a.LIC_TYPE,a.NAME,a.FNAME,a.MNAME,a.LNAME,a.BUS_NAME,a.ADDR1,a.ADDR2,a.ADDR3,a.CITY,a.STATE,a.ZIP,a.PH1,a.PH2,a.FAX,a.EMAIL,a.COMMENTS,a.TITLE,a.PH3,a.COUNTRY_CODE,a.NOTIFY,a.NAME_SUFFIX,a.BUS_LIC,a.LIC_ORIGINAL_ISSUE_DATE,a.EXPIRATION_DATE,a.RENEWAL_DATE,a.MAIL_ADDR1,a.MAIL_ADDR2,a.MAIL_ADDR3,a.MAIL_CITY,a.MAIL_STATE,a.MAIL_ZIP,a.MAIL_COUNTRY,a.OWNER_TYPE,a.GENDER,a.SALUTATION,a.PO_BOX,a.BUS_NAME2,a.BIRTH_DATE,a.PH1_COUNTRY_CODE,a.PH2_COUNTRY_CODE,a.FAX_COUNTRY_CODE,a.PH3_COUNTRY_CODE,a.TRADE_NAME,a.CONTACT_TYPE_FLAG,a.SOCIAL_SECURITY_NUMBER,a.FEDERAL_EMPLOYER_ID_NUM,a.CONTRA_TYPE_FLAG,a.LIC_BOARD,a.B1_ID,a.CONT_LIC_BUS_NAME,a.B1_ACCESS_LEVEL,a.BIRTH_CITY,a.BIRTH_STATE,a.BIRTH_REGION,a.B1_CONTACT_NBR,a.DECEASED_DATE,a.DRIVER_LIC_NBR,a.DRIVER_LIC_STATE,a.PASSPORT_NBR,a.STATE_ID_NBR,a.RACE,a.G1_CONTACT_NBR,a.LIC_STATE
from AATABLE_PERMIT_PEOPLE a
join AATABLE_PERMIT_HISTORY pnum on pnum.PERMITNUM = a.PERMITNUM + '-CBS'
join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum 
where
	1=1	
;
go



