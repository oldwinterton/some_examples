/*
create_aatable_PERMIT_PARCEL
duplicate the parcel information into the cbs record
*/

--create_aatable_PERMIT_PARCEL
IF OBJECT_ID('tempdb.dbo.##completed', 'U') IS NOT NULL 
insert into ##completed values (getdate(),'create_aatable_PERMIT_PARCEL')
;
;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_PARCEL
;
;print 'AATABLE_PERMIT_PARCEL';
insert into AATABLE_PERMIT_PARCEL (
PERMITNUM,PARCELNUM,BOOK,PAGE,PARCEL,LOT,BLOCK,TRACT,LEGAL_DESC,PARCEL_AREA,PLAN_AREA,CENSUS_TRACT,COUNCIL_DISTRICT,SUPERVISOR_DISTRICT,INSPECTION_DISTRICT,LAND_VALUE,IMPROVED_VALUE,EXEMPT_VALUE,MAP_REFERENCE,MAP_NUMBER,SUBDIVISION,PRIMARY_FLAG,TOWNSHIP,RANGE,SECTION,EXT_PARCEL_UID
)
select distinct
    pnum.permitnum as [PERMITNUM]
	,left(numberKey_parcelNo.PARCEL_NO,24) as [PARCELNUM]
	,null as [BOOK]
	,null as [PAGE]
	,null as [PARCEL]
	,left(a.lot,40) as [LOT]
	,left(a.census_block,15) as [BLOCK]
	,a.tra as [TRACT]
	,left(a.legal_desc,2000) as [LEGAL_DESC]
	,a.acres as [PARCEL_AREA]
	,a.area as [PLAN_AREA]
	,a.census_tract as [CENSUS_TRACT]
	,null as [COUNCIL_DISTRICT]
	,null as [SUPERVISOR_DISTRICT]
	,null as [INSPECTION_DISTRICT]
	,null --a.land_Value as [LAND_VALUE]
	,null --a.imp_value as [IMPROVED_VALUE]
	,null --a.tot_exemp as [EXEMPT_VALUE]
	,null as [MAP_REFERENCE]
	,null as [MAP_NUMBER]
	,a.subdiv as [SUBDIVISION]
	,0 as [PRIMARY_FLAG] --update this value (below)
	,null as [TOWNSHIP]
	,null as [RANGE]
	,null as [SECTION]
	,null as [EXT_PARCEL_UID]
from aatable_permit_history pnum --from (select number_key permitnum from hcfl_src.dbo.apd_base) pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
join hcfl_src.dbo.par_base a on a.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
;


update a set
    a.PRIMARY_FLAG = 1
from AATABLE_PERMIT_PARCEL a
join (
    SELECT
        d.permitnum
        ,a.parcelNum
    from (select distinct parcelNum from AATABLE_PERMIT_PARCEL) a
    outer apply (select top 1 * from AATABLE_PERMIT_PARCEL where parcelNum = a.parcelNum) d
) f on f.permitnum = a.permitnum and f.parcelNum = a.parcelNum
;
go

--duplicate the parcel information into the cbs record
insert into aatable_permit_parcel
select
    pnum.PERMITNUM
    ,a.PARCELNUM,a.BOOK,a.PAGE,a.PARCEL,a.LOT,a.BLOCK,a.TRACT,a.LEGAL_DESC,a.PARCEL_AREA,a.PLAN_AREA,a.CENSUS_TRACT,a.COUNCIL_DISTRICT,a.SUPERVISOR_DISTRICT,a.INSPECTION_DISTRICT,a.LAND_VALUE,a.IMPROVED_VALUE,a.EXEMPT_VALUE,a.MAP_REFERENCE,a.MAP_NUMBER,a.SUBDIVISION,a.PRIMARY_FLAG,a.TOWNSHIP,a.RANGE,a.SECTION,a.EXT_PARCEL_UID
from aatable_permit_parcel a
join jms_numberKey_permitnum pmap on pmap.permitnum = a.permitnum
join aatable_permit_history pnum on pnum.permitnum = a.permitnum + '-CBS'
;
