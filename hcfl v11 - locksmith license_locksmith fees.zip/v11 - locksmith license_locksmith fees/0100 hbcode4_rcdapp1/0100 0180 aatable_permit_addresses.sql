/*
create_AATABLE_PERMIT_ADDRESS
locksmith_addresses
apd_adr__addresses
remove_duplicate_numberKey_fullAddress
Address_addendum__parsing
address_assemble_all
remove_str_suffix
CBS address duplication
*/
--create_AATABLE_PERMIT_ADDRESS
IF OBJECT_ID('tempdb.dbo.##completed', 'U') IS NOT NULL 
insert into ##completed values (getdate(),'create_AATABLE_PERMIT_ADDRESS')
;
;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_ADDRESS
;
;IF OBJECT_ID('tempdb.dbo.#AATABLE_PERMIT_ADDRESS', 'U') IS NOT NULL drop table #AATABLE_PERMIT_ADDRESS
--;select top 0 * into #AATABLE_PERMIT_ADDRESS from AATABLE_PERMIT_ADDRESS
;CREATE TABLE #AATABLE_PERMIT_ADDRESS (
	[PERMITNUM] [varchar](30) NOT NULL,
	[ISPRIMARY] [varchar](1) NULL,
	[STR_NUM_START] [numeric](9, 0) NULL,
	[STR_NUM_END] [numeric](9, 0) NULL,
	[STR_FRAC_START] [varchar](20) NULL,
	[STR_FRAC_END] [varchar](20) NULL,
	[STR_DIR] [varchar](20) NULL,
	[STR_NAME] [varchar](100) NULL,
	[STR_SUFFIX] [varchar](30) NULL,
	[STR_SUFFIX_DIR] [varchar](20) NULL,
	[STR_PREFIX] [varchar](20) NULL,
	[STR_UNIT_START] [varchar](10) NULL,
	[STR_UNIT_END] [varchar](10) NULL,
	[STR_UNIT_TYPE] [varchar](20) NULL,
	[SITUS_CITY] [varchar](40) NULL,
	[SITUS_STATE] [varchar](30) NULL,
	[SITUS_ZIP] [varchar](10) NULL,
	[SITUS_COUNTY] [varchar](30) NULL,
	[SITUS_COUNTRY] [varchar](30) NULL,
	[SITUS_COUNTRY_CODE] [varchar](2) NULL,
	[X_COORD] [numeric](20, 8) NULL,
	[Y_COORD] [numeric](20, 8) NULL,
	[ADDR_DESC] [varchar](255) NULL,
	[FULL_ADDRESS] [varchar](600) NOT NULL,
	[ADDRESS1] [varchar](200) NULL,
	[ADDRESS2] [varchar](200) NULL,
	[SITUS_NBRHD] [varchar](30) NULL,
	[EXT_ADDRESS_UID] [varchar](100) NULL,
	[STREET_NAME_START] [varchar](200) NULL,
	[STREET_NAME_END] [varchar](200) NULL,
	[CROSS_STREET_NAME_START] [varchar](200) NULL,
	[CROSS_STREET_NAME_END] [varchar](200) NULL,
	[HSE_NBR_ALPHA_START] [varchar](20) NULL,
	[HSE_NBR_ALPHA_END] [varchar](20) NULL,
	[LEVEL_PREFIX] [varchar](20) NULL,
	[LEVEL_NBR_START] [varchar](20) NULL,
	[LEVEL_NBR_END] [varchar](20) NULL
)
;

--locksmith_addresses
;print 'locksmith_addresses';
    --client (represented this time by shane varnum) explicitly asked for locksmith records to use apd_Base.location
insert into #AATABLE_PERMIT_ADDRESS (
PERMITNUM,ISPRIMARY,STR_NUM_START,STR_NUM_END,STR_FRAC_START,STR_FRAC_END,STR_DIR,STR_NAME,STR_SUFFIX,STR_SUFFIX_DIR,STR_PREFIX,STR_UNIT_START,STR_UNIT_END,STR_UNIT_TYPE,SITUS_CITY,SITUS_STATE,SITUS_ZIP,SITUS_COUNTY,SITUS_COUNTRY,SITUS_COUNTRY_CODE,X_COORD,Y_COORD,ADDR_DESC,FULL_ADDRESS,ADDRESS1,ADDRESS2,SITUS_NBRHD,EXT_ADDRESS_UID,STREET_NAME_START, STREET_NAME_END, CROSS_STREET_NAME_START,CROSS_STREET_NAME_END, HSE_NBR_ALPHA_START,HSE_NBR_ALPHA_END,LEVEL_PREFIX,	LEVEL_NBR_START,LEVEL_NBR_END
)
select distinct
    pnum.PERMITNUM
    ,'Y' --(case when a.primary_addr = 1 then 'Y' else 'N' end) as ISPRIMARY
    ,null --try_convert(int,a.street_no) as STR_NUM_START
    ,null as STR_NUM_END
    ,null --a.addr_fraction as STR_FRAC_START
    ,null as STR_FRAC_END
    ,null --a.street_direction as STR_DIR
    ,null --left( a.street_name ,40) as STR_NAME
    ,null as STR_SUFFIX
    ,null as STR_SUFFIX_DIR
    ,null as STR_PREFIX
    ,null --(case when trim(isnull(a.unit_id,'')) <> '' then a.unit_id else null end) as STR_UNIT_START
    ,null as STR_UNIT_END
    ,null as STR_UNIT_TYPE
    ,null --isnull(left(city_id.city_name,40),left(city_id.city_name,40)) as SITUS_CITY
    ,null --'FL' as SITUS_STATE
    ,null --left(b.zip_code,10) as SITUS_ZIP
    ,null SITUS_COUNTY --,left(district.description,30) as SITUS_COUNTY
    ,'US' as SITUS_COUNTRY
    ,null as SITUS_COUNTRY_CODE
    ,null --b.x_coord as X_COORD
    ,null --b.y_coord as Y_COORD
    ,'Physical Location' as ADDR_DESC
    ,ab.location --coalesce(  CONCAT_WS(' ',a.street_no,a.street_name,a.street_direction,a.addr_fraction,'unit ' + a.unit_id,city_id.city_name,',FL',b.zip_code)  ,'Not Set') as FULL_ADDRESS 
    ,null --coalesce(  CONCAT_WS(' ',a.street_no,a.street_name,a.street_direction,a.addr_fraction,'unit ' + a.unit_id),'Not Set' ) as ADDRESS1
    ,null --coalesce(  CONCAT_WS(' ',city_id.city_name,',FL',b.zip_code),null ) as ADDRESS2
    ,null as SITUS_NBRHD
    ,null as EXT_ADDRESS_UID
    ,null as STREET_NAME_START
    ,null as STREET_NAME_END
    ,null as CROSS_STREET_NAME_START
    ,null as CROSS_STREET_NAME_END
    ,null as HSE_NBR_ALPHA_START
    ,null as HSE_NBR_ALPHA_END
    ,null as LEVEL_PREFIX
    ,null as LEVEL_NBR_START
    ,null as LEVEL_NBR_END
from aatable_permit_history pnum --from (select number_key as permitnum from hcfl_src.dbo.apd_base) pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_base ab on ab.number_key = pmap.number_key
--join hcfl_src.dbo.apd_adr a on a.number_key = pmap.number_key
--left join hcfl_src.dbo.CIT_BASE city_id on city_id.city_id = a.city_id
--left join hcfl_src.dbo.ADR_BASE b on b.ELEMENT_KEY = a.SITE_ELEMENT_KEY
WHERE
    1=1
    and pnum.tt_Record like 'locksmith%'
	and ab.location is not null
;


--apd_adr__addresses
;print 'apd_adr__addresses';
insert into #AATABLE_PERMIT_ADDRESS (
PERMITNUM,ISPRIMARY,STR_NUM_START,STR_NUM_END,STR_FRAC_START,STR_FRAC_END,STR_DIR,STR_NAME,STR_SUFFIX,STR_SUFFIX_DIR,STR_PREFIX,STR_UNIT_START,STR_UNIT_END,STR_UNIT_TYPE,SITUS_CITY,SITUS_STATE,SITUS_ZIP,SITUS_COUNTY,SITUS_COUNTRY,SITUS_COUNTRY_CODE,X_COORD,Y_COORD,ADDR_DESC,FULL_ADDRESS,ADDRESS1,ADDRESS2,SITUS_NBRHD,EXT_ADDRESS_UID,STREET_NAME_START, STREET_NAME_END, CROSS_STREET_NAME_START,CROSS_STREET_NAME_END, HSE_NBR_ALPHA_START,HSE_NBR_ALPHA_END,LEVEL_PREFIX,	LEVEL_NBR_START,LEVEL_NBR_END
)
select distinct
    pnum.PERMITNUM
    ,(case when a.primary_addr = 1 then 'Y' else 'N' end) as ISPRIMARY
    ,try_convert(int,a.street_no) as STR_NUM_START
    ,null as STR_NUM_END
    ,a.addr_fraction as STR_FRAC_START
    ,null as STR_FRAC_END
    ,a.street_direction as STR_DIR
    ,left( a.street_name ,40) as STR_NAME
    ,null as STR_SUFFIX
    ,null as STR_SUFFIX_DIR
    ,null as STR_PREFIX
    ,(case when trim(isnull(a.unit_id,'')) <> '' then a.unit_id else null end) as STR_UNIT_START
    ,null as STR_UNIT_END
    ,null as STR_UNIT_TYPE
    ,isnull(left(city_id.city_name,40),left(city_id.city_name,40)) as SITUS_CITY
    ,'FL' as SITUS_STATE
    ,left(b.zip_code,10) as SITUS_ZIP
    ,null SITUS_COUNTY --,left(district.description,30) as SITUS_COUNTY
    ,'US' as SITUS_COUNTRY
    ,null as SITUS_COUNTRY_CODE
    ,b.x_coord as X_COORD
    ,b.y_coord as Y_COORD
    ,'Physical Location' as ADDR_DESC
    ,replace(replace(replace(replace(replace(replace(coalesce(  CONCAT_WS(' ',a.street_no,a.street_name,a.street_direction,a.addr_fraction,case when trim(isnull(a.unit_id,'')) <> '' then 'unit ' + a.unit_id else null end,city_id.city_name,', FL',b.zip_code)  ,'Not Set'),'  ',' '),'  ',' '),'  ',' '),'  ',' '),'  ',' '),' , ',', ') as FULL_ADDRESS 
    ,coalesce(  CONCAT_WS(' ',a.street_no,a.street_name,a.street_direction,a.addr_fraction,case when trim(isnull(a.unit_id,'')) <> '' then 'unit ' + a.unit_id else null end),'Not Set' ) as ADDRESS1
    ,replace(coalesce(  CONCAT_WS(' ',city_id.city_name,', FL',b.zip_code),null ),' , ',', ') as ADDRESS2
    ,null as SITUS_NBRHD
    ,null as EXT_ADDRESS_UID
    ,null as STREET_NAME_START
    ,null as STREET_NAME_END
    ,null as CROSS_STREET_NAME_START
    ,null as CROSS_STREET_NAME_END
    ,null as HSE_NBR_ALPHA_START
    ,null as HSE_NBR_ALPHA_END
    ,null as LEVEL_PREFIX
    ,null as LEVEL_NBR_START
    ,null as LEVEL_NBR_END
from aatable_permit_history pnum --from (select number_key as permitnum from hcfl_src.dbo.apd_base) pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_adr a on a.number_key = pmap.number_key
left join hcfl_src.dbo.CIT_BASE city_id on city_id.city_id = a.city_id
left join hcfl_src.dbo.ADR_BASE b on b.ELEMENT_KEY = a.SITE_ELEMENT_KEY
;



--remove_duplicate_numberKey_fullAddress
--aatable_permit_Address unique_key on permitnum,fulladdress. Some in source data have same address as both primary and non-primary.
-- Therefore: delete the duplicate keys.
-- note: in source, the two rows have different auto_key values, and different site_element_key values.
-- rem: I think that CE09015735 is the only duplicating row.
;print 'address permitnum,full_Address unique-collision-preventing-deletions'
;WITH cte AS (
  SELECT 
	permitnum
	,full_address
    ,ROW_NUMBER() OVER(PARTITION BY permitnum,full_address ORDER BY isprimary desc) AS Rn
  FROM #aatable_permit_address
)
DELETE cte WHERE Rn > 1



--Address_addendum__parsing
;print 'Address_addendum__parsing';
    --set str_name based on full address
update t set
	STR_NAME = (case 
		when full_address like '%,%' then trim(' ,' from substring(full_address,1,charindex(',',full_address)))
		else full_address 
		end
    )
from #AATABLE_PERMIT_ADDRESS t
where 
	(str_name = 'not set' or str_name is null)
	and 
	(  full_address like '%road%'
	or full_address like '%rd%'
	or full_address like '%lane%'
	or full_address like '%ln%'
	or full_address like '%drive%'
	or full_address like '%dr%'
	or full_address like '%drives%'
	or full_address like '%drs%'
	or full_address like '%street%'
	or full_address like '%st%'
	or full_address like '%boulevard%'
	or full_address like '%blvd%'
	or full_address like '%avenue%'
	or full_address like '%ave%'
	or full_address like '%court%'
	or full_address like '%ct%'
	or full_address like '%circle%'
	or full_address like '%cir%'
	or full_address like '%way%'
	or full_address like '%wy%'
	or full_address like '%run%'
	or full_address like '%trail%'
	or full_address like '%trl%'
	or full_address like '%terrace%'
	or full_address like '%ter%'
	or full_address like '%highway%'
	or full_address like '%hwy%'
	or full_address like '%walk%'
	or full_address like '%path%'
	or full_address like '%place%'
	or full_address like '%pl%'
	or full_address like '%meadow%'
	or full_address like '%mdw%'
	or full_address like '%mdws%'
	)
;

    --remove cardinal direction
update t set
	str_dir = trim(reverse(substring(reverse(str_name),1,charindex(' ',reverse(str_name)))))
	,str_name = trim(replace(str_name,trim(reverse(substring(reverse(str_name),1,charindex(' ',reverse(str_name))))),''))
from #AATABLE_PERMIT_ADDRESS t
where
	str_dir is null
	and
	trim(reverse(substring(reverse(str_name),1,charindex(' ',reverse(str_name))))) in ('north','east','SOUTH','west','n','e','s','w') 
;

    --remove str number
update t set
	str_num_start = convert(int,substring(STR_NAME,1,charindex(' ',str_name))) 
	,STR_NAME = trim(substring(STR_NAME,charindex(' ',str_name),len(str_name)))
from #AATABLE_PERMIT_ADDRESS t
where 
	STR_NUM_START is null
	and 
    try_convert(int,substring(STR_NAME,1,charindex(' ',str_name))) is not null
;

    --remove str suffix
update t set
	str_suffix = reverse(trim(substring(reverse(str_name),1,charindex(' ',reverse(str_name)))))
	,STR_NAME = trim(reverse(substring(
			reverse(str_name)
			,charindex(' ',reverse(str_name))
			,len(reverse(str_name))
		)))
from #AATABLE_PERMIT_ADDRESS t
where 
	str_suffix is null
	and 
	reverse(trim(substring(reverse(str_name),1,charindex(' ',reverse(str_name)))))
	in ('road','rd','lane','ln','drive','dr','drives','drs','street','st','boulevard','blvd','avenue','ave','court','ct','circle','cir','way','wy','run','trail','trl','terrace','ter','highway','hwy','walk','path','place','pl','meadow','mdw','mdws')
;

--    --add county if city matches to existing districts
--update t set
--	situs_county = situs_city
--from #AATABLE_PERMIT_ADDRESS t
--join CD_CORE_DISTRICT_CODE district on district.description = t.situs_city
--WHERE
--    t.situs_county is null
--    or t.situs_county = 'not set'
--;

    --add full address based on primary address data
update t set
	full_address = trim(isnull(
        (  isnull(try_convert(varchar(max),STR_NUM_START),'')
            + isnull(' '+STR_DIR,'')
            + isnull(' '+STR_NAME,'')
            + isnull(' '+STR_SUFFIX,'')
            + isnull(' '+STR_UNIT_START,'')
            + isnull(', '+SITUS_CITY,'')
            + isnull(', '+SITUS_STATE,'')
            + isnull(' '+situs_zip,'')
        ) 
        ,'Not Set'
     ))
from #AATABLE_PERMIT_ADDRESS t
where
	FULL_ADDRESS = 'Not Set'
;
    
    --remove some empty fields
update t set
    str_suffix_dir = case when trim(str_suffix_dir) = '' then null else str_suffix_dir end
    ,str_unit_start = case when trim(str_unit_start) = '' then null else str_unit_start end
    ,str_unit_type = case when trim(str_unit_type) = '' then null else str_unit_type end
from #AATABLE_PERMIT_ADDRESS t
where
    1=1
    and (
        str_suffix_dir is not null
        or str_unit_start is not null
        or str_unit_type  is not null
    )
;





--address_assemble_all
;print 'address_assemble_all';
;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_ADDRESS
;insert into AATABLE_PERMIT_ADDRESS (
PERMITNUM,ISPRIMARY,STR_NUM_START,STR_NUM_END,STR_FRAC_START,STR_FRAC_END,STR_DIR,STR_NAME,STR_SUFFIX,STR_SUFFIX_DIR,STR_PREFIX,STR_UNIT_START,STR_UNIT_END,STR_UNIT_TYPE,SITUS_CITY,SITUS_STATE,SITUS_ZIP,SITUS_COUNTY,SITUS_COUNTRY,SITUS_COUNTRY_CODE,X_COORD,Y_COORD,ADDR_DESC,FULL_ADDRESS,ADDRESS1,ADDRESS2,SITUS_NBRHD,EXT_ADDRESS_UID,STREET_NAME_START, STREET_NAME_END, CROSS_STREET_NAME_START,CROSS_STREET_NAME_END, HSE_NBR_ALPHA_START,HSE_NBR_ALPHA_END,LEVEL_PREFIX,	LEVEL_NBR_START,LEVEL_NBR_END
)
SELECT
    PERMITNUM,ISPRIMARY,STR_NUM_START,STR_NUM_END,STR_FRAC_START,STR_FRAC_END,STR_DIR
	,left(STR_NAME,40),STR_SUFFIX,STR_SUFFIX_DIR,STR_PREFIX,STR_UNIT_START,STR_UNIT_END,STR_UNIT_TYPE,SITUS_CITY,SITUS_STATE,SITUS_ZIP,SITUS_COUNTY,SITUS_COUNTRY,SITUS_COUNTRY_CODE,X_COORD,Y_COORD,ADDR_DESC,FULL_ADDRESS,ADDRESS1,ADDRESS2,SITUS_NBRHD,EXT_ADDRESS_UID,STREET_NAME_START, STREET_NAME_END, CROSS_STREET_NAME_START,CROSS_STREET_NAME_END, HSE_NBR_ALPHA_START,HSE_NBR_ALPHA_END,LEVEL_PREFIX,	LEVEL_NBR_START,LEVEL_NBR_END
from #AATABLE_PERMIT_ADDRESS
;





    --remove_str_suffix
update t set
	str_suffix = reverse(trim(substring(reverse(str_name),1,charindex(' ',reverse(str_name)))))
	,STR_NAME = trim(reverse(substring(
			reverse(str_name)
			,charindex(' ',reverse(str_name))
			,len(reverse(str_name))
		)))
from AATABLE_PERMIT_ADDRESS t
where 
	str_suffix is null
	and 
	reverse(trim(substring(reverse(str_name),1,charindex(' ',reverse(str_name)))))
	in ('road','rd','lane','ln','drive','dr','drives','drs','street','st','boulevard','blvd','avenue','ave','court','ct','circle','cir','way','wy','run','trail','trl','terrace','ter','highway','hwy','walk','path','place','pl','meadow','mdw','mdws')
;

--CBS address duplication
insert into aatable_permit_Address
SELECT
	pnum.PERMITNUM
	,a.ISPRIMARY,a.STR_NUM_START,a.STR_NUM_END,a.STR_FRAC_START,a.STR_FRAC_END,a.STR_DIR,a.STR_NAME,a.STR_SUFFIX,a.STR_SUFFIX_DIR,a.STR_PREFIX,a.STR_UNIT_START,a.STR_UNIT_END,a.STR_UNIT_TYPE,a.SITUS_CITY,a.SITUS_STATE,a.SITUS_ZIP,a.SITUS_COUNTY,a.SITUS_COUNTRY,a.SITUS_COUNTRY_CODE,a.X_COORD,a.Y_COORD,a.ADDR_DESC,a.FULL_ADDRESS,a.ADDRESS1,a.ADDRESS2,a.SITUS_NBRHD,a.EXT_ADDRESS_UID,a.STREET_NAME_START,a.STREET_NAME_END,a.CROSS_STREET_NAME_START,a.CROSS_STREET_NAME_END,a.HSE_NBR_ALPHA_START,a.HSE_NBR_ALPHA_END,a.LEVEL_PREFIX,a.LEVEL_NBR_START,a.LEVEL_NBR_END
from aatable_permit_address a 
join jms_numberKey_permitnum pmap on pmap.permitnum = a.permitnum
join AATABLE_PERMIT_HISTORY pnum on pnum.permitnum = a.permitnum + '-CBS'
;
