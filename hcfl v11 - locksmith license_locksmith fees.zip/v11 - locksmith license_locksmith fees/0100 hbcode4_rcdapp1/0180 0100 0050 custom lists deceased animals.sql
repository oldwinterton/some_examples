--deceased animals
;IF OBJECT_ID('accelaConv7.dbo.cl_deceased_animal_type', 'U') IS NOT NULL drop table cl_deceased_animal_type
;
with g as (
select distinct
	pnum.permitnum
	,pnum.tt_record
	,case	
		when t0.YN_019 = 'Y' then 'Dog'
		when t0.yn_020 = 'Y' then 'Cat'
		when t0.yn_021 = 'Y' then 'Other'
		when t0.yn_022 = 'Y' then 'Other'
		else null
		end
		as animal_type    
--into cl_deceased_animal_type
from hcfl_Src.dbo.apd_txt0 t0
join accelaconv7..jms_apd_base_filtered f on f.NUMBER_KEY = t0.NUMBER_KEY
join accelaconv7..jms_numberKey_permitnum pmap on pmap.number_key = f.NUMBER_KEY
join accelaconv7..aatable_permit_history pnum on pnum.permitnum = pmap.permitnum
where
	1=1
	--and YN_023 is not null
	and case	
		when t0.YN_019 = 'Y' then 'Dog'
		when t0.yn_020 = 'Y' then 'Cat'
		when t0.yn_021 = 'Y' then 'Other'
		when t0.yn_022 = 'Y' then 'Other'
		else null
		end is not null
)
select
	*
	,ROW_NUMBER() OVER(PARTITION BY pnum.permitnum order by pnum.permitnum) AS row_num
into cl_deceased_animal_type
from g pnum
;


/*
--debris removal
;IF OBJECT_ID('accelaConv7.dbo.cl_debris_removal', 'U') IS NOT NULL drop table cl_debris_removal
;
select 
	pnum.permitnum
	,pnum.tt_record
	
    ,t0.Num_048 numTires          
    
into cl_deceased_animal_type
from hcfl_Src.dbo.apd_txt0 t0
join accelaconv7..jms_apd_base_filtered f on f.NUMBER_KEY = t0.NUMBER_KEY
join accelaconv7..jms_numberKey_permitnum pmap on pmap.number_key = f.NUMBER_KEY
join accelaconv7..aatable_permit_history pnum on pnum.permitnum = pmap.permitnum
where
	1=1
;
*/