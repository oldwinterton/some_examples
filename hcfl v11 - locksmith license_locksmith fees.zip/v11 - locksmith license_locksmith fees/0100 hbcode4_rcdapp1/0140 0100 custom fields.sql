/*
Citizen Board Support - ENF_CBS
Enforcement Complaint - ENF_COMPLAIN
Locksmith Initial Application - ENF_LOCK
Locksmith License - ENF_LOCK
Locksmith Renewal - ENF_LOCK
Violation - PMT_VIO
*/

--Citizen Board Support - ENF_CBS
;IF OBJECT_ID('tempdb.dbo.##completed', 'U') is not null insert into ##completed values (getdate(),'0140 0100 custom fields.sql -- cbs')
;print 'Citizen Board Support - ENF_CBS';

;IF OBJECT_ID('tempdb.dbo.#green_card_date', 'U') IS NOT NULL DROP TABLE #green_card_date
;select
    t.NUMBER_KEY
    ,min(t.date_entered) date_entered
into #green_card_date
from hcfl_src.dbo.lhn_tab t
join jms_numberKey_permitnum pmap on pmap.number_key = t.number_key
join aatable_permit_history pnum on pnum.permitnum = pmap.number_key + '-CBS'
where 
    1=1
    and pnum.tt_record in ('Citizen Board Support')
    and the_text like '%green card%' 
    and the_text not like '%not REC%D%' 
    and the_text not like '%missing%' 
    and the_text not like '%not%return%' 
    and the_text not like '%no green%'
group by t.NUMBER_KEY
;--30sec
;IF OBJECT_ID('tempdb.dbo.#a', 'U') IS NOT NULL DROP TABLE #a
;SELECT
    a.number_key
    ,a.date_d
    ,a.date_g
    ,a.date_h
    ,a.date_i
into #a
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
where 
	pnum.tt_record = 'Citizen Board Support'
    and coalesce(a.date_d,a.date_g,a.date_h,a.date_i) is not null
;--0sec
;IF OBJECT_ID('tempdb.dbo.#m0', 'U') IS NOT NULL DROP TABLE #m0
;SELECT
    m.number_key
    ,m.mon_080
    ,m.MON_045
    ,m.MON_046
    ,m.MON_047
    ,m.MON_048    
into #m0
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
join hcfl_src.dbo.apd_mon0 m on m.number_key = pmap.number_key
where 
	pnum.tt_record = 'Citizen Board Support'
	and coalesce(m.mon_080,m.MON_045,m.MON_046,m.MON_047,m.MON_048) is not null
;--30sec
;IF OBJECT_ID('tempdb.dbo.#n0', 'U') IS NOT NULL DROP TABLE #n0
;SELECT
     n0.number_key
    ,n0.Date_031 dtCertSent        
    ,n0.date_054 dtLastVisitNot    
    ,n0.date_057 dtPosting1    
    ,n0.date_052 dtCEBOrder
    ,n0.date_094 dtLienRec1  --Date principal lien recorded
    ,n0.date_096 dtLienRel1  --Date principal lien released
    ,(case when n0.date_052 is not null then 'Yes' else 'No' end) as repeat_violator
    ,n0.Date_095 dtLienRec2       
    ,n0.date_097 dtLienRel2  --Date principal lien released
    
    ,n0.date_099 as dtCBSReceived     
    ,n0.DATE_084
    ,n0.DATE_085
    ,n0.DATE_099
    ,n0.date_077
into #n0
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
join hcfl_src.dbo.apd_num0 n0 on n0.number_key = pmap.number_key
where 
	pnum.tt_record = 'Citizen Board Support'
	and coalesce(n0.Date_031,n0.date_054,n0.date_057,n0.date_052,n0.date_094,n0.date_096,n0.date_052,n0.Date_095,n0.date_097,n0.DATE_084,n0.DATE_085,n0.DATE_099,n0.date_077) is not null
;--50sec
;IF OBJECT_ID('tempdb.dbo.#n1', 'U') IS NOT NULL DROP TABLE #n1
;SELECT
     n1.number_key
    ,n1.Date_101 as dtPostingPrep
    ,n0.date_099 as dtCBSReceived
into #n1
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
left join hcfl_src.dbo.apd_num1 n1 on n1.number_key = pmap.number_key
left join hcfl_src.dbo.apd_num0 n0 on n0.number_key = pmap.number_key
where 
	pnum.tt_record = 'Citizen Board Support'
	and coalesce(n1.date_101,n0.date_099) is not null
;--20sec
;IF OBJECT_ID('tempdb.dbo.#t0', 'U') IS NOT NULL DROP TABLE #t0
;SELECT
     t.number_key
    ,t.text_018 txtAffiant        
    ,t.text_029 strDefendantHrng  
    ,t.text_031 strCountyWitness  
    ,t.text_038 strRecOR2         
    ,t.text_039 strRelOR2         
    ,t.Text_042 strHearingType    
    ,t.Text_013 strCEBNoticeType
    ,t.TEXT_032
    ,t.TEXT_040
    ,t.TEXT_041    
    ,t.YN_007
    ,t.YN_051
into #t0
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
join hcfl_src.dbo.apd_txt0 t on t.number_key = pmap.number_key
where 
	pnum.tt_record = 'Citizen Board Support'
	and coalesce(t.text_018,t.text_029,t.text_031,t.text_038,t.text_039,t.Text_042,t.Text_013,t.TEXT_032,t.TEXT_040,t.TEXT_041,t.YN_007,t.YN_051,null) is not null
;--8sec
;IF OBJECT_ID('tempdb.dbo.#t1', 'U') IS NOT NULL DROP TABLE #t1
;SELECT
     t.number_key
    ,t.text_054 
    ,t.text_080 NOTICE_TYPE       
    ,t.text_082 strCetLetter      
    ,t.TEXT_077
    ,t.TEXT_098
into #t1
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
join hcfl_src.dbo.apd_txt1 t on t.number_key = pmap.number_key
where 
	pnum.tt_record = 'Citizen Board Support'
	and coalesce(t.text_054,t.text_080,t.text_082,t.TEXT_077,t.TEXT_098) is not null
;--3sec
;IF OBJECT_ID('tempdb.dbo.#STRINSTRUMENTREC', 'U') IS NOT NULL DROP TABLE #STRINSTRUMENTREC
;SELECT
    pmap.number_key --STRINSTRUMENTREC.vdi_key
    ,STRINSTRUMENTREC.text_value
	,t0.text_031 strCountyWitness 
into #STRINSTRUMENTREC
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
left join hcfl_src.dbo.vdi_detl STRINSTRUMENTREC on STRINSTRUMENTREC.vdi_key = pmap.number_key and STRINSTRUMENTREC.aka_name = 'STRINSTRUMENTREC'
left join hcfl_src.dbo.APD_Txt0 t0 on t0.NUMBER_KEY = pmap.number_key 
where 
    pnum.tt_record = 'Citizen Board Support'
	and coalesce(STRINSTRUMENTREC.TEXT_VALUE,t0.text_031) is not null
;--22sec
;IF OBJECT_ID('tempdb.dbo.#STRINSTRUMENTREL', 'U') IS NOT NULL DROP TABLE #STRINSTRUMENTREL
;SELECT
    pmap.number_key --STRINSTRUMENTREL.vdi_key
    ,STRINSTRUMENTREL.text_value
	,t0.Text_037 strRelOR1
into #STRINSTRUMENTREL
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
left join hcfl_src.dbo.vdi_detl STRINSTRUMENTREL on STRINSTRUMENTREL.vdi_key = pmap.number_key and STRINSTRUMENTREL.aka_name = 'STRINSTRUMENTREL'
left join hcfl_src.dbo.APD_Txt0 t0 on t0.number_key = pmap.number_key
where 
    pnum.tt_record = 'Citizen Board Support'
	and coalesce(STRINSTRUMENTREL.text_value,t0.text_037) is not null
;--22sec
;IF OBJECT_ID('tempdb.dbo.#primary_name', 'U') IS NOT NULL DROP TABLE #primary_name
;WITH RankedResults AS (
    SELECT 
        pmap.number_key --STRINSTRUMENTREL.vdi_key
        ,p.name
        ,ROW_NUMBER() OVER(PARTITION BY  pmap.number_key ORDER BY p.primary_name,p.name ) AS Rank
    from aatable_permit_history pnum
    join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
    join hcfl_src.dbo.apd_peo p on p.number_key = pmap.number_key 
)
SELECT 
    *
into #primary_name
FROM RankedResults
WHERE
    1=1
    and Rank = 1
;--22sec
;IF OBJECT_ID('tempdb.dbo.#primary_address', 'U') IS NOT NULL DROP TABLE #primary_address
;WITH RankedResults AS (
  SELECT 
	permitnum
	,full_address
    ,ROW_NUMBER() OVER(PARTITION BY permitnum ORDER BY case when isprimary='Y' then 1 else 2 end) AS Rank
  FROM AATABLE_PERMIT_ADDRESS
)
SELECT 
	*
into #primary_address
FROM RankedResults
WHERE
	1=1
	and Rank = 1
;--xx sec
;IF OBJECT_ID('tempdb.dbo.#legal_descs', 'U') IS NOT NULL DROP TABLE #legal_descs
;create table #legal_descs ( permitnum varchar(50), legal_desc varchar(max) )
;with cte_many as (
	select 
		pmap.permitnum + '-cbs' permitnum
		,count(LEGAL_DESC) ct
	from aatable_permit_history pnum
	join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
	join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
	left join hcfl_src.dbo.par_base pb on pb.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
	where
		1=1
		and pnum.tt_record in ('Citizen Board Support')
	group by pmap.permitnum
	having count(LEGAL_DESC) > 1
), g as (
	select distinct
		pmap.permitnum + '-CBS' permitnum
		,pb.LEGAL_DESC
	from aatable_permit_history pnum
	join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
	join cte_many f on f.permitnum =  pmap.permitnum+'-CBS'
	join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
	left join hcfl_src.dbo.par_base pb on pb.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
	where
		1=1
		and pnum.tt_record in ('Citizen Board Support')
),h as (
	SELECT
		permitnum
		,trim('^| ' from 
			  STUFF(
				(SELECT ' ^|^ ' + LEGAL_DESC
				 FROM g AS innerTable
				 WHERE innerTable.permitnum = outerTable.permitnum
				 FOR XML PATH(''), TYPE
				).value('.', 'NVARCHAR(MAX)'), 1, 2, '') 
		) AS legal_desc
	FROM g AS outerTable
	where
		1=1
		--and permitnum = 'CE19003259-cbs'
	GROUP BY permitnum
)
insert into #legal_descs
select * from h

union

select 
	pmap.permitnum + '-CBS' permitnum
	,trim(pb.LEGAL_DESC) legal_desc
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
left join hcfl_src.dbo.par_base pb on pb.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
where
	1=1
	and pnum.tt_record in ('Citizen Board Support')
	and not exists (
		select 1
		from h
		where permitnum =  pmap.permitnum+'-CBS'
	)
;
go



;IF OBJECT_ID('cf_Citizen_Board_Support', 'U') IS NOT NULL DROP TABLE cf_Citizen_Board_Support
;
SELECT distinct
    pnum.permitNum
    ,pnum.tt_record
 
    --DATA FIELDS
    ,n0.dtLastVisitNot as [Notice Date]
    --,n0.dtLastVisitNot as [Date of Service] --Date  --'dtLastVisitNot    ',' Date of the last visitor service'
    ,t0.strCEBNoticeType as [Method of Service] --t1.NOTICE_TYPE as [Method of Service] --Text --'NOTICE_TYPE       ','Type of service '
    ,a.date_i as [Date of Affidavit] --Date 
    ,a.date_d as [Hearing Date] --Date 
    ,n0.dtCertSent as [Postmark Date] --Date  --'dtCertSent        ',' DateCertified Letter Sent to Violator'
    ,n1.dtCBSReceived as [Date received for Hearing] --Date  --'dtHearingSched    ','Scheduled date for hearing (not actual)'
    ,a.date_h as [Date of Board Order] --Date 
    ,t0.strDefendantHrng as [who appeared for hearing] --Text  --'strDefendantHrng  ',' Defendant Name Appearing at Hearing'
    ,m0.mon_080 as [Cap Value] --Number --curFineCap
    ,t0.strCountyWitness as [Name of the officer giving testimony] --Text  --'txtAffiant        ','Name of Officer for NCA'
    ,null as [hearing location]
    ,n0.dtLienRec1 as [Recording Date] --Date 
    ,n0.dtLienRec2 as [Secondary Recording Date] --Date 
    ,n0.dtLienRel1 as [Release Date] --Date 
    ,n0.dtLienRel2 as [Secondary Release Date] --Date 
    ,t1.text_054 as [Book Page for Liens] --Text Area  --'strPPOBook        ',' Book for recording PPO lien'
    ,coalesce(STRINSTRUMENTREC.text_value,t0.text_032,null) as [Instrument Number for Recording Date] --Text  --'STRINSTRUMENTREC  '
    ,t0.strRecOR2 as [Secondary Instrument Number for Recording Date] --Text 
    ,coalesce(STRINSTRUMENTREL.text_value,STRINSTRUMENTREL.strRelOR1) as [Instrument Number for Release Date] --Text 
    
    
    ,t0.strRelOR2 as [Secondary Instrument Number for Release Date] --Text 
    ,t1.strCetLetter as [Tracking Number] --Text  --'strCetLetter      ',' USPS Tracking number'
    ,n0.dtPosting1 as [Date Posted at Property] --Date --'dtPosting1        '
    --,null as [Card Received] --Yes/No 
    --,null as [Reason Letter was not received] --Text Area 
    ,a.date_g as [Date Notice of Hearing Posted] --Date 
    --,null as [Change of Address] --CheckBox 
    ,g.date_entered as [Green Card Received] --Date 
    --,null as [Date Posted at Courthouse] --Date 
    
    ,t0.strHearingType as [Type of Hearing]
    
    ,null [Notice of Hearing Date Verified by Mail Date]
    ,null [Officer Phone Number]
    ,null [Code Record]
    ,null [Officer Assigned]
    ,null [Hearing Time]
    ,a.date_g [Notice of Hearing Date]
    ,null [Hearing Date Continued]
    ,null [Officer Email]
    ,null [Extension Order]
    ,null [Name of person that signed Affidavit]
    
    --HISTORICAL PERMITS PLUS FIELDS
    ,m0.MON_045
    ,m0.MON_046
    ,m0.MON_047
    ,m0.MON_048
    ,n0.DATE_084
    ,n0.DATE_085
    ,n0.DATE_099
    ,t0.TEXT_032
    ,t0.TEXT_040
    ,t0.TEXT_041 
    ,t1.TEXT_098
    ,n1.dtPostingPrep as DATE_101
    ,t0.YN_007
    ,case when t0.YN_051 = 'N' then null else 'CHECKED' end YN_051
    ,pb.LEGAL_DESC
    ,a.CALC_FEES
    ,a.ADDL_FEES
    ,aa.full_address PRIMARY_ADDR
    ,ap.name PRIMARY_NAME
    ,ai.APPROVED
    ,coalesce(user_id.user_name,a.user_id) [user_id]
    ,a.ENTERED_DATE as THE_DATE
    ,a.sub_type [SUB_TYPE]
    ,a.DATE_A [DATE_A]
    ,n0.date_077 [PIP hearing date]
into cf_Citizen_Board_Support
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
left join #green_card_date g on g.number_key = pmap.number_key
left join #m0 m0 on m0.number_key =   pmap.number_key
left join #n0 n0 on n0.number_key =   pmap.number_key
left join #n1 n1 on n1.number_key = pmap.number_key
left join #t0 t0 on t0.number_key =   pmap.number_key
left join #t1 t1 on t1.number_key =  pmap.number_key
left join #STRINSTRUMENTREC STRINSTRUMENTREC on STRINSTRUMENTREC.number_key = pmap.number_key
left join #STRINSTRUMENTREL STRINSTRUMENTREL on STRINSTRUMENTREL.number_key = pmap.number_key
left join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
left join #legal_descs pb on pb.permitnum = pmap.permitnum ---left join hcfl_src.dbo.par_base pb on pb.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
left join #primary_address aa on aa.permitnum = pmap.permitnum --left join hcfl_src.dbo.apd_adr aa on aa.number_key = pmap.number_key
left join #primary_name ap on ap.number_key = pmap.number_key --left join hcfl_src.dbo.apd_peo ap on ap.number_key = pmap.number_key
outer apply (select top 1 * from hcfl_src.dbo.APD_ITMS where number_key = pmap.number_key order by case when APPROVED = 'N' then 1 else 2 end) ai
left join jms_userid_username user_id on user_id.user_id = a.user_id
where
    1=1
    and pnum.tt_record in ('Citizen Board Support')
;

 
    --ensure_fields_arent_too_long
declare @table_name varchar(100) = 'cf_Citizen_Board_Support' 

declare @cutoff int = 50;
DECLARE long_colname_cursor CURSOR for (
	select 
		column_name
	from INFORMATION_SCHEMA.columns 
	where 
		table_name = @table_name
		and len(column_name) > @cutoff
);

declare @column_name_old varchar(200);
declare @modString varchar(200);
declare @newname varchar(200);


OPEN long_colname_cursor
FETCH NEXT FROM long_colname_cursor INTO @column_name_old
    WHILE @@FETCH_STATUS = 0  
		begin
			set @modString = 'dbo.' + @table_name + '.' + @column_name_old;
			set @newname = left(@column_name_old, @cutoff)
			EXEC sp_rename @modString, @newname, 'COLUMN';
			FETCH NEXT FROM long_colname_cursor   INTO @column_name_old
		end
CLOSE long_colname_cursor
DEALLOCATE long_colname_cursor
;
go
;




--Enforcement Complaint - ENF_COMPLAIN
;IF OBJECT_ID('tempdb.dbo.##completed', 'U') is not null insert into ##completed values (getdate(),'0140 0100 custom fields.sql -- complaint')
;print 'Complaint - ENF_COMPLAIN';

;IF OBJECT_ID('tempdb.dbo.#a', 'U') IS NOT NULL DROP TABLE #a
;SELECT
    a.number_key
    ,a.date_d
    ,a.sub_Type
into #a
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
where 
	pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive')
;--0sec
;IF OBJECT_ID('tempdb.dbo.#d', 'U') IS NOT NULL DROP TABLE #d
;SELECT
    d.number_key
    ,d.description
into #d
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_desc d on d.number_key = pmap.number_key
where 
	pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive')
;--4sec
;IF OBJECT_ID('tempdb.dbo.#n0', 'U') IS NOT NULL DROP TABLE #n0
;SELECT
    n0.number_key
    ,n0.num_013 days_to_comply    
    ,n0.num_025 numLastTimeToCompl
    ,n0.num_065 numADXSR  
    ,(case when n0.date_052 is not null then 'Yes' else 'No' end) as repeat_violator
    ,n0.Date_052 dtCEBOrder       
    ,n0.date_077 
into #n0
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_num0 n0 on n0.number_key = pmap.number_key
where 
	pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive')
	and coalesce(n0.num_013,n0.num_065) is not null
;--50sec
;IF OBJECT_ID('tempdb.dbo.#n1', 'U') IS NOT NULL DROP TABLE #n1
;SELECT
    n.number_key
    ,n.DATE_103
    ,n.DATE_109
    ,n.DATE_118
into #n1
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_num1 n on n.number_key = pmap.number_key
where 
	pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive')
;
;IF OBJECT_ID('tempdb.dbo.#t0', 'U') IS NOT NULL DROP TABLE #t0
;SELECT
     t.number_key
    ,t.text_002 txt_location                  
    ,t.text_006 txt_occupancy 
    ,t.YN_001 ynForeclosure
    ,t.Text_013 strCEBNoticeType
    ,t.TEXT_000
    ,t.TEXT_004
    ,t.TEXT_014
into #t0
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_txt0 t on t.number_key = pmap.number_key
where 
	pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive')
	and coalesce(t.text_002,t.text_006) is not null
;--9sec
;IF OBJECT_ID('tempdb.dbo.#t1', 'U') IS NOT NULL DROP TABLE #t1
;SELECT
     t.number_key
    ,t.text_059 ZONING       
    ,t.text_076 str_type    
    ,t.TEXT_077      
	
    ,t.TEXT_050
    ,t.TEXT_067
    ,t.TEXT_069
    ,t.TEXT_072
    ,t.TEXT_060
into #t1
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_txt1 t on t.number_key = pmap.number_key
where 
	pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive')
	and coalesce(t.text_059,t.text_076,t.TEXT_077,t.TEXT_050,t.TEXT_067,t.TEXT_069,t.TEXT_072,t.TEXT_060,null) is not null
;--0sec
;IF OBJECT_ID('tempdb.dbo.#m0', 'U') IS NOT NULL DROP TABLE #m0
;SELECT
     m.number_key
    ,m.MON_066
into #m0
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_mon0 m on m.number_key = pmap.number_key
where 
	pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive')
;--0sec
;IF OBJECT_ID('tempdb.dbo.#primary_name', 'U') IS NOT NULL DROP TABLE #primary_name
select
	pmap.number_key
	,a.NAME
into #primary_name
from AATABLE_PERMIT_HISTORY pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.APD_PEO a on a.number_key = pmap.number_key
where
	1=1
	and PRIMARY_NAME = 1
    and pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive')
;
;IF OBJECT_ID('tempdb.dbo.#approved', 'U') IS NOT NULL DROP TABLE #approved
;with g as (
	SELECT distinct
        pmap.number_key
		,a.APPROVED
		,a.THE_DATE
    from AATABLE_PERMIT_HISTORY pnum
	join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
	join hcfl_src.dbo.APD_ITMS a on a.number_key = pmap.number_key
	where
		1=1
		and a.APPROVED is not null
), CTE AS (
    SELECT distinct
        a.number_key
		,a.APPROVED
		,a.THE_DATE
        ,ROW_NUMBER() OVER (PARTITION BY a.number_key ORDER BY a.the_date desc) AS row_num
    from g a
)
SELECT 
    *
into #approved
FROM CTE
WHERE 
    1=1
	and row_num = 1
;

;IF OBJECT_ID('tempdb.dbo.#primary_address', 'U') IS NOT NULL DROP TABLE #primary_address
;WITH RankedResults AS (
  SELECT 
	permitnum
	,full_address
    ,ROW_NUMBER() OVER(PARTITION BY permitnum ORDER BY case when isprimary='Y' then 1 else 2 end) AS Rank
  FROM AATABLE_PERMIT_ADDRESS
)
SELECT 
	*
into #primary_address
FROM RankedResults
WHERE
	1=1
	and Rank = 1
;
;IF OBJECT_ID('tempdb.dbo.#legal_descs', 'U') IS NOT NULL DROP TABLE #legal_descs
;create table #legal_descs ( permitnum varchar(50), legal_desc varchar(max) )
;with cte_many as (
	select 
		pmap.permitnum + '' permitnum
		,count(LEGAL_DESC) ct
	from aatable_permit_history pnum
	join jms_numberKey_permitnum pmap on pmap.permitnum+'' = pnum.permitnum
	join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
	left join hcfl_src.dbo.par_base pb on pb.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
	where
		1=1
		and pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive')
	group by pmap.permitnum
	having count(LEGAL_DESC) > 1
), g as (
	select distinct
		pmap.permitnum + '' permitnum
		,pb.LEGAL_DESC
	from aatable_permit_history pnum
	join jms_numberKey_permitnum pmap on pmap.permitnum+'' = pnum.permitnum
	join cte_many f on f.permitnum =  pmap.permitnum+''
	join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
	left join hcfl_src.dbo.par_base pb on pb.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
	where
		1=1
		and pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive')
),h as (
	SELECT
		permitnum
		,trim('^| ' from 
			  STUFF(
				(SELECT ' ^|^ ' + LEGAL_DESC
				 FROM g AS innerTable
				 WHERE innerTable.permitnum = outerTable.permitnum
				 FOR XML PATH(''), TYPE
				).value('.', 'NVARCHAR(MAX)'), 1, 2, '') 
		) AS legal_desc
	FROM g AS outerTable
	where
		1=1
		--and permitnum = 'CE21009275'
	GROUP BY permitnum
)
insert into #legal_descs
select * from h
where
	1=1 
	and legal_desc is not null

union

select 
	pmap.permitnum + '' permitnum
	,trim(pb.LEGAL_DESC) legal_desc
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum+'' = pnum.permitnum
join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key
left join hcfl_src.dbo.par_base pb on pb.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
where
	1=1
	and pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive')
	and not exists (
		select 1
		from h
		where permitnum =  pmap.permitnum+''
	)
	and legal_desc is not null
;
go

;IF OBJECT_ID('cf_Complaint', 'U') IS NOT NULL DROP TABLE cf_Complaint
;
select distinct
    pnum.permitNum
    ,pnum.tt_record
 
    --HISTORICAL PERMITS PLUS FIELDS
    ,aa.FULL_ADDRESS as PRIMARY_ADDR
    ,t1.TEXT_077
    ,NOTATION.notation
    ,PRIMARY_NAME.name as primary_name
    ,ai.APPROVED
    ,a.CALC_FEES
    ,a.ADDL_FEES
    ,t0.TEXT_000
    ,m0.MON_066
    ,t0.TEXT_004
    ,t0.TEXT_014
    ,n1.DATE_103
    ,n1.DATE_109
    ,n1.DATE_118
    ,t1.TEXT_050
    ,t1.TEXT_067
    ,t1.TEXT_069
    ,t1.TEXT_072
    ,pb.LEGAL_DESC
    ,t1.TEXT_060
    ,ai.THE_DATE
    ,a.date_k 
    
    ,null ADDRESS_4
    ,null DATE_L
    ,a.insp_area INSP_AREA
    ,null VIOLATIONS
    ,a.sub_type [SUB_TYPE]
    ,a.DATE_A [DATE_A]
    ,n0.date_077 [PIP hearing date]
    
    
    --COMPLAINT INFO
    ,pnum.Asgn_Staff [Assigned To] 
     --( case 
     --   when 1=1 then 'Donald Duck'
     --    when 1=1 then 'Mickey Mouse'
     --   end
     --) as [Assigned To] --Drop Down  req 
    ,( case 
         when d.description like '%abandon%sign%' then 'Abandoned Sign'
         when a.sub_type = 'FTBC    ' or (d.description like '%blight%' and d.description like '%commerc%prop%') then 'Blighted Commercial Property'
         when d.description like '%commercial%vehicle%' then 'Commercial Vehicle Complaint'
         when d.description like '%construct%permit%' and (d.description like '% no %' or d.description like '%without%') then 'Construction without a Permit'
         when d.description like '%contractor%complain%' then 'Contractor Complaint'
         when 1=1 then 'Digital Billboard Permit/Inspection'
         when d.description like '%educat%outrea%' then 'Educational Outreach'
         when d.description like '%fenc%violat%' then 'Fence Violations'
         when a.sub_type = 'GRAFFITI' then 'Graffiti Complaint'
         when d.description like '%hazard%' and d.description like '%tree%' then 'Hazard Tree'
         when d.description like '%homeless%encamp%' then 'Homeless Encampment'
         when a.sub_type = 'ILDUMP  ' then 'Illegal Dumping of Trash or Debris'
         when 1=0 then 'Illegal Fill Complaint'
         when 1=0 then 'Illicit Discharge Violation'
         when d.description like '%inop%vehicl%' then 'Inoperable Vehicle'
         when 1=0 then 'New Regulatory Sign Enforcement'
         when d.description like '%noise%ordinance%' then 'Noise Ordinance Violation'
         when d.description like '%obstructed%roadway%' then 'Obstructed Roadway'
         when 1=0 then 'Operating without a B.T.R.'
         when d.description like '%overgrown%condition%' then 'Overgrown Conditions'
         when d.description like '%permitted use viol%' then 'Permitted Use Violation'
         when 1=0 then 'Request for Demolition'
         when d.description like '%sign%ordinance%viol%' then 'Sign Ordinance Violation'
         when d.description like '%sign permit%' then 'Sign Permit'
         when d.description like '%signs%' then 'Signs - Misc. Complaints'
         when 1=0 then 'Site Development Violation'
         when 1=0 then 'Stinging Insects'
         when d.description like '%street numbers%' then 'Street Numbers Complaint'
         when d.description like '%towing%' then 'Towing'
         when d.description like '%trash%' then 'Trash and Junk'
         when 1=0 then 'Tree Permit'
         when d.description like '%tree%removal%' and (d.description like '%no%permit%' or d.description like '%without%permit%') then 'Tree Removal without Permit'
         when d.description like '%unlicensed%contractor%' then 'Unlicensed Contractors'
         when d.description like '%unmaint%pool%' then 'Unmaintained Swimming Pool'
         when d.description like '%unpermitted%' then 'Unpermitted Work'
         when d.description like '%Unsecured%applian%' then 'Unsecured Appliances'
         when d.description like '%Unsecured%pool%' then 'Unsecured Pool'
         when 1=0 then 'Violation of Foreclosure Registry'
         when d.description like '%watering%' then 'Watering Complaint'
         when d.description like '%waterway%' then 'Waterway Issues'
         
         when d.description like '%misc%viol%' then 'Miscellaneous Code Violations'
         when d.description like '%minimum%standards%' then 'Minimum Standards'
         when d.description like '%boat%' or d.description like '%rv%' or d.description like '%trailer%' then 'Boats, Trailers and RV''s'
         when 0=1 then 'Clear Sight Triangle Violation'
        
         else 'Other'
         
        end
     ) as [General Type of Complaint] --Drop Down  req 240
    ,null as [Description of Legal Code] --Text Area 
    ,null as [Res or Non Res]
    --,( case 
    --     when 1=0 then 'Citizen'
    --     when 1=0 then 'Government Official'
    --     when 1=0 then 'Law Enforcement Office'
    --     when 1=0 then 'Staff'
    --    else null
    --    end
    -- ) as [Source] --Drop Down 
    --,( case 
    --    when 1=0 then 'Email'
    --     when 1=0 then 'FAX'
    --     when 1=0 then 'In Person'
    --     when 1=0 then 'Online'
    --     when 1=0 then 'Phone'
    --     when 1=0 then 'Postal Mail'
    --     when 1=0 then 'Unknown'
    --    else null
    --    end
    -- ) as [Type of Submittal] --Drop Down 
    ,t0.ynForeclosure as [Lis pendence] --Yes/No 
    --,null as [Add Comments] --Text Area 240
    --,null as [Is this a Home Owner Associate complaint?] --Yes/No 
    --,null as [If yes, is the letter attached?] --Yes/No 
    --,null as [Officer''s Comments] --Text Area 
    --,null as [Create Violator from Owner] --CheckBox 
    --,null as [Court Case Number] --Text 
    ,n0.repeat_violator as [Repeat Violator(complaint info)] --Yes/No 
    --,null as [Compliant] --Yes/No 
 
    --DATA FIELDS
    ,n0.numADXSR as [ADX Number] --Text  --'numADXSR          ',' ADX SR Number'
    ,(case t1.str_type
        when 'BLK' then 'Block'
        when 'FR'  then 'Frame'
        when 'MH'  then 'Mobile Home'
        else t1.str_type
        end
    ) as [structure type]
    ,t0.txt_occupancy as [Occupancy] --Text --'txt_occupancy     ','occupancy from table'
    ,t1.ZONING as [Zoning] --Text --'ZONING            ','ZONE DISTRICT'
    ,null as [Code Inspection Area]
    ,n0.days_to_comply as [Days for Initial Compliance] --Number    --'days_to_comply    ',' transferred from qty_reinsp_days'
    ,n0.dtCEBOrder as [Order date for repeat violator] --Date 
    ,a.location [Description of Location] --t0.txt_location as [Description of Location] --Text Area --'txt_location      ','from location table'
    ,null [Type of Submittal(DATA FIELDS)]
    ,t0.ynForeclosure as [Lis pendens] --Yes/No 
    ,n0.repeat_violator as [Repeat Violator(data fields)] --Yes/No 
    ,null as [Occupancy Type]
    --,null as [Days for Pre-Hearing Inspection] --Number 
    ,a.date_d as [Hearing Date] --Date 
    ,null as [Method of Service]
    ,null as [Notice Date]
    ,null as [Date of Affidavit]
    --,null as [Hearing] 
 
    --SWEEP INFO
    --,'Yes' as [Is this complaint related to a sweep operation?] --Yes/No  req 
    --,( case 
    --    when 1=0 then '1'
    --     when 1=0 then '2'
    --     when 1=0 then '3'
    --     when 1=0 then '4'
    --    else null
    --    end
    -- ) as [Sweep Number] --Drop Down 
    --,null as [Date of Sweep] --Date 
    --,null as [Location of Sweep Operation] --Text Area 
    
    
into cf_Complaint
from AATABLE_PERMIT_HISTORY pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
left join #n0 n0 on n0.number_key = a.number_key
left join #t0 t0 on t0.number_key = a.number_key
left join #t1 t1 on t1.number_key = a.number_key
left join #d d on d.number_key = a.number_key
left join #m0 m0 on m0.NUMBER_KEY = a.NUMBER_KEY
left join #n1 n1 on n1.NUMBER_KEY = a.NUMBER_KEY

left join #legal_descs pb on pb.permitnum = pmap.permitnum --left join hcfl_src.dbo.apd_par numberKey_parcelNo on numberKey_parcelNo.NUMBER_KEY = pmap.number_key      left join hcfl_src.dbo.par_base pb on pb.PARCEL_NO = numberKey_parcelNo.PARCEL_NO
left join #primary_address aa on aa.permitnum = pmap.permitnum --left join (select * from aatable_permit_address where isprimary = 'Y') aa on aa.permitnum = pmap.permitnum --left join hcfl_src.dbo.apd_adr aa on aa.number_key = pmap.number_key
--left join hcfl_src.dbo.apd_peo ap on ap.number_key = pmap.number_key
left join hcfl_src.dbo.tab_cond notation on notation.element_key = pmap.number_key
left join #primary_name primary_name on primary_name.number_key = pmap.number_key
left join #approved ai on ai.number_key = pmap.number_key
where
    1=1
    and pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive')
;

 
    --ensure_fields_arent_too_long
declare @table_name varchar(100) = 'cf_Complaint' 

declare @cutoff int = 50;
DECLARE long_colname_cursor CURSOR for (
	select 
		column_name
	from INFORMATION_SCHEMA.columns 
	where 
		table_name = @table_name
		and len(column_name) > @cutoff
);

declare @column_name_old varchar(200);
declare @modString varchar(200);
declare @newname varchar(200);


OPEN long_colname_cursor
FETCH NEXT FROM long_colname_cursor INTO @column_name_old
    WHILE @@FETCH_STATUS = 0  
		begin
			set @modString = 'dbo.' + @table_name + '.' + @column_name_old;
			set @newname = left(@column_name_old, @cutoff)
			EXEC sp_rename @modString, @newname, 'COLUMN';
			FETCH NEXT FROM long_colname_cursor   INTO @column_name_old
		end
CLOSE long_colname_cursor
DEALLOCATE long_colname_cursor
;
go
;

--LOCKSMITH THINGS
;IF OBJECT_ID('tempdb.dbo.#t0', 'U') IS NOT NULL DROP TABLE #t0
;SELECT
     pmap.number_key
    ,case when t0.YN_038 = 'Y' then 'CHECKED' else NULL end ckBusinessTax      -- Business Tax Receipt
    ,case when t0.YN_037 = 'Y' then 'CHECKED' else NULL end ckLiabilityInsur -- Copy of Liability Insurance
    ,case when t0.YN_006 = 'Y' then 'CHECKED' else NULL end salesTaxCertificate
    ,case when t0.YN_015 = 'Y' then 'CHECKED' else NULL end leaseAgreement
into #t0
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_txt0 t0 on t0.number_key = pmap.number_key
where 
	pnum.tt_record in (
        'Locksmith Initial Application'
        ,'Locksmith License'
        ,'Locksmith Renewal'
    )
	and coalesce(t0.YN_006,t0.YN_015,t0.YN_037,t0.YN_038,null) is not null
;
;IF OBJECT_ID('tempdb.dbo.#t1', 'U') IS NOT NULL DROP TABLE #t1
;SELECT
     pmap.number_key
    ,t1.text_093 S8_CE
into #t1
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_txt1 t1 on t1.number_key = pmap.number_key
where 
	pnum.tt_record in (
        'Locksmith Initial Application'
        ,'Locksmith License'
        ,'Locksmith Renewal'
    )
	and coalesce(t1.text_093,null) is not null
;--0sec
;IF OBJECT_ID('tempdb.dbo.#n1', 'U') IS NOT NULL DROP TABLE #n1
;SELECT
     pmap.number_key
    ,n1.DATE_121 Received
    ,n1.date_122 Issued
    ,n1.date_123 Expires
into #n1
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_num1 n1 on n1.number_key = pmap.number_key
where 
	pnum.tt_record in (
        'Locksmith Initial Application'
        ,'Locksmith License'
        ,'Locksmith Renewal'
    )
	and coalesce(n1.DATE_121,n1.date_122,n1.date_123,null) is not null
;--0sec
;IF OBJECT_ID('tempdb.dbo.#m0', 'U') IS NOT NULL DROP TABLE #m0
;SELECT
     pmap.number_key
    ,m0.MON_019 Application_Amount 
into #m0
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_mon0 m0 on m0.number_key = pmap.number_key
where 
	pnum.tt_record in (
        'Locksmith Initial Application'
        ,'Locksmith License'
        ,'Locksmith Renewal'
    )
	and coalesce(m0.MON_019,null) is not null
;--0sec
;IF OBJECT_ID('tempdb.dbo.#n0', 'U') IS NOT NULL DROP TABLE #n0
;SELECT
     pmap.number_key
    ,n0.DATE_005 Date_paid
    ,n0.date_054 dtLastVisitNot
into #n0
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_num0 n0 on n0.number_key = pmap.number_key
where 
	pnum.tt_record in (
        'Locksmith Initial Application'
        ,'Locksmith License'
        ,'Locksmith Renewal'
    )
	and coalesce(n0.DATE_005,n0.date_054,null) is not null
;--0sec

go

    --Locksmith Initial Application - ENF_LOCK
print 'Locksmith Initial Application - ENF_LOCK';
IF OBJECT_ID('cf_Locksmith_Initial_Application', 'U') IS NOT NULL DROP TABLE cf_Locksmith_Initial_Application
;
select distinct
    pnum.permitNum
    ,pnum.tt_record
 
    --LICENSE INFORMATION
    ,t1.S8_CE as [License number] --Text 
    
    ----APPLICATION
    --,( case 
    --     when 1=0 then '1-5 employees'
    --     when 1=0 then '11 or more employees'
    --     when 1=0 then '6-10 employees'
    --    end
    -- ) as [Number of employees] --Drop Down  req 
    --,( case 
    --    when  1=0 then 'Mobile'
    --     when 1=0 then 'Site & Mobile'
    --    end
    -- ) as [Category] --Drop Down  req 
 
    --HISTORICAL FIELDS
    ,n1.Received as [received]
    ,n1.issued [Issued]
    ,n1.Expires [Expires]
    ,m0.Application_Amount [Application_Amount]
    ,n0.Date_paid [Date_paid]
    ,a.sub_type [SUB_TYPE]
    
    
    ,a.location as [LOCATION]
    ,null as [Follow Up]
    ,n0.dtLastVisitNot as [Last Visit]
    ,t0.ckBusinessTax as [Business Tax Receipt]
    ,t0.salesTaxCertificate as [Sales Tax Receipt]
    ,t0.ckLiabilityInsur   as [Liability Insurance]
    ,t0.leaseAgreement as [Lease Agreement]
into cf_Locksmith_Initial_Application
from AATABLE_PERMIT_HISTORY pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
left join #t0 t0 on t0.number_key = pmap.number_key
left join #t1 t1 on t1.number_key = pmap.number_key
left join #n0 n0 on n0.number_key = pmap.number_key
left join #n1 n1 on n1.number_key = pmap.number_key
left join #m0 m0 on m0.number_key = pmap.number_key
where
    1=1
    and pnum.tt_record = 'Locksmith Initial Application'
;
 
    --ensure_fields_arent_too_long
declare @table_name varchar(100) = 'cf_Locksmith_Initial_Application' 

declare @cutoff int = 50;
DECLARE long_colname_cursor CURSOR for (
	select 
		column_name
	from INFORMATION_SCHEMA.columns 
	where 
		table_name = @table_name
		and len(column_name) > @cutoff
);

declare @column_name_old varchar(200);
declare @modString varchar(200);
declare @newname varchar(200);


OPEN long_colname_cursor
FETCH NEXT FROM long_colname_cursor INTO @column_name_old
    WHILE @@FETCH_STATUS = 0  
		begin
			set @modString = 'dbo.' + @table_name + '.' + @column_name_old;
			set @newname = left(@column_name_old, @cutoff)
			EXEC sp_rename @modString, @newname, 'COLUMN';
			FETCH NEXT FROM long_colname_cursor   INTO @column_name_old
		end
CLOSE long_colname_cursor
DEALLOCATE long_colname_cursor
;
go
;
    --Locksmith License - ENF_LOCK
print 'Locksmith License - ENF_LOCK';
IF OBJECT_ID('cf_Locksmith_License', 'U') IS NOT NULL DROP TABLE cf_Locksmith_License
;
select distinct
    pnum.permitNum
    ,pnum.tt_record
 
    --LICENSE INFORMATION
    ,t1.S8_CE as [License number] --Text 
    
    ----APPLICATION
    --,( case 
    --     when 1=0 then '1-5 employees'
    --     when 1=0 then '11 or more employees'
    --     when 1=0 then '6-10 employees'
    --    end
    -- ) as [Number of employees] --Drop Down  req 
    --,( case 
    --     when 1=0 then 'Mobile'
    --     when 1=0 then 'Site &amp; Mobile'
    --    end
    -- ) as [Category] --Drop Down  req 
 
    --HISTORICAL FIELDS
    ,n1.Received as [received]
    ,n1.issued [Issued]
    ,n1.Expires [Expires]
    ,m0.Application_Amount [Application_Amount]
    ,n0.Date_paid [Date_paid]
    ,a.sub_type [SUB_TYPE]
    
    ,a.location as [LOCATION]
    ,null as [Follow Up]
    ,n0.dtLastVisitNot as [Last Visit]
    ,t0.ckBusinessTax as [Business Tax Receipt]
    ,null as [Sales Tax Receipt]
    ,t0.ckLiabilityInsur   as [Liability Insurance]
    ,null as [Lease Agreement]
into cf_Locksmith_License
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
left join #t0 t0 on t0.number_key = pmap.number_key
left join #t1 t1 on t1.number_key = pmap.number_key
left join #n0 n0 on n0.number_key = pmap.number_key
left join #n1 n1 on n1.number_key = pmap.number_key
left join #m0 m0 on m0.number_key = pmap.number_key
where
    1=1
    and pnum.tt_record = 'Locksmith License'
;
 
    --ensure_fields_arent_too_long
declare @table_name varchar(100) = 'cf_Locksmith_License' 

declare @cutoff int = 50;
DECLARE long_colname_cursor CURSOR for (
	select 
		column_name
	from INFORMATION_SCHEMA.columns 
	where 
		table_name = @table_name
		and len(column_name) > @cutoff
);

declare @column_name_old varchar(200);
declare @modString varchar(200);
declare @newname varchar(200);


OPEN long_colname_cursor
FETCH NEXT FROM long_colname_cursor INTO @column_name_old
    WHILE @@FETCH_STATUS = 0  
		begin
			set @modString = 'dbo.' + @table_name + '.' + @column_name_old;
			set @newname = left(@column_name_old, @cutoff)
			EXEC sp_rename @modString, @newname, 'COLUMN';
			FETCH NEXT FROM long_colname_cursor   INTO @column_name_old
		end
CLOSE long_colname_cursor
DEALLOCATE long_colname_cursor
;
go
;
    --Locksmith Renewal - ENF_LOCK
print 'Locksmith Renewal - ENF_LOCK';
IF OBJECT_ID('cf_Locksmith_Renewal', 'U') IS NOT NULL DROP TABLE cf_Locksmith_Renewal
;
select distinct
    pnum.permitNum
    ,pnum.tt_record
    
    --LICENSE INFORMATION
    ,t1.S8_CE as [License number] --Text 
 
    ----APPLICATION
    --,( case 
    --     when 1=0 then '1-5 employees'
    --     when 1=0 then '11 or more employees'
    --     when 1=0 then '6-10 employees'
    --    end
    -- ) as [Number of employees] --Drop Down  req 
    --,( case 
    --     when 1=0 then 'Mobile'
    --     when 1=0 then 'Site &amp; Mobile'
    --    end
    -- ) as [Category] --Drop Down  req   

    --HISTORICAL FIELDS
    ,n1.Received as [received]
    ,n1.issued [Issued]
    ,n1.Expires [Expires]
    ,m0.Application_Amount [Application_Amount]
    ,n0.Date_paid [Date_paid]
    ,a.sub_type [SUB_TYPE]
    
    ,a.location as [LOCATION]
    ,null as [Follow Up]
    ,n0.dtLastVisitNot as [Last Visit]
    ,t0.ckBusinessTax as [Business Tax Receipt]
    ,null as [Sales Tax Receipt]
    ,t0.ckLiabilityInsur   as [Liability Insurance]
    ,null as [Lease Agreement]
into cf_Locksmith_Renewal
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
left join #t0 t0 on t0.number_key = pmap.number_key
left join #t1 t1 on t1.number_key = pmap.number_key
left join #n0 n0 on n0.number_key = pmap.number_key
left join #n1 n1 on n1.number_key = pmap.number_key
left join #m0 m0 on m0.number_key = pmap.number_key
where
    1=1
    and pnum.tt_record = 'Locksmith Renewal'
;
 
    --ensure_fields_arent_too_long
declare @table_name varchar(100) = 'cf_Locksmith_Renewal' 

declare @cutoff int = 50;
DECLARE long_colname_cursor CURSOR for (
	select 
		column_name
	from INFORMATION_SCHEMA.columns 
	where 
		table_name = @table_name
		and len(column_name) > @cutoff
);

declare @column_name_old varchar(200);
declare @modString varchar(200);
declare @newname varchar(200);


OPEN long_colname_cursor
FETCH NEXT FROM long_colname_cursor INTO @column_name_old
    WHILE @@FETCH_STATUS = 0  
		begin
			set @modString = 'dbo.' + @table_name + '.' + @column_name_old;
			set @newname = left(@column_name_old, @cutoff)
			EXEC sp_rename @modString, @newname, 'COLUMN';
			FETCH NEXT FROM long_colname_cursor   INTO @column_name_old
		end
CLOSE long_colname_cursor
DEALLOCATE long_colname_cursor
;
go
;

/*
--Violation - PMT_VIO
;IF OBJECT_ID('tempdb.dbo.##completed', 'U') is not null insert into ##completed values (getdate(),'0140 0100 custom fields.sql -- violation')
;print 'Violation - PMT_VIO';

;IF OBJECT_ID('tempdb.dbo.#a', 'U') IS NOT NULL DROP TABLE #a
;SELECT
    a.number_key
    ,a.date_d
into #a
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
where 
	pnum.tt_record = 'Violation'
    and a.date_d is not null
;--0sec
;IF OBJECT_ID('tempdb.dbo.#n0', 'U') IS NOT NULL DROP TABLE #n0
;SELECT
     n.number_key
    ,n.date_010
    ,n.date_028
    ,n.date_031
    ,n.date_094
    ,n.date_096
into #n0
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join hcfl_src.dbo.apd_num0 n on n.number_key = pmap.number_key
where 
	pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive')
	and coalesce(n.date_010,n.date_028,n.date_031,n.date_094,n.date_096) is not null
;--50s
;IF OBJECT_ID('tempdb.dbo.#t1', 'U') IS NOT NULL DROP TABLE #t1
;SELECT
     t1.number_key
    ,t1.text_054
    ,t1.text_062
into #t1
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
join hcfl_src.dbo.apd_txt1 t1 on t1.number_key = pmap.number_key
where 
	pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive')
	and coalesce(t1.text_054,t1.text_062) is not null
;--0sec
go




;IF OBJECT_ID('cf_Violation', 'U') IS NOT NULL DROP TABLE cf_Violation
;
select distinct
     pnum.permitNum
    ,pnum.tt_record
 
    --VIOLATION INFORMATION - PCCB
    --,null as [Structure Type]
    --,null as [Warning Notice Date]
    --,null as [Warning Notice Time]
    --,null as [Follow Up Date]
    --,null as [Inspector Number]
    --,null as [Inspector]
    --,null as [Inspector Number 2]
    --,null as [Inspector 2]

    ----GIS INFORMATION
    --,null as [Taxing Authority] --Text 
    --,null as [FEMA] --Text 
    --,null as [Actual Year Built] --Text 
    --,null as [Wind Speed] --Text 
    --,null as [Depreciated Value 50%] --Text 
    --,null as [Easements] --Text 
    --,null as [Transportation Analysis Zone] --Text 
    --,null as [Wetlands] --Text 
    --,null as [Zoning District] --Text 
    --,null as [Appraised Value] --Text 
    --,null as [Base Flood Elevation] --Text 
    --,null as [Depreciated Value] --Text 
    --,null as [Future Land Use District] --Text 
    --,null as [Lot Size] --Text 
    --,null as [Navigable Bodies of Water] --Text 
    --,null as [Special Flood Hazard Areas] --Text 

    --BOARD ACTION INFORMATION
    ,n0.Date_028 as [Notice Date] --Date --'date_first_notice '
    ,n0.Date_031 as [NOV Certified Mail Address] --Text --'dtCertSent        ',' DateCertified Letter Sent to Violator'
    --,null as [NOV Certified Mail Registered Agent] --Text
    ,n0.Date_010 as [NOV Received Date] --Date  --'date_cert_1       ','certifide letter received 1'
    --,( case 
    --     when 1=0 then 'CCEB'
    --     when 1=0 then 'CLB'
    --     when 1=0 then 'PCCB'
    --    else null
    --    end
    -- ) as [Board] --Drop Down 
    ,a.date_d as [Hearing Date] --Date 
 
    --,null as [Primary Violation] --Text 
    --,null as [Date of Service] --Date 
    --,null as [Date of Alternate Service First Class] --Date 
    --,( case 
    --     when 1=0 then 'Debbie Russo'
    --     when 1=0 then 'Gary Smith'
    --     when 1=0 then 'Holly Fritts'
    --     when 1=0 then 'Jesse Stuiso'
    --     when 1=0 then 'Philip Dufour'
    --     when 1=0 then 'Shon Kriel'
    --    else null
    --    end
    -- ) as [Alternate Service First Class Employee] --Drop Down 
    --,null as [Date of Alternate Service Posting GVT] --Date 
    --,( case 
    --    when 1=0 then 'Debbie Russo'
    --     when 1=0 then 'Gary Smith'
    --     when 1=0 then 'Holly Fritts'
    --     when 1=0 then 'Jesse Stuiso'
    --     when 1=0 then 'Philip Dufour'
    --     when 1=0 then 'Shon Kriel'
    --    else null
    --    end
    -- ) as [Alternate Service Posting GVT Employee] --Drop Down 
    --,null as [Date of Alternate Service Posting at site] --Date 
    --,( case 
    --    when 1=0 then 'Debbie Russo'
    --     when 1=0 then 'Gary Smith'
    --     when 1=0 then 'Holly Fritts'
    --     when 1=0 then 'Jesse Stuiso'
    --     when 1=0 then 'Philip Dufour'
    --     when 1=0 then 'Shon Kriel'
    --    else null
    --    end
    -- ) as [Alternate Service Posting at Site Employee] --Drop Down 
 
    ----BOARD ONLY FIELDS PCCB
    --,null as [Present] --Yes/No 
    --,null as [Found in Violation] --Yes/No 
    --,null as [Days for Compliance] --Number 
    --,null as [Finding of Facts] --Text Area 
    --,null as [Conclusion of Law] --Text Area 
    --,null as [Penalty Date] --Date 
    --,null as [Per Day] --Yes/No 
    --,null as [Fine] -- 
    --,null as [BO Certified Mail Address of Record] --Text 
    --,null as [BO Certified Mail Registered Agent] --Text 
    --,null as [BO Certified Mail Return Date] --Date 
    --,null as [BO Certified Mail Registered Date] --Date 
    --,null as [Amount to Date] -- 
    --,null as [Affidavit of Comp] --Date 
    --,null as [Affidavit of Non Comp] --Date 
    --,null as [Lien Date] --Date 
    --,null as [Lien Amount] -- 
    ,t1.Text_054 as [Book] --Text --'strPPOBook        ',' Book for recording PPO lien'
    ,t1.Text_062 as [Page] --Text --'strPPOPage        ',' Page for PPO lien recording'
    ,n0.Date_094 as [Lien Recorded Date] --Text --'dtLienRec1        '
    --,null as [Lien Mailed Date] --Date 
    ,n0.Date_096 as [Lien Release Date] --Date --'dtLienRel1        '
    --,null as [Lien Release Book] --Text 
    --,null as [Lien Release Page] --Text 
    --,null as [BOCC Board Reduction Date] --Date 
    --,null as [BOCC Override Amount] -- 
    --,null as [Override Due] --Date 
    --,null as [Payments] --Yes/No 
    --,null as [Payment Desc] --Text Area 
    --,null as [PCCB Ordered Fine] -- 
    --,null as [PCCB Ordered Payment] --Text 
 

 
    ----VIOLATION INFORMATION - PCCB
    --,'1900-01-01' as [Warning Notice Date] --Date  req 
    --,null as [Warning Notice Time] -- 
    --,null as [Follow Up Date] --Date 
    --,null as [Inspector Number] --Text 
    --,null as [Inspector] --Text 
    --,null as [Inspector Number 2] --Text 
    --,null as [Inspector 2] --Text 
into cf_Violation
from AATABLE_PERMIT_HISTORY pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
left join #n0 n0 on n0.number_key =  pmap.number_key
left join #t1 t1 on t1.number_key = pmap.number_key
where
    1=1
    and pnum.tt_record in ('Violation')
;
 
    --ensure_fields_arent_too_long
declare @table_name varchar(100) = 'cf_Violation' 

declare @cutoff int = 50;
DECLARE long_colname_cursor CURSOR for (
	select 
		column_name
	from INFORMATION_SCHEMA.columns 
	where 
		table_name = @table_name
		and len(column_name) > @cutoff
);

declare @column_name_old varchar(200);
declare @modString varchar(200);
declare @newname varchar(200);


OPEN long_colname_cursor
FETCH NEXT FROM long_colname_cursor INTO @column_name_old
    WHILE @@FETCH_STATUS = 0  
		begin
			set @modString = 'dbo.' + @table_name + '.' + @column_name_old;
			set @newname = left(@column_name_old, @cutoff)
			EXEC sp_rename @modString, @newname, 'COLUMN';
			FETCH NEXT FROM long_colname_cursor   INTO @column_name_old
		end
CLOSE long_colname_cursor
DEALLOCATE long_colname_cursor
;
go
;
*/
