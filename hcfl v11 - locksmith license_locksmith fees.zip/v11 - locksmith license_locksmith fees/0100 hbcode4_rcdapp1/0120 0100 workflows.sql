/* 
rem: the apd_insp table: I am conceptualizing it like... a site visit happens, and subsequent actions/results are in subsequent rows.
Therefore: omit SV,SSV,QCSV,LSV rows, and omit COM,ACOM rows.

Citizens_Board_Support__ENF_CBS
Complaint__ENF_GEN_CPT_V5
Locksmith_Initial_Application__ENF_LOCK_LIC_V1
Locksmith_License__NO_WORKFLOW
Locksmith_Renewal__ENF_LOCK_RENEW_V2
Other__ENF_GEN_CPT_V5
Violation__PMT_VIOLATION
Water_Enforcement__ENF_GEN_CPT_V5
comment apostrophes
*/

;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table AATABLE_PERMIT_WORKFLOW
;


--Citizens_Board_Support__ENF_CBS
;IF OBJECT_ID('tempdb.dbo.#dataStatus_task_status_enf_cbs', 'U') IS NOT NULL drop table #dataStatus_task_status_enf_cbs
go
select
*
into #dataStatus_task_status_enf_cbs
from (VALUES
-- ('PREHRNG' ,'CBS Case Review',
--,('PRECEB'  ,'CBS Case Review',
 ('INSP','CBS Case Review','Request to Post At Property')
,('ADJUDIC','Post Hearing','Adjudicated')
,('CMPLFINE','Post-Hearing','Adjudicated')
,('FINERUN' ,'Post-Hearing','Adjudicated')
,('NWOWNFIN','Post-Hearing','Adjudicated')
,('CAONC'   ,'Post-Hearing','Adjudicated')
,('CAOPR'   ,'Post-Hearing','Adjudicated')
,('COMPLIED','Fee Intake','Fees Received')
,('CLOSED'  ,'Fee Intake','Fees Received')
,('CMPLCEB' ,'Fee Intake','Fees Received')
,('CNCL'    ,'Fee Intake','Fees Received')
,('DISMISS' ,'Fee Intake','Fees Received')
) t(data_status,tt_workflow_task,tt_workflow_status)
;
;insert into AATABLE_PERMIT_WORKFLOW (
PERMITNUM,TASKUPDATED,COMMENTS,ASGN_DATE,DUE_DATE,TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS,USER_ID,ID,SD_HOURS_SPENT,SD_BILLABLE,SD_OVERTIME,ESTIMATED_HOURS,ASGN_EMAIL_DISPLAY_FOR_ACA ,RESTRICT_COMMENT_FOR_ACA,RESTRICT_ROLE,TASK_UNIQUE_ID
)
select distinct
    pnum.permitnum as PERMITNUM
    ,COALESCE(try_convert(datetime,pnum.dateopened),'1900-01-01 00:00:00') as TASKUPDATED
    ,null as COMMENTS
    ,null as ASGN_DATE
    ,null as DUE_DATE
    ,f.tt_workflow_task as TT_WORKFLOW_TASK
    ,f.tt_workflow_status as TT_WORKFLOW_STATUS
    ,coalesce(asgn_staff.user_name,created_by.user_name,'Not Set') as USER_ID
    ,null as ID
    ,null as SD_HOURS_SPENT
    ,null as SD_BILLABLE
    ,null as SD_OVERTIME
    ,null as ESTIMATED_HOURS
    ,null as ASGN_EMAIL_DISPLAY_FOR_ACA
    ,null as RESTRICT_COMMENT_FOR_ACA
    ,null as RESTRICT_ROLE
    ,pnum.permitnum +'_initWorkflow' as TASK_UNIQUE_ID
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum+'-CBS' = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
left join jms_userid_username created_by on created_by.user_id = a.user_id
left join jms_userid_username asgn_staff on asgn_staff.user_id = a.insp_area
join #dataStatus_task_status_enf_cbs f on f.data_status = a.data_status
where 
    1=1
    and pnum.tt_record in ('Citizen Board Support')
;


--Complaint__ENF_GEN_CPT_V5
    --I think this is irrelevant:
;IF OBJECT_ID('tempdb.dbo.#actionEnt_map', 'U') IS NOT NULL drop table #actionEnt_map
;
SELECT
    action_ent
    ,action_ent_desc
    ,tt_workflow_task
    ,tt_workflow_status
into #actionEnt_map
from (VALUES 
    ('ADMN','Non inspection time'       ,'Supervisor Review','Note')
    ,('AFFN','Affidavit Non Compliance' ,'Case Affadavit','Case of Affidavit Sent')
    ,('AP','APPROVED'                   ,'Supervisor Review','Note')
    ,('CA','CANCELED'                   ,'Supervisor Review','Administratively Closed')   --final action
    --,('CA','CANCELED'                   ,'Supervisor Approval','Administratively Closed') --final action
    ,('CEB','Referred for CEB hearing'  ,'Citizen Board Support','Inspection')
    ,('CERT','CertifiedLetter'          ,'Admin Send Letter','Action Status Complete')
    ,('CEWD','OUTREACH WORKDAY'         ,'Supervisor Review','Note')
    ,('CMP','Compliance'                ,'Follow-up Investigation','In Compliance')
    ,('CMP','Compliance'                ,'Supervisor Review','In Compliance') --final action
    ,('CNCL','ITEM CANCELLED'           ,'Supervisor Review','Administratively Closed')  --final action
    --,('CNCL','ITEM CANCELLED'           ,'Supervisor Approval','Administratively Closed')--final action
    ,('CO','CORRECTION'                 ,'Supervisor Review','Corrections Applied')
    ,('COMP','Item Complied'            ,'Follow-up Investigation','In Compliance') --SV
    ,('COMP','Item Complied'            ,'Supervisor Review','In Compliance') --SSV
    ,('CONF','Conflict'                 ,'Follow-up Investigation','Request Re-inspection')
    ,('CPST','Posting Prepared'         ,'Supervisor Approval','NOV Issued')
    ,('CREV','Case Review'              ,'Supervisor Review','Note')
    ,('CRTY','Courtesy Notice Deliver'  ,'Supervisor Approval','NOV Issued')
    ,('DFLT','NOTICE OF DEFAULT'        ,'Supervisor Approval','NOV Issued')
    ,('DUMP','RRT Dumping'              ,'Initial Investigation','Administratively Closed')
    ,('EXT','Extension Granted (noSV)'  ,'Initial Investigation','Extension')
    ,('FCON','Field Contact'            ,'Case Intake','Note')
    ,('HAND','Hand Delivery of NOV'     ,'Supervisor Approval','NOV Issued')
    ,('INOC','I-Non Compliant'          ,'Initial Investigation','Owner on site - NOV/SN issued')
    ,('INVC','INVOICE FOR PPO'          ,'Supervisor Review','Note')
    ,('MHAS','Minimum Housing Appointm' ,'Supervisor Review','Note')
    ,('MISC','Miscellaneous Time'       ,'Supervisor Review','Note')
    ,('NOH','Notice of Hearing'         ,'Citizen Board Support','Inspection')
    ,('NOT2','Posted NOV'               ,'Supervisor Approval','NOV Issued')
    ,('NOV','Notice of Violation'       ,'Supervisor Approval','NOV Issued')
    ,('NOVA','Abatement Notice Complet' ,'Supervisor Approval','NOV Issued')
    ,('NOVB','COMBO NOTICES'            ,'Follow-up Investigation','Combo Issued')
    ,('NOVC','Notice Completed'         ,'Supervisor Approval','NOV Issued')
    ,('NOVF','final notice completed'   ,'Supervisor Review','Final Letter Approved')
    ,('NOVR','NOTICE REQUESTED'         ,'Follow-Up Investigation','NOV Requested')
    ,('NOVS','SITE NOTICE'              ,'Follow-Up Investigation','SN Issued')
    ,('NREV','NOTICE REVIEW'            ,'Supervisor Review','Final Letter Approved')
    ,('PC','PHONE CALL'                 ,'Initial Investigation','Requesting Call Back')
    ,('POST','Notice Posted'            ,'Follow-up Investigation','SN Issued')
    ,('PRT1','PART ONE OF AN ORDER'     ,'Citizen Board Support','Inspection')
    ,('PRT2','PART TWO OF AN ORDER'     ,'Citizen Board Support','Inspection')
    ,('PRT3','PART 3 OF AN ORDER'       ,'Citizen Board Support','Inspection')
    ,('REG','Regular Letter'            ,'Admin Send Letter','Action Status Complete')
    ,('REPT','REPEAT NOTICE OF VIOLATI' ,'Follow-up Investigation','SN Issued')
    ,('RIC','REMAIN IN COMPLIANCE'      ,'Follow-up','Request Re-inspection')
    ,('STLO','CEB Settlement Offered'   ,'Citizen Board Support','Inspection')
    ,('STLS','CEB Settlement Begins'    ,'Citizen Board Support','Inspection')
    ,('SWVN','Solid Waste NOV'          ,'Supervisor Approval','NOV Issued')
    ,('TRPL','TRIPLE PLAY NOTICE'       ,'Follow-up Investigation','SN Issued')
    ,('VIOL','Violation Added'          ,'Initial Investigation','Owner on site - NOV/SN issued')
) t(action_ent,action_ent_desc,tt_workflow_task,tt_workflow_status)
;

    --This is relevant:
;IF OBJECT_ID('tempdb.dbo.#dataStatus_task_status_ENF_GEN_CPT_V5', 'U') IS NOT NULL drop table #dataStatus_task_status_ENF_GEN_CPT_V5
;
go
select
*
into #dataStatus_task_status_ENF_GEN_CPT_V5
from (VALUES
 ('ABATED','Follow up Investigation','Administratively Closed')
,('CLNO','Supervisor Approval','Approval to Close')
,('CLSD','Supervisor Approval','Administratively Closed')
,('CMPL','Follow up Investigation','In Compliance')
,('CMPLABAT','Follow up Investigation','Administratively Closed')
,('CMPLCEB','Citizen Board Support','Close')
,('CMPLFINE','Citizen Board Support','Close')
,('DONE','Initial Investigation','Dead Animal Removal')
,('DISMISS','Citizen Board Support','Case Dismissed')
,('REMOVED','Initial Investigation','Dead Animal Removal')
,('INSP','Admin Send Letter','Action Status Complete')  --'Follow up Investigation','Request Re-Inspection') --ACTIVE')
,('ADJUDIC',  'Case Affadavit','Case of Affidavit Sent')  --'Citizen Board Support','Inspection') --'ACTIVE'
,('CAONC',    'Case Affadavit','Case of Affidavit Sent')  --'Citizen Board Support','Inspection') --???
,('CAOPR',    'Case Affadavit','Case of Affidavit Sent')  --'Citizen Board Support','Inspection') --???
,('CODEBRD',  'Case Affadavit','Case of Affidavit Sent')  --'Citizen Board Support','Inspection') --???
,('FINERUN',  'Case Affadavit','Case of Affidavit Sent')  --'Citizen Board Support','Inspection') --???
,('NWOWNFIN', 'Case Affadavit','Case of Affidavit Sent')  --'Citizen Board Support','Inspection') --???
,('PREHRNG',  'Case Affadavit','Case of Affidavit Sent')  --'Citizen Board Support','Inspection') --???
,('PRECEB',   'Case Affadavit','Case of Affidavit Sent')  --'Citizen Board Support','Inspection') --???
,('PENDING','Initial Investigation','Combo Notice Issued')  --'Supervisor Approval','ACTIVE')
,('REFERRED','Follow up Investigation','Request for Final Letter Notice') --'Supervisor Review','ACTIVE')
,('XFER',  'Initial Investigation','Combo Notice Issued') --'Supervisor Approval','ACTIVE'
,('RECITE','Initial Investigation','Combo Notice Issued') --'Supervisor Approval','ACTIVE'
,('OPEN','Case Intake','Assigned') --'Initial Investigation','ACTIVE'
) t(data_status,tt_workflow_task,tt_workflow_status)
;


;insert into AATABLE_PERMIT_WORKFLOW (
PERMITNUM,TASKUPDATED,COMMENTS,ASGN_DATE,DUE_DATE,TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS,USER_ID,ID,SD_HOURS_SPENT,SD_BILLABLE,SD_OVERTIME,ESTIMATED_HOURS,ASGN_EMAIL_DISPLAY_FOR_ACA ,RESTRICT_COMMENT_FOR_ACA,RESTRICT_ROLE,TASK_UNIQUE_ID
)
select distinct
    pnum.permitnum as PERMITNUM
    ,COALESCE(try_convert(datetime,pnum.dateopened),'1900-01-01 00:00:00') as TASKUPDATED
    ,null as COMMENTS
    ,null as ASGN_DATE
    ,null as DUE_DATE
    ,f.tt_workflow_task as TT_WORKFLOW_TASK
    ,f.tt_workflow_status as TT_WORKFLOW_STATUS
    ,coalesce(asgn_staff.user_name,created_by.user_name,'Not Set') as USER_ID
    ,null as ID
    ,null as SD_HOURS_SPENT
    ,null as SD_BILLABLE
    ,null as SD_OVERTIME
    ,null as ESTIMATED_HOURS
    ,null as ASGN_EMAIL_DISPLAY_FOR_ACA
    ,null as RESTRICT_COMMENT_FOR_ACA
    ,null as RESTRICT_ROLE
    ,pnum.permitnum +'_initWorkflow' as TASK_UNIQUE_ID
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
left join jms_userid_username created_by on created_by.user_id = a.user_id
left join jms_userid_username asgn_staff on asgn_staff.user_id = a.insp_area
join #dataStatus_task_status_ENF_GEN_CPT_V5 f on f.data_status = a.data_status
where 
    (pnum.tt_record in ('Enforcement Complaint','Enforcement Complaint - Proactive') or pnum.tt_record like 'Other%')
;



--Locksmith_Initial_Application__ENF_LOCK_LIC_V1

;IF OBJECT_ID('tempdb.dbo.#locksmith_app_presumption_data', 'U') IS NOT NULL drop table #locksmith_app_presumption_data
;
select
	'' [ ]
	,(case 
		when the_text like '%deficien%' then 'Application Intake/Additional Info Required'
		when the_text like '%need%' then 'Application Intake/Additional Info Required'
		when the_text like '%request%' then 'Application Intake/Additional Info Required'
		when the_text like '%license%issue%%' then 'License Issuance/Issued'
		when the_text like '%approv%' then 'License Issuance/Issued'
		when the_text like '%renew%' then 'License Issuance/Issued'
		when the_text like '%visit%' then 'Inspections/Inspections Completed'
		when the_text like '%met%' then 'Inspections/Inspections Completed'
						
		when the_text like '%current%' then 'Application Intake/Review Complete'
		when the_text like '%receiv%' then 'Application Intake/Review Complete'

		when the_text like '%inactive%' then 'Application Intake/Denied'
		when the_text like '%does not fit%' then 'Application Intake/Denied'
		when the_text like '%NOV%' then 'Application Intake/Denied'
		when the_text like '%closed%' then 'License Issuance/Issued'
		when the_text like '%generated%' then 'Inspections/Not Applicable'
		else 'Application Intake/Additional Info Required'
		end
	) presumption
	,l.NUMBER_KEY
	,DATE_ENTERED
	, the_text
	,coalesce(l.USER_X,convert(varchar(max),l.user_id),'Not Set') [ASGN_STAFF]
    ,convert(varchar(max),l.auto_key) as auto_key
into #locksmith_app_presumption_data
from hcfl_Src..LHN_TAB l
join AATABLE_PERMIT_HISTORY p on p.permitnum = l.NUMBER_KEY
where
	1=1
	and p.TT_RECORD = 'Locksmith Initial Application'
	--and NUMBER_KEY = 'CE18005969'

union 

select
	'' [ ]
	,'Inspections/Inspections Completed' presumption
	,i.NUMBER_KEY
	,i.DATE_ENT
	,i.any_comments
	,coalesce(user_id.USER_NAME,i.user_id,'Not Set') [ASGN_STAFF]
    ,i.unique_key as auto_key
from jms_apd_insp_filteredToPop i
join AATABLE_PERMIT_HISTORY p on p.permitnum = i.NUMBER_KEY
left join hcfl_src.dbo.usr_base user_id on user_id.user_id = i.user_id
where
	1=1
	and p.tt_record = 'Locksmith Initial Application'
	and i.UNIQUE_KEY not like 'ORPH-%'
	and i.ACTION_ENT in ('sv','ssv','qcsv','lsv')
;


insert into AATABLE_PERMIT_WORKFLOW (
PERMITNUM,TASKUPDATED,COMMENTS,ASGN_DATE,DUE_DATE,TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS,USER_ID,ID,SD_HOURS_SPENT,SD_BILLABLE,SD_OVERTIME,ESTIMATED_HOURS,ASGN_EMAIL_DISPLAY_FOR_ACA ,RESTRICT_COMMENT_FOR_ACA,RESTRICT_ROLE,TASK_UNIQUE_ID
)
select distinct
    pnum.permitnum as PERMITNUM
    ,COALESCE(try_convert(datetime,pnum.dateopened),'1900-01-01 00:00:00') as TASKUPDATED
    ,null as COMMENTS
    ,null as ASGN_DATE
    ,null as DUE_DATE
    ,'Application Intake' as TT_WORKFLOW_TASK
    ,'Additional Info Required' as TT_WORKFLOW_STATUS
    ,coalesce(asgn_staff.user_name,created_by.user_name,'Not Set') as USER_ID
    ,null as ID
    ,null as SD_HOURS_SPENT
    ,null as SD_BILLABLE
    ,null as SD_OVERTIME
    ,null as ESTIMATED_HOURS
    ,null as ASGN_EMAIL_DISPLAY_FOR_ACA
    ,null as RESTRICT_COMMENT_FOR_ACA
    ,null as RESTRICT_ROLE
    ,pnum.permitnum +'_initWorkflow' as TASK_UNIQUE_ID
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
left join jms_userid_username created_by on created_by.user_id = a.user_id
left join jms_userid_username asgn_staff on asgn_staff.user_id = a.insp_area
--join jms_apd_insp_filteredToPop i on i.number_key = pmap.number_key
--join #actionEnt_map am on am.action_ent = i.action_ent 
where 
    pnum.tt_record in ('Locksmith Initial Application')
;

insert into AATABLE_PERMIT_WORKFLOW (
PERMITNUM,TASKUPDATED,COMMENTS,ASGN_DATE,DUE_DATE,TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS,USER_ID,ID,SD_HOURS_SPENT,SD_BILLABLE,SD_OVERTIME,ESTIMATED_HOURS,ASGN_EMAIL_DISPLAY_FOR_ACA ,RESTRICT_COMMENT_FOR_ACA,RESTRICT_ROLE,TASK_UNIQUE_ID
)
select distinct
    pnum.permitnum as PERMITNUM
    ,COALESCE(a.date_entered,'1900-01-01 00:00:00') as TASKUPDATED
    ,left(replace(replace(a.the_text,char(10),'®'),char(13),''),4000) as COMMENTS
    ,null as ASGN_DATE
    ,null as DUE_DATE
    ,trim('/ ' from substring(a.presumption,1,charindex('/',a.presumption))					) as TT_WORKFLOW_TASK
    ,trim('/ ' from substring(a.presumption,charindex('/',a.presumption),len(a.presumption)) ) as TT_WORKFLOW_STATUS
    ,a.ASGN_STAFF as USER_ID
    ,null as ID
    ,null as SD_HOURS_SPENT
    ,null as SD_BILLABLE
    ,null as SD_OVERTIME
    ,null as ESTIMATED_HOURS
    ,null as ASGN_EMAIL_DISPLAY_FOR_ACA
    ,null as RESTRICT_COMMENT_FOR_ACA
    ,null as RESTRICT_ROLE
    ,convert(varchar(max),a.auto_key) as TASK_UNIQUE_ID --,pnum.permitnum +'_' + convert(varchar(max),a.auto_key) as TASK_UNIQUE_ID
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join #locksmith_app_presumption_data a on a.number_key = pmap.number_key
where 
    pnum.tt_record in ('Locksmith Initial Application')
;


--Locksmith_License__NO_WORKFLOW

--Locksmith_Renewal__ENF_LOCK_RENEW_V2


;IF OBJECT_ID('tempdb.dbo.#locksmith_ren_presumption_data', 'U') IS NOT NULL drop table #locksmith_ren_presumption_data
;
select
	'' [ ]
	,(case 
		when the_text like '%fail%' then 'Application Intake/Withdrawn'
		when the_text like '%await%' then 'Application Intake/Additional Info Required'
		when the_text like '%request%' then 'Application Intake/Additional Info Required'
		when the_text like '%return%call%' then 'Application Intake/Additional Info Required'
		when the_text like '%spoke with%' then 'Application Intake/Additional Info Required'
		when the_text like '%Research%' then 'Application Intake/Additional Info Required'
		
		when the_text like '%business no long%' then 'Application Intake/Withdrawn'
		when the_text like '%creat%err%' then 'Application Intake/Withdrawn'
		when the_text like '%no%resp%' then 'Application Intake/Additional Info Required'
		when the_text like '%met%' then 'Inspections/Inspections Completed'
		when the_text like '%emailed investigators%' then 'Inspections/Schedule Site Visit'
		when the_text like '%for an inspect%' then 'Inspections/Schedule Site Visit'
		when the_text like '%proof of%' then 'Application Intake/Review Complete'
		when the_text like '%received%' then 'Application Intake/Review Complete'
		when the_text like '%entering%' then 'Inspections/Inspections Complete'
		when the_text like '%inspect%' then 'Inspections/Schedule Site Visit'
		when the_text like '%get together%' then 'Inspections/Schedule Site Visit'

		
		when the_text like '%renew%' then 'Renew License/Issued'
		when the_text like '%issue%' then 'Renew License/Issued'
		when the_text like '%generated lic%' then 'Renew License/Issued'
		when the_text like '%clos%' then 'Application Intake/Withdrawn'
		when the_text like '%NOV%' then 'Application Intake/Withdrawn'
		when the_text like '%pulled%' then 'Application Intake/Withdrawn'
		
		else 'Application Intake/Additional Info Required'
		end
	) presumption
	,l.NUMBER_KEY
	,DATE_ENTERED
	, the_text
	,coalesce(l.USER_X,convert(varchar(max),l.user_id),'Not Set') [ASGN_STAFF]
    ,convert(varchar(max),l.auto_key) as auto_key
into #locksmith_ren_presumption_data
from hcfl_Src..LHN_TAB l
join AATABLE_PERMIT_HISTORY p on p.permitnum = l.NUMBER_KEY
where
	1=1
	and p.TT_RECORD = 'Locksmith Renewal'
	--and NUMBER_KEY = 'CE18005969'

union 

select
	'' [ ]
	,'Inspections/Inspections Completed' presumption
	,i.NUMBER_KEY
	,i.DATE_ENT
	,i.any_comments
	,coalesce(user_id.USER_NAME,i.user_id,'Not Set') [ASGN_STAFF]
    ,i.unique_key as auto_key
from jms_apd_insp_filteredToPop i
join AATABLE_PERMIT_HISTORY p on p.permitnum = i.NUMBER_KEY
left join hcfl_src.dbo.usr_base user_id on user_id.user_id = i.user_id
where
	1=1
	and p.tt_record = 'Locksmith Renewal'
	and i.UNIQUE_KEY not like 'ORPH-%'
	and i.ACTION_ENT in ('sv','ssv','qcsv','lsv')
;





insert into AATABLE_PERMIT_WORKFLOW (
PERMITNUM,TASKUPDATED,COMMENTS,ASGN_DATE,DUE_DATE,TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS,USER_ID,ID,SD_HOURS_SPENT,SD_BILLABLE,SD_OVERTIME,ESTIMATED_HOURS,ASGN_EMAIL_DISPLAY_FOR_ACA ,RESTRICT_COMMENT_FOR_ACA,RESTRICT_ROLE,TASK_UNIQUE_ID
)
select distinct
    pnum.permitnum as PERMITNUM
    ,COALESCE(try_convert(datetime,pnum.dateopened),'1900-01-01 00:00:00') as TASKUPDATED
    ,null as COMMENTS
    ,null as ASGN_DATE
    ,null as DUE_DATE
    ,'Application Intake' as TT_WORKFLOW_TASK
    ,'Additional Info Required' as TT_WORKFLOW_STATUS
    ,coalesce(asgn_staff.user_name,created_by.user_name,'Not Set') as USER_ID
    ,null as ID
    ,null as SD_HOURS_SPENT
    ,null as SD_BILLABLE
    ,null as SD_OVERTIME
    ,null as ESTIMATED_HOURS
    ,null as ASGN_EMAIL_DISPLAY_FOR_ACA
    ,null as RESTRICT_COMMENT_FOR_ACA
    ,null as RESTRICT_ROLE
    ,pnum.permitnum +'_initWorkflow' as TASK_UNIQUE_ID
from AATABLE_PERMIT_HISTORY pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
left join jms_userid_username created_by on created_by.user_id = a.user_id
left join jms_userid_username asgn_staff on asgn_staff.user_id = a.insp_area
where 
    pnum.tt_record in ('Locksmith Renewal')
;


insert into AATABLE_PERMIT_WORKFLOW (
PERMITNUM,TASKUPDATED,COMMENTS,ASGN_DATE,DUE_DATE,TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS,USER_ID,ID,SD_HOURS_SPENT,SD_BILLABLE,SD_OVERTIME,ESTIMATED_HOURS,ASGN_EMAIL_DISPLAY_FOR_ACA ,RESTRICT_COMMENT_FOR_ACA,RESTRICT_ROLE,TASK_UNIQUE_ID
)
select distinct
    pnum.permitnum as PERMITNUM
    ,COALESCE(a.date_entered,'1900-01-01 00:00:00') as TASKUPDATED
    ,left(replace(replace(a.the_text,char(10),'®'),char(13),''),4000) as COMMENTS
    ,null as ASGN_DATE
    ,null as DUE_DATE
    ,trim('/ ' from substring(a.presumption,1,charindex('/',a.presumption))					) as TT_WORKFLOW_TASK
    ,trim('/ ' from substring(a.presumption,charindex('/',a.presumption),len(a.presumption)) ) as TT_WORKFLOW_STATUS
    ,a.ASGN_STAFF as USER_ID
    ,null as ID
    ,null as SD_HOURS_SPENT
    ,null as SD_BILLABLE
    ,null as SD_OVERTIME
    ,null as ESTIMATED_HOURS
    ,null as ASGN_EMAIL_DISPLAY_FOR_ACA
    ,null as RESTRICT_COMMENT_FOR_ACA
    ,null as RESTRICT_ROLE
    ,convert(varchar(max),a.auto_key) as TASK_UNIQUE_ID --,pnum.permitnum +'_'+convert(varchar(max),a.auto_key) as TASK_UNIQUE_ID
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join #locksmith_ren_presumption_data a on a.number_key = pmap.number_key
where 
    pnum.tt_record in ('Locksmith Renewal')
;


--Other__ENF_GEN_CPT_V5
;insert into AATABLE_PERMIT_WORKFLOW (
PERMITNUM,TASKUPDATED,COMMENTS,ASGN_DATE,DUE_DATE,TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS,USER_ID,ID,SD_HOURS_SPENT,SD_BILLABLE,SD_OVERTIME,ESTIMATED_HOURS,ASGN_EMAIL_DISPLAY_FOR_ACA ,RESTRICT_COMMENT_FOR_ACA,RESTRICT_ROLE,TASK_UNIQUE_ID
)
select distinct
    pnum.permitnum as PERMITNUM
    ,COALESCE(try_convert(datetime,pnum.dateopened),'1900-01-01 00:00:00') as TASKUPDATED
    ,null as COMMENTS
    ,null as ASGN_DATE
    ,null as DUE_DATE
    ,'Case Intake' as TT_WORKFLOW_TASK
    ,'Assigned' as TT_WORKFLOW_STATUS
    ,coalesce(asgn_staff.user_name,created_by.user_name,'Not Set') as USER_ID
    ,null as ID
    ,null as SD_HOURS_SPENT
    ,null as SD_BILLABLE
    ,null as SD_OVERTIME
    ,null as ESTIMATED_HOURS
    ,null as ASGN_EMAIL_DISPLAY_FOR_ACA
    ,null as RESTRICT_COMMENT_FOR_ACA
    ,null as RESTRICT_ROLE
    ,pnum.permitnum +'_initWorkflow' as TASK_UNIQUE_ID
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
left join jms_userid_username created_by on created_by.user_id = a.user_id
left join jms_userid_username asgn_staff on asgn_staff.user_id = a.insp_area
--join jms_apd_insp_filteredToPop i on i.number_key = pmap.number_key
--join #actionEnt_map am on am.action_ent = i.action_ent 
where 
    pnum.tt_record like 'Other%'
;

;insert into AATABLE_PERMIT_WORKFLOW (
PERMITNUM,TASKUPDATED,COMMENTS,ASGN_DATE,DUE_DATE,TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS,USER_ID,ID,SD_HOURS_SPENT,SD_BILLABLE,SD_OVERTIME,ESTIMATED_HOURS,ASGN_EMAIL_DISPLAY_FOR_ACA ,RESTRICT_COMMENT_FOR_ACA,RESTRICT_ROLE,TASK_UNIQUE_ID
)
select distinct
    pnum.permitnum as PERMITNUM
    ,COALESCE(try_convert(datetime,i.date_ent),'1900-01-01 00:00:00') as TASKUPDATED
    ,left(replace(replace(i.any_comments,char(10),'®'),char(13),''),4000) as COMMENTS
    ,null as ASGN_DATE
    ,null as DUE_DATE
    ,am.tt_workflow_task as TT_WORKFLOW_TASK
    ,am.tt_workflow_status as TT_WORKFLOW_STATUS
    ,coalesce(user_id.user_name,i.user_id,'Not Set') as USER_ID
    ,null as ID
    ,null as SD_HOURS_SPENT
    ,null as SD_BILLABLE
    ,null as SD_OVERTIME
    ,null as ESTIMATED_HOURS
    ,null as ASGN_EMAIL_DISPLAY_FOR_ACA
    ,null as RESTRICT_COMMENT_FOR_ACA
    ,null as RESTRICT_ROLE
    ,i.UNIQUE_KEY as TASK_UNIQUE_ID
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_insp_filteredToPop i on i.number_key = pmap.number_key
join #actionEnt_map am on am.action_ent = i.action_ent 
left join hcfl_src.dbo.usr_base user_id on user_id.user_id = i.user_id
where 
    pnum.tt_record like 'Other%'
    and i.action_ent not in ('sv','ssv','qcsv','lsv','com','acom')
;

--Violation__PMT_VIOLATION
;IF OBJECT_ID('tempdb.dbo.#violation_presumption_data', 'U') IS NOT NULL drop table #violation_presumption_data

select 
	'' [ ]
	,(case 
		when action_ent like 'NOV%' or action_ent in ('CERT','NOT2','HAND','CRTY','SWVN','POST','SUB','DUMP','CPST') then 'Pending Violation Review/Violation Issued'
		when action_ent in ('COMP','CMP','AP') then 'Review Violation/Complied'
		when action_ent in ('EXT','BCMP') then 'Review Violation/Extension Granted'
		when action_ent = 'VIOL' then 'Pending Violation Review/Violation Issued'
		when action_ent in ('REPT','NCMP','PC','INVC') then 'Review Violation/Note'
		when action_ent = 'CEB' then 'Review Violation/File PCCB'
		when action_ent = 'CO' then 'Review Violation/Complied'
		when action_ent in ('STLO','STLS','RIC','DFLT') then 'Case Closure/Note'
		when action_ent in ('ABAT','TRPL','NREV','CONF','CREV','COM','ACOM','TRNG','ADMN','MISC') then 'Review Violation/Note'
		when action_ent in ('PRT1','PRT2','PRT3','AFFN') then 'PCCB/In Violation'
		when action_ent in ('CA','CNCL','NA','CEWD') then 'Case Closure/Closed'
		when action_ent in ('OVT','ASTA','MHAS','UNIT','COSV') then 'Pending Violation Review/Note'
		else null
		end
	) presumption
	,i.NUMBER_KEY
	,i.DATE_ENT
	,i.any_comments
	,coalesce(user_id.USER_NAME,i.user_id,'Not Set') [ASGN_STAFF]
	,i.ACTION_ENT
    ,i.UNIQUE_KEY
	,i.item_id
into #violation_presumption_data
from jms_apd_insp_filteredToPop i
join AATABLE_PERMIT_HISTORY p on p.permitnum = i.NUMBER_KEY
left join hcfl_src.dbo.usr_base user_id on user_id.user_id = i.user_id
where
	1=1
	and p.tt_record = 'violation'
	and i.UNIQUE_KEY not like 'ORPH-%'
	and i.ACTION_ENT not in ('sv','ssv','qcsv','lsv')
	--and i.NUMBER_KEY = 'CE12001626'
	--and i.ACTION_ENT = 'co'
--order by i.date_ent
;
delete from #violation_presumption_data where presumption is null
;


insert into AATABLE_PERMIT_WORKFLOW (
PERMITNUM,TASKUPDATED,COMMENTS,ASGN_DATE,DUE_DATE,TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS,USER_ID,ID,SD_HOURS_SPENT,SD_BILLABLE,SD_OVERTIME,ESTIMATED_HOURS,ASGN_EMAIL_DISPLAY_FOR_ACA ,RESTRICT_COMMENT_FOR_ACA,RESTRICT_ROLE,TASK_UNIQUE_ID
)
select distinct
    pnum.permitnum as PERMITNUM
    ,COALESCE(try_convert(datetime,pnum.dateopened),'1900-01-01 00:00:00') as TASKUPDATED
    ,null as COMMENTS
    ,null as ASGN_DATE
    ,null as DUE_DATE
    ,'Application Intake' as TT_WORKFLOW_TASK
    ,'Additional Info Required' as TT_WORKFLOW_STATUS
    ,coalesce(asgn_staff.user_name,created_by.user_name,'Not Set') as USER_ID
    ,null as ID
    ,null as SD_HOURS_SPENT
    ,null as SD_BILLABLE
    ,null as SD_OVERTIME
    ,null as ESTIMATED_HOURS
    ,null as ASGN_EMAIL_DISPLAY_FOR_ACA
    ,null as RESTRICT_COMMENT_FOR_ACA
    ,null as RESTRICT_ROLE
    ,pnum.permitnum +'_initWorkflow' as TASK_UNIQUE_ID
from AATABLE_PERMIT_HISTORY pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
left join jms_userid_username created_by on created_by.user_id = a.user_id
left join jms_userid_username asgn_staff on asgn_staff.user_id = a.insp_area
where 
    pnum.tt_record in ('Violation')
;

insert into AATABLE_PERMIT_WORKFLOW (
PERMITNUM,TASKUPDATED,COMMENTS,ASGN_DATE,DUE_DATE,TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS,USER_ID,ID,SD_HOURS_SPENT,SD_BILLABLE,SD_OVERTIME,ESTIMATED_HOURS,ASGN_EMAIL_DISPLAY_FOR_ACA ,RESTRICT_COMMENT_FOR_ACA,RESTRICT_ROLE,TASK_UNIQUE_ID
)
select distinct
    pnum.permitnum as PERMITNUM
    ,COALESCE(try_convert(datetime,a.date_ent),'1900-01-01 00:00:00') as TASKUPDATED
    ,left(replace(replace(a.any_comments,char(10),'®'),char(13),''),4000) as COMMENTS
    ,null as ASGN_DATE
    ,null as DUE_DATE
    ,trim('/ ' from substring(a.presumption,1,charindex('/',a.presumption))					) as TT_WORKFLOW_TASK
    ,trim('/ ' from substring(a.presumption,charindex('/',a.presumption),len(a.presumption)) ) as TT_WORKFLOW_STATUS
    ,a.ASGN_STAFF as USER_ID
    ,null as ID
    ,null as SD_HOURS_SPENT
    ,null as SD_BILLABLE
    ,null as SD_OVERTIME
    ,null as ESTIMATED_HOURS
    ,null as ASGN_EMAIL_DISPLAY_FOR_ACA
    ,null as RESTRICT_COMMENT_FOR_ACA
    ,null as RESTRICT_ROLE
    ,a.unique_key as TASK_UNIQUE_ID
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join #violation_presumption_data a on a.number_key = pmap.number_key
where 
    pnum.tt_record in ('Violation')
;

--What if the case is closed and there is no closure step?
--What if the case has a hearing or order date in apd_base, and no occurrence of "hearing" or similar in apd_insp?



--Water_Enforcement__ENF_GEN_CPT_V5
--use #actionEnt_map

insert into AATABLE_PERMIT_WORKFLOW (
PERMITNUM,TASKUPDATED,COMMENTS,ASGN_DATE,DUE_DATE,TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS,USER_ID,ID,SD_HOURS_SPENT,SD_BILLABLE,SD_OVERTIME,ESTIMATED_HOURS,ASGN_EMAIL_DISPLAY_FOR_ACA ,RESTRICT_COMMENT_FOR_ACA,RESTRICT_ROLE,TASK_UNIQUE_ID
)
select distinct
    pnum.permitnum as PERMITNUM
    ,COALESCE(try_convert(datetime,pnum.dateopened),'1900-01-01 00:00:00') as TASKUPDATED
    ,null as COMMENTS
    ,null as ASGN_DATE
    ,null as DUE_DATE
    ,'Case Intake' as TT_WORKFLOW_TASK
    ,'Assigned' as TT_WORKFLOW_STATUS
    ,coalesce(asgn_staff.user_name,created_by.user_name,'Not Set') as USER_ID
    ,null as ID
    ,null as SD_HOURS_SPENT
    ,null as SD_BILLABLE
    ,null as SD_OVERTIME
    ,null as ESTIMATED_HOURS
    ,null as ASGN_EMAIL_DISPLAY_FOR_ACA
    ,null as RESTRICT_COMMENT_FOR_ACA
    ,null as RESTRICT_ROLE
    ,pnum.permitnum +'_initWorkflow' as TASK_UNIQUE_ID
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_base_filtered a on a.number_key = pmap.number_key
left join jms_userid_username created_by on created_by.user_id = a.user_id
left join jms_userid_username asgn_staff on asgn_staff.user_id = a.insp_area
--join jms_apd_insp_filteredToPop i on i.number_key = pmap.number_key
--join #actionEnt_map am on am.action_ent = i.action_ent 
where 
    pnum.tt_record in ('Water Enforcement')
;

;insert into AATABLE_PERMIT_WORKFLOW (
PERMITNUM,TASKUPDATED,COMMENTS,ASGN_DATE,DUE_DATE,TT_WORKFLOW_TASK,TT_WORKFLOW_STATUS,USER_ID,ID,SD_HOURS_SPENT,SD_BILLABLE,SD_OVERTIME,ESTIMATED_HOURS,ASGN_EMAIL_DISPLAY_FOR_ACA ,RESTRICT_COMMENT_FOR_ACA,RESTRICT_ROLE,TASK_UNIQUE_ID
)
select distinct
    pnum.permitnum as PERMITNUM
    ,COALESCE(try_convert(datetime,i.date_ent),'1900-01-01 00:00:00') as TASKUPDATED
    ,left(replace(replace(i.any_comments,char(10),'®'),char(13),''),4000) as COMMENTS
    ,null as ASGN_DATE
    ,null as DUE_DATE
    ,am.tt_workflow_task as TT_WORKFLOW_TASK
    ,am.tt_workflow_status as TT_WORKFLOW_STATUS
    ,coalesce(user_id.user_name,i.user_id,'Not Set') as USER_ID
    ,null as ID
    ,null as SD_HOURS_SPENT
    ,null as SD_BILLABLE
    ,null as SD_OVERTIME
    ,null as ESTIMATED_HOURS
    ,null as ASGN_EMAIL_DISPLAY_FOR_ACA
    ,null as RESTRICT_COMMENT_FOR_ACA
    ,null as RESTRICT_ROLE
    ,i.UNIQUE_KEY as TASK_UNIQUE_ID
from aatable_permit_history pnum
join jms_numberKey_permitnum pmap on pmap.permitnum = pnum.permitnum
join jms_apd_insp_filteredToPop i on i.number_key = pmap.number_key
join #actionEnt_map am on am.action_ent = i.action_ent 
left join hcfl_src.dbo.usr_base user_id on user_id.user_id = i.user_id
where 
    pnum.tt_record in ('Water Enforcement')
    and i.action_ent not in ('sv','ssv','qcsv','lsv','com','acom')
;


--comment apostrophes
update aatable_permit_workflow set
    comments = replace(comments,'''','Å')
;
    --and user_id's, apparently...
update aatable_permit_workflow set
    user_id = 'Spriggs, Teddy'
WHERE
    1=1
    and user_id = 'Spriggs, Edward ''Teddy'''
;