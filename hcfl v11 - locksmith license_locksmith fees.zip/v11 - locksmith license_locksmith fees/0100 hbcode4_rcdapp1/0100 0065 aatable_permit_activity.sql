/*
setup
actual logic
*/

IF OBJECT_ID('tempdb.dbo.##completed', 'U') IS NOT NULL 
insert into ##completed values (getdate(),'aatable_permit_activity')
;

--setup

--determine child rows per inspection, then assert inspection type and inspection result based on those children
;IF OBJECT_ID('tempdb.dbo.#parents', 'U') IS NOT NULL drop table #parents
;IF OBJECT_ID('tempdb.dbo.#is_initial_site_visit', 'U') IS NOT NULL drop table #is_initial_site_visit
;IF OBJECT_ID('tempdb.dbo.#g', 'U') IS NOT NULL drop table #g
;IF OBJECT_ID('tempdb.dbo.#orphaned', 'U') IS NOT NULL drop table #orphaned
;IF OBJECT_ID('tempdb.dbo.#h', 'U') IS NOT NULL drop table #h
;
go


--;with parents
    --assumes inspections are site visits, and results are implied by the subsequent rows prior to the following site visit.
	select
		number_key
		,unique_key
		,date_ent
		,the_Date
		,action_ent
    into #parents
	from jms_apd_insp_filteredToPop
	where action_ent in ('SV','SSV','QCSV','LSV')
	--and number_key = 'CE18015425'
;
--), is_initial_site_visit as (
    --"initial site visiit" is an accela inspection type
	select
		b.UNIQUE_KEY
        ,b.action_ent
    into #is_initial_site_visit
	from jms_apd_base_filtered a
	outer apply (select top 1 * from jms_apd_insp_filteredToPop where NUMBER_KEY = a.NUMBER_KEY and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent,the_date) b
;
--),g as (
    select
        a.number_key
        ,a.item_id
        ,a.unique_key
        ,a.action_ent
        ,action_ent.DESCRIPTION action_ent_desc
        ,case when is_initial_site_visit.UNIQUE_KEY is not null then 1 else 0 end as is_initial_site_visit
        ,'xxxx' [ ]
        ,coalesce(b.unique_key,is_initial_site_visit.unique_key) parent_unique_key
        ,b.action_ent parent_action_ent
        ,(case 
            when is_initial_site_visit.UNIQUE_KEY is not null then 'Initial Site Visit'
            when a.ACTION_ENT in ('QCSV','LSV') then 'Quality Control Inspection'
            when A.ACTION_ENT = 'SSV' then 'Re-Inspection'
            --when A.ACTION_ENT = 'CREV' then 'Case Review'
            when  a.any_comments like '%re%inspect%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%re%check%'    then 'Re-Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%annual%insp%'    then 'Annual Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%post%hearing%'    then 'Post-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%pre%hearing%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%hear%'    then 'Pre-Hearing Inspection' --I don't know about pre vs post hearing
            when  a.any_comments like '%follow%up%'    then 'Follow-up Inspection' --I don't know about pre vs post hearing
            else 'Inspection'
            end		
        ) as inspection_type
        ,(case 
            --when a.ACTION_ENT in ('SV','SSV','QCSV','LSV') then null
            when a.ACTION_ENT = 'NOVR' then 'Notice of Violation Requested'
            when a.ACTION_ENT = 'NOVC' then 'NOV issued'
            when a.ACTION_ENT = 'NOVB' then 'Combo Issued'
            when a.action_ent = 'ECIT' then 'Citation Issued'
            when a.ACTION_ENT = 'COMP' then 'Compliant'
            when a.ACTION_ENT = 'VIOL' then 'Violation'
            when A.ACTION_ENT in ('CA','CNCL') then 'No Violation'
            when  a.any_comments like '%dead%animal%'	  then 'Extension'
            when  a.any_comments like '%exten%'	  then 'Extension'
            when  a.any_comments like '%violation%'  then 'Violation'
            when  a.any_comments like '%non%compli%' then 'Not Compliant'
            when  a.any_comments like '%send%nov%'   then 'NOV Issued'
            when  a.any_comments like '%req%nov%'    then 'Notice of Violation Requested'
            when  a.any_comments like '%cont%fin%'    then 'Not Compliant' --continue fines
            else null
            end
        ) as inspection_result
        
        ,'xxxx' [2]
        ,a.date_ent
        ,a.the_date
        ,'xxxx'[3]
        ,a.any_comments
        
    into #g
    from jms_apd_insp_filteredToPop a
    outer apply (select top 1 * from #parents where number_key = a.number_key and the_date <= a.the_date and action_ent in ('SV','SSV','QCSV','LSV') order by date_ent desc,the_date desc) b
    left join jms_actionEnt_passFail action_ent on action_ent.action_ent = a.action_ent
    left join #is_initial_site_visit is_initial_site_visit on is_initial_site_visit.UNIQUE_KEY = a.UNIQUE_KEY
    where
        1=1
        --and a.action_ent not in ('SV','SSV','QCSV','LSV')
        --and a.number_key = 
        --	--'CE03003081'
        --	--'CE22014264'
        --	'CE22014971'
    --order by --a.date_ent,a.the_Date,case when a.action_ent in ('SV','SSV','QCSV','LSV') then 1 else 2 end
    --	a.UNIQUE_KEY
;



--), h as (
    select distinct
         a1.NUMBER_KEY
        ,a1.UNIQUE_KEY
        ,a1.action_ent
        --,a1.inspection_type
        ,coalesce(a1.inspection_result,'Not Set') inspection_result
        ,trim('^|' from stuff((
            select 
                '^|^' + cast(
                    trim(replace(replace(replace(replace(   isnull(a2.any_comments,'')   ,'"',''''''),'''',''),char(13),''),char(10),'®')) 
                    as varchar(max)
                )
            from #g a2 with(nolock)
            where 
                a2.unique_key = a1.unique_key
            group by a2.any_comments
            order by a2.any_comments
            FOR XML PATH('')
         ), 1, 1, '')) as any_comments
    into #h
    from #g a1
    where
        1=1
        and a1.ACTION_ENT not in ('SV','SSV','QCSV','LSV','COM','ACOM')
        --and a1.number_key = 'CE17015692'
		--and a1.unique_key = 'A008828260'
    ;
	--select * from #g a1 where 1=1 and a1.unique_key = 'A008828260'
    --order by a.UNIQUE_KEY
--)
;



--actual logic

;if object_id('tempdb.dbo.#includeTruncates','U') is null truncate table aatable_permit_activity
;

;print 'aatable_permit_activity'
;
insert into aatable_permit_activity (
PERMITNUM,ACT_NAME,ACT_DES,ACT_TYPE,ACT_DATE,ACT_DEPT,ACT_STAF,REC_DATE,REC_FUL_NAM,INTERNAL_USE_ONLY,ACT_DUE_DATE,ACT_PRIORITY,ACT_STATUS,act_unique_id
)
select distinct
     pmap.permitnum as PERMITNUM
    ,isnull(i.parent_unique_key + '-','') + a.unique_key as ACT_NAME
    ,left((case 
        when '' = (case when trim(coalesce(h.any_comments,'')) <> '' then h.any_comments else '' end)
        then 'Not Set'
        else (case when trim(coalesce(h.any_comments,'')) <> '' then h.any_comments else '' end)
        end
     ),4000) as ACT_DES --probably change this to `left(action_ent.description,30)`
    ,coalesce(item_no.description,i.item_id,'Not Set') as ACT_TYPE --'Meeting' or 'Phone Call'
    ,coalesce(try_convert(datetime,a.date_ent),'1900-01-01 00:00:00') as ACT_DATE
    ,'Code Enforcement' as ACT_DEPT
    ,coalesce(user_id.user_name,'Not Set') as ACT_STAF
    ,coalesce(try_convert(datetime,a.date_ent),'1900-01-01 00:00:00') as REC_DATE
    ,coalesce(user_id.user_name,a.user_id,'Not Set') as REC_FUL_NAM
    ,'N' as INTERNAL_USE_ONLY
    ,null as ACT_DUE_DATE
    ,null as ACT_PRIORITY
    ,left(action_ent.description,30) as ACT_STATUS --'Not Started','In Process','Completed','Waiting on someone else','Deferred'
    ,row_number() over(order by permitnum) act_unique_id
from jms_apd_insp_filteredToPop a
join jms_numberKey_permitnum pmap on pmap.number_key = a.NUMBER_KEY
join #g i on i.number_key = a.NUMBER_KEY and i.unique_key = a.unique_key
left join hcfl_src.dbo.usr_base user_id on user_id.user_id = a.user_id
left join hcfl_src.dbo.tab_insp item_no on convert(varchar(max),item_no.item_no) = convert(varchar(max),a.item_id)

left join #h h on h.unique_key = i.unique_key
left join jms_actionEnt_passFail action_ent on action_ent.action_ent = h.action_ent

WHERE
    1=1
    and a.action_ent not in ('SV','SSV','QCSV','LSV','COM','ACOM') --SV things are site visits, which are accounted for in aatable_permit_insp.
    and a.record_type not in ('CD') -- these are for guidesheets, I think
	--and a.unique_key = 'A008828260'
;

;update aatable_permit_activity set rec_ful_nam = 'Spriggs, Teddy' where rec_ful_nam = 'Spriggs, Edward ''Teddy'''
;update aatable_permit_activity set ACT_STAF = 'Spriggs, Teddy' where ACT_STAF = 'Spriggs, Edward ''Teddy'''
;