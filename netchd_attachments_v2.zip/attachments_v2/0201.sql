
select 
	a.ATTACHMENT_DEFINITION_ID
	,a.RELATED_ID
	,'Attachments\Original\' +convert(varchar(max),a.oid) as old
	,'AccelaDocuments\' + related_id + '\'+ --'
	(
		'HIST-'+right('0'+convert(varchar(2),ROW_NUMBER() over (partition by [related_id],[filename] order by entered_date)),2)
		+'_'+
		replace(
		replace(
		replace(
		replace(
		replace(
		--replace(
		a.filename
		,':','_')
		,';','_')
		,'?','_')
		,'!','_')
		--,'''','_')
		,'"','_')
	) as new
from #tb_attachment_definition a
where 
	1=1
	--and filename like '%[:;?!''"]%'
	--and RELATED_ID = 'PR0000022'
    and left(related_id,2) not in (
        'PI' --https://redmine.scubeenterprise.com/issues/18429 -- 'Certified Professional Record Type - DO NOT bring over'
        ,'WA' --https://redmine.scubeenterprise.com/issues/18429 -- 'Misc. water records - DO NOT bring over'
    ) 
;