import zipfile
import os
import sys

TARGET_FOLDER = 'AccelaDocuments' #sys.argv[1] #'AccelaDocuments'
OUTPUT_ZIP_FILENAME = 'AccelaDocuments_sample_forNonprod2_20240416.zip' #sys.argv[2] #'AccelaDocuments.zip'
INCLUDE_REMOVE = (sys.argv[3] if len(sys.argv) == 3 else 0)

def main():
    sourceFolder = os.path.join(os.path.dirname(os.path.abspath(__file__)),TARGET_FOLDER)
    zipFilename = os.path.join(os.path.dirname(os.path.abspath(__file__)),OUTPUT_ZIP_FILENAME)
    
    zip_files_and_delete(sourceFolder, zipFilename, INCLUDE_REMOVE)
    
def zip_files_and_delete(sourceFolder, zipFilename,includeRemove=0):
    """ includeRemove is if there is space problems
    """
    ct = 1
    with (zipfile.ZipFile(zipFilename, 'w', zipfile.ZIP_DEFLATED) as zipf
    , open('zip_and_delete_log.txt','w') as logg
    ):
        ## get metadata file
        root = r'C:\Users\Administrator\Desktop\Attachments'
        file = 'metadata_file__NETCHD__filePath_recordId_docGroup_docType_entityType.dat'
        file_path = os.path.join(root, file)
        relative_path = file
        zipf.write(file_path, relative_path)
        
        for root, dirs, files in os.walk(sourceFolder):
            for file in files:
                file_path = os.path.join(root, file)
                logg.write(file_path+'\n')
                if not ct % 500:
                    logg.flush()
                    print(ct,end='\r')
                # Add file to the zip with its relative path
                relative_path = os.sep.join(root.rsplit('\\',2)[-2:]+[file])
                #breakpoint()
                zipf.write(file_path, relative_path) #os.path.relpath(file_path, sourceFolder))
                # Delete the file after it's zipped
                if includeRemove:
                    os.remove(file_path)
                ct += 1
        
        
    print()

if __name__ =='__main__':
    main()
