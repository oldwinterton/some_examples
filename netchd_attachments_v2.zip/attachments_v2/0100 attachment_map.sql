/*
setup
ACTUAL_LOGIC
*/

--setup 
    --I want to update record_id values to be actual record_id's. Some are PT, or other.
select
	distinct
	left(relateD_id,2)
from NETCHD_EnvisionConnect.dba.TB_ATTACHMENT_DEFINITION
order by 1
/*
AR - accounts receivable
CO - complaint
FA - facility
ON - septic
PI - licensed professional
PR - general program
SU - land development
WA - water
DA - daily
PT	--MAPped
SR  --MAPped

OW - owners. Mapped as I could.
TE

*/

select * into #tb_attachment_definition from NETCHD_EnvisionConnect.dba.tb_attachment_definition
update #tb_attachment_definition set filename = [dbo].[ReplaceASCII](filename)
;
    --PT that have some related record_id 
update a set 
    related_id = p.related_id
    ,filename = a.related_id+'__'+a.filename
from #tb_attachment_definition a 
join NETCHD_EnvisionConnect.dba.TB_CORE_PERMIT p on p.RECORD_ID = a.RELATED_ID
where 
	1=1
	and a.RELATED_ID like 'pt%' --877 like pt%. 785 actually match.
;
    --PT that have no related record_id -- I put them to the facility_id
update a set 
    related_id = a.facility_id
    ,filename = a.related_id+'__'+a.filename
from #tb_attachment_definition a 
where 
	1=1
	and a.RELATED_ID like 'pt%' --92 remaining are addressed by this query.
;

    --SR -- only one seems to map to an actual record (ON record); so I put them to AR
update a set 
	filename = a.related_id + '__' + a.filename 
	,related_id = i.ACCOUNT_ID
from #tb_attachment_definition a --83
--join NETCHD_EnvisionConnect.dba.TB_SERVICE_REQUEST sr on sr.record_id = a.RELATED_ID --68 => 15 service requests missing, just not in the system at all
--join NETCHD_EnvisionConnect.dba.TB_SEPTIC_ONSITE_SYSTEM os on os.UDF_SERVICE_REQUEST_NO = sr.RECORD_ID
join NETCHD_EnvisionConnect.dba.TB_FIN_INVOICE_LINE_ITEM li on li.RECORD_IDENTIFIER = a.RELATED_ID --65 => 15 missing
join NETCHD_EnvisionConnect.dba.TB_FIN_INVOICE i on i.invoice_no = li.INVOICE_NO
where
	1=1
	and a.RELATED_ID like 'SR%' --115
;
    --SR part 2. The remaining sr's after this, I dont know how to map em.
update a set 
	filename = i.account_id + '__' + a.filename 
	,related_id = i.ACCOUNT_ID	
from #tb_attachment_definition a --83
--join NETCHD_EnvisionConnect.dba.TB_SERVICE_REQUEST sr on sr.record_id = a.RELATED_ID --68 => 15 service requests missing, just not in the system at all
--join NETCHD_EnvisionConnect.dba.TB_SEPTIC_ONSITE_SYSTEM os on os.UDF_SERVICE_REQUEST_NO = sr.RECORD_ID
join NETCHD_EnvisionConnect.dba.tb_fin_audit_invoice_line_item li on li.RECORD_IDENTIFIER = a.RELATED_ID --65 => 15 missing
join NETCHD_EnvisionConnect.dba.tb_fin_invoice i on i.invoice_no = li.INVOICE_NO
where
	1=1
	and a.RELATED_ID like 'SR%' --
;
    --DA daily records. 6 of em.
update a set 
	filename = a.related_id + '__'+ a.filename
	,related_id = d.RECORD_ID
from #tb_attachment_definition a --6
join NETCHD_EnvisionConnect.dba.tb_core_daily d on d.SERIAL_NUMBER = a.related_id
where
	1=1
	and related_id like 'da%'
;
    --OW owners with singular map to facility. 
    --6 remain unmapped; the owner value appears to exist nowhere but tb_core_owner.
;with g as (
select 
	o.OWNER_ID
	,o.name
	,fac.FACILITY_ID
from #tb_attachment_definition a --24
join NETCHD_EnvisionConnect.dba.tb_core_owner o on o.owner_id = a.related_id --24
--join NETCHD_EnvisionConnect.dba.tb_fin_accounts_receivable ar on ar.owner_id = o.owner_id
outer apply (select top 1 * from NETCHD_EnvisionConnect.dba.TB_CORE_FACILITY fac where fac.FACILITY_OWNER_ID = a.related_id) fac
where
	1=1
	and related_id like 'ow%'
	and fac.facility_name not like '%temp%'
), singles as (
select
	owner_id,count(*) ct
from g
group by owner_id 
having count(owner_id) = 1
)
update a set
	related_id = g.facility_id
	,filename = a.related_id + '__' + a.filename
from #tb_attachment_definition a
join g on g.OWNER_ID = a.related_id
--join singles f on f.OWNER_ID = g.OWNER_ID
;

    --TE TEMPORARY events
update a set 
	related_id = te.facility_id
	,filename = a.related_id + '__' + a.filename 
from #tb_attachment_definition a 
join NETCHD_EnvisionConnect.dba.TB_TEMPORARY_EVENT te on te.TEMPORARY_EVENT_ID = a.related_id 
;


--setup 
    --I want to update record_id values to be actual record_id's. Some are PT, or other.
select
	distinct
	left(relateD_id,2)
from #tb_attachment_definition
order by 1









-------------------------
--ACTUAL_LOGIC
-------------------------
select count(*) from #oids --69853

select 
	count(*) 
from #tb_attachment_definition a --69740
join #oids b on b.oid = a.OID --69689

select oid from #oids except select oid from #tb_attachment_definition
;

select 
	'HIS-'+a.related_id permitnum
	,'Attachments\Original\' + convert(varchar(max),a.oid) src --'
	,a.filename
	,isnull(a.description,'') description
	,a.entered_date
	,a.entered_by
	,a.oid
from #tb_attachment_definition a
join #oids b on b.oid = a.OID
order by permitnum,entered_date
;
