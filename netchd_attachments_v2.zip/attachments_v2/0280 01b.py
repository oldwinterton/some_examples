import shutil
import os
from zip_and_delete import zip_files_and_delete
DEBUG_INITIALRUN = 0
ONLY_USE_SAMPLE = 1

TARGET_FOLDER = 'AccelaDocuments'
OUTPUT_ZIP_FILENAME = 'test_AccelaDocuments_sample_forNonprod2_20240416.zip'

IN = '0260 attachmentId_relatedId_oldPath_newPath.tsv'
_OUT = 'metadata_file__NETCHD__filePath_recordId_docGroup_docType_entityType.dat'

def main():
    fc = get_population(IN)
    
    totalCount = len(fc)
    with open(_OUT,'w') as OUT, open('missing.txt','w') as missing:
        OUT.write('filePath_recordId_docGroup_docType_entityType\n'.replace('_','\t')) ## the accela process sees the first row is a header row, and disregards this row. (Ensure no data goes here!)
        for debugIdx,row in enumerate(fc):
            if not debugIdx % 300:
                print(debugIdx,'of',totalCount,sep=' ',end='\r')
                OUT.flush()
                missing.flush()
            #breakpoint()
            try:
                attachmentId,recordId,oldPath,newPath = row
                if not os.path.exists(oldPath):
                    missing.write('\t'.join(row)+'\n')
                    continue
                if DEBUG_INITIALRUN: 
                    print(row)
                os.makedirs(os.path.dirname(newPath), exist_ok=True)
                shutil.copy2(oldPath,newPath)
                _toWrite = [
                    newPath #file path - relative file path
                    ,'HIS-'+recordId #application number/parcel number
                    ,'Historical' #document group
                    ,'Document Migration' #document type
                    ,'CAP' #entity type 
                ]
                toWrite = '\t'.join(_toWrite) + '\n'
                OUT.write(toWrite)
            except:
                print(row)
                raise
        print(debugIdx+1,'of',totalCount,sep=' ',end='\r')
        print()
    
    verify()
    
    print('zipping')
    sourceFolder = os.path.join(os.path.dirname(os.path.abspath(__file__)),TARGET_FOLDER)
    zipFilename = os.path.join(os.path.dirname(os.path.abspath(__file__)),OUTPUT_ZIP_FILENAME)
    zip_files_and_delete(sourceFolder,zipFilename)
    
def get_population(inputFilename):
    with open(inputFilename) as f:
        fc = [i.split('\t') for i in f.read().strip().replace('\r','').split('\n')]
    headers = fc.pop(0)
    #if ONLY_USE_SAMPLE:
    #    #sampleSize = len(fc) // 10 ## accela say they will only use sample of documents in nonprod2. 10% they said.
    #    #print(sampleSize)
    #    #someConstant = 1
    #    #fc = fc[:sampleSize]
    #    fc = fc[:284]
    #
    #assert set(len(i) for i in fc) == {4}
    #if DEBUG_INITIALRUN: fc = fc[0:2]  
    fc = [i for i in fc if i[1] == 'ON0022537' or i[1] == 'PR0014478']
    
    return fc 
    
#def ensure_size(population,sizeInGb=20):
#    return 
#    toReturn = []
#    curSize = 0
#    batch = []
#    for idx,row in enumerate(row):
#        attachmentId,recordId,oldPath,newPath = row
#        curSize += os.path.getsize(oldPath) // 
#        if curSize >= 20
#        batch += row 
#        
#        

    
def verify():
    ## verify
    print('verifying all files exist.')
    with open('metadata_file__NETCHD__filePath_recordId_docGroup_docType_entityType.dat') as f:
        fc = [i.split('\t') for i in f.read().strip().replace('\r','').split('\n')]
    for idx,row in enumerate(fc):
        print(idx,end='\r')
        _filepath = row[0]
        filepath = os.path.join(
            os.path.dirname(os.path.abspath(__file__))
            ,_filepath
        )
        if not os.path.exists(filepath):
            print(filepath)

if __name__ == '__main__':
    main()
    